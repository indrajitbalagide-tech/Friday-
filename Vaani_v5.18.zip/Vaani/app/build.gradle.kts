plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.vaani.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.vaani.app"; minSdk = 26; targetSdk = 34; versionCode = 33; versionName = "5.18" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }

    // v5.9 — RELEASE SIGNING (ek hi key, har jagah):
    // Debug APK har machine/runner apni alag debug key se sign karta hai — isiliye naya APK
    // install karne ke liye purana version DELETE karna padta tha (signature mismatch).
    // Ek baar ka setup: ek release keystore banao (README "Release signing" dekho), uska
    // path + passwords gradle.properties ya environment mein daalo:
    //   VAANI_STORE_FILE=/path/vaani-release.keystore
    //   VAANI_STORE_PASSWORD=...
    //   VAANI_KEY_ALIAS=vaani
    //   VAANI_KEY_PASSWORD=...
    // Ye values NA hon to release build bina signing ke banta hai (debug par koi asar nahi).
    // GitHub Actions mein yahi values secrets se aati hain (.github/workflows/build.yml).
    val storeProp = (project.findProperty("VAANI_STORE_FILE") as? String)
        ?: System.getenv("VAANI_STORE_FILE")
    val storeFile = storeProp?.let { file(it) }?.takeIf { it.exists() }
    signingConfigs {
        if (storeFile != null) {
            create("release") {
                this.storeFile = storeFile
                storePassword = (project.findProperty("VAANI_STORE_PASSWORD") as? String)
                    ?: System.getenv("VAANI_STORE_PASSWORD")
                keyAlias = (project.findProperty("VAANI_KEY_ALIAS") as? String)
                    ?: System.getenv("VAANI_KEY_ALIAS") ?: "vaani"
                keyPassword = (project.findProperty("VAANI_KEY_PASSWORD") as? String)
                    ?: System.getenv("VAANI_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            if (storeFile != null) signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }
}
dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("ai.picovoice:porcupine-android:3.0.2")   // wake word ("Vaani" custom .ppn)
}
