package com.vaani.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini REST + function calling. Model name is configurable. */
object Gemini {
    const val MODEL = "gemini-2.5-flash"

    private fun fn(name: String, desc: String, props: String = "", req: String = "") =
        """{"name":"$name","description":"$desc","parameters":{"type":"OBJECT","properties":{$props}${if (req.isNotEmpty()) ""","required":[$req]""" else ""}}}"""
    private fun s(n: String, d: String) = """"$n":{"type":"STRING","description":"$d"}"""
    private fun i(n: String, d: String) = """"$n":{"type":"INTEGER","description":"$d"}"""

    val tools = "[{\"functionDeclarations\":[" + listOf(
        fn("call", "Phone call a contact or number", s("who", "contact name or number"), "\"who\""),
        fn("whatsapp", "Send a WhatsApp message", s("who", "contact name or number") + "," + s("message", "text"), "\"who\",\"message\""),
        fn("open_app", "Open an installed app", s("app", "app name"), "\"app\""),
        fn("play_youtube", "Search/play something on YouTube", s("query", "song or video"), "\"query\""),
        fn("flashlight", "Turn flashlight on/off", """"on":{"type":"BOOLEAN"}""", "\"on\""),
        fn("media", "Control media playback", s("action", "play|pause|toggle|next|previous"), "\"action\""),
        fn("settings", "Open a settings screen", s("target", "wifi|bluetooth|location|hotspot"), "\"target\""),
        fn("timer", "Set a countdown timer", i("seconds", "duration") + "," + s("label", "label"), "\"seconds\""),
        fn("calendar_event", "Add calendar event", s("title", "title") + "," + i("hours_from_now", "start offset hours"), "\"title\""),
        fn("call_control", "Answer, reject or announce the incoming phone call", s("action", "answer|reject|announce"), "\"action\""),
        fn("notifications", "Read latest WhatsApp/Instagram/Telegram/SMS notifications, or turn auto-reply on/off", s("action", "read_latest|enable_auto_reply|disable_auto_reply"), "\"action\""),
        fn("system_control", "Volume, brightness, silent/vibrate, Do Not Disturb, auto-rotate, battery status", s("action", "volume_set|volume_up|volume_down|mute|unmute|brightness_set|dnd_on|dnd_off|ringer_silent|ringer_vibrate|ringer_normal|autorotate_on|autorotate_off|battery") + "," + i("value", "0-100 for volume_set / brightness_set"), "\"action\""),
        fn("screen_control", "Control the screen: system buttons, scroll, swipe, tap an on-screen text, type into focused field, read screen", s("action", "back|home|recents|notifications|quick_settings|power_menu|lock_screen|screenshot|scroll_up|scroll_down|swipe_up|swipe_down|swipe_left|swipe_right|tap_text|type_text|read_screen") + "," + s("text", "text to tap or type"), "\"action\""),
        fn("navigate", "Start Google Maps navigation", s("place", "destination"), "\"place\""),
        fn("web_search", "Google search", s("query", "query"), "\"query\""),
        fn("open_url", "Open an http/https link", s("url", "link"), "\"url\""),
        fn("sms", "Open SMS compose with text", s("who", "contact or number") + "," + s("message", "text"), "\"who\",\"message\""),
        fn("email", "Open email compose", s("to", "address") + "," + s("subject", "subject") + "," + s("body", "body"), "\"to\""),
        fn("share_text", "Open the share sheet with text", s("text", "text"), "\"text\""),
        fn("alarm", "Set an alarm at a clock time", i("hour", "0-23") + "," + i("minute", "0-59") + "," + s("label", "label"), "\"hour\",\"minute\""),
        fn("camera", "Open the camera app", s("mode", "photo|video")),
        fn("routine", "Save, run, list or delete a named routine (a sequence of tool calls)", s("action", "save|run|list|delete") + "," + s("name", "routine name") + "," + s("steps", "for save: JSON array like [{\"name\":\"system_control\",\"args\":{\"action\":\"dnd_on\"}}]"), "\"action\"")
    ).joinToString(",") + "]}]"

    private const val SYSTEM = "You are Vaani, a phone assistant. Understand Hindi, Marathi, English and Hinglish and reply in the language " +
        "the user used (default Hinglish). Use tools for device actions. Otherwise answer in one or two short sentences."

    /** Returns parts of the first candidate (text or functionCall objects). Call off the main thread. */
    fun ask(key: String, userText: String, useTools: Boolean = true): JSONArray {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userText)))))

        if (useTools) body.put("tools", JSONArray(tools))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val txt = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode !in 200..299) throw RuntimeException("API ${c.responseCode}: ${txt.take(160)}")
        return JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
    }
}
