package com.vaani.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.method.ScrollingMovementMethod
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONObject
import java.util.Locale

/** Hands-free by default: opens -> starts listening on its own. Conversation shows in the small box. */
class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var keyBox: EditText
    private lateinit var toggle: Button
    private var lastHint = ""
    private val prefs by lazy { getSharedPreferences("vaani", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this, this)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
            Manifest.permission.ANSWER_PHONE_CALLS, "android.permission.POST_NOTIFICATIONS"), 1)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(40), dp(16), dp(16)) }
        status = TextView(this).apply { textSize = 18f; setPadding(0, 0, 0, dp(8)) }
        log = TextView(this).apply {
            textSize = 15f; setTextColor(Color.parseColor("#1F1A17")); setPadding(dp(12), dp(10), dp(12), dp(10))
            movementMethod = ScrollingMovementMethod(); isVerticalScrollBarEnabled = true
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.parseColor("#F4F1EC")); setStroke(dp(1), Color.parseColor("#D8CFC4")) }
        }
        keyBox = EditText(this).apply { hint = "Gemini API key (daalke Enter dabao)"; setText(prefs.getString("key", "")); setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_DONE
            setOnEditorActionListener { _, _, _ -> prefs.edit().putBoolean("manual_stop", false).apply(); autoStart(); true } }
        val typed = EditText(this).apply { hint = "Type bhi kar sakte ho"; setSingleLine()
            setOnEditorActionListener { v, _, _ -> handle(v.text.toString()); v.text = ""; true } }
        toggle = Button(this).apply { setOnClickListener { toggleMode() } }
        root.addView(status); root.addView(log, LinearLayout.LayoutParams(-1, dp(240)))
        root.addView(typed); root.addView(keyBox)
        root.addView(toggle)
        root.addView(btn("🧬 Meri awaaz record karo (12 sec)") { enroll() })
        root.addView(btn("🪟 Floating orb permission") { overlayPerm() })
        root.addView(btn("🔋 Battery: Unrestricted") { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) })
        root.addView(btn("♿ Accessibility ON karo (tap/scroll/type ke liye)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        setContentView(root)
        VaaniService.log = { t -> say(t) }
        say("🤖 Namaste! Main Vaani hu. Hindi, मराठी, English ya Hinglish, jo bhi bolo.")
    }

    override fun onResume() { super.onResume(); autoStart() }
    override fun onPause() { prefs.edit().putString("key", keyBox.text.toString().trim()).apply(); super.onPause() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { autoStart() }
    override fun onInit(s: Int) { if (s == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN") }

    private fun say(t: String, speak: Boolean = false) {
        runOnUiThread {
            log.append(t + "\n\n")
            if (log.text.length > 6000) log.text = log.text.takeLast(4000)   // keep memory flat over 24h
            log.layout?.let { l -> log.scrollTo(0, maxOf(0, l.getLineTop(log.lineCount) - log.height + log.paddingTop + log.paddingBottom)) }
        }
        if (speak) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "v")
    }

    private fun hint(t: String) { if (t != lastHint) { lastHint = t; say(t) } }

    private fun refresh() { runOnUiThread {
        status.text = if (VaaniService.running) "🟢 Hands-free ON, bas bolo" else "⚪ Hands-free band"
        toggle.text = if (VaaniService.running) "⏹ Hands-free band karo" else "▶ Hands-free chalu karo"
    } }

    /** Starts the always-on service by itself whenever setup is complete. */
    private fun autoStart() {
        prefs.edit().putString("key", keyBox.text.toString().trim()).apply()
        refresh()
        if (VaaniService.running || prefs.getBoolean("manual_stop", false)) return
        when {
            prefs.getString("key", "").isNullOrEmpty() -> hint("👋 Pehle Gemini API key daalo.")
            !VoicePrint(this).enrolled() -> hint("🧬 Ab 'Meri awaaz record karo' dabao. Uske baad Vaani apne aap hands-free chalega.")
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED -> hint("🎙 Mic permission allow karo.")
            else -> { startForegroundService(Intent(this, VaaniService::class.java)); window.decorView.postDelayed({ refresh() }, 700) }
        }
    }

    private fun toggleMode() {
        if (VaaniService.running) { prefs.edit().putBoolean("manual_stop", true).apply()
            startService(Intent(this, VaaniService::class.java).setAction("STOP")); window.decorView.postDelayed({ refresh() }, 700) }
        else { prefs.edit().putBoolean("manual_stop", false).apply(); autoStart() }
    }

    private fun enroll() {
        val wasOn = VaaniService.running
        if (wasOn) startService(Intent(this, VaaniService::class.java).setAction("STOP"))
        window.decorView.postDelayed({
            say("🧬 12 second normal awaaz mein kuch bhi bolte raho…")
            VoicePrint.enroll(this) { m -> say(m); runOnUiThread { prefs.edit().putBoolean("manual_stop", false).apply(); autoStart() } }
        }, if (wasOn) 900 else 0)
    }

    private fun overlayPerm() {
        if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        else say("🪟 Overlay permission pehle se hai.")
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    /** Typed fallback (REST). Spoken conversation goes through the service + Gemini Live. */
    private fun handle(text: String) {
        if (text.isBlank()) return
        val key = prefs.getString("key", "").orEmpty()
        if (key.isEmpty()) return say("Pehle Gemini API key daalo.")
        say("🧑 $text")
        Thread {
            try {
                val parts = Gemini.ask(key, text)
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("functionCall")) {
                        val f = p.getJSONObject("functionCall")
                        say("🤖 " + Actions.run(this, f.getString("name"), f.optJSONObject("args") ?: JSONObject()), true)
                    } else if (p.has("text")) say("🤖 " + p.getString("text"), true)
                }
            } catch (e: Exception) { say("⚠ ${e.message?.take(100)}") }
        }.start()
    }

    override fun onDestroy() { VaaniService.log = null; tts.shutdown(); super.onDestroy() }
}
