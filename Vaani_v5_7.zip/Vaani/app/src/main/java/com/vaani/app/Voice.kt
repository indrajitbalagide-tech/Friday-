package com.vaani.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingDeque

/*
 * v5.4 - POORE APP MEIN SIRF GEMINI KI AWAAZ.
 * Phone ki android.speech.tts (robotic) ab kahin use nahi hoti - na notifications mein, na fallback mein.
 * Gemini ki awaaz na mile (key/internet/API error) to robotic bolne ke bajaye wajah chat box mein likhi jaati hai.
 *
 * WIRING (Gemini.kt / Extras.kt - pehle jaisa hi, koi badlav nahi):
 * Gemini.kt - tools lazy block mein, `for (d in Extras.decls()) fd.put(d)` ke baad:
 *     for (i in 0 until VoiceTools.decls().length()) fd.put(VoiceTools.decls().getJSONObject(i))
 * Extras.kt - run() ke when() mein:
 *     "voice_lang", "voice_tone" -> VoiceTools.dispatch(c, name, a) ?: "Ye voice action nahi aata."
 */

/**
 * Gemini ki natural TTS voice (Aoede) REST se. Ye Live conversation wali awaaz (LiveClient mein bhi Aoede) jaisi hi hai.
 * - Disk cache: ek baar bani awaaz dobara network ke bina turant bajti hai (offline mein bhi).
 * - Model fail-over: model hi na mile (404) to agla; network jhatke par ek retry; kul samay-seema hai.
 */
object GeminiVoice {
    private val MODELS = listOf("gemini-3.8-flash-lite-tts", "gemini-3.8-flash-tts",
        "gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
    @Volatile private var preferred: String? = null
    @Volatile var lastError: String? = null
    private val missing = ConcurrentHashMap<String, Long>()   // jo model nahi mila, 30 min skip
    private const val MISSING_MS = 30 * 60_000L
    const val VOICE = "Aoede"

    private class ModelMissing(msg: String) : RuntimeException(msg)

    private fun cacheFile(ctx: Context, text: String, style: String): File {
        val dir = File(ctx.cacheDir, "tts").also { it.mkdirs() }
        val h = MessageDigest.getInstance("SHA-1").digest("$VOICE|$style|$text".toByteArray())
            .joinToString("") { "%02x".format(it) }
        return File(dir, "$h.pcm")
    }

    private fun saveCache(f: File, pcm: ByteArray) {
        try {
            if (pcm.size > 1_500_000) return
            f.writeBytes(pcm)
            val all = f.parentFile?.listFiles()?.sortedBy { it.lastModified() } ?: return
            if (all.size > 80) all.take(all.size - 60).forEach { it.delete() }
        } catch (_: Exception) {}
    }

    /** Blocking - background thread se bulao. PCM (24kHz mono 16-bit) ya null. */
    fun synth(ctx: Context, key: String, text: String, style: String? = null,
              cacheOnly: Boolean = false, budgetMs: Long = 14000): ByteArray? {
        val cf = cacheFile(ctx, text, style ?: "")
        try { if (cf.exists() && cf.length() > 0) { cf.setLastModified(System.currentTimeMillis()); return cf.readBytes() } } catch (_: Exception) {}
        if (cacheOnly) { lastError = "internet nahi hai"; return null }
        val start = System.currentTimeMillis(); val deadline = start + budgetMs
        val usable = MODELS.filter { start - (missing[it] ?: 0L) > MISSING_MS }.ifEmpty { MODELS }
        val order = listOfNotNull(preferred?.takeIf { it in usable }) + usable.filter { it != preferred }
        val prompt = if (style.isNullOrEmpty()) text else "$style: $text"
        var err: String? = null
        for (model in order) {
            var tries = 0
            while (tries < 2 && System.currentTimeMillis() < deadline) {
                tries++
                try {
                    val pcm = request(model, key, prompt)
                    preferred = model; lastError = null
                    saveCache(cf, pcm)
                    return pcm
                } catch (e: ModelMissing) {
                    missing[model] = System.currentTimeMillis(); err = "$model: ${e.message}".take(150); break
                } catch (e: Exception) {
                    err = "$model: ${e.message}".take(150)
                    if (tries < 2) Thread.sleep(500)
                }
            }
        }
        lastError = err ?: "samay khatam"
        return null
    }

    private fun request(model: String, key: String, text: String): ByteArray {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", VOICE)))))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 6000; c.readTimeout = 12000
            c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code !in 200..299) {
                val eb = try { c.errorStream?.bufferedReader()?.readText() ?: "" } catch (_: Exception) { "" }
                val low = eb.lowercase()
                val modelProblem = code == 404 || (code == 400 && ("not found" in low || "not supported" in low) && "api key" !in low)
                if (modelProblem) throw ModelMissing("API $code: ${eb.take(110)}")
                throw RuntimeException("API $code: ${eb.take(110)}")
            }
            val txt = c.inputStream.bufferedReader().readText()
            val parts = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            for (i in 0 until parts.length()) {
                val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
                if (d.isNotEmpty()) return stripWav(Base64.decode(d, Base64.DEFAULT))
            }
            throw RuntimeException("response mein audio nahi aaya")
        } finally { c.disconnect() }
    }

    /** Kuch models WAV (RIFF header ke saath) bhejte hain, kuch kaccha PCM - dono ko saaf PCM bana do. */
    private fun stripWav(b: ByteArray): ByteArray {
        if (b.size < 44 || !(b[0] == 'R'.code.toByte() && b[1] == 'I'.code.toByte())) return b
        var i = 12
        while (i + 8 <= b.size) {
            val id = String(b, i, 4)
            val sz = (b[i + 4].toInt() and 0xFF) or ((b[i + 5].toInt() and 0xFF) shl 8) or
                ((b[i + 6].toInt() and 0xFF) shl 16) or ((b[i + 7].toInt() and 0xFF) shl 24)
            if (id == "data") return b.copyOfRange(i + 8, minOf(b.size, i + 8 + sz))
            i += 8 + sz + (sz and 1)
        }
        return b
    }

    @Volatile private var cur: AudioTrack? = null

    /** Chal rahi awaaz turant rok do (naya Live session / barge-in). */
    fun stopPlayback() { val t = cur; cur = null; try { t?.pause(); t?.flush(); t?.stop() } catch (_: Exception) {} }

    /** Blocking: awaaz bajne tak ruko. */
    fun play(pcm: ByteArray) {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, pcm.size))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        cur = track
        track.setVolume(1f)
        track.play()
        track.write(pcm, 0, pcm.size)
        val end = System.currentTimeMillis() + pcm.size / 2 * 1000L / 24000 + 250
        while (cur === track && System.currentTimeMillis() < end) Thread.sleep(30)
        try { track.stop() } catch (_: Exception) {}
        track.release()
        if (cur === track) cur = null
    }
}

/**
 * Poore app ka ek hi speaker - SIRF Gemini ki awaaz. Ek queue, ek worker thread:
 * - speak(): normal (reply, reminder, briefing...)
 * - speakNow(): zaroori (notification, call) - queue mein sabse aage, purani (45 sec+) ho jaye to chhod do
 * - Gemini ki awaaz na mile to robotic NAHI bolta; wajah chat box mein likhta hai.
 */
object Speaker {
    // ---- bhasha (Gemini text ki bhasha dekhkar khud bolta hai; ye pref Gemini ko jawab ki bhasha batane ke liye) ----
    val LANGS = mapOf(
        "hi-IN" to Locale("hi", "IN"),
        "mr-IN" to Locale("mr", "IN"),
        "en-IN" to Locale("en", "IN")
    )
    private val LANG_NAMES = mapOf("hi-IN" to "Hindi (Hinglish)", "mr-IN" to "Marathi", "en-IN" to "English (India)")

    fun voiceLang(c: Context): String =
        P.of(c).getString("voice_lang", "hi-IN") ?: "hi-IN"

    fun setVoiceLang(ctx: Context, lang: String): String {
        val code = when (lang.trim().lowercase()) {
            "hindi", "hinglish", "hi", "hi-in" -> "hi-IN"
            "marathi", "mr", "mr-in" -> "mr-IN"
            "english", "en", "en-in" -> "en-IN"
            else -> null
        } ?: return "Ye bhasha abhi nahi aati — Hindi (Hinglish), Marathi ya English (India) chuno."
        P.of(ctx).edit().putString("voice_lang", code).apply()
        return "Bhasha badal di: ${LANG_NAMES[code]}. Ab se isi bhasha mein bolungi (awaaz wahi Gemini wali rahegi)."
    }

    /** Raat 22:00-06:00 - awaaz apne aap dheemi/narm. */
    fun isNight(): Boolean {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return h >= 22 || h < 6
    }

    // ---- queue ----
    private class Item(val app: Context, val text: String, val style: String?, val at: Long, val urgent: Boolean)
    private val q = LinkedBlockingDeque<Item>()
    @Volatile private var worker: Thread? = null
    @Volatile private var lastFailLog = 0L

    private fun ensureWorker() {
        synchronized(q) {
            if (worker?.isAlive == true) return
            worker = Thread { loop() }.also { it.isDaemon = true; it.name = "vaani-voice"; it.start() }
        }
    }

    private fun loop() {
        while (true) {
            val item = try { q.takeFirst() } catch (_: InterruptedException) { return }
            if (System.currentTimeMillis() - item.at > (if (item.urgent) 45_000L else 90_000L)) continue   // baasi khabar mat bolo
            try { say(item) } catch (e: Exception) { AgentStatus.voice = "Awaaz error: ${e.message?.take(60)}" }
        }
    }

    private fun say(item: Item) {
        val app = item.app
        val key = P.of(app).getString("key", "").orEmpty()
        if (key.isEmpty()) {
            failLog("🔑 API key nahi mili — Gemini ki awaaz nahi bol sakti. Setup (🔑) mein key dobara daalo.")
            AgentStatus.voice = "API key nahi • ${AgentStatus.time()}"; return
        }
        AgentStatus.voice = "Bol rahi hai…"; AgentStatus.voiceAt = System.currentTimeMillis()
        val pcm = GeminiVoice.synth(app, key, item.text, item.style, cacheOnly = !Net.online(app))
        if (pcm == null) {
            failLog("🔊 Gemini ki awaaz nahi mili" + (GeminiVoice.lastError?.let { " — $it" } ?: "") +
                " | Text chat mein hai. (Phone ki robotic awaaz band hai.)")
            AgentStatus.voice = "Awaaz nahi mili • ${AgentStatus.time()}"; return
        }
        GeminiVoice.play(pcm)
        AgentStatus.voice = "Bola • ${AgentStatus.time()}"
    }

    private fun failLog(m: String) {
        val now = System.currentTimeMillis()
        if (now - lastFailLog < 30_000) return   // chat box spam na ho
        lastFailLog = now; VaaniService.log?.invoke(m)
    }

    /** Lambe text ko sentence par todo - pehla tukda jaldi bajne lage. */
    private fun chunks(text: String): List<String> {
        val t = text.trim(); if (t.isEmpty()) return emptyList()
        if (t.length <= 380) return listOf(t)
        val out = ArrayList<String>(); var cur = StringBuilder()
        for (s in t.split(Regex("(?<=[.!?।\\n])\\s+"))) {
            if (cur.isNotEmpty() && cur.length + s.length > 380) { out.add(cur.toString().trim()); cur = StringBuilder() }
            cur.append(s).append(' ')
        }
        if (cur.isNotBlank()) out.add(cur.toString().trim())
        return out
    }

    private fun enqueue(ctx: Context, text: String, style: String?, urgent: Boolean) {
        val app = ctx.applicationContext; val now = System.currentTimeMillis()
        val parts = chunks(text); if (parts.isEmpty()) return
        if (urgent) for (p in parts.asReversed()) q.addFirst(Item(app, p, style, now, true))
        else for (p in parts) q.addLast(Item(app, p, style, now, false))
        ensureWorker()
    }

    // ---- public API (purane callers jaisa hi) ----

    fun speak(ctx: Context, text: String) = enqueue(ctx, text, null, false)

    /** Notifications / calls: sabse aage, turant. */
    fun speakNow(ctx: Context, text: String) = enqueue(ctx, text, null, true)

    /** Pehle "offline" ke liye alag thi - ab bhi Gemini ki hi awaaz (cache mein ho to bina internet ke bhi). */
    fun speakLocal(ctx: Context, text: String) = enqueue(ctx, text, null, false)

    /** Mood ke hisaab se Gemini ko style batao: jaldi = tez, raat = dheemi/narm, normal, auto (raat mein narm). */
    fun speakTone(ctx: Context, text: String, mood: String = "auto") {
        val m = mood.trim().lowercase()
        val soft = "Say this slowly in a soft, calm, quiet voice"
        val style = when (m) {
            "jaldi", "fast", "tez" -> "Say this quickly and energetically"
            "raat", "slow", "dheemi", "soft" -> soft
            "normal" -> null
            else -> if (isNight()) soft else null
        }
        enqueue(ctx, text, style, false)
    }

    fun speak(ctx: Context, text: String, mood: String) = speakTone(ctx, text, mood)

    /** Chal rahi aur line mein lagi saari awaaz rok do (naya Live session shuru hone par). */
    fun stop() { q.clear(); GeminiVoice.stopPlayback() }

    /** Online hote hi kuch zaroori jumle cache kar lo - taaki offline mode mein bhi Gemini ki awaaz mile. */
    fun warmCache(ctx: Context) {
        val app = ctx.applicationContext
        Thread {
            val key = P.of(app).getString("key", "").orEmpty()
            if (key.isEmpty() || !Net.online(app)) return@Thread
            for (s in listOf("Offline hoon, boliye.", "Offline suna nahi ja sakta.",
                "Ye offline mein nahi samajh paayi. Internet aane par poochna.", "Namaste! Main Vaani hu. Kahiye, kya karun?"))
                try { GeminiVoice.synth(app, key, s) } catch (_: Exception) {}
        }.start()
    }
}

/** Gemini tools: voice_lang / voice_tone. */
object VoiceTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject>, req: List<String> = emptyList()): JSONObject {
        val p = JSONObject(); for ((k, v) in props) p.put(k, v)
        val params = JSONObject().put("type", "OBJECT").put("properties", p)
        if (req.isNotEmpty()) params.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("parameters", params)
    }

    fun decls(): JSONArray = JSONArray().put(fn("voice_lang",
        "Vaani ki bolne ki bhasha badlo: Hindi (Hinglish, default), Marathi, ya English (India).",
        mapOf("lang" to sp("hindi|hinglish|marathi|english ya hi-IN|mr-IN|en-IN")), listOf("lang")))
        .put(fn("voice_tone",
            "Kisi text ko khaas mood mein bolo: jaldi (tez), raat (dheemi/narm), normal, auto (raat mein apne aap dheemi).",
            mapOf("text" to sp("bolne wala text"), "mood" to sp("jaldi|raat|normal|auto")), listOf("text")))

    /** Unknown naam par null (taaki Actions/Extras aage fall-through kar sake). */
    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "voice_lang" -> Speaker.setVoiceLang(c, a.optString("lang"))
        "voice_tone" -> {
            Speaker.speakTone(c, a.optString("text"), a.optString("mood", "auto"))
            "Bol raha hu (${a.optString("mood", "auto")} tone mein)."
        }
        else -> null
    }
}
