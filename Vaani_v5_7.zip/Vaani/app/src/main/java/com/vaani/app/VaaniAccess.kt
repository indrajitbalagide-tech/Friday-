package com.vaani.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.view.Display
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Screen automation: tap by text, type, scroll, swipe, global buttons (back/home/recents/...). User must enable it in Android settings. */
class VaaniAccess : AccessibilityService() {
    companion object { @Volatile var inst: VaaniAccess? = null }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }

    /**
     * Screen-delta hook (Group B ka live watcher is par listener lagata hai).
     * Koi listener nahi hai to onAccessibilityEvent kuch nahi karta - bilkul sasta hai.
     * Yahan kabhi bolna / log nahi karna: listener khud decide karta hai.
     */
    var onScreenDelta: ((String) -> Unit)? = null
    private val deltaHandler = Handler(Looper.getMainLooper())
    private val deltaRunnable = Runnable {
        try { onScreenDelta?.invoke(screenText(2000)) } catch (_: Exception) {}
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || onScreenDelta == null) return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                // 1000ms debounce: lagatar events par sirf aakhri ke baad ek baar bulao.
                deltaHandler.removeCallbacks(deltaRunnable)
                deltaHandler.postDelayed(deltaRunnable, 1000)
            }
        }
    }
    override fun onInterrupt() {}

    // ---- ScreenModel helpers (Group A, v5.1) ----

    /** Poora screen model: windows + elements (0..1000 coordinates). */
    fun model(): Snapshot? = ScreenModel.snapshot(this)

    /** UiEl ke centre (0..1000) ko wapas pixels mein badal kar tap karo. */
    fun tapEl(el: UiEl): Boolean {
        val dm = resources.displayMetrics
        val px = el.x / 1000f * dm.widthPixels
        val py = el.y / 1000f * dm.heightPixels
        return tapXY(px, py)
    }

    /** nth (1-based) element is role ka tap karo, nahi mila to false. */
    fun tapRole(role: String, nth: Int = 1): Boolean {
        val snap = model() ?: return false
        val el = ScreenModel.findByRole(snap, role, nth) ?: return false
        return tapEl(el)
    }

    /** Foreground app ka package: pehle active root, phir focused window. */
    fun foregroundPackage(): String? {
        try { rootInActiveWindow?.packageName?.toString()?.let { if (it.isNotBlank()) return it } } catch (_: Exception) {}
        try {
            for (w in windows) {
                if (w.isFocused || w.isActive) {
                    try { w.root?.packageName?.toString()?.let { if (it.isNotBlank()) return it } } catch (_: Exception) {}
                }
            }
            windows.firstOrNull()?.let {
                try { it.root?.packageName?.toString()?.let { p -> if (p.isNotBlank()) return p } } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        return null
    }

    /** Saari windows ki jaankari (app / overlay / dialog / keyboard / system). */
    fun windowsInfo(): List<WinInfo> = ScreenModel.windowsInfo(this)

    private fun find(n: AccessibilityNodeInfo?, ok: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (ok(n)) return n
        for (i in 0 until n.childCount) find(n.getChild(i), ok)?.let { return it }
        return null
    }

    fun global(code: Int) = performGlobalAction(code)

    fun tapText(t: String): Boolean {
        val hits = rootInActiveWindow?.findAccessibilityNodeInfosByText(t) ?: return false
        for (n in hits) {
            var x: AccessibilityNodeInfo? = n
            while (x != null && !x.isClickable) x = x.parent
            if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    fun typeText(t: String): Boolean {
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun scroll(forward: Boolean): Boolean {
        val n = find(rootInActiveWindow) { it.isScrollable } ?: return false
        return n.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    fun swipe(dir: String): Boolean {
        val dm = resources.displayMetrics; val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        val p = Path()
        when (dir) {
            "up" -> { p.moveTo(w / 2, h * 0.75f); p.lineTo(w / 2, h * 0.25f) }
            "down" -> { p.moveTo(w / 2, h * 0.25f); p.lineTo(w / 2, h * 0.75f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            else -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
        }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
    }

    fun screenText(limit: Int): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > limit) return
            (n.text ?: n.contentDescription)?.let { if (it.isNotBlank()) sb.append(it).append(". ") }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return sb.toString().take(limit)
    }

    fun readScreen(): String = screenText(700).ifEmpty { "Screen par kuch padhne layak nahi mila." }

    fun tapXY(x: Float, y: Float): Boolean {
        val p = Path(); p.moveTo(x, y)
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }

    /** Silent screenshot (Android 11+): koi permission popup nahi. Background thread se bulao. */
    fun shot(): Bitmap? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1); var bmp: Bitmap? = null
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    try {
                        val hb = r.hardwareBuffer
                        bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                    } catch (_: Exception) {}
                    latch.countDown()
                }
                override fun onFailure(errorCode: Int) { latch.countDown() }
            })
        } catch (_: Exception) { return null }
        latch.await(5, TimeUnit.SECONDS)
        return bmp
    }
}
