package com.vaani.app

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Process
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/**
 * Screen tools (Group A, Vaani v5.1 screen-intelligence upgrade).
 *
 * - screen_windows: saari windows ki list (foreground, overlay, dialog, keyboard, split-screen).
 * - screen_app: foreground app pehchano - package + label, sirf Accessibility se
 *   (Usage Stats mile to doosre source se cross-check). Screen text se app
 *   KABHI guess nahi karte - app ki pehchan hamesha package se hoti hai.
 * - screen_model: debug / one-shot - ScreenModel snapshot ka chhota Hinglish
 *   summary + role-wise counts; poora JSON tool result mein ~3000 chars tak
 *   milta hai (speech mein poora JSON nahi bola jata).
 *
 * SAFETY: payment / password / PIN / OTP jaisi screen par teeno tools wahi
 * standard message lautate hain aur screen ka content na bolte hain na log karte hain.
 * Password field ka text ScreenModel mein pehle se "***" hota hai.
 *
 * WIRING (coordinator ke liye - is file mein koi aur file edit nahi ki gayi):
 *   Gemini.kt `tools` lazy block mein:  for (d in ScreenTools.decls()) if (seen.add(d.optString("name"))) fd.put(d)
 *   Actions.kt/Extras.kt chain mein:   ScreenTools.dispatch(c, name, a) ?: ... (AppActionTools.dispatch ke paas)
 *   Safety.kt Confirm.gate mein (optional): screen_* tools sirf padhte hain, tap nahi karte - gate zaroori nahi.
 *   AndroidManifest.xml mein PACKAGE_USAGE_STATS declaration wiring group karega;
 *   yahan code dono haalat sambhalta hai (permission ho ya na ho).
 */
object ScreenTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)

    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("screen_windows",
            "Screen par khuli saari windows batao: kaun si app aage hai, koi popup/dialog/overlay ya keyboard khula hai ya nahi, " +
                "aur split-screen hai ya nahi. Sirf padhta hai, kuch tap nahi karta."),
        fn("screen_app",
            "Abhi foreground mein kaun si app khuli hai, ye batao: app ka naam aur package. " +
                "Usage Stats permission ho to usse bhi cross-check karta hai. Sirf padhta hai."),
        fn("screen_model",
            "Screen ka poora structured model lo: windows aur UI elements (buttons, text fields, lists) unki " +
                "position ke saath. Debug / one-shot screen samajhne ke liye. Sirf padhta hai, kuch tap nahi karta.")
    )

    private fun needAccess(c: Context): String {
        c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Pehle Accessibility mein Vaani ko ON karo, settings khol di."
    }

    private const val DANGER_MSG =
        "Ye screen payment/password/PIN jaisi lag rahi hai - yahan main khud aage nahi badhungi. Aap haath se kar lo."

    private fun appLabel(c: Context, pkg: String): String {
        if (pkg.isBlank()) return ""
        return try {
            val ai = c.packageManager.getApplicationInfo(pkg, 0)
            c.packageManager.getApplicationLabel(ai)?.toString() ?: pkg
        } catch (_: Exception) { pkg }
    }

    /** Known apps: package -> (display name, 2-3 jaane-pehchane screen patterns). */
    private val KNOWN_APPS: Map<String, Pair<String, List<String>>> = mapOf(
        "com.instagram.android" to ("Instagram" to listOf(
            "home/feed - Home, Reels, feed posts",
            "search - Search, Explore",
            "chat list ya chat - Messages, Send message")),
        "com.whatsapp" to ("WhatsApp" to listOf(
            "chat list - Chats",
            "chat - Type a message",
            "calls - Calls")),
        "com.google.android.youtube" to ("YouTube" to listOf(
            "home - Home, Shorts",
            "search - Search",
            "subscriptions - Subscriptions, Library")),
        "com.google.android.apps.maps" to ("Google Maps" to listOf(
            "search - Search here",
            "navigation - Start, directions",
            "saved places - Saved")),
        "com.google.android.chrome" to ("Chrome" to listOf(
            "new tab / address bar - Search or type URL",
            "open tabs - tab switcher",
            "web page - page content")),
        "com.google.android.gm" to ("Gmail" to listOf(
            "inbox - Inbox, Search in mail",
            "compose - Compose",
            "message view - Reply, Forward")),
        "com.google.android.dialer" to ("Phone" to listOf(
            "dialer / keypad - dial pad",
            "recents - Recents, call history",
            "contacts - Contacts")),
        "com.google.android.apps.messaging" to ("Messages" to listOf(
            "conversation list - Messages",
            "chat - Text message, RCS messaging",
            "compose - New conversation")),
        "org.telegram.messenger" to ("Telegram" to listOf(
            "chat list - chats",
            "chat - Message, send",
            "calls - Calls"))
    )

    /** Screen text mein kaun sa known pattern dikh raha hai (sirf description ke liye - app ki pehchan package se hi hoti hai). */
    private fun matchPattern(pkg: String, rawText: String): String {
        val patterns = KNOWN_APPS[pkg]?.second ?: return ""
        val lower = rawText.lowercase()
        for (p in patterns) {
            val hint = p.substringAfter(" - ").lowercase()
            val keywords = hint.split(",", " ", "/").map { it.trim() }.filter { it.length > 2 }
            if (keywords.any { lower.contains(it) }) return p.substringBefore(" - ")
        }
        return ""
    }

    /**
     * Usage Stats se foreground app ka cross-check.
     * PACKAGE_USAGE_STATS AppOps se check hota hai (runtime permission nahi hai).
     * Manifest mein declaration na ho ya permission na mile to null lautata hai.
     */
    private fun foregroundViaUsageStats(c: Context): String? {
        return try {
            val appOps = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
            if (mode != AppOpsManager.MODE_ALLOWED) return null
            val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 10_000, now)
            stats?.maxByOrNull { it.lastTimeUsed }?.packageName?.takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    fun dispatch(c: Context, name: String, a: JSONObject): String? {
        when (name) {
            "screen_windows" -> return screenWindows(c)
            "screen_app" -> return screenApp(c)
            "screen_model" -> return screenModel(c)
            else -> return null
        }
    }

    private fun screenWindows(c: Context): String {
        val acc = VaaniAccess.inst ?: return needAccess(c)
        val snap = acc.model()
        val raw = snap?.rawText ?: acc.screenText(2000)
        if (ScreenModel.isDangerous(raw)) return DANGER_MSG
        val wins = acc.windowsInfo()
        if (wins.isEmpty()) return "Koi window dikh nahi rahi - shayad Accessibility abhi screen padh nahi pa raha."
        val fg = wins.firstOrNull { it.isForeground } ?: wins.firstOrNull()
        val appWins = wins.filter { it.type == "app" }
        val kb = wins.any { it.isKeyboard }
        val overlays = wins.filter { it.type == "overlay" }
        val dialogs = wins.filter { it.type == "dialog" }
        val sb = StringBuilder()
        sb.append("Screen par ${wins.size} window${if (wins.size > 1) "s" else ""} khuli hain. ")
        if (fg != null) {
            val label = appLabel(c, fg.pkg)
            sb.append("Aage ${if (label.isNotBlank()) label else fg.pkg.ifEmpty { "ek app" }} hai")
            if (fg.title.isNotBlank()) sb.append(" (${fg.title})")
            sb.append(". ")
        }
        if (appWins.size >= 2) sb.append("Split-screen lag raha hai - do app windows ek saath dikh rahi hain. ")
        if (dialogs.isNotEmpty()) sb.append("Ek popup/dialog bhi khula hai${if (dialogs.first().title.isNotBlank()) " (${dialogs.first().title})" else ""}. ")
        if (overlays.isNotEmpty()) sb.append("Ek overlay bhi dikh raha hai. ")
        if (kb) sb.append("Keyboard khula hua hai. ")
        if (dialogs.isEmpty() && overlays.isEmpty() && !kb && appWins.size < 2)
            sb.append("Koi popup, overlay ya keyboard nahi dikh raha.")
        return sb.toString().trim()
    }

    private fun screenApp(c: Context): String {
        val acc = VaaniAccess.inst ?: return needAccess(c)
        val snap = acc.model()
        val raw = snap?.rawText ?: acc.screenText(2000)
        if (ScreenModel.isDangerous(raw)) return DANGER_MSG
        // App ki pehchan SIRF package se - screen text se kabhi guess nahi karte.
        val pkg = (acc.foregroundPackage() ?: snap?.pkg).orEmpty()
        if (pkg.isBlank()) return "Foreground app pehchan nahi paya - Accessibility ON hai, par koi active window nahi mili."
        val label = appLabel(c, pkg)
        val known = KNOWN_APPS[pkg]
        val usagePkg = foregroundViaUsageStats(c)
        val sourceNote = if (usagePkg != null) {
            if (usagePkg == pkg) "Usage Stats se bhi cross-check ho gaya - dono ne $label hi bataya."
            else "Usage Stats ne $usagePkg bataya, jabki Accessibility ne $label bataya - Accessibility wali pehchan zyada bharosemand hai."
        } else {
            "Usage Stats permission nahi hai, Accessibility se pehchana."
        }
        val wins = acc.windowsInfo()
        val fgTitle = wins.firstOrNull { it.isForeground }?.title ?: ""
        val sb = StringBuilder()
        sb.append("Abhi ${if (label.isNotBlank()) label else pkg} khula hai")
        if (pkg.isNotBlank()) sb.append(" ($pkg)")
        if (fgTitle.isNotBlank()) sb.append(", window: $fgTitle")
        sb.append(". ")
        if (known != null) {
            val pattern = matchPattern(pkg, raw)
            sb.append("${known.first} ki jaani-pehchani screens: ${known.second.joinToString("; ")}. ")
            if (pattern.isNotBlank()) sb.append("Abhi ye $pattern wali screen lag rahi hai. ")
        } else {
            sb.append("Ye app meri jaani-pehchani list mein nahi hai, isliye iski screens ke pattern nahi bata sakta. ")
        }
        sb.append(sourceNote)
        return sb.toString().trim()
    }

    private fun screenModel(c: Context): String {
        val acc = VaaniAccess.inst ?: return needAccess(c)
        val snap = acc.model() ?: return "Screen ka model nahi bana paya - Accessibility ON hai, par screen padh nahi paya."
        if (ScreenModel.isDangerous(snap.rawText)) return DANGER_MSG
        val byRole = snap.elements.groupBy { it.role }.mapValues { it.value.size }
        val roleOrder = listOf("Button", "EditText", "Text", "Image", "List", "CheckBox", "Switch", "SeekBar", "Other")
        val counts = roleOrder.filter { byRole.containsKey(it) }
            .joinToString(", ") { "$it: ${byRole[it]}" }
        val summary = StringBuilder()
        summary.append("Screen model taiyaar hai: ${if (snap.label.isNotBlank()) snap.label else snap.pkg.ifEmpty { "unknown app" }} mein " +
            "${snap.elements.size} elements aur ${snap.windows.size} windows hain. ")
        if (counts.isNotEmpty()) summary.append("Role-wise: $counts. ")
        val topTexts = snap.elements.mapNotNull { it.text.ifEmpty { it.desc } }
            .filter { it.isNotBlank() && it != "***" }.take(8)
        if (topTexts.isNotEmpty()) summary.append("Upar dikh raha text: ${topTexts.joinToString(", ").take(200)}. ")
        val json = try { ScreenModel.toJson(snap).toString() } catch (_: Exception) { "{}" }
        return summary.toString().trim() + "\nJSON: " + json.take(3000)
    }
}
