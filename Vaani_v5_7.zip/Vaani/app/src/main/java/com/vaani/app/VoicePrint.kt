package com.vaani.app

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.sqrt

/**
 * On-device speaker check (MFCC statistics).
 * V1.7 sudhar: har hisse (dimension) ko uske apne phailav (sd) se naapo - "whitened" distance.
 * Pehle ek hi paimana sab par lagta tha, isiliye ek bada hissa poore match ko bigaad deta tha.
 * NOT security-grade: shor, sardi, ya recording ise dhokha de sakti hai.
 */
class VoicePrint(ctx: Context) {
    private val p = ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE)
    // Awaaz profile phone mein na ho to pehle app ke andar bundled (assets/voiceprint.json), phir Documents/Vaani backup se wapas lo.
    @Suppress("unused") private val restored = VoiceStore.restoreIfMissing(ctx)
    private val center: FloatArray? = p.getString("vp_center", null)?.split(",")?.map { it.toFloat() }?.toFloatArray()
    private val sd: FloatArray? = p.getString("vp_sd", null)?.split(",")?.map { it.toFloat() }?.toFloatArray()
    private val thr = p.getFloat("vp_thr", 0f)

    fun enrolled() = center != null && thr > 0f

    fun verify(frames: List<ShortArray>): Boolean {
        val c = center ?: return false
        val all = ShortArray(frames.sumOf { it.size }); var o = 0
        for (f in frames) { f.copyInto(all, o); o += f.size }
        val v = Mfcc.vector(all) ?: return false
        val s = sd
        val d = if (s != null && s.size == v.size) wdist(v, c, s) else dist(v, c)
        lastScore = d; lastLimit = thr
        return d <= thr
    }

    companion object {
        @Volatile var lastScore = -1f
        @Volatile var lastLimit = 0f

        fun dist(a: FloatArray, b: FloatArray): Float { var s = 0f; for (i in a.indices) s += (a[i] - b[i]) * (a[i] - b[i]); return sqrt(s) }

        /** Har hisse ko uske sd se bhaag karke naapo - chhota phailav wala hissa zyada sakht, bada wala naram. */
        fun wdist(a: FloatArray, b: FloatArray, sd: FloatArray): Float {
            var s = 0f; for (i in a.indices) { val d = (a[i] - b[i]) / sd[i]; s += d * d }; return sqrt(s)
        }

        // 1-minute dialogue enrollment: ye lines ek-ek karke screen par aati hain, user padhkar bolta hai.
        // Zyada aur alag-alag tarah ki awaaz = behtar pehchan (pehle sirf 12 second ki recording hoti thi).
        val LINES = listOf(
            "Namaste Vaani, main ghar ja raha hoon.",
            "Aaj mausam bahut achha hai, thodi thand bhi hai.",
            "Meri awaaz ko dhyaan se suno aur yaad rakho.",
            "Kal subah saat baje mujhe jaga dena.",
            "WhatsApp par Rahul ko message bhej do.",
            "Gaana chalao aur awaaz thodi badha do.",
            "Ek, do, teen, chaar, paanch, chhe, saat, aath, nau, dus.",
            "Mumbai se Pune jaane mein kitna samay lagta hai?",
            "Raat ko sone se pehle saare darwaze band kar dena.",
            "Meri tabiyat aaj thodi theek nahi lag rahi hai.",
            "Bank ka kaam kal tak poora karna hai.",
            "Vaani, tum meri sabse achhi dost ho.")

        fun enroll(ctx: Context, progress: (String) -> Unit, done: (String) -> Unit) = Thread {
            try {
                val total = 16000 * 60   // poora 1 minute
                val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, 32000)
                val pcm = ShortArray(total); rec.startRecording()
                val recDone = java.util.concurrent.atomic.AtomicBoolean(false)
                // Har 5 second par agli line dikhao - user bas padhta jaye, recording chalti rahegi.
                Thread { var idx = 0
                    while (!recDone.get() && idx < LINES.size) {
                        progress("📖 Dialogue ${idx + 1}/${LINES.size} — zor se padho:\n\"${LINES[idx]}\"")
                        idx++; var w = 0; while (!recDone.get() && w < 50) { Thread.sleep(100); w++ }
                    } }.start()
                var n = 0; while (n < total) { val r = rec.read(pcm, n, minOf(1600, total - n)); if (r <= 0) break; n += r }
                recDone.set(true); rec.stop(); rec.release()
                val heard = pcm.copyOf(n)
                val chunk = 24000  // 1.5 s, same as live check
                val vs = (0 until heard.size / chunk).mapNotNull { Mfcc.vector(heard.copyOfRange(it * chunk, (it + 1) * chunk)) }
                if (vs.size < 10) return@Thread done("Awaaz ke samples kam mile (${vs.size}) — shant jagah mein, phone paas rakhkar dobara try karo.")
                val c = FloatArray(24) { i -> vs.map { it[i] }.average().toFloat() }
                // Har hisse ka apna phailav; bahut chhote phailav ko floor do taaki ek hissa match ko kaid na kar le.
                // NOTE: sumOf ka Float wala version Kotlin mein hota hi nahi (sirf Int/Long/Double/UInt/ULong) -
                // isiliye andar ka hisaab Double mein rakho, warna "overload resolution ambiguity" se build fail hoti hai.
                val rawSd = FloatArray(24) { i ->
                    val m = c[i]; sqrt(vs.sumOf { ((it[i] - m) * (it[i] - m)).toDouble() } / vs.size).toFloat() }
                val avgSd = rawSd.average().toFloat()
                val effSd = FloatArray(24) { i -> maxOf(rawSd[i], avgSd * 0.30f, 0.05f) }
                val self = vs.map { wdist(it, c, effSd) }.average().toFloat()
                val newThr = (self * 1.6f).coerceIn(4.0f, 12.0f)
                ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE).edit()
                    .putString("vp_center", c.joinToString(","))
                    .putString("vp_sd", effSd.joinToString(","))
                    .putFloat("vp_thr", newThr).apply()
                VoiceStore.backup(ctx)   // reinstall/update ke baad dobara record na karna pade
                done("Awaaz save ho gayi — 1 minute ke dialogues se seekhi (${vs.size} samples, naya smart match).")
            } catch (e: Exception) { done("Record nahi hua: ${e.message?.take(80)}") }
        }.start()
    }
}


/** Awaaz profile (center, sd, threshold) ka inbuilt/backup store - baar baar enroll na karna pade. */
object VoiceStore {
    private fun backupFile() = java.io.File(
        android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOCUMENTS), "Vaani/voiceprint.json")

    /** Profile ko Documents/Vaani/voiceprint.json mein likho (Files access ON ho tabhi; warna chup-chaap skip). */
    fun backup(ctx: Context) {
        try {
            val p = ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE)
            val c = p.getString("vp_center", null) ?: return
            val j = org.json.JSONObject().put("center", c).put("sd", p.getString("vp_sd", "")).put("thr", p.getFloat("vp_thr", 0f).toDouble())
            val f = backupFile(); f.parentFile?.mkdirs(); f.writeText(j.toString())
        } catch (_: Exception) {}
    }

    /** Prefs mein profile nahi hai to: 1) assets/voiceprint.json (app mein bundled) 2) Documents/Vaani backup. */
    fun restoreIfMissing(ctx: Context): Boolean {
        val p = ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE)
        if (p.getString("vp_center", null) != null && p.getFloat("vp_thr", 0f) > 0f) return false
        val txt = try { ctx.assets.open("voiceprint.json").bufferedReader().use { it.readText() } } catch (_: Exception) { null }
            ?: try { backupFile().takeIf { it.exists() }?.readText() } catch (_: Exception) { null } ?: return false
        return try {
            val j = org.json.JSONObject(txt)
            val thr = j.getDouble("thr").toFloat()
            if (j.getString("center").split(",").size != 24 || thr <= 0f) return false
            p.edit().putString("vp_center", j.getString("center")).putString("vp_sd", j.getString("sd"))
                .putFloat("vp_thr", thr).apply()
            true
        } catch (_: Exception) { false }
    }
}
