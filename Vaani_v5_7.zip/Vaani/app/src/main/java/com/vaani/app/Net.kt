package com.vaani.app

import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.HttpURLConnection
import java.net.URL

/** Chhota HTTP helper + shared prefs + permission check. */
object P { fun of(c: Context) = c.getSharedPreferences("vaani", Context.MODE_PRIVATE) }

object Perm { fun has(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED }

object Net {
    fun request(method: String, url: String, body: String? = null,
                headers: Map<String, String> = emptyMap(), timeout: Int = 10000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = timeout; c.readTimeout = timeout
        for ((k, v) in headers) c.setRequestProperty(k, v)
        if (body != null) {
            c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
        if (code !in 200..299) throw RuntimeException("HTTP $code ${txt.take(120)}")
        return txt
    }

    fun get(url: String, headers: Map<String, String> = emptyMap(), timeout: Int = 10000) =
        request("GET", url, null, headers, timeout)

    fun online(c: Context): Boolean = try {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val cap = if (n == null) null else cm.getNetworkCapabilities(n)
        cap != null && cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (e: Exception) {
        true   // permission/OEM dikkat par "online maan lo" - asli request khud fail hokar wajah bata degi
    }
}
