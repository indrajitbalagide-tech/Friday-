package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/*
 * WIRING (Gemini.kt / Extras.kt — inhe koi aur group edit karega, ye file nahi):
 *
 * Gemini.kt — tools lazy block mein, `for (d in Extras.decls()) fd.put(d)` ke baad:
 *     for (i in 0 until HabitTools.decls().length()) fd.put(HabitTools.decls().getJSONObject(i))
 *
 * Extras.kt — run() ke when() mein:
 *     "habit_suggest", "habit_decide" ->
 *         HabitTools.dispatch(c, name, a) ?: "Ye habit action nahi aata."
 *
 * Routine bante waqt Automation.kt ki "routines" prefs hi use hoti hai (wahi format:
 * JSONObject naam -> JSONArray steps), isliye bani hui routine turant `routine run` se chalti hai.
 * Vaani KABHI khud routine nahi banati — sirf user ke "haan" (habit_decide accept=true) par.
 */

/**
 * Vaani ki "seekhne" wali diary: kaun-sa kaam baar-baar ho raha hai, ye note karti hai.
 * Ye koi neural-network training nahi hai - ye pattern-memory hai, jisse Vaani
 * user ki aadatein pehchankar samay par sujhav de sakti hai.
 *
 * Naya rule (Feature 8): sirf "3 baar" ginna kaafi nahi — sujhav tab banta hai jab
 * wahi kaam WAHI SAMAY (±1 ghanta) par >=2 alag din ho, YA WAHI JAGAH par 2 baar ho.
 * Jaise roz 10 baje DND -> "Roz 10 baje DND lagate ho, routine bana dun?"
 */
object Habits {
    private fun prefs(c: Context) = c.getSharedPreferences("vaani", Context.MODE_PRIVATE)

    /** (tool, detail) se ek step bharosa-se ban sake to uska arg-key; warna routine auto-nahi banti. */
    private val ARG_KEY = mapOf(
        "system_control" to "action", "media" to "action", "settings" to "target"
    )

    private fun describeWhat(tool: String, detail: String): String = when {
        detail == "dnd_on" -> "DND lagana"
        detail == "dnd_off" -> "DND hatana"
        detail == "ringer_silent" -> "phone silent karna"
        detail.isNotEmpty() -> detail
        else -> tool
    }

    private fun slug(s: String): String =
        s.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(30).ifEmpty { "routine" }

    /** Record karte waqt user kahan hai (saved jagah: ghar/office) — last known location se, blocking nahi. */
    private fun currentPlaceLabel(c: Context): String {
        return try {
            val l = Loc.last(c) ?: return ""
            val pl = Memory.places(c)
            for (k in pl.keys()) {
                val o = pl.optJSONObject(k) ?: continue
                if (Loc.dist(l, o.optDouble("lat"), o.optDouble("lon")) < maxOf(o.optDouble("r", 150.0), 100.0)) return k
            }
            ""
        } catch (_: Exception) { "" }
    }

    /** Har tool-call yaha note hota hai (Actions.run se). Galti ho to bhi asli kaam nahi rukna chahiye. */
    fun record(c: Context, tool: String, detail: String) = recordRich(c, tool, detail, null)

    /** Jagah ke saath record (placeLabel khali ho to current saved jagah khud nikaali jaati hai). */
    fun recordRich(c: Context, tool: String, detail: String, placeLabel: String?) {
        try {
            val p = prefs(c)
            val all = JSONObject(p.getString("habits", "{}") ?: "{}")
            val key = tool + "|" + detail.take(24).lowercase()
            val e = all.optJSONObject(key) ?: JSONObject().put("n", 0).put("h", JSONArray()).put("occ", JSONArray())
            e.put("n", e.optInt("n") + 1)
            val cal = Calendar.getInstance()
            val hour = cal.get(Calendar.HOUR_OF_DAY)
            val day = cal.get(Calendar.DAY_OF_WEEK)
            val hrs = e.getJSONArray("h"); hrs.put(hour)
            while (hrs.length() > 12) hrs.remove(0)
            val occ = e.optJSONArray("occ") ?: JSONArray()
            occ.put(JSONObject().put("h", hour).put("d", day)
                .put("pl", (placeLabel ?: currentPlaceLabel(c)).lowercase())
                .put("t", System.currentTimeMillis()))
            while (occ.length() > 20) occ.remove(0)
            e.put("occ", occ)
            all.put(key, e)
            if (all.length() > 40) {   // diary zyada badi na ho - sabse kam-use wali entry hatao
                var worst: String? = null; var wn = Int.MAX_VALUE
                val it = all.keys(); while (it.hasNext()) { val k = it.next()
                    val n = all.getJSONObject(k).optInt("n"); if (n < wn) { wn = n; worst = k } }
                worst?.let { all.remove(it) }
            }
            p.edit().putString("habits", all.toString()).apply()
        } catch (e: Exception) { /* seekhna kabhi asli kaam na roke */ }
    }

    private data class Candidate(
        val key: String, val tool: String, val detail: String,
        val hour: Int?, val place: String?, val days: Int, val count: Int
    )

    /** Ek key ke occurrences se time-pattern (wahi samay ±1h, >=2 din) ya place-pattern (wahi jagah 2 baar). */
    private fun findCandidate(key: String, e: JSONObject): Candidate? {
        val parts = key.split("|", limit = 2)
        val tool = parts[0]; val detail = if (parts.size > 1) parts[1] else ""
        val occ = e.optJSONArray("occ") ?: return null
        if (occ.length() == 0) return null
        // Time-pattern: har occurrence ke hour ke aas-paas (±1h) kitne alag din?
        var bestTime: Candidate? = null
        for (i in 0 until occ.length()) {
            val h0 = occ.getJSONObject(i).optInt("h")
            val days = HashSet<Int>(); var cnt = 0
            for (j in 0 until occ.length()) {
                val o = occ.getJSONObject(j)
                if (Math.abs(o.optInt("h") - h0) <= 1) { days.add(o.optInt("d")); cnt++ }
            }
            if (days.size >= 2 && (bestTime == null || cnt > bestTime.count))
                bestTime = Candidate(key, tool, detail, h0, null, days.size, cnt)
        }
        // Place-pattern: wahi jagah 2 baar.
        var bestPlace: Candidate? = null
        val byPlace = HashMap<String, Int>()
        for (i in 0 until occ.length()) {
            val pl = occ.getJSONObject(i).optString("pl")
            if (pl.isNotEmpty()) byPlace[pl] = (byPlace[pl] ?: 0) + 1
        }
        for ((pl, cnt) in byPlace) {
            if (cnt >= 2 && (bestPlace == null || cnt > bestPlace.count))
                bestPlace = Candidate(key, tool, detail, null, pl, 0, cnt)
        }
        // Time-pattern ko pehchan: wahi samay roz hona zyada pakka signal hai.
        return bestTime ?: bestPlace
    }

    private fun stepsFor(tool: String, detail: String): JSONArray? {
        val argKey = ARG_KEY[tool] ?: return null
        if (detail.isEmpty()) return null
        return JSONArray().put(JSONObject().put("name", tool)
            .put("args", JSONObject().put(argKey, detail)))
    }

    private fun routineNameFor(cand: Candidate): String {
        val what = slug(describeWhat(cand.tool, cand.detail))
        return when {
            cand.hour != null -> "roz_${cand.hour}_baje_$what"
            cand.place != null -> "${slug(cand.place)}_par_$what"
            else -> "roz_$what"
        }
    }

    private fun declinedUntil(c: Context, key: String): Long {
        return try {
            JSONObject(prefs(c).getString("habit_declined", "{}") ?: "{}").optLong(key, 0L)
        } catch (_: Exception) { 0L }
    }

    private fun suggestionText(cand: Candidate): String {
        val what = describeWhat(cand.tool, cand.detail)
        val whenPart = when {
            cand.hour != null -> "Roz ${if (cand.hour % 12 == 0) 12 else cand.hour % 12} baje"
            cand.place != null -> "${cand.place} par"
            else -> "Aksar"
        }
        return "$whenPart $what karte ho — routine bana dun? Phir bas ek baar bolna hoga. " +
            "Haan bolne par bana dunga ('haan, bana do'), na bolne par 7 din tak dobara nahi poochhunga."
    }

    /** Pending sujhav (accept/decline ka intezaar) — ek waqt par ek hi. */
    fun pendingSuggestion(c: Context): JSONObject? {
        return try {
            val s = prefs(c).getString("habit_pending", null) ?: return null
            JSONObject(s)
        } catch (_: Exception) { null }
    }

    /**
     * Sujhav do (ek baar): time/place pattern mila to pending save karke text do;
     * purani entries (occ nahi hai) ke liye purana "3 baar" wala fallback.
     * Ye sirf SUJHAV deta hai — routine kabhi khud nahi banata.
     */
    fun suggestion(c: Context): String? {
        pendingSuggestion(c)?.let { pend ->
            // Pehle se pending sujhav hai to wahi dobara dikhao, naya mat banao.
            val cand = Candidate(pend.optString("key"), pend.optString("tool"), pend.optString("detail"),
                pend.optInt("hour", -1).takeIf { it >= 0 }, pend.optString("place").takeIf { it.isNotEmpty() },
                0, pend.optInt("count", 0))
            return suggestionText(cand)
        }
        val p = prefs(c)
        val all = JSONObject(p.getString("habits", "{}") ?: "{}")
        val told = p.getStringSet("habit_told", emptySet()) ?: emptySet()
        val now = System.currentTimeMillis()
        var best: Candidate? = null
        val it = all.keys()
        while (it.hasNext()) {
            val k = it.next()
            if (k in told || declinedUntil(c, k) > now) continue
            val e = all.getJSONObject(k)
            val cand = findCandidate(k, e)
                ?: if (e.optInt("n") >= 3) {   // purani entry: occ nahi, sirf ginti hai
                    val parts = k.split("|", limit = 2)
                    Candidate(k, parts[0], if (parts.size > 1) parts[1] else "", null, null, 0, e.optInt("n"))
                } else null
            if (cand != null && (best == null || cand.count > best.count)) best = cand
        }
        val cand = best ?: return null
        val steps = stepsFor(cand.tool, cand.detail)
        val pend = JSONObject().put("key", cand.key).put("tool", cand.tool).put("detail", cand.detail)
            .put("hour", cand.hour ?: -1).put("place", cand.place ?: "")
            .put("count", cand.count).put("routine", routineNameFor(cand))
            .put("steps", steps?.toString() ?: "")
            .put("created", now)
        p.edit().putString("habit_pending", pend.toString()).apply()
        return suggestionText(cand)
    }

    /**
     * User ka faisla — ONE-TAP accept/decline. accept=true: routine banao (Automation wali
     * "routines" prefs mein); accept=false: 7 din tak ye sujhav dobara mat dikhao.
     * Kabhi auto-apply nahi hota: ye sirf tab chalta hai jab user ne haan/na bola ho.
     */
    fun decide(c: Context, accept: Boolean): String {
        val pend = pendingSuggestion(c) ?: return "Abhi koi sujhav pending nahi hai — pehle 'sujhav dikhao' bolo."
        val p = prefs(c)
        val key = pend.optString("key")
        if (!accept) {
            val dec = try { JSONObject(p.getString("habit_declined", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
            dec.put(key, System.currentTimeMillis() + 7 * 24 * 3600_000L)
            p.edit().putString("habit_declined", dec.toString()).remove("habit_pending").apply()
            return "Theek hai, 7 din tak ye sujhav dobara nahi dunga."
        }
        val stepsStr = pend.optString("steps")
        if (stepsStr.isEmpty()) {
            p.edit().remove("habit_pending").apply()
            return "Is kaam ki routine ek step se nahi ban sakti (poori details record nahi hain) — " +
                "steps batao to 'routine save' se bana dunga."
        }
        val name = pend.optString("routine")
        val all = try { JSONObject(p.getString("routines", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        var finalName = name; var n = 2
        while (all.has(finalName)) { finalName = "${name}_$n"; n++ }
        all.put(finalName, JSONArray(stepsStr))
        p.edit().putString("routines", all.toString()).apply()
        val told = (p.getStringSet("habit_told", emptySet()) ?: emptySet()) + key
        p.edit().putStringSet("habit_told", told).remove("habit_pending").apply()
        return "Routine '$finalName' bana di — ab bas '$finalName' bolo to ye kaam ho jayega."
    }
}

/** Gemini tools: habit_suggest / habit_decide. */
object HabitTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun bp(d: String) = JSONObject().put("type", "BOOLEAN").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject>, req: List<String> = emptyList()): JSONObject {
        val p = JSONObject(); for ((k, v) in props) p.put(k, v)
        val params = JSONObject().put("type", "OBJECT").put("properties", p)
        if (req.isNotEmpty()) params.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("parameters", params)
    }

    fun decls(): JSONArray = JSONArray().put(fn("habit_suggest",
        "Vaani ne user ki aadat se jo sujhav banaya hai wo dikhao (jaise roz 10 baje DND -> routine bana dun?). Sujhav kabhi khud apply nahi hota.",
        emptyMap()))
        .put(fn("habit_decide",
            "Pending sujhav par user ka faisla: accept=true to routine banao, accept=false to 7 din ke liye daba do.",
            mapOf("accept" to bp("true = routine banao, false = 7 din tak mat poochho")), listOf("accept")))

    /** Unknown naam par null (taaki Actions/Extras aage fall-through kar sake). */
    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "habit_suggest" -> Habits.suggestion(c) ?: "Abhi koi naya sujhav nahi hai — jab koi kaam roz wahi samay ya wahi jagah par hoga, tab bata dunga."
        "habit_decide" -> Habits.decide(c, a.optBoolean("accept", false))
        else -> null
    }
}
