package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Ghar (Home Assistant), webhook (ESP32/IFTTT/Node-RED) aur PC bridge. */
object Home {
    fun run(c: Context, name: String, a: JSONObject): String? = when (name) {
        "smart_home" -> try { smart(c, a) } catch (e: NoCfg) { "Home Assistant set nahi hai - Vaani ke ⚙ Settings mein URL aur token daalo." }
            catch (e: Exception) { "Ghar se baat nahi ho payi: ${e.message?.take(80)}" }
        "webhook" -> hook(c, a)
        "pc" -> try { pc(c, a) } catch (e: NoCfg) { "PC bridge set nahi hai - ⚙ Settings mein PC URL aur token daalo." }
            catch (e: Exception) { "PC se baat nahi ho payi: ${e.message?.take(80)}" }
        else -> null
    }

    private class NoCfg : Exception()

    // ---------------- Home Assistant ----------------
    private val DOMAINS = setOf("light", "switch", "fan", "climate", "cover", "media_player", "scene", "script",
        "input_boolean", "lock", "automation", "humidifier", "vacuum", "button")
    private var cache: JSONArray? = null
    private var cacheAt = 0L

    private fun ha(c: Context): Pair<String, Map<String, String>> {
        val p = P.of(c)
        val url = p.getString("ha_url", "").orEmpty().trim().trimEnd('/'); val tok = p.getString("ha_token", "").orEmpty().trim()
        if (url.isEmpty() || tok.isEmpty()) throw NoCfg()
        return url to mapOf("Authorization" to "Bearer $tok")
    }

    private fun states(c: Context): JSONArray {
        val now = System.currentTimeMillis()
        cache?.let { if (now - cacheAt < 60_000) return it }
        val (url, h) = ha(c)
        val r = JSONArray(Net.get("$url/api/states", h)); cache = r; cacheAt = now; return r
    }

    private fun find(c: Context, target: String): JSONObject? {
        val t = target.lowercase().trim(); if (t.isEmpty()) return null
        val s = states(c); var best: JSONObject? = null; var bs = 0
        for (i in 0 until s.length()) {
            val e = s.getJSONObject(i); val id = e.getString("entity_id")
            if (id.substringBefore('.') !in DOMAINS) continue
            val fn = e.optJSONObject("attributes")?.optString("friendly_name", "").orEmpty().lowercase()
            val score = when {
                fn == t -> 100
                id.substringAfter('.') == t.replace(' ', '_') -> 95
                fn.contains(t) -> 70 - minOf(fn.length - t.length, 30)
                t.split(' ').all { fn.contains(it) } -> 40
                else -> 0
            }
            if (score > bs) { bs = score; best = e }
        }
        return best
    }

    private fun callService(c: Context, domain: String, service: String, data: JSONObject) {
        val (url, h) = ha(c)
        Net.request("POST", "$url/api/services/$domain/$service", data.toString(), h)
        cache = null
    }

    private fun smart(c: Context, a: JSONObject): String {
        val act = a.optString("action").lowercase()
        if (act == "list") {
            val s = states(c); val names = ArrayList<String>()
            for (i in 0 until s.length()) { val e = s.getJSONObject(i)
                if (e.getString("entity_id").substringBefore('.') in setOf("light", "switch", "fan", "climate", "cover", "scene", "script", "lock"))
                    names.add(e.optJSONObject("attributes")?.optString("friendly_name", e.getString("entity_id")) ?: e.getString("entity_id")) }
            return if (names.isEmpty()) "Koi device nahi mila." else names.take(30).joinToString(", ")
        }
        val e = find(c, a.optString("target")) ?: return "'${a.optString("target")}' naam ka koi device nahi mila. 'list' se naam dekho."
        val id = e.getString("entity_id"); val dom = id.substringBefore('.')
        val nm = e.optJSONObject("attributes")?.optString("friendly_name", id) ?: id
        val v = a.optInt("value", -1)
        fun id1() = JSONObject().put("entity_id", id)
        if (act == "state") {
            val at = e.optJSONObject("attributes")
            val extra = listOf("current_temperature", "temperature", "brightness", "percentage", "current_position")
                .mapNotNull { k -> at?.opt(k)?.takeIf { it != JSONObject.NULL }?.let { "$k=$it" } }.joinToString(", ")
            return "$nm: ${e.getString("state")}" + if (extra.isNotEmpty()) " ($extra)" else ""
        }
        if (dom == "lock") Confirm.need("lock/unlock: $nm $act")?.let { return it }
        when (act) {
            "on", "off", "toggle" -> {
                val svc = when (dom) {
                    "cover" -> when (act) { "on" -> "open_cover"; "off" -> "close_cover"; else -> "toggle" }
                    "lock" -> when (act) { "on" -> "lock"; "off" -> "unlock"; else -> return "Lock ke liye on(lock) ya off(unlock) bolo." }
                    "vacuum" -> when (act) { "on" -> "start"; "off" -> "return_to_base"; else -> "start" }
                    "scene", "script", "automation" -> "turn_on"
                    "button" -> "press"
                    else -> "turn_$act"
                }
                callService(c, dom, svc, id1())
                return "$nm: $act."
            }
            "set" -> {
                if (v < 0) return "Kitna set karna hai (0-100 ya temperature)?"
                when (dom) {
                    "light" -> callService(c, "light", "turn_on", id1().put("brightness_pct", v.coerceIn(0, 100)))
                    "climate" -> callService(c, "climate", "set_temperature", id1().put("temperature", v))
                    "fan" -> callService(c, "fan", "set_percentage", id1().put("percentage", v.coerceIn(0, 100)))
                    "media_player" -> callService(c, "media_player", "volume_set", id1().put("volume_level", v.coerceIn(0, 100) / 100.0))
                    "cover" -> callService(c, "cover", "set_cover_position", id1().put("position", v.coerceIn(0, 100)))
                    else -> return "$nm par 'set' nahi chalta."
                }
                return "$nm: $v."
            }
            else -> return "smart_home mein on, off, toggle, set, state ya list chalta hai."
        }
    }

    // ---------------- Webhooks (ESP32, IFTTT, Node-RED...) ----------------
    private fun hook(c: Context, a: JSONObject): String {
        val p = P.of(c); val all = try { JSONObject(p.getString("hooks", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        val n = a.optString("name").lowercase().trim()
        return when (a.optString("action")) {
            "save" -> { val u = a.optString("url"); if (!u.startsWith("http")) "Sirf http/https URL chalega." else {
                all.put(n, u); p.edit().putString("hooks", all.toString()).apply(); "Webhook '$n' save ho gaya." } }
            "delete" -> { all.remove(n); p.edit().putString("hooks", all.toString()).apply(); "Webhook '$n' hata diya." }
            "list" -> if (all.length() == 0) "Koi webhook nahi hai." else all.keys().asSequence().joinToString(", ")
            else -> {
                val u = all.optString(n); if (u.isEmpty()) return "Webhook '$n' nahi mila."
                try { val d = a.optString("data")
                    Net.request(if (d.isEmpty()) "GET" else "POST", u, d.ifEmpty { null }, emptyMap(), 8000); "Webhook '$n' chal gaya."
                } catch (e: Exception) { "Webhook fail: ${e.message?.take(60)}" }
            }
        }
    }

    // ---------------- PC bridge ----------------
    private fun pc(c: Context, a: JSONObject): String {
        val p = P.of(c)
        val url = p.getString("pc_url", "").orEmpty().trim().trimEnd('/'); val tok = p.getString("pc_token", "").orEmpty().trim()
        if (url.isEmpty() || tok.isEmpty()) throw NoCfg()
        val body = JSONObject().put("action", a.optString("action")).put("arg", a.optString("arg"))
        val r = Net.request("POST", "$url/do", body.toString(), mapOf("Authorization" to "Bearer $tok"), 15000)
        return JSONObject(r).optString("result", "Ho gaya.")
    }
}
