package com.vaani.app

import android.content.Context
import android.content.Intent
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/**
 * Voice screen automation (Group 4, PLUS feature - TOP focus).
 *
 * Generic flow: Gemini `app_action` tool se steps ki list aati hai, Vaani unhe ek ke baad ek
 * chalati hai - har step ke baad screen padh kar verify karti hai ki expected text dikh raha hai.
 * Expected text na mile to wahin RUK jati hai, andha-aage nahi badhti.
 *
 * Steps ka format (JSONArray, har step ek JSONObject):
 *   { "action": "open_app|search|tap_text|type_text|send|wait|read_screen",
 *     "text": "app ka naam / dabane wala text / type karne wala text / search query",
 *     "value": "text ka alternative (koi bhi ek chalega)",
 *     "expect": "is step ke baad screen par ye text hona chahiye (optional, verify ke liye)",
 *     "wait_ms": 1500 }          // is step ke baad kitna rukna hai (default 1200ms)
 *
 * Zaroori:
 * - Accessibility mein Vaani ON honi chahiye (VaaniAccess.inst), warna settings khol kar batata hai.
 * - Ye function background thread se hi bulao (Gemini askAgent thread) - is mein Thread.sleep hai.
 * - Payment / password / PIN / OTP jaisi screen dikhte hi flow khud ruk jata hai.
 * - Kabhi password, PIN, OTP ya payment confirm nahi karta.
 *
 * Instagram preset "instagram_rohit_hi" - step list (exact):
 *   1. open_app  "Instagram"        -> Instagram kholo
 *   2. wait      2500ms             -> app load hone do
 *   3. search    "Rohit"            -> Search dabao, "Rohit" type karo
 *   4. wait      1500ms
 *   5. tap_text  "Rohit" (expect "Rohit") -> chat kholo, verify karo chat screen par "Rohit" dikh raha hai
 *   6. wait      1200ms
 *   7. type_text "hi"               -> message box mein "hi" likho (Hinglish)
 *   8. send      (expect "hi")      -> Send dabao (pehli baar ho to neeche Safety gate dekho)
 * NOTE: Instagram ka UI (button ke naam/position) version aur bhasha ke hisaab se badal sakta hai;
 * agar "Search" ya "Send" text na mile to step fail hoga aur flow ruk jayega - galat jagah tap nahi hogi.
 */
object AppAction {
    // Vision.agent wala hi danger check: payment/password screen par khud ruk jao.
    private val DANGER = Regex("(?i)(upi pin|enter pin|enter upi|password|passcode|\\botp\\b|pay now|send money|transfer|confirm payment|delete account|factory reset|cvv)")

    private fun needAccess(c: Context): String {
        c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Pehle Accessibility mein Vaani ko ON karo, settings khol di."
    }

    /** Instagram preset: Rohit ko "hi" bhejne ke steps (upar wali list ke hisaab se). */
    fun instagramRohitHiSteps(): JSONArray = JSONArray().apply {
        put(JSONObject().put("action", "open_app").put("text", "Instagram"))
        put(JSONObject().put("action", "wait").put("wait_ms", 2500))
        put(JSONObject().put("action", "search").put("text", "Rohit"))
        put(JSONObject().put("action", "wait").put("wait_ms", 1500))
        put(JSONObject().put("action", "tap_text").put("text", "Rohit").put("expect", "Rohit"))
        put(JSONObject().put("action", "wait").put("wait_ms", 1200))
        put(JSONObject().put("action", "type_text").put("text", "hi"))
        put(JSONObject().put("action", "send").put("expect", "hi"))
    }

    /**
     * Steps chalao. Har step: execute -> (defaultWaitMs) ruko -> expect ho to screen par verify karo.
     * Koi step fail ho ya expect na mile to wahin ruk kar batata hai kaun sa step fail hua.
     * Success par: "Ho gaya — saare N steps poore hue." (AppActionTools isi se pehchanta hai.)
     */
    fun runFlow(c: Context, steps: JSONArray, defaultWaitMs: Long = 1200): String {
        val s = VaaniAccess.inst ?: return needAccess(c)
        if (steps.length() == 0) return "Steps khali hain - kya karna hai, ye nahi mila."
        for (i in 0 until steps.length()) {
            val st = try { steps.getJSONObject(i) } catch (e: Exception) { return "Step ${i + 1} samajh nahi aaya." }
            val action = st.optString("action").trim().lowercase()
            val text = st.optString("text").ifEmpty { st.optString("value") }
            val waitMs = st.optLong("wait_ms", defaultWaitMs).coerceIn(0, 15_000)
            val expect = st.optString("expect").trim()
            val stepNo = i + 1

            // Payment/password screen dikhe to aage mat badho.
            if (DANGER.containsMatchIn(s.readScreen()))
                return "Step $stepNo se pehle screen payment/password/PIN jaisi lag rahi hai - yahan ruk gaya."

            val ok: Boolean = when (action) {
                "open_app" -> {
                    if (text.isEmpty()) false
                    else !Actions.run(c, "open_app", JSONObject().put("app", text)).contains("nahi mila")
                }
                "search" -> {
                    // Search dabao (na mile to bhi type try karo - kai apps mein box pehle se focus hota hai),
                    // phir query type karo.
                    s.tapText("Search")
                    Thread.sleep(600)
                    if (!s.typeText(text)) { s.tapText("Search"); Thread.sleep(700); s.typeText(text) } else true
                }
                "tap_text" -> if (text.isEmpty()) false else s.tapText(text)
                "type_text" -> if (text.isEmpty()) false else s.typeText(text)
                "send" -> s.tapText("Send") || s.tapText("send")
                "wait" -> true
                "read_screen" -> true   // sirf padhna hai - verify neeche expect se hota hai
                else -> return "Step $stepNo: '$action' action nahi aata - ruk gaya."
            }
            if (!ok) return "Step $stepNo ($action '$text') nahi ho paya - ruk gaya."
            Thread.sleep(waitMs)
            if (expect.isNotEmpty()) {
                val screen = s.readScreen()
                if (!screen.contains(expect, ignoreCase = true))
                    return "Step $stepNo ($action) ke baad '$expect' screen par nahi mila - ruk gaya. Ab screen par: ${screen.take(120)}"
            }
            if (action == "read_screen") {
                val screen = s.readScreen()
                if (expect.isEmpty()) return "Screen par ye dikh raha hai: ${screen.take(300)}"
            }
        }
        return "Ho gaya — saare ${steps.length()} steps poore hue."
    }
}

/**
 * `app_action` tool ki declarations + dispatch. EK hi tool hai - Instagram sirf iska preset hai.
 *
 * WIRING (coordinator ke liye - is file mein koi aur file edit nahi ki gayi):
 *   Gemini.kt `tools` lazy block mein:  for (d in AppActionTools.decls()) if (seen.add(d.optString("name"))) fd.put(d)
 *   Actions.kt/Extras.kt chain mein:   AppActionTools.dispatch(c, name, a) ?: ... (Extras.run ke andar,
 *   Info.run ke baad - taaki "app_action" yahin pakda jaye)
 *   Safety.kt Confirm.gate mein (optional, extra safety): "app_action" -> "phone par khud steps chalana: ..."
 *   (Instagram preset ka pehli-baar-send gate is file mein pehle se hai - Safety.kt edit zaroori nahi.)
 */
object AppActionTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)

    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("app_action", "Kisi bhi app ke andar multi-step kaam khud karo: steps ki list do (open_app/search/tap_text/type_text/send/wait/read_screen), " +
            "har step ke baad screen verify hoti hai. Preset 'instagram_rohit_hi' = Instagram par Rohit ko 'hi' bhejo. " +
            "Pehli baar kisi naye vyakti ko message bhejne se pehle Vaani malik se poochhegi.",
            mapOf("task" to sp("kaam ek line mein, jaise 'Instagram par Rohit ko hi bhejo'"),
                "steps" to sp("JSON array string: [{\"action\":\"open_app\",\"text\":\"Instagram\"},{\"action\":\"tap_text\",\"text\":\"Rohit\",\"expect\":\"Rohit\"}] - preset ho to zaroori nahi"),
                "preset" to sp("shortcut preset: 'instagram_rohit_hi' (Instagram par Rohit ko hi bhejo). Preset ho to steps mat do.")), listOf("task"))
    )

    /** Jin logon ko pehle message bheja ja chuka hai (pehli-baar confirm ke baad yahan naam judta hai). */
    private fun sentContacts(c: Context): MutableSet<String> {
        val raw = P.of(c).getString("appaction_sent", "") ?: ""
        return raw.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toMutableSet()
    }

    private fun markSent(c: Context, who: String) {
        val set = sentContacts(c); set.add(who.trim().lowercase())
        P.of(c).edit().putString("appaction_sent", set.joinToString(",")).apply()
    }

    /** Sirf "app_action" pakdo, baaki ke liye null (taaki chain aage badh sake). */
    fun dispatch(c: Context, name: String, a: JSONObject): String? {
        if (name != "app_action") return null
        val preset = a.optString("preset").trim().lowercase()
        val steps: JSONArray = when {
            preset == "instagram_rohit_hi" -> {
                // SAFETY (Confirm-first pattern, Safety.kt jaisa): Rohit ko pehli baar "hi" bhejne se
                // pehle malik se poochho. Pehli call par ye sawal lautata hai; malik ke "haan" ke baad
                // (naya turn + 2.5 sec) dobara wahi call aaye to hi aage badhta hai.
                if ("rohit" !in sentContacts(c)) {
                    Confirm.need("Instagram par Rohit ko pehli baar 'hi' bhejna")?.let {
                        return "Rohit ko pehli baar 'hi' bhejun? Haan bolo to bhejunga"
                    }
                }
                AppAction.instagramRohitHiSteps()
            }
            preset.isNotEmpty() -> return "Preset '$preset' nahi aata. Abhi sirf 'instagram_rohit_hi' hai."
            a.optString("steps").isNotBlank() -> try { JSONArray(a.getString("steps")) }
                catch (e: Exception) { return "Steps samajh nahi aaye - JSON array bhej, jaise [{\"action\":\"open_app\",\"text\":\"Instagram\"}]." }
            else -> return "Steps ya preset do - kya karna hai, ye nahi mila."
        }
        val result = AppAction.runFlow(c, steps)
        if (preset == "instagram_rohit_hi" && result.startsWith("Ho gaya")) markSent(c, "rohit")
        return result
    }
}
