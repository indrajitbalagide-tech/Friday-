package com.vaani.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

/** Draggable floating orb. Tap = start a session without the voice check. State: 0 idle, 1 listening, 2 speaking. */
class Overlay(private val c: Context) {
    private val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var v: TextView? = null
    private val lp = WindowManager.LayoutParams(150, 150, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
        PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }

    fun show(onTap: () -> Unit) {
        if (!Settings.canDrawOverlays(c)) return
        h.post {
            val t = TextView(c).apply {
                text = "🎙"; textSize = 24f; gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.GRAY) }
            }
            var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
            t.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt()
                        if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true; wm.updateViewLayout(t, lp) }
                    MotionEvent.ACTION_UP -> if (!moved) onTap()
                }
                true
            }
            v = t; try { wm.addView(t, lp) } catch (_: Exception) {}
        }
    }

    fun state(s: Int) = h.post {
        (v?.background as? GradientDrawable)?.setColor(when (s) { 1 -> Color.rgb(46, 160, 67); 2 -> Color.rgb(232, 89, 12); else -> Color.GRAY })
    }

    fun hide() = h.post { v?.let { try { wm.removeView(it) } catch (_: Exception) {} }; v = null }
}
