package com.vaani.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Internet na ho to bhi basic kaam: phone ki apni offline speech recognition + simple Hindi/Hinglish/English commands.
 * (Gemini jaisa samajh nahi - sirf fixed commands.) Offline Hindi/English language pack phone mein download hona chahiye.
 */
object Offline {
    private fun rest(t: String, drop: Set<String>) = t.split(Regex("\\s+")).filter { it.isNotBlank() && it !in drop }.joinToString(" ")
    private val CALL_DROP = setOf("call", "karo", "kar", "do", "ko", "phone", "laga", "lagao", "please", "mujhe", "kaal", "कॉल", "करो", "को", "फोन", "लगाओ", "लगा", "दो")
    private val OPEN_DROP = setOf("open", "kholo", "khol", "do", "karo", "app", "please", "खोलो", "खोल", "दो", "ऐप")

    /** Samajh aaya to kaam karke bolne layak jawab, warna null. */
    fun parse(c: Context, raw: String): String? {
        val t = raw.lowercase().trim(); if (t.isEmpty()) return null
        fun has(vararg w: String) = w.any { t.contains(it) }
        fun sys(a: String) = Actions.run(c, "system_control", JSONObject().put("action", a))
        fun scr(a: String) = Actions.run(c, "screen_control", JSONObject().put("action", a))
        return when {
            has("torch", "flashlight", "tourch", "टॉर्च", "फ्लैश") ->
                Actions.run(c, "flashlight", JSONObject().put("on", !has("band", "off", "बंद", "bujha", "बुझा")))
            has("volume", "वॉल्यूम") && has("badha", "up", "increase", "zyada", "बढ़ा") -> sys("volume_up")
            has("volume", "वॉल्यूम") && has("kam", "down", "decrease", "घटा", "कम") -> sys("volume_down")
            has("unmute") -> sys("unmute")
            has("mute", "म्यूट") -> sys("mute")
            has("battery", "बैटरी") -> sys("battery")
            has("kitne baje", "time", "samay", "कितने बजे", "टाइम") -> "Abhi " + SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date()) + " baje hain."
            has("wifi", "वाईफाई") -> Actions.run(c, "settings", JSONObject().put("target", "wifi"))
            has("bluetooth", "ब्लूटूथ") -> Actions.run(c, "settings", JSONObject().put("target", "bluetooth"))
            has("answer", "utha", "उठा") && CallReceiver.ringingNow != null -> Actions.run(c, "call_control", JSONObject().put("action", "answer"))
            has("reject", "kaat", "काट") && CallReceiver.ringingNow != null -> Actions.run(c, "call_control", JSONObject().put("action", "reject"))
            has("call", "कॉल", "फोन लगा") -> rest(t, CALL_DROP).takeIf { it.isNotEmpty() }?.let { Actions.run(c, "call", JSONObject().put("who", it)) }
            has("open", "kholo", "khol", "खोलो", "खोल") -> rest(t, OPEN_DROP).takeIf { it.isNotEmpty() }?.let { Actions.run(c, "open_app", JSONObject().put("app", it)) }
            has("home", "होम") -> scr("home")
            has("peeche", "back", "वापस") -> scr("back")
            has("lock", "लॉक") -> scr("lock_screen")
            else -> null
        }
    }

    /** MAIN thread par bulao. Ek baar suno, parse karo, bolo, phir done(). */
    fun listen(c: Context, done: () -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(c)) { Speaker.speakLocal(c, "Offline suna nahi ja sakta."); done(); return }
        val sr = SpeechRecognizer.createSpeechRecognizer(c)
        var finished = false
        fun finish() { if (!finished) { finished = true; try { sr.destroy() } catch (_: Exception) {}; done() } }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { Speaker.speakLocal(c, "Offline hoon, boliye.") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) { finish() }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onResults(b: Bundle?) {
                val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                VaaniService.log?.invoke("🧑 (offline) ${list.firstOrNull() ?: ""}")
                val res = list.firstNotNullOfOrNull { parse(c, it) }
                val say = res ?: "Ye offline mein nahi samajh paayi. Internet aane par poochna."
                VaaniService.log?.invoke("🤖 $say"); Speaker.speakLocal(c, say); finish()
            }
        })
        try { sr.startListening(i) } catch (e: Exception) { finish() }
    }
}
