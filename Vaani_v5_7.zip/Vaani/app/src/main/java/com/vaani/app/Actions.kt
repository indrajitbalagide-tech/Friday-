package com.vaani.app

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.KeyEvent
import org.json.JSONObject

/** Real device actions. Each returns a short spoken result. */
object Actions {
    private fun go(c: Context, i: Intent) = c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun number(c: Context, who: String): String? {
        if (who.replace(Regex("[ +\\-()]"), "").all { it.isDigit() }) return who.filter { it.isDigit() || it == '+' }
        c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$who%"), null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    private fun listenerOn(c: Context) =
        (Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: "").contains(c.packageName)

    private fun callControl(c: Context, act: String): String {
        val tm = c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        return when (act) {
            "answer" -> { tm.acceptRingingCall(); "Call utha li." }
            "reject" -> if (tm.endCall()) "Call kaat di." else "Call kaat nahi paya."
            else -> CallReceiver.lastCaller?.let { "$it ka call aa raha hai." } ?: "Abhi koi call nahi aa raha."
        }
    }

    private fun notif(c: Context, act: String): String {
        if (!listenerOn(c)) { go(c, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return "Pehle Vaani ko notification access do, settings khol di." }
        val p = c.getSharedPreferences("vaani", Context.MODE_PRIVATE)
        return when (act) {
            "enable_auto_reply" -> { p.edit().putBoolean("auto", true).apply(); "Auto-reply on. Ab aane wale messages ka jawab main dunga." }
            "disable_auto_reply" -> { p.edit().putBoolean("auto", false).apply(); "Auto-reply off." }
            else -> NotifService.recent.takeLast(5).joinToString(". ") { "${it.first}: ${it.second}" }.ifEmpty { "Koi naya message nahi." }
        }
    }

    /** Gate (risky kaam ki confirmation) + diary + asli kaam.
     *  v5.0: Guest mode pehle (guest ko personal/risky tools nahi), phir
     *  Confirm (turn-based ROKO), phir Security auth gate (fingerprint/PIN). */
    fun run(c: Context, name: String, a: JSONObject): String {
        GuestMode.checkGuest(c, name)?.let { ActionLog.add(c, name, a, "ROKA (guest mode)"); return it }
        Confirm.gate(c, name, a)?.let { ActionLog.add(c, name, a, "ROKA (confirmation chahiye)"); return it }
        val r = Security.gateRisky(c, name, a) { runInner(c, name, a) }
        ActionLog.add(c, name, a, r)
        return r
    }

    private fun runInner(c: Context, name: String, a: JSONObject): String = try {
        // Har kaam diary mein note hota hai - Vaani aadatein yahi se seekhti hai.
        Habits.record(c, name, listOf("app", "who", "action", "query", "text", "title", "place", "name")
            .firstNotNullOfOrNull { k -> a.optString(k).takeIf { it.isNotEmpty() } } ?: "")
        AgentStatus.worker = "$name • ${AgentStatus.time()}"; AgentStatus.workerAt = System.currentTimeMillis()
        // Office ke naye agents ke apne signal: Files, Home aur Camera desk tabhi jaagegi jab unka asal kaam hoga.
        when (name) {
            "files" -> { AgentStatus.files = "files ${a.optString("action")} • ${AgentStatus.time()}"; AgentStatus.filesAt = System.currentTimeMillis() }
            "smart_home", "webhook", "pc" -> { AgentStatus.home = "$name • ${AgentStatus.time()}"; AgentStatus.homeAt = System.currentTimeMillis() }
            "look", "screen_agent" -> { AgentStatus.cam = "$name • ${AgentStatus.time()}"; AgentStatus.camAt = System.currentTimeMillis() }
        }
        when (name) {
            "call" -> number(c, a.getString("who"))?.let {
                go(c, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(it)))); "Call laga raha hu." } ?: "Contact nahi mila."
            "whatsapp" -> number(c, a.getString("who"))?.let {
                var n = it.filter { ch -> ch.isDigit() }; if (n.length == 10) n = "91$n"
                go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=" + Uri.encode(a.getString("message")))))
                "WhatsApp khol diya, bas send dabao." } ?: "Contact nahi mila."
            "open_app" -> {
                val q = a.getString("app").lowercase(); val pm = c.packageManager
                val hit = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                    .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
                if (hit == null) "App nahi mila." else {
                    go(c, pm.getLaunchIntentForPackage(hit.activityInfo.packageName)!!); "${hit.loadLabel(pm)} khol diya." }
            }
            "play_youtube" -> { go(c, Intent(Intent.ACTION_VIEW, Uri.parse(
                "https://www.youtube.com/results?search_query=" + Uri.encode(a.getString("query"))))); "YouTube par dhoondh raha hu." }
            "flashlight" -> { val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val on = a.getBoolean("on"); cm.setTorchMode(cm.cameraIdList[0], on); if (on) "Torch on." else "Torch off." }
            "media" -> {
                val code = when (a.getString("action")) { "play" -> KeyEvent.KEYCODE_MEDIA_PLAY; "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE }
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code)); "Ho gaya."
            }
            "settings" -> { go(c, Intent(when (a.getString("target")) { "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS; "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                else -> Settings.ACTION_WIRELESS_SETTINGS })); "Settings khol di." }
            "timer" -> { go(c, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Vaani")).putExtra(AlarmClock.EXTRA_SKIP_UI, true)); "Timer set." }
            "calendar_event" -> { val t = System.currentTimeMillis() + a.optInt("hours_from_now", 1) * 3600_000L
                go(c, Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI).putExtra(CalendarContract.Events.TITLE, a.getString("title"))
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, t).putExtra(CalendarContract.EXTRA_EVENT_END_TIME, t + 3600_000L)); "Event bana raha hu." }
            "call_control" -> callControl(c, a.getString("action"))
            "notifications" -> notif(c, a.getString("action"))
            "pending_reply" -> NotifService.respondPending(a.optString("action") == "send")
            "pending_read" -> NotifService.respondRead(a.optString("action") == "read")
            "files" -> Files.run(c, a.getString("action"), a.optString("path"))
            // v5.0 tools: har dispatch null lautata hai agar naam uska na ho, isliye chain safe hai.
            else -> NotifService.NotifTools.dispatch(c, name, a)
                ?: PcTools.dispatch(c, name, a)
                ?: AppActionTools.dispatch(c, name, a)
                ?: ScreenTools.dispatch(c, name, a)
                ?: ScreenIntelTools.dispatch(c, name, a)
                ?: ScreenNavTools.dispatch(c, name, a)
                ?: SyncTools.dispatch(c, name, a)
                ?: DocumentTools.dispatch(c, name, a)
                ?: TranslateTools.dispatch(c, name, a)
                ?: SecurityTools.dispatch(c, name, a)
                ?: ReminderTools.dispatch(c, name, a)
                ?: HabitTools.dispatch(c, name, a)
                ?: HealthTools.dispatch(c, name, a)
                ?: VoiceTools.dispatch(c, name, a)
                ?: Extras.run(c, name, a) ?: Automation.run(c, name, a) ?: "Ye action abhi nahi aata."
        }
    } catch (e: Exception) { "Nahi ho paya: ${e.message?.take(80)}" }
}
