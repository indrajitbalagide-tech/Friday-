package com.vaani.app

import android.app.admin.DeviceAdminReceiver

/** Device admin - sirf pakka screen-lock (lockNow) ke liye. Ise ON karna user ke haath mein hai (Settings se). */
class AdminReceiver : DeviceAdminReceiver()
