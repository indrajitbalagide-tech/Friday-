package com.vaani.app

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/*
 * WIRING (Gemini.kt / Extras.kt — inhe koi aur group edit karega, ye file nahi):
 *
 * Gemini.kt — tools lazy block mein, `for (d in Extras.decls()) fd.put(d)` ke baad:
 *     for (i in 0 until HealthTools.decls().length()) fd.put(HealthTools.decls().getJSONObject(i))
 *
 * Extras.kt — run() ke when() mein:
 *     "health_summary", "health_water" ->
 *         HealthTools.dispatch(c, name, a) ?: "Ye health action nahi aata."
 *
 * HEALTH CONNECT SETUP (phone par, ek baar — code se nahi hota):
 *   1. Play Store se "Health Connect by Android" install karo (Android 14+ par system mein hota hai).
 *   2. Health Connect app kholo > App permissions > Vaani ko Steps + Sleep padhne ki permission do.
 *   3. Vaani se "health setup karo" bolo — settings khul jayengi.
 *   NOTE: app/build.gradle.kts mein androidx.health.connect.client dependency NAHI hai,
 *   isliye ye file us library ko hard-import nahi karti (build toot-ta nahi). Steps/sleep
 *   seedhe Health Connect se tabhi padhe jayenge jab dependency add ho — tab Health.kt
 *   ka `readFromHealthConnect()` hissa likha jayega. Tab tak steps/sleep wahi dikhte hain
 *   jo user ne khud bataye (health_summary mein steps/sleep_hours dekar) ya jo pehle
 *   log hue — aur paani ka hisaab hamesha local prefs mein chalta hai.
 */

/**
 * Health — sirf phone ka local data, kahin upload nahi hota, koi network call nahi.
 * Har health reply mein disclaimer: "Main doctor nahi hoon, ye sirf aapke phone ka data hai."
 * Password/PIN/OTP ki tarah health data bhi kabhi yaad-dasht (Memory) mein nahi likha jaata.
 */
object Health {
    const val DISCLAIMER = "Main doctor nahi hoon, ye sirf aapke phone ka data hai."
    private const val WATER_GOAL = 8          // din bhar 8 glass ka lakshya
    private const val STEPS_GOAL_DEFAULT = 10000
    private const val HC_SETTINGS_ACTION = "androidx.health.connect.action.HEALTH_CONNECT_SETTINGS"
    private const val HC_PACKAGE = "com.google.android.apps.healthdata"

    private fun dayKey(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    private fun waterKey() = "health_water_${dayKey()}"
    private fun stepsKey() = "health_steps_${dayKey()}"
    private fun sleepKey() = "health_sleep_${dayKey()}"

    // ---------------- paani ----------------

    fun waterToday(c: Context): Int = P.of(c).getInt(waterKey(), 0)

    /** Ek glass paani piya — local hisaab badhao, aaj ki ginti lautao. */
    fun logWater(c: Context, glasses: Int = 1): Int {
        val n = (waterToday(c) + glasses.coerceIn(1, 10)).coerceAtMost(50)
        P.of(c).edit().putInt(waterKey(), n).apply()
        return n
    }

    /** Samay ke hisaab se paani yaad dilane wala text (aaj ki ginti ke saath). */
    fun waterReminderText(c: Context): String {
        val n = waterToday(c)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val head = when (hour) {
            in 5..10 -> "Subah ka pehla glass paani pi lo"
            in 11..16 -> "Dopahar mein paani peena mat bhoolo"
            in 17..21 -> "Shaam ho gayi hai, ek glass paani aur pi lo"
            else -> "Sone se pehle halka sa paani pi lo"
        }
        return "$head — aaj abhi tak $n glass ($WATER_GOAL glass ka lakshya hai)." +
            if (n >= WATER_GOAL) " Lakshya poora, badhai!" else " Abhi ${WATER_GOAL - n} glass baaki hai."
    }

    // ---------------- steps / neend (local log; Health Connect judne par yahi bharega) ----------------

    /** Aaj ke steps: -1 = abhi record nahi hain. */
    fun stepsToday(c: Context): Int = P.of(c).getInt(stepsKey(), -1)

    fun logSteps(c: Context, steps: Int): Int {
        val n = steps.coerceIn(0, 100000)
        P.of(c).edit().putInt(stepsKey(), n).apply()
        return n
    }

    /** Aaj ki neend (ghante): -1f = abhi record nahi hai. */
    fun sleepHours(c: Context): Float = P.of(c).getFloat(sleepKey(), -1f)

    fun logSleep(c: Context, hours: Float): Float {
        val h = hours.coerceIn(0f, 24f)
        P.of(c).edit().putFloat(sleepKey(), h).apply()
        return h
    }

    /** Step-goal check: lakshya (default 10,000) ke mukable aaj kahan khade ho. */
    fun stepGoalCheck(c: Context, goal: Int = STEPS_GOAL_DEFAULT): String {
        val steps = stepsToday(c)
        if (steps < 0) return "Aaj ke steps abhi record nahi hain — Health Connect setup karo ya 'aaj 8000 steps chale' batao."
        return if (steps >= goal) "Aaj $steps steps — $goal ka lakshya poora, badhai!"
        else "Aaj $steps steps hue hain, lakshya $goal se ${goal - steps} kam hai — thoda aur chalo."
    }

    // ---------------- Health Connect (Intent — bina library ke) ----------------

    /** Health Connect app phone par installed hai ya Android 14+ system mein hai? */
    fun healthConnectInstalled(c: Context): Boolean {
        return try {
            c.packageManager.getPackageInfo(HC_PACKAGE, 0); true
        } catch (_: Exception) {
            // Android 14+ par Health Connect system service ho sakta hai — settings intent se pata chalega.
            val i = Intent(HC_SETTINGS_ACTION)
            i.resolveActivity(c.packageManager) != null
        }
    }

    /** Health Connect ki settings kholo taaki user Vaani ko Steps/Sleep permission de sake. */
    fun openHealthConnectSettings(c: Context): String {
        return try {
            val i = Intent(HC_SETTINGS_ACTION)
            if (i.resolveActivity(c.packageManager) == null)
                return "Health Connect app phone par nahi mila — Play Store se 'Health Connect by Android' install karo, phir dobara bolo."
            c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Health Connect settings khol di — wahan Vaani ko Steps aur Sleep padhne ki permission do. $DISCLAIMER"
        } catch (e: Exception) {
            "Health Connect settings nahi khul payi: ${e.message?.take(60)}"
        }
    }

    /**
     * Health Connect se seedha padhna: dependency (androidx.health.connect.client) build mein
     * nahi hai, isliye ye STUB hai — hamesha null. Dependency add hote hi yahan Steps +
     * SleepSession read (last 24h) likha jayega aur summary() use karega.
     */
    fun readFromHealthConnect(c: Context): JSONObject? = null

    /** Aaj ka health summary: steps, neend, paani — hamesha disclaimer ke saath, sirf local data. */
    fun summary(c: Context): String {
        val steps = stepsToday(c)
        val sleep = sleepHours(c)
        val water = waterToday(c)
        val sb = StringBuilder("Aaj ki health: ")
        sb.append(if (steps >= 0) "steps $steps. " else "steps record nahi hain — Health Connect setup karo ya mujhe batao. ")
        sb.append(if (sleep >= 0) "Neend ${"%.1f".format(sleep)} ghante. " else "Neend record nahi hai. ")
        sb.append("Paani $water/$WATER_GOAL glass. ")
        sb.append(stepGoalCheck(c)).append(" ")
        sb.append(DISCLAIMER).append(" Ye data sirf aapke phone par hai, kahin upload nahi hota.")
        return sb.toString()
    }
}

/** Gemini tools: health_summary / health_water. */
object HealthTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun ip(d: String) = JSONObject().put("type", "INTEGER").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject>, req: List<String> = emptyList()): JSONObject {
        val p = JSONObject(); for ((k, v) in props) p.put(k, v)
        val params = JSONObject().put("type", "OBJECT").put("properties", p)
        if (req.isNotEmpty()) params.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("parameters", params)
    }

    fun decls(): JSONArray = JSONArray().put(fn("health_summary",
        "Aaj ka health summary: steps, neend (ghante), paani ke glass. Steps/sleep_hours dekar user ki batayi value bhi log hoti hai. Har jawab mein doctor-nahi-hoon disclaimer aata hai.",
        mapOf("steps" to ip("aaj ke steps (user ne bataye to, optional)"),
            "sleep_hours" to ip("pichhli raat ki neend ghante mein (optional)"))))
        .put(fn("health_water",
            "Paani ka hisaab: log = ek glass piya note karo; remind = paani yaad dilao; count = aaj kitne glass hue.",
            mapOf("action" to sp("log|remind|count"), "glasses" to ip("log ke liye kitne glass, default 1")), listOf("action")))

    /** Unknown naam par null (taaki Actions/Extras aage fall-through kar sake). */
    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "health_summary" -> {
            if (a.has("steps") && a.optInt("steps", 0) > 0) Health.logSteps(c, a.optInt("steps"))
            if (a.has("sleep_hours") && a.optDouble("sleep_hours", 0.0) > 0) Health.logSleep(c, a.optDouble("sleep_hours").toFloat())
            Health.summary(c)
        }
        "health_water" -> when (a.optString("action")) {
            "log" -> {
                val n = Health.logWater(c, a.optInt("glasses", 1))
                "Note kar liya — aaj $n glass paani ho gaya. ${Health.DISCLAIMER}"
            }
            "remind" -> Health.waterReminderText(c) + " " + Health.DISCLAIMER
            "count" -> "Aaj ${Health.waterToday(c)} glass paani pi liya hai. ${Health.DISCLAIMER}"
            else -> "Paani ke liye action batao: log (pi liya), remind (yaad dilao), ya count (kitne hue)."
        }
        else -> null
    }
}
