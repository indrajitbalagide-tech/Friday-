package com.vaani.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.CallLog
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Location helper (last known + taaza fix). */
object Loc {
    @SuppressLint("MissingPermission")
    fun last(c: Context): Location? {
        if (!Perm.has(c, Manifest.permission.ACCESS_FINE_LOCATION)) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.getProviders(true).mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }.maxByOrNull { it.time }
    }

    @SuppressLint("MissingPermission")
    fun fresh(c: Context): Location? {
        if (!Perm.has(c, Manifest.permission.ACCESS_FINE_LOCATION)) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (Build.VERSION.SDK_INT >= 30) {
            val prov = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
                .firstOrNull { try { lm.isProviderEnabled(it) } catch (e: Exception) { false } } ?: return last(c)
            val latch = CountDownLatch(1); var res: Location? = null
            try { lm.getCurrentLocation(prov, null, c.mainExecutor) { l -> res = l; latch.countDown() } }
            catch (e: Exception) { return last(c) }
            latch.await(10, TimeUnit.SECONDS)
            return res ?: last(c)
        }
        return last(c)
    }

    fun dist(l: Location, lat: Double, lon: Double): Float {
        val r = FloatArray(1); Location.distanceBetween(l.latitude, l.longitude, lat, lon, r); return r[0]
    }
}

/** Asli jaankari wale tools: web jawab, mausam, calendar, call log, SMS, location. */
object Info {
    fun run(c: Context, name: String, a: JSONObject): String? = when (name) {
        "web_answer" -> webAnswer(c, a.getString("query"))
        "weather" -> weather(c, a.optString("place"))
        "calendar_read" -> calendar(c, a.optInt("hours", 24))
        "call_log" -> callLog(c, a.optInt("count", 6))
        "sms_read" -> sms(c, a.optString("from"), a.optInt("count", 4))
        "my_location" -> where(c)
        else -> null
    }

    private fun txt(parts: JSONArray): String {
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString().trim()
    }

    /** Google Search grounding: Vaani khud web padhkar jawab deti hai (sirf browser nahi kholti). */
    fun webAnswer(c: Context, q: String): String {
        val key = P.of(c).getString("key", "").orEmpty()
        if (key.isEmpty()) return "API key nahi hai."
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                "Answer using Google Search. Reply in the user's language (Hinglish by default), plain text, max 3 short sentences, no markdown."))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", q)))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        return txt(Gemini.post(key, body).getJSONArray("parts")).ifEmpty { "Kuch nahi mila." }
    }

    private fun wmo(code: Int) = when (code) {
        0 -> "saaf aasman"; 1, 2 -> "halke badal"; 3 -> "badal chhaye"; 45, 48 -> "kohra"
        in 51..57 -> "phuhaar"; in 61..67 -> "baarish"; in 71..77 -> "barf"
        in 80..82 -> "tez baarish ki bauchhaar"; in 95..99 -> "aandhi-toofan"; else -> "mausam badla hua"
    }

    fun weather(c: Context, place: String): String {
        return try {
            val lat: Double; val lon: Double; val label: String
            if (place.isNotBlank()) {
                val g = JSONObject(Net.get("https://geocoding-api.open-meteo.com/v1/search?name=${Uri.encode(place)}&count=1"))
                    .optJSONArray("results")?.optJSONObject(0) ?: return "'$place' jagah nahi mili."
                lat = g.getDouble("latitude"); lon = g.getDouble("longitude"); label = g.optString("name", place)
            } else {
                val l = Loc.fresh(c) ?: return "Location nahi mili - location permission/GPS on karo ya jagah ka naam batao."
                lat = l.latitude; lon = l.longitude; label = "Yahan"
            }
            val j = JSONObject(Net.get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,apparent_temperature,weather_code&daily=temperature_2m_max,temperature_2m_min," +
                "precipitation_probability_max&timezone=auto&forecast_days=1"))
            val cur = j.getJSONObject("current"); val d = j.getJSONObject("daily")
            "$label: abhi ${Math.round(cur.getDouble("temperature_2m"))}°C (mehsoos ${Math.round(cur.getDouble("apparent_temperature"))}°C), " +
                "${wmo(cur.getInt("weather_code"))}. Aaj ${Math.round(d.getJSONArray("temperature_2m_min").getDouble(0))} se " +
                "${Math.round(d.getJSONArray("temperature_2m_max").getDouble(0))}°C, baarish ki sambhavna ${d.getJSONArray("precipitation_probability_max").optInt(0)}%."
        } catch (e: Exception) { "Mausam nahi mil paya: ${e.message?.take(60)}" }
    }

    /** (title, begin, location) - all-day events chhodkar. */
    fun events(c: Context, start: Long, end: Long): List<Triple<String, Long, String>> {
        if (!Perm.has(c, Manifest.permission.READ_CALENDAR)) return emptyList()
        val out = ArrayList<Triple<String, Long, String>>()
        try {
            val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(b, start); ContentUris.appendId(b, end)
            c.contentResolver.query(b.build(), arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY), null, null,
                "${CalendarContract.Instances.BEGIN} ASC")?.use { cur ->
                while (cur.moveToNext() && out.size < 15) {
                    if (cur.getInt(3) == 1) continue
                    out.add(Triple(cur.getString(0) ?: "(bina naam)", cur.getLong(1), cur.getString(2) ?: ""))
                }
            }
        } catch (_: Exception) {}
        return out
    }

    fun calendar(c: Context, hours: Int): String {
        if (!Perm.has(c, Manifest.permission.READ_CALENDAR)) return "Calendar permission nahi hai - Vaani app kholke allow karo."
        val now = System.currentTimeMillis()
        val f = SimpleDateFormat("EEE HH:mm", Locale.getDefault())
        val ev = events(c, now, now + hours.coerceIn(1, 168) * 3600_000L)
        return if (ev.isEmpty()) "Is dauran koi event nahi hai." else
            ev.take(10).joinToString("; ") { "${f.format(it.second)} ${it.first}" + if (it.third.isNotEmpty()) " (${it.third})" else "" }
    }

    private fun nameFor(c: Context, num: String?): String {
        if (num.isNullOrEmpty()) return "anjaan"
        if (!Perm.has(c, Manifest.permission.READ_CONTACTS)) return num
        try {
            c.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) return it.getString(0) }
        } catch (_: Exception) {}
        return num
    }

    fun callLog(c: Context, n: Int): String {
        if (!Perm.has(c, Manifest.permission.READ_CALL_LOG)) return "Call log permission nahi hai."
        val out = ArrayList<String>(); val f = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
        try {
            c.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE, CallLog.Calls.DATE), null, null, "${CallLog.Calls.DATE} DESC")?.use { cur ->
                while (cur.moveToNext() && out.size < n.coerceIn(1, 15)) {
                    val who = cur.getString(1) ?: nameFor(c, cur.getString(0))
                    val t = when (cur.getInt(2)) { CallLog.Calls.INCOMING_TYPE -> "aaya"; CallLog.Calls.OUTGOING_TYPE -> "gaya"
                        CallLog.Calls.MISSED_TYPE -> "MISSED"; else -> "call" }
                    out.add("$who $t (${f.format(cur.getLong(3))})")
                }
            }
        } catch (e: Exception) { return "Call log nahi padh paya." }
        return if (out.isEmpty()) "Call log khali hai." else out.joinToString("; ")
    }

    fun sms(c: Context, from: String, n: Int): String {
        if (!Perm.has(c, Manifest.permission.READ_SMS)) return "SMS permission nahi hai - Vaani app kholke allow karo."
        val out = ArrayList<String>(); val want = from.trim().lowercase()
        try {
            c.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
                null, null, "${Telephony.Sms.DATE} DESC")?.use { cur ->
                var scanned = 0
                while (cur.moveToNext() && out.size < n.coerceIn(1, 8) && scanned++ < 300) {
                    val addr = cur.getString(0) ?: ""; val who = nameFor(c, addr)
                    if (want.isNotEmpty() && !who.lowercase().contains(want) && !addr.lowercase().contains(want)) continue
                    out.add("$who: ${(cur.getString(1) ?: "").take(120)}")
                }
            }
        } catch (e: Exception) { return "SMS nahi padh paya." }
        return if (out.isEmpty()) "Koi SMS nahi mila." else out.joinToString(" | ")
    }

    fun where(c: Context): String {
        val l = Loc.fresh(c) ?: return "Location nahi mili - location permission aur GPS check karo."
        return try {
            @Suppress("DEPRECATION")
            val ad = Geocoder(c, Locale.getDefault()).getFromLocation(l.latitude, l.longitude, 1)?.firstOrNull()
            ad?.getAddressLine(0) ?: "${l.latitude}, ${l.longitude}"
        } catch (e: Exception) { "${l.latitude}, ${l.longitude}" }
    }
}
