package com.vaani.app

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

/*
 * FEATURE 12 — Security layer.
 *
 * DEPENDENCY NOTE (zaroori): app/build.gradle.kts mein androidx.biometric ki
 * dependency NAHI hai. Isiliye BiometricPrompt library use nahi ki gayi —
 * uska import compile fail karta. Fallback (aur is waqt ka asal rasta):
 * KeyguardManager.createConfirmDeviceCredentialIntent() — phone ka system
 * lock screen (fingerprint / PIN / pattern — jo bhi user ne lock screen par
 * set kiya hai, wahi). Ye framework API hai, koi extra dependency nahi
 * chahiye. Jab kabhi androidx.biometric dependency add ho, tab Security.requireAuth
 * ko BiometricPrompt par badla ja sakta hai; gateRisky / isRisky / GuestMode
 * ka API waisa hi rahega.
 *
 * Auth window: ek baar confirm karne par 5 minute tak risky kaam chal sakta
 * hai (prefs "last_auth_at"). 5 minute baad dobara confirm karna padega.
 * Kabhi bhi password / PIN / OTP save nahi hota — sirf "kab confirm hua"
 * ka timestamp save hota hai (long).
 *
 * Voiceprint: GuestMode sirf VoicePrint.enrolled() / verify() ka natija
 * padhta hai. Voiceprint data (vp_center / vp_sd / vp_thr) pehle se hi app-
 * private SharedPreferences ("vaani", MODE_PRIVATE) mein hai — use kahin
 * aur copy / upload / export nahi kiya jata. Ye file voiceprint ko haath
 * nahi lagati.
 */

/** Risky actions ke liye device lock-screen (fingerprint/PIN/pattern) auth. */
object Security {
    const val AUTH_REQUEST_CODE = 9001
    private const val AUTH_WINDOW_MS = 5 * 60 * 1000L  // 5 minute

    /** Kaun se tool risky hain — in par confirm-first + auth dono lagte hain. */
    fun isRisky(toolName: String): Boolean = toolName.lowercase().trim() in setOf(
        // Payment / paise (aaj inme se kuch tools hain nahi, par naam aate hi gate lagega)
        "payment", "upi_pay", "send_money", "pay", "transfer",
        // Delete
        "files",            // sirf delete action par (gateRisky mein action bhi check hota hai)
        "delete",
        // Auto-reply: aapke naam se jawab jayenge
        "notifications",    // sirf enable_auto_reply action par
        // PC shutdown / control
        "pc",               // sirf shutdown/restart/sleep/run action par
        "screen_agent"      // phone par khud steps chalana
    )

    /** Is (tool + args) combo par auth chahiye ya nahi — action-level check. */
    fun needsAuth(toolName: String, args: JSONObject): Boolean {
        return when (toolName.lowercase().trim()) {
            "files" -> args.optString("action") == "delete"
            "notifications" -> args.optString("action") == "enable_auto_reply"
            "pc" -> args.optString("action") in setOf("shutdown", "restart", "sleep", "run")
            "payment", "upi_pay", "send_money", "pay", "transfer", "delete", "screen_agent" -> true
            else -> false
        }
    }

    /** Pichhle 5 minute mein lock-screen se confirm hua ho to true. */
    fun isAuthenticated(c: Context): Boolean {
        val at = P.of(c).getLong("last_auth_at", 0L)
        return at > 0L && System.currentTimeMillis() - at < AUTH_WINDOW_MS
    }

    /** Auth kaamyaab hone par bulao — 5 minute ki window shuru hoti hai. */
    fun markAuthenticated(c: Context) {
        P.of(c).edit().putLong("last_auth_at", System.currentTimeMillis()).apply()
    }

    /**
     * System lock-screen confirm karne wala Intent banao (fingerprint / PIN /
     * pattern — jo lock screen par set hai). Null mile to phone par koi lock
     * hi set nahi hai — user ko pehle Settings > Security mein lock lagana
     * padega. Activity se startActivityForResult(intent, AUTH_REQUEST_CODE)
     * se chalao; result Security.onAuthResult() ko do.
     */
    fun authIntent(c: Context, reason: String): Intent? {
        val km = c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceSecure) return null
        return km.createConfirmDeviceCredentialIntent("Vaani — confirm karo", reason)
    }

    /**
     * UI flow: Activity se bulao. Lock set hai to confirm screen khulti hai
     * aur onOk tabhi chalta hai jab onAuthResult() success bataye.
     * NOTE: onOk turant nahi chalta — user ke confirm karne ke baad Activity
     * ke onActivityResult mein Security.onAuthResult() bulao, wahan se onOk.
     * Isiliye requireAuth sirf screen kholta hai aur false/true batata hai
     * (screen khuli ya nahi); asal kaam onAuthResult ke baad hota hai.
     */
    fun requireAuth(ctx: Context, activity: Activity, reason: String, onOk: () -> Unit): Boolean {
        val intent = authIntent(ctx, reason)
            ?: return false  // lock set hi nahi — caller "pehle lock lagao" bataye
        PendingAuth.onOk = onOk
        PendingAuth.ctx = ctx.applicationContext
        activity.startActivityForResult(intent, AUTH_REQUEST_CODE)
        return true
    }

    /** Activity.onActivityResult se bulao. Success ho to onOk chalakar true lautata hai. */
    fun onAuthResult(c: Context, requestCode: Int, resultCode: Int): Boolean {
        if (requestCode != AUTH_REQUEST_CODE) return false
        if (resultCode != Activity.RESULT_OK) {
            PendingAuth.onOk = null; PendingAuth.ctx = null
            return false
        }
        markAuthenticated(c)
        val ok = PendingAuth.onOk; PendingAuth.onOk = null; PendingAuth.ctx = null
        try { ok?.invoke() } catch (_: Exception) {}
        return true
    }

    /**
     * Tool dispatch ke andar ka gate: risky kaam ho aur pichhle 5 minute mein
     * auth na hua ho to proceed() chalaye bina Hinglish mein roko; warna
     * proceed() chalao aur uska result lautao. Ye Safety.Confirm (turn-based
     * ROKO) ki jagah nahi leta — dono lagte hain: pehle Confirm, phir auth.
     */
    fun gateRisky(c: Context, toolName: String, args: JSONObject, proceed: () -> String): String {
        if (!needsAuth(toolName, args)) return proceed()
        if (isAuthenticated(c)) return proceed()
        return "Pehle fingerprint/PIN se confirm karo — security_auth tool se auth karo, phir dobara bolo. " +
            "Bina confirm kiye ye kaam nahi karungi."
    }

    /** Auth screen khulne ke beech onOk ko rakhne ke liye (memory mein hi, kahin save nahi hota). */
    private object PendingAuth {
        var onOk: (() -> Unit)? = null
        var ctx: Context? = null
    }
}

/**
 * Guest Mode: malik ki awaaz match na kare (ya guest mode on ho) to sirf
 * basic tools. Guest ko kabhi nahi milta: messages, payments, personal data
 * (memory / call log / SMS / calendar / notifications), call (malik ke
 * contacts guest ke nahi hote — isiliye call bhi allowed list mein NAHI hai).
 */
object GuestMode {
    /** Guest mode on hai ya nahi (prefs "guest_mode"). */
    fun isGuest(c: Context): Boolean = P.of(c).getBoolean("guest_mode", false)

    fun setGuest(c: Context, on: Boolean): String {
        P.of(c).edit().putBoolean("guest_mode", on).apply()
        return if (on) "Guest mode on. Ab sirf basic cheezein chalengi — time, mausam, app kholna, search. " +
            "Messages, payments aur personal data band hai."
        else "Guest mode off. Malik wapas aa gaya — saare features khul gaye."
    }

    /**
     * Voice-match ke natije se guest mode lagao: VoicePrint.verify() false
     * aaye to guest on kar do. frames yahan nahi aate — VaaniService ke
     * tryVerify() wale flow se bulao (snippet README/report mein).
     * enrolled() false ho (awaaz kabhi enroll hi nahi hui) to guest force
     * mat karo — pehli baar setup chal raha hoga.
     */
    fun applyVoiceResult(c: Context, voiceMatched: Boolean): String? {
        val vp = VoicePrint(c)
        if (!vp.enrolled()) return null  // enroll hi nahi hua — guest nahi, setup baaki hai
        return if (voiceMatched) {
            if (isGuest(c)) setGuest(c, false) else null
        } else {
            if (!isGuest(c)) setGuest(c, true) else "Guest mode pehle se on hai."
        }
    }

    /** Guest ko allowed basic tools (sirf ye — baaki sab par checkGuest rokega). */
    fun allowedToolsGuest(): Set<String> = setOf(
        "weather",      // mausam
        "open_app",     // app kholna
        "web_search",   // search
        "web_answer",   // taaza jaankari
        "look"          // camera/screen dekhna (screen par password/PIN dikhe to Vision khud rukta hai)
        // NOTE: "call" jaan-boojhkar NAHI hai — guest ke paas malik ke contacts nahi hote.
        // "time" ka alag tool nahi hai; waqt system prompt mein pehle se aata hai (Brain.system).
    )

    /**
     * Har tool call se pehle bulao (Actions.run / Gemini dispatch mein — snippet
     * README/report mein). Guest ho aur tool allowed list mein na ho to
     * Hinglish refusal lautata hai; warna null (chalne do).
     */
    fun checkGuest(c: Context, toolName: String): String? {
        if (!isGuest(c)) return null
        if (toolName.lowercase().trim() in allowedToolsGuest()) return null
        return "Guest mode on hai — ye kaam sirf malik ke liye hai. " +
            "Messages, payments, calls, personal data aur settings guest ko nahi milte. " +
            "Malik apni awaaz se bolkar guest mode band kar sakta hai."
    }
}

/** Gemini tools: security_auth + guest_mode. */
object SecurityTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("security_auth", "Risky kaam (payment, delete, auto-reply, PC shutdown) se pehle fingerprint/PIN se confirm karo.",
            mapOf("action" to sp("start | status"), "reason" to sp("kis kaam ke liye confirm kar rahe ho (optional)")),
            listOf("action")),
        fn("guest_mode", "Guest mode on/off karo ya status dekho. Guest ko sirf basic tools milte hain.",
            mapOf("action" to sp("on | off | status")), listOf("action"))
    )

    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "security_auth" -> when (a.optString("action")) {
            "status" -> if (Security.isAuthenticated(c))
                "Auth abhi valid hai (pichhle 5 minute mein confirm hua tha)."
            else
                "Abhi auth nahi hua hai. Risky kaam se pehle fingerprint/PIN se confirm karna padega."
            // "start": tool ke paas Activity nahi hoti, isiliye yahan sirf
            // bataya jata hai ki aage kya hoga. Asal confirm screen MainActivity /
            // VaaniService se Security.requireAuth() se khulti hai (snippet README mein).
            // Agar ctx hi Activity ho to seedha screen kholo.
            "start" -> {
                val reason = a.optString("reason").ifEmpty { "Risky kaam confirm karna hai" }
                val act = c as? Activity
                if (act != null) {
                    val opened = Security.requireAuth(c, act, reason) { /* result onAuthResult se aayega */ }
                    if (opened) "Confirm screen khol di — fingerprint ya PIN lagao, phir dobara bolo."
                    else "Phone par koi lock (fingerprint/PIN/pattern) set nahi hai. Pehle Settings > Security mein lock lagao, phir auth karo."
                } else {
                    "Auth ke liye phone ki confirm screen chahiye — MainActivity kholo aur wahan se confirm karo. " +
                        "Bina confirm kiye risky kaam nahi hoga."
                }
            }
            else -> "security_auth: action 'start' ya 'status' do."
        }
        "guest_mode" -> when (a.optString("action")) {
            "on" -> GuestMode.setGuest(c, true)
            "off" -> GuestMode.setGuest(c, false)
            "status" -> if (GuestMode.isGuest(c))
                "Guest mode ON hai — sirf basic tools (mausam, app kholna, search) chalenge."
            else
                "Guest mode OFF hai — malik mode mein ho."
            else -> "guest_mode: action 'on', 'off' ya 'status' do."
        }
        else -> null
    }
}
