package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/*
 * FEATURE 5 — Live translation (Hindi <-> English <-> Marathi).
 *
 * Implementation: Gemini ask() with a translation-only prompt (useTools=false,
 * taaki translation ke beech mein koi phone action trigger na ho). Offline
 * ya bina key ke fallback: original text + saaf note (galat translation
 * banakar dena se behtar hai).
 * LiveClient.kt ko CHHEDA NAHI gaya hai — LiveTranslate sirf prefs mein mode
 * rakhta hai aur Gemini REST se translate karta hai; Live session ke andar
 * koi wire-in nahi hai (wiring README/report dekho).
 * Kabhi bhi password / PIN / OTP translate karke save nahi hota.
 */
object TranslateTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("translate", "Kisi bhi text ko Hindi, English ya Marathi mein translate karo.",
            mapOf("text" to sp("translate karne wala text"),
                "from" to sp("source language: hi | en | mr | auto (default auto)"),
                "to" to sp("target language: hi | en | mr (default en)")),
            listOf("text")),
        fn("translate_board", "Saamne wale board / sign par kya likha hai, use padhkar translate karke batao (camera se).",
            mapOf("to" to sp("kis bhasha mein batana hai: hi | en | mr (default hi)")))
    )

    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "translate" -> Translator.translate(c, a.getString("text"), a.optString("from", "auto"), a.optString("to", "en"))
        "translate_board" -> LiveTranslate.translateBoard(c, a.optString("to", "hi"))
        else -> null
    }
}

/** Gemini se translation (no tools) + offline fallback. */
object Translator {
    private val LANG_NAME = mapOf("hi" to "Hindi", "en" to "English", "mr" to "Marathi", "auto" to "auto-detect")

    fun langName(code: String): String = LANG_NAME[code.lowercase().trim()] ?: code

    /**
     * text ko from -> to mein translate karo. from="auto" ho to Gemini khud
     * pehchanta hai. Key na ho ya network na chale to original text + note.
     */
    fun translate(c: Context, text: String, from: String, to: String): String {
        val t = text.trim()
        if (t.isEmpty()) return "Translate karne ke liye koi text nahi diya."
        val src = from.lowercase().trim().ifEmpty { "auto" }
        val dst = to.lowercase().trim().ifEmpty { "en" }
        if (src == dst && src != "auto") return t  // same language — kuch karna hi nahi
        val key = P.of(c).getString("key", "").orEmpty()
        if (key.isEmpty()) return "$t\n(Translate nahi ho paya — Gemini key nahi hai. Settings mein API key daalo.)"
        return try {
            val prompt = if (src == "auto")
                "Translate this text to ${langName(dst)}. Reply with ONLY the translated text, no explanation, no quotes:\n\n$t"
            else
                "Translate this text from ${langName(src)} to ${langName(dst)}. Reply with ONLY the translated text, no explanation, no quotes:\n\n$t"
            // useTools=false: translation ke dauraan model koi tool na bulaye.
            val parts = Gemini.ask(key, prompt, false)
            val out = (0 until parts.length()).mapNotNull { parts.getJSONObject(it).optString("text").ifEmpty { null } }.joinToString(" ").trim()
            out.ifEmpty { "$t\n(Translation khaali aaya — dobara try karo.)" }
        } catch (e: Exception) {
            "$t\n(Translate nahi ho paya: ${e.message?.take(80)} — offline ho ya key mein dikkat hai.)"
        }
    }
}

/**
 * Live translation mode: do bhashaon ke beech baat-cheet.
 * State sirf SharedPreferences ("vaani") mein: live_tr_on, live_tr_a, live_tr_b.
 * Bolte waqt Vaani Live session se sunti hai; ye mode sirf batata hai ki
 * kaun si jodi active hai aur kis direction mein translate karna hai.
 * Asli live wire-in (LiveClient ke system prompt mein jodi jodna) coordinator
 * ke paas hai — README/report mein snippet hai.
 */
object LiveTranslate {
    fun startMode(c: Context, langA: String, langB: String): String {
        val a = langA.lowercase().trim(); val b = langB.lowercase().trim()
        if (a !in setOf("hi", "en", "mr") || b !in setOf("hi", "en", "mr") || a == b)
            return "Live translation ke liye do alag bhasha chahiye — hi, en ya mr mein se (jaise hi aur en)."
        P.of(c).edit().putBoolean("live_tr_on", true).putString("live_tr_a", a).putString("live_tr_b", b).apply()
        return "Live translation on: ${Translator.langName(a)} <-> ${Translator.langName(b)}. " +
            "Ab jo bhi bologe, use doosri bhasha mein bolkar bataungi. Band karne ke liye 'live translation band karo' bolo."
    }

    fun stopMode(c: Context): String {
        P.of(c).edit().putBoolean("live_tr_on", false).apply()
        return "Live translation band ho gaya."
    }

    fun isActive(c: Context): Boolean = P.of(c).getBoolean("live_tr_on", false)

    /** Active jodi, nahi to null. */
    fun pair(c: Context): Pair<String, String>? {
        if (!isActive(c)) return null
        val a = P.of(c).getString("live_tr_a", "hi") ?: "hi"
        val b = P.of(c).getString("live_tr_b", "en") ?: "en"
        return a to b
    }

    /**
     * Live mode mein boli hui baat ka translation: fromLang jo bhi ho, use
     * jodi ki doosri bhasha mein badlo. Mode off ho to seedha translate karo.
     */
    fun translateSpoken(c: Context, text: String, fromLang: String): String {
        val pair = pair(c) ?: return Translator.translate(c, text, fromLang, "hi")
        val (a, b) = pair
        val target = if (fromLang.lowercase().trim() == a) b else a
        return Translator.translate(c, text, fromLang, target)
    }

    /**
     * "Ye board kya keh raha hai" — camera se board padhkar translate karo.
     * Vision.look ka existing camera path use hota hai (camera permission +
     * Gemini key chahiye). STUB NAHI HAI — Vision.look public hai — par do
     * limits hain: (1) ye sirf ek still photo leta hai, live video OCR nahi;
     * (2) board tedha / andhere mein ho to padhna chhoot sakta hai.
     */
    fun readBoard(c: Context): String {
        val key = P.of(c).getString("key", "").orEmpty()
        if (key.isEmpty()) return "Board padhne ke liye Gemini key chahiye. Settings mein API key daalo."
        return Vision.look(c, "camera_back",
            "Is board / sign par jo bhi text likha hai, use bilkul waise hi padhkar likh do. " +
                "Agar text kisi aur bhasha mein ho to uska matlab bhi ek line mein batao.")
    }

    /** Board padho, phir `to` bhasha mein translate karke Hinglish mein batao. */
    fun translateBoard(c: Context, to: String): String {
        val boardText = readBoard(c)
        if (boardText.startsWith("Board padhne") || boardText.startsWith("API key") || boardText.startsWith("Camera se"))
            return boardText
        val dst = to.lowercase().trim().ifEmpty { "hi" }
        val translated = Translator.translate(c, boardText, "auto", dst)
        return "Board par likha hai: $boardText\nMatlab (${Translator.langName(dst)}): $translated"
    }
}
