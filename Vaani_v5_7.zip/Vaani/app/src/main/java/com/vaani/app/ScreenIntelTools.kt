package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Group B — screen-intelligence tools (Features 1, 2, 4).
 *
 * Tools:
 * - screen_read_live : live screen padhna — action start|stop|status.
 *   Action value "screen_watch" bhi start jaisa hi hai (alias, alag tool nahi hai).
 * - ocr_screen      : screen ka saara text (screenshot OCR + node-tree merge).
 * - screen_analyse  : screen kya hai, yahan kya kar sakte ho, kya important hai.
 *
 * WIRING (coordinator ke liye — is file mein koi aur file edit nahi ki gayi):
 *   Gemini.kt `tools` lazy block mein:
 *       for (d in ScreenIntelTools.decls()) if (seen.add(d.optString("name"))) fd.put(d)
 *   Actions.kt/Extras.kt chain mein (Info.run ke baad, AppActionTools.dispatch ke saath):
 *       ScreenIntelTools.dispatch(c, name, a) ?: ...
 *   Safety.kt Confirm.gate mein (optional): "screen_read_live" / "ocr_screen" /
 *   "screen_analyse" -> "screen padhna / OCR karna: ..." (koi send/payment nahi hota,
 *   isliye gate zaroori nahi — sirf read-only tools hain).
 *
 * Threading: dispatch Gemini askAgent thread (background) se aata hai — screenshot aur
 * Gemini calls wahin blocking chalte hain, main thread block nahi hota. Live watcher ka
 * delta sirf diff + Speaker.speak karta hai (Speaker apna thread banata hai).
 */
object ScreenIntelTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)

    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("screen_read_live",
            "Screen ko live padhna shuru/band karo ya status poochho: start karne par screen par jo naya aayega " +
                "(naya message, button, notification) Vaani bol kar batayegi; payment/password wali screen aate hi khud ruk jayegi. " +
                "10 minute kuch naya na aaye to apne aap band ho jata hai. Accessibility ON honi chahiye.",
            mapOf("action" to sp("start|stop|status — 'screen_watch' bhi start jaisa hi hai")),
            listOf("action")),
        fn("ocr_screen",
            "Screen par dikh raha saara text nikalo — screenshot se OCR + screen ke text se merge karke. " +
                "Image mein chhupa text (jo screen reader ko nahi milta) bhi milta hai, '(image se)' likha hota hai. " +
                "OCR ke liye Gemini API key chahiye; key na ho to sirf screen ka text milta hai. " +
                "Payment/password/PIN wali screen par poora text nahi padha jata."),
        fn("screen_analyse",
            "Screen ko samjho: kaun si app hai, kaun sa screen/page hai (jaise Instagram home, chat list, Rohit se chat), " +
                "yahan kya-kya kar sakte ho, aur kya important hai (unread message, error, price, warning). " +
                "Screenshot + Gemini key ho to poori detail, warna sirf screen ke text se analysis.")
    )

    /** Sirf apne 3 tools pakdo, baaki ke liye null (taaki chain aage badh sake). */
    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "screen_read_live" -> when (a.optString("action", "status").trim().lowercase()) {
            "start", "screen_watch" -> ScreenWatch.start(c)
            "stop" -> ScreenWatch.stop()
            "status" -> ScreenWatch.status()
            else -> "Action 'start', 'stop' ya 'status' do — 'screen_watch' bhi start jaisa hi hai."
        }
        "ocr_screen" -> OcrTools.ocrScreen(c)
        "screen_analyse" -> OcrTools.analyseScreen(c)
        else -> null
    }
}
