package com.vaani.app

import android.content.Context
import android.os.Build
import android.os.Environment
import java.io.File

/**
 * Storage ki files: list aur delete.
 * Sirf shared storage (Download/Documents/Pictures...) ke andar; delete ke liye pakka naam chahiye.
 * Pehle "All files access" permission chahiye hoti hai (setup checklist se milti hai).
 */
object Files {
    fun run(c: Context, action: String, path: String): String {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager())
            return "Pehle Files access do: app ke Setup checklist mein 'Files access' wali line par tap karo."
        val base = Environment.getExternalStorageDirectory().canonicalFile
        val target = File(base, path.trim().trim('/')).canonicalFile
        if (!target.path.startsWith(base.path)) return "Ye jagah storage ke bahar hai, waha nahi ja sakta."
        return when (action) {
            "list" -> {
                if (!target.isDirectory) return "'$path' koi folder nahi mila."
                val items = target.listFiles()?.sortedByDescending { it.lastModified() }?.take(25)
                if (items.isNullOrEmpty()) "'$path' folder khali hai."
                else items.joinToString("\n") { (if (it.isDirectory) "📁 " else "📄 ") + it.name +
                    (if (it.isFile) " (${it.length() / 1024} KB)" else "") }
            }
            "delete" -> {
                val top = path.trim().trim('/').substringBefore('/').lowercase()
                if (top !in setOf("download", "downloads", "documents", "pictures", "dcim", "movies", "music"))
                    return "Safety: delete sirf Download, Documents, Pictures, DCIM, Movies ya Music ke andar hota hai."
                if (!target.exists()) return "'$path' naam ki koi file nahi mili. Pehle files list karke pakka naam dekho."
                if (target.isDirectory && (target.list()?.isNotEmpty() == true))
                    return "Ye folder khali nahi hai - pehle andar ki files delete karo, phir folder hoga."
                val nm = target.name
                if (target.delete()) "'$nm' delete ho gayi." else "'$nm' delete nahi ho payi."
            }
            else -> "files mein sirf list ya delete hota hai."
        }
    }
}
