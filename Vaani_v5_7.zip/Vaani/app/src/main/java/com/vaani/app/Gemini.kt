package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini REST + function calling. Model name is configurable. */
object Gemini {
    const val MODEL = "gemini-3.5-flash-lite"

    // Tools JSON org.json se banta hai taaki quotes hamesha sahi escape hon.
    // (Purana haath se joda gaya string routine tool ke description wale
    //  double-quotes par toot jata tha - wahi "Unterminated object" error.)
    private fun strProp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun intProp(d: String) = JSONObject().put("type", "INTEGER").put("description", d)

    private fun fn(
        name: String, desc: String,
        props: Map<String, JSONObject> = emptyMap(),
        req: List<String> = emptyList()
    ): JSONObject {
        val properties = JSONObject()
        for ((k, v) in props) properties.put(k, v)
        val params = JSONObject().put("type", "OBJECT").put("properties", properties)
        if (req.isNotEmpty()) params.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("parameters", params)
    }

    private val baseTools: String = JSONArray().put(
        JSONObject().put(
            "functionDeclarations", JSONArray()
                .put(fn("call", "Phone call a contact or number", mapOf("who" to strProp("contact name or number")), listOf("who")))
                .put(fn("whatsapp", "Send a WhatsApp message", mapOf("who" to strProp("contact name or number"), "message" to strProp("text")), listOf("who", "message")))
                .put(fn("open_app", "Open an installed app", mapOf("app" to strProp("app name")), listOf("app")))
                .put(fn("play_youtube", "Search/play something on YouTube", mapOf("query" to strProp("song or video")), listOf("query")))
                .put(fn("flashlight", "Turn flashlight on/off", mapOf("on" to JSONObject().put("type", "BOOLEAN")), listOf("on")))
                .put(fn("media", "Control media playback", mapOf("action" to strProp("play|pause|toggle|next|previous")), listOf("action")))
                .put(fn("settings", "Open a settings screen", mapOf("target" to strProp("wifi|bluetooth|location|hotspot")), listOf("target")))
                .put(fn("timer", "Set a countdown timer", mapOf("seconds" to intProp("duration"), "label" to strProp("label")), listOf("seconds")))
                .put(fn("calendar_event", "Add calendar event", mapOf("title" to strProp("title"), "hours_from_now" to intProp("start offset hours")), listOf("title")))
                .put(fn("call_control", "Answer, reject or announce the incoming phone call", mapOf("action" to strProp("answer|reject|announce")), listOf("action")))
                .put(fn("notifications", "Read latest notifications from ALL apps, or turn auto-reply on/off", mapOf("action" to strProp("read_latest|enable_auto_reply|disable_auto_reply")), listOf("action")))
                .put(fn("pending_reply", "Jab kisi message ka jawab bhejna pending ho aur Vaani ne user se poochha ho: user ki haan par pending jawab bhejo, naa par gira do", mapOf("action" to strProp("send|drop")), listOf("action")))
                .put(fn("pending_read", "Jab kisi naye message ka content padhna pending ho aur Vaani ne poochha ho 'batau kya': user haan bole to content padho, naa bole to skip karo", mapOf("action" to strProp("read|skip")), listOf("action")))
                .put(fn("system_control", "Volume, brightness, silent/vibrate, Do Not Disturb, auto-rotate, battery status", mapOf("action" to strProp("volume_set|volume_up|volume_down|mute|unmute|brightness_set|dnd_on|dnd_off|ringer_silent|ringer_vibrate|ringer_normal|autorotate_on|autorotate_off|battery"), "value" to intProp("0-100 for volume_set / brightness_set")), listOf("action")))
                .put(fn("screen_control", "Control the screen: system buttons, scroll, swipe, tap an on-screen text, type into focused field, read screen", mapOf("action" to strProp("back|home|recents|notifications|quick_settings|power_menu|lock_screen|wake_screen|screenshot|scroll_up|scroll_down|swipe_up|swipe_down|swipe_left|swipe_right|tap_text|type_text|read_screen"), "text" to strProp("text to tap or type")), listOf("action")))
                .put(fn("navigate", "Start Google Maps navigation", mapOf("place" to strProp("destination")), listOf("place")))
                .put(fn("web_search", "Google search", mapOf("query" to strProp("query")), listOf("query")))
                .put(fn("open_url", "Open an http/https link", mapOf("url" to strProp("link")), listOf("url")))
                .put(fn("sms", "Open SMS compose with text", mapOf("who" to strProp("contact name or number"), "message" to strProp("text")), listOf("who", "message")))
                .put(fn("email", "Open email compose", mapOf("to" to strProp("address"), "subject" to strProp("subject"), "body" to strProp("body")), listOf("to")))
                .put(fn("share_text", "Open the share sheet with text", mapOf("text" to strProp("text")), listOf("text")))
                .put(fn("alarm", "Set an alarm at a clock time", mapOf("hour" to intProp("0-23"), "minute" to intProp("0-59"), "label" to strProp("label")), listOf("hour", "minute")))
                .put(fn("camera", "Open the camera app", mapOf("mode" to strProp("photo|video"))))
                .put(fn("files", "Phone storage ki files dekho ya delete karo (Download, Documents, Pictures jaise folders). Delete ke liye pehle list karke pakka naam jaano.", mapOf("action" to strProp("list|delete"), "path" to strProp("list ke liye folder path jaise Download; delete ke liye poora path jaise Download/report.pdf")), listOf("action", "path")))
                .put(fn("routine", "Save, run, list or delete a named routine (a sequence of tool calls)", mapOf("action" to strProp("save|run|list|delete"), "name" to strProp("routine name"), "steps" to strProp("for save: JSON array like [{\"name\":\"system_control\",\"args\":{\"action\":\"dnd_on\"}}]")), listOf("action")))
        )
    ).toString()

    /** Notification tools (Feature 2) ki declarations. Dispatch NotifService.NotifTools mein hai
     *  (Actions.kt is file ko nahi chhooti) - wiring ke liye NotifService.kt ke upar wala comment dekho.
     *  NOTE: "notif_summary" Extras.decls() mein bhi hai (param-less, purana nhist wala). Tools merge
     *  ke waqt naam duplicate ho to yahi wala jeetega, taaki Gemini API ko duplicate function
     *  name na mile. Extras wala dispatch tab bhi fallback ke roop mein zinda rehta hai. */
    fun notifDecls(): JSONArray = JSONArray()
        .put(fn("notif_summary", "Haal ke notifications ka smart summary: zaroori (bank/payment/delivery/OTP/boss) alag, baaki sirf ginti. 'Kya miss hua', 'raat mein kya aaya' jaise sawaalon ke liye.",
            mapOf("since_hours" to intProp("kitne ghante peeche tak dekho, default 12"))))
        .put(fn("notif_read", "Kisi ek app ya sender ki notifications ka poora text padho, nayi pehle. OTP ka code kabhi nahi bola jata, sirf 'OTP aaya hai'.",
            mapOf("who" to strProp("app ya sender ka naam, jaise WhatsApp, HDFC, boss")), listOf("who")))
        .put(fn("notif_status", "Notification bolna chalu hai ya nahi, check karo: listener ON/OFF, aakhri notification kab aaya, aakhri baar kab bola, API key hai ya nahi.",
            mapOf<String, JSONObject>()))
        .put(fn("notif_test", "Notification bolne ka test: ek test line phone ki awaaz se bolo aur report karo. Listener OFF ho to pehle wahi batayega.",
            mapOf<String, JSONObject>()))

    /** Purane tools + v5.0 ke saare naye tools ek saath.
     *  Naam duplicate ho to pehle wala jeetega - Gemini API duplicate
     *  function name par error deta hai, isliye dedupe zaroori hai.
     *  Order: PcTools pehle (uski `pc` declaration Extras wali purani se nayi
     *  hai, naye actions ke saath), phir notif, phir Extras, phir baaki. */
    val tools: String by lazy {
        val arr = JSONArray(baseTools)
        val fd = arr.getJSONObject(0).getJSONArray("functionDeclarations")
        val seen = HashSet<String>()
        for (i in 0 until fd.length()) seen.add(fd.getJSONObject(i).optString("name"))
        fun putList(list: List<JSONObject>) { for (d in list) if (seen.add(d.optString("name"))) fd.put(d) }
        fun putArr(a: JSONArray) { for (i in 0 until a.length()) { val o = a.optJSONObject(i) ?: continue; if (seen.add(o.optString("name"))) fd.put(o) } }
        putList(PcTools.decls())
        putArr(notifDecls())
        for (d in Extras.decls()) if (seen.add(d.optString("name"))) fd.put(d)
        putArr(ReminderTools.decls()); putArr(HabitTools.decls()); putArr(HealthTools.decls()); putArr(VoiceTools.decls())
        putList(DocumentTools.decls()); putList(TranslateTools.decls()); putList(SecurityTools.decls())
        putList(AppActionTools.decls()); putList(SyncTools.decls())
        putList(ScreenTools.decls()); putList(ScreenIntelTools.decls()); putList(ScreenNavTools.decls())
        arr.toString()
    }

    // ---- Baat-cheet history (Feature 1): 50 turns tak, prefs mein saved, Live ke saath shared ----
    private val hist = ArrayList<JSONObject>()   // chhoti baat-cheet yaadasht (confirmations ke liye zaroori)
    private const val HIST_MAX = 100             // 50 turns = 100 entries (user+model jode)
    private const val HIST_KEY = "chat_hist"     // prefs "vaani" mein JSON array [{role, text}]
    @Volatile private var histLoaded = false
    @Volatile private var histCtx: Context? = null

    /** Prefs se history pehli baar load karo. Agar Live ne pehle se kuch jod diya ho to purani
     *  entries ko UPAR (pehle) lagate hain taaki order na bigde. */
    private fun ensureLoaded(c: Context?) {
        if (histLoaded) return
        val ctx = c?.applicationContext ?: return
        synchronized(hist) {
            if (histLoaded) return
            histCtx = ctx
            try {
                val arr = JSONArray(P.of(ctx).getString(HIST_KEY, "[]") ?: "[]")
                val loaded = ArrayList<JSONObject>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val role = o.optString("role"); val text = o.optString("text")
                    if (role.isEmpty() || text.isEmpty()) continue
                    loaded.add(JSONObject().put("role", role)
                        .put("parts", JSONArray().put(JSONObject().put("text", text))))
                }
                hist.addAll(0, loaded)
                while (hist.size > HIST_MAX) hist.removeAt(0)
            } catch (_: Exception) {}
            histLoaded = true
        }
    }

    /** Poori history prefs mein save karo (har askAgent completion + har Live exchange par). */
    private fun saveHist(c: Context?) {
        val ctx = c ?: histCtx ?: return
        try {
            val arr = JSONArray()
            synchronized(hist) {
                for (h in hist) {
                    val text = h.optJSONArray("parts")?.optJSONObject(0)?.optString("text") ?: continue
                    if (text.isEmpty()) continue
                    arr.put(JSONObject().put("role", h.optString("role")).put("text", text))
                }
            }
            P.of(ctx).edit().putString(HIST_KEY, arr.toString()).apply()
        } catch (_: Exception) {}
    }

    /** Live session ke liye ab tak ki baat-cheet ka snapshot: [{role, text}, ...] (purani pehle). */
    fun historySnapshot(): List<JSONObject> = synchronized(hist) {
        hist.mapNotNull { h ->
            val text = h.optJSONArray("parts")?.optJSONObject(0)?.optString("text") ?: return@mapNotNull null
            if (text.isEmpty()) null else JSONObject().put("role", h.optString("role")).put("text", text)
        }
    }

    /** Live session ka ek user<->model exchange shared history mein jodo (aur save karo).
     *  LiveClient turnComplete par isko bulata hai, taaki "usko phir bhejo" jaise follow-up
     *  text mode mein bhi samajh aayein. */
    fun addLiveExchange(userText: String, modelText: String) {
        if (userText.isBlank() && modelText.isBlank()) return
        synchronized(hist) {
            if (userText.isNotBlank()) hist.add(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userText.trim()))))
            if (modelText.isNotBlank()) hist.add(JSONObject().put("role", "model")
                .put("parts", JSONArray().put(JSONObject().put("text", modelText.trim()))))
            while (hist.size > HIST_MAX) hist.removeAt(0)
        }
        saveHist(null)
    }

    /**
     * LastRef: aakhri baar kis contact/app/screen ki baat hui. "Usko call karo", "wapas wahi
     * dikhao", "us message ka jawab do" jaise pronouns yahin se sulajhte hain - model ko
     * system prompt mein "Last mentioned: ..." line milti hai aur askAgent user ke text
     * mein pronoun dikhe to wahi hint jod deta hai. Sirf naam/label save hote hain,
     * password/PIN/OTP kabhi nahi.
     */
    object LastRef {
        private const val K_CONTACT = "lastref_contact"
        private const val K_APP = "lastref_app"
        private const val K_SCREEN = "lastref_screen"

        fun saveContact(c: Context, who: String) {
            if (who.isNotBlank()) P.of(c).edit().putString(K_CONTACT, who.trim().take(80)).apply()
        }
        fun saveApp(c: Context, app: String) {
            if (app.isNotBlank()) P.of(c).edit().putString(K_APP, app.trim().take(80)).apply()
        }
        fun saveScreen(c: Context, screen: String) {
            if (screen.isNotBlank()) P.of(c).edit().putString(K_SCREEN, screen.trim().take(200)).apply()
        }

        /** System prompt mein daalne wali line; kuch yaad na ho to khaali string. */
        fun line(c: Context): String {
            val p = P.of(c)
            val parts = ArrayList<String>()
            p.getString(K_CONTACT, "")?.takeIf { it.isNotBlank() }?.let { parts.add("contact=$it") }
            p.getString(K_APP, "")?.takeIf { it.isNotBlank() }?.let { parts.add("app=$it") }
            p.getString(K_SCREEN, "")?.takeIf { it.isNotBlank() }?.let { parts.add("screen=$it") }
            return if (parts.isEmpty()) "" else
                " Last mentioned: " + parts.joinToString("; ") + ". 'Usko', 'wahi', 'us', 'usi', 'wapas' jaise shabdon ka matlab yahi last mentioned cheez hai."
        }

        private val PRONOUN = Regex("(?i)\\b(usko|use|us|usi|wahi|wapas|isiko|usika)\\b")

        /** User ke text mein pronoun ho aur last mentioned kuch ho to saaf hint jod do,
         *  taaki model galat contact/app na pakde. Pronoun na ho to text jaisa ka taisa. */
        fun resolve(c: Context, text: String): String {
            if (!PRONOUN.containsMatchIn(text)) return text
            val l = line(c)
            return if (l.isEmpty()) text else "$text [$l]"
        }
    }

    /** Tool chalane ke baad LastRef update karo taaki agle "usko/wahi" wale sawaal sulajh sakein.
     *  askAgent aur LiveClient dono yahin se bulate hain. */
    fun noteToolCall(c: Context, name: String, a: JSONObject, result: String) {
        try {
            when (name) {
                "call", "whatsapp", "sms" -> a.optString("who").takeIf { it.isNotBlank() }?.let { LastRef.saveContact(c, it) }
                "open_app" -> a.optString("app").takeIf { it.isNotBlank() }?.let { LastRef.saveApp(c, it) }
                "screen_control" -> if (a.optString("action") == "read_screen") LastRef.saveScreen(c, result.take(200))
            }
        } catch (_: Exception) {}
    }

    private const val SYSTEM = "You are Vaani, a phone assistant. Understand Hindi, Marathi, English and Hinglish and reply in the language " +
        "the user used (default Hinglish). Use tools for device actions. Otherwise answer in one or two short sentences. " +
        "Agar user 'usko', 'wahi', 'us message', 'wapas' jaise shabd bole to uska matlab haal ki baat-cheet mein aakhri baar jis contact, app ya screen ki baat hui wahi hai " +
        "- 'Last mentioned' line dekho aur wahi use karo; saaf na ho to andaza mat lagao, poochho."

    private const val AGENT = " You are also an autonomous agent: break the user's task into steps yourself, call tools one by one, " +
        "watch each result and continue until the WHOLE task is done. If a tool fails, try another way yourself. " +
        "When everything is done, give a one-line summary in the user's language. " +
        "Pronoun ('usko'/'wahi'/'us') hamesha Last mentioned wali contact/app/screen se suljhao."

    /** Ek POST - ask() aur askAgent() dono ke liye. */
    fun post(key: String, body: JSONObject): JSONObject {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val txt = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode !in 200..299) throw RuntimeException("API ${c.responseCode}: ${txt.take(300)}")
        return JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
    }

    /** Returns parts of the first candidate (text or functionCall objects). Call off the main thread. */
    fun ask(key: String, userText: String, useTools: Boolean = true): JSONArray {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userText)))))
        if (useTools) body.put("tools", JSONArray(tools))
        return post(key, body).getJSONArray("parts")
    }

    /**
     * AGENT MODE: model khud plan banata hai - tool chalata hai, result dekhta hai,
     * aur poora kaam hone tak aage badhta hai (zyada se zyada 5 steps).
     * Aakhir mein user ki bhasha mein ek-line ka summary lautata hai.
     */
    fun askAgent(ctx: Context, key: String, userText: String): String {
        ensureLoaded(ctx)
        AgentStatus.brain = "Soch raha hai…"
        val contents = JSONArray()
        synchronized(hist) { for (h in hist) contents.put(h) }
        val resolvedText = LastRef.resolve(ctx, userText)
        val userMsg = JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", resolvedText)))
        contents.put(userMsg)
        Confirm.newTurn()
        val sysText = Brain.system(ctx, false) + AGENT + LastRef.line(ctx)
        var lastText = ""
        for (step in 0 until 12) {
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sysText))))
                .put("contents", contents)
                .put("tools", JSONArray(tools))
            val content = post(key, body)
            contents.put(content)
            val parts = content.getJSONArray("parts")
            var called = false
            val fnResults = JSONArray()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (p.has("text")) p.optString("text").takeIf { it.isNotBlank() }?.let { lastText = it }
                if (p.has("functionCall")) {
                    called = true
                    val fc = p.getJSONObject("functionCall")
                    val fname = fc.getString("name")
                    val fargs = fc.optJSONObject("args") ?: JSONObject()
                    val res = try { Actions.run(ctx, fname, fargs) }
                        catch (e: Exception) { "Error: ${e.message}" }
                    noteToolCall(ctx, fname, fargs, res)
                    fnResults.put(JSONObject().put("functionResponse",
                        JSONObject().put("name", fname)
                            .put("response", JSONObject().put("result", res))))
                }
            }
            if (!called) break
            contents.put(JSONObject().put("role", "user").put("parts", fnResults))
        }
        AgentStatus.brain = "Intezaar mein"
        val finalText = lastText.ifEmpty { "Ho gaya." }
        synchronized(hist) {
            hist.add(userMsg)
            hist.add(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", finalText))))
            while (hist.size > HIST_MAX) hist.removeAt(0)
        }
        saveHist(ctx)
        return finalText
    }
}
