package com.vaani.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.provider.Settings
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Group B — Feature 2 (OCR Text Extraction) aur Feature 4 (Screen Analysis).
 *
 * Dono kaam Gemini vision se hote hain — NO ML Kit / Tesseract dependency.
 * Image-ask helper Vision.askImage ka pattern copy karta hai (private tha, isliye yahan
 * apna copy hai): Base64 inlineData + Gemini.post, JSON mode jab structured jawab chahiye.
 *
 * ScreenModel (Group A) se seedha kaam hota hai: snapshot().rawText node-tree text hai,
 * snapshot().elements se analysis mein clickable actions nikalte hain, aur danger check
 * ScreenModel.isDangerous se hota hai. Snapshot na bane (null) to fallback
 * VaaniAccess.screenText hai — ScreenModel class ko yahan dobara define nahi kiya gaya.
 *
 * Safety: danger screen (payment/password/PIN/OTP) par poora read refuse hota hai;
 * OTP/PIN/password ke aas-paas ke digits ScreenWatch.maskSecrets se "***" hote hain.
 * Ye functions Gemini askAgent thread (background) se call hone ke liye hain — inmein
 * blocking screenshot + network calls hain, main thread se mat bulao.
 */
object OcrTools {
    private const val DANGER_MSG =
        "Ye screen payment/password/PIN jaisi lag rahi hai — yahan se main poora text nahi padhunga."
    private const val MAX_OUT = 3000

    private fun needAccess(c: Context): String {
        c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Pehle Accessibility mein Vaani ko ON karo, settings khol di."
    }

    /** Vision.askImage jaisa hi — Gemini ko JPEG dikhakar text/JSON jawab lo. */
    private fun askImage(key: String, jpeg: ByteArray, prompt: String, json: Boolean = false): String {
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray()
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))))
            .put(JSONObject().put("text", prompt)))))
        if (json) body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val parts = Gemini.post(key, body).getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString().trim()
    }

    private fun toJpeg(b: Bitmap, maxSide: Int): ByteArray {
        var bm = b
        val s = maxSide.toFloat() / maxOf(bm.width, bm.height)
        if (s < 1f) bm = Bitmap.createScaledBitmap(bm, (bm.width * s).toInt(), (bm.height * s).toInt(), true)
        val o = ByteArrayOutputStream()
        bm.compress(Bitmap.CompressFormat.JPEG, 80, o)
        return o.toByteArray()
    }

    /** Node-tree text: ScreenModel snapshot ka rawText (password nodes "***", deduped). */
    private fun nodeText(acc: VaaniAccess, limit: Int = 3000): String =
        try { ScreenModel.snapshot(acc)?.rawText?.take(limit) ?: acc.screenText(limit) } catch (_: Exception) { "" }

    private fun cleanJson(raw: String): String =
        raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()

    // ---------- Feature 2: OCR ----------

    private data class OcrLine(val text: String, val vpos: String, val hpos: String)

    private fun parseOcrLines(reply: String): List<OcrLine> {
        val arr = try { JSONArray(cleanJson(reply)) } catch (_: Exception) { return emptyList() }
        val out = ArrayList<OcrLine>()
        for (i in 0 until arr.length()) {
            val o = try { arr.getJSONObject(i) } catch (_: Exception) { continue }
            val t = ScreenWatch.maskSecrets(o.optString("text").trim())
            if (t.length < 2) continue
            // Danger + digits wali line (jaise OTP display) kabhi wapas mat do.
            if (ScreenModel.isDangerous(t) && t.any { it.isDigit() }) continue
            val v = o.optString("vpos").trim().lowercase().takeIf { it in setOf("top", "middle", "bottom") } ?: "middle"
            val h = o.optString("hpos").trim().lowercase().takeIf { it in setOf("left", "centre", "right", "center") } ?: "centre"
            out.add(OcrLine(t, v, if (h == "center") "centre" else h))
        }
        return out
    }

    private fun posHinglish(v: String, h: String): String {
        val vv = when (v) { "top" -> "upar"; "bottom" -> "neeche"; else -> "beech mein" }
        val hh = when (h) { "left" -> "bayein"; "right" -> "dayein"; else -> "beech mein" }
        return "$vv-$hh"
    }

    private fun buildOcrResult(nodeLines: List<String>, ocrOnly: List<OcrLine>, note: String?): String {
        if (nodeLines.isEmpty() && ocrOnly.isEmpty()) return "Screen par kuch padhne layak nahi mila."
        val merged = ArrayList<String>()
        merged.addAll(nodeLines)
        for (o in ocrOnly) merged.add("${o.text} (image se, ${posHinglish(o.vpos, o.hpos)})")
        val text = ScreenWatch.maskSecrets(merged.joinToString("\n")).take(MAX_OUT)
        val head = "Screen par ye text mila:"
        return if (note.isNullOrBlank()) "$head\n$text" else "$head\n$text\nNote: $note"
    }

    /**
     * ocr_screen: screenshot -> Gemini OCR (saara visible text + approximate position per line)
     * -> ScreenModel node-tree text se merge (dedupe case-insensitive, OCR-only lines "(image se)" flagged).
     * Key nahi hai ya screenshot nahi mila to node-tree text hi lautata hai + wajah batata hai.
     */
    fun ocrScreen(c: Context): String {
        val acc = VaaniAccess.inst ?: return needAccess(c)
        val node = nodeText(acc)
        if (ScreenModel.isDangerous(node)) return DANGER_MSG
        val nodeLines = ScreenWatch.splitItems(node)
        val key = P.of(c).getString("key", "").orEmpty()
        if (key.isEmpty()) {
            return buildOcrResult(nodeLines, emptyList(),
                "OCR ke liye API key chahiye, abhi sirf screen ka text mila.")
        }
        val bm = try { acc.shot() } catch (_: Exception) { null }
            ?: return buildOcrResult(nodeLines, emptyList(),
                "Screenshot nahi mila (Android 11+ aur Accessibility ON chahiye), isliye sirf screen ka text mila.")
        val prompt = "Is screenshot mein dikh raha SAARA text padho, har line ke saath uski approximate position. " +
            "Reply ONLY with a JSON array: [{\"text\":\"...\",\"vpos\":\"top|middle|bottom\",\"hpos\":\"left|centre|right\"}]. " +
            "Koi aur text mat likho. OTP, PIN, password ya CVV dikhe to us line ka text mat likho — uski jagah \"***\" likho."
        val reply = try {
            askImage(key, toJpeg(bm, 1024), prompt, true)
        } catch (e: Exception) {
            return buildOcrResult(nodeLines, emptyList(),
                "OCR nahi ho paya (${e.message?.take(80)}), isliye sirf screen ka text mila.")
        }
        val ocrLines = parseOcrLines(reply)
        if (ocrLines.isEmpty()) {
            return buildOcrResult(nodeLines, emptyList(),
                "Screenshot se koi extra text nahi mila, isliye sirf screen ka text mila.")
        }
        // Merge: node-tree lines pehle (screen order), phir sirf OCR-only lines.
        val nodeNorm = nodeLines.map { it.lowercase() }.toSet()
        val ocrOnly = ocrLines.filter { it.text.lowercase() !in nodeNorm }.distinctBy { it.text.lowercase() }
        return buildOcrResult(nodeLines, ocrOnly, null)
    }

    // ---------- Feature 4: Screen Analysis ----------

    /** Snapshot ke clickable elements se actions list (role + text/desc se). */
    private fun actionsFromSnapshot(snap: Snapshot?): List<String> {
        if (snap == null) return emptyList()
        val out = ArrayList<String>()
        for (e in snap.elements) {
            if (out.size >= 5) break
            if (!e.clickable || !e.enabled) continue
            val label = e.text.ifEmpty { e.desc }.trim().take(40)
            when (e.role) {
                "Button" -> if (label.isNotEmpty()) out.add("'$label' dabaa sakte ho")
                "EditText" -> out.add(if (label.isNotEmpty()) "'$label' mein type kar sakte ho" else "Type kar sakte ho")
                "CheckBox", "Switch" -> if (label.isNotEmpty()) out.add("'$label' on/off kar sakte ho")
                "List" -> out.add("List mein scroll kar sakte ho")
                "Image" -> if (label.isNotEmpty()) out.add("'$label' khol sakte ho")
                else -> if (label.isNotEmpty() && label.length > 2) out.add("'$label' par tap kar sakte ho")
            }
        }
        if (snap.elements.any { it.scrollable }) out.add("Scroll kar sakte ho")
        return out.distinct().take(5)
    }

    /** Key/screenshot na ho to snapshot + node text se local heuristic analysis (honest, limited). */
    private fun localAnalysis(node: String, snap: Snapshot?): String {
        val lines = ScreenWatch.splitItems(node)
        if (lines.isEmpty()) return "Screen par kuch padhne layak nahi mila."
        val appName = when {
            snap == null -> ""
            snap.label.isNotBlank() -> snap.label
            else -> snap.pkg
        }
        val title = lines.take(2).joinToString(" — ").take(140)
        val actions = actionsFromSnapshot(snap).toMutableList()
        if (actions.isEmpty()) {
            val actionHints = mapOf(
                "search" to "Search kar sakte ho", "send" to "Message bhej sakte ho",
                "settings" to "Settings khol sakte ho", "play" to "Play kar sakte ho",
                "back" to "Wapas ja sakte ho", "home" to "Home par ja sakte ho",
                "menu" to "Menu khol sakte ho", "call" to "Call kar sakte ho",
                "camera" to "Camera khol sakte ho", "share" to "Share kar sakte ho"
            )
            for ((word, label) in actionHints) {
                if (lines.any { it.contains(word, ignoreCase = true) }) actions.add(label)
                if (actions.size >= 5) break
            }
            if (actions.isEmpty()) actions.add("Screen par tap karke cheezein khol sakte ho, aur scroll kar sakte ho")
        }
        val importantPat = Regex("(?i)(unread|new message|error|fail|warning|low|expired|₹|rs\\.? |price|update available)")
        val important = lines.filter { importantPat.containsMatchIn(it) }.take(3)
        val sb = StringBuilder()
        if (appName.isNotEmpty()) sb.append("Ye $appName ka screen lag raha hai. ")
        sb.append("Screen par sabse upar: \"$title\" dikh raha hai.\n")
        sb.append("Yahan kar sakte ho: ${actions.joinToString(", ")}.\n")
        if (important.isEmpty()) sb.append("Important: koi khaas warning, error ya unread message nahi dikha.")
        else sb.append("Important: ${ScreenWatch.maskSecrets(important.joinToString("; ")).take(300)}")
        return sb.toString()
    }

    private fun formatAnalysisJson(reply: String, node: String, snap: Snapshot?): String {
        val j = try { JSONObject(cleanJson(reply)) } catch (_: Exception) { return localAnalysis(node, snap) }
        val snapApp = when {
            snap == null -> ""
            snap.label.isNotBlank() -> snap.label
            else -> snap.pkg
        }
        val app = j.optString("app").trim().ifEmpty { snapApp }
        val screen = j.optString("screen").trim()
        val actions = ArrayList<String>()
        val acts = j.optJSONArray("actions")
        if (acts != null) for (i in 0 until acts.length()) acts.optString(i).trim().takeIf { it.isNotEmpty() }?.let { actions.add(it) }
        if (actions.isEmpty()) actions.addAll(actionsFromSnapshot(snap))
        val important = ArrayList<String>()
        val imps = j.optJSONArray("important")
        if (imps != null) for (i in 0 until imps.length()) imps.optString(i).trim().takeIf { it.isNotEmpty() }?.let { important.add(it) }
        if (app.isEmpty() && screen.isEmpty() && actions.isEmpty() && important.isEmpty()) return localAnalysis(node, snap)
        val sb = StringBuilder()
        if (app.isNotEmpty() || screen.isNotEmpty()) {
            sb.append("Ye ")
            if (app.isNotEmpty()) sb.append("$app ka ")
            sb.append(if (screen.isNotEmpty()) "$screen screen lag raha hai." else "screen hai.").append("\n")
        }
        if (actions.isNotEmpty()) sb.append("Yahan kar sakte ho: ${actions.take(5).joinToString(", ")}.\n")
        if (important.isNotEmpty()) sb.append("Important: ${important.take(3).joinToString("; ")}")
        else sb.append("Important: koi khaas warning, error ya unread message nahi dikha.")
        return ScreenWatch.maskSecrets(sb.toString().trim()).take(1500)
    }

    /**
     * screen_analyse: one-shot — ScreenModel snapshot + screenshot (mile to) + Gemini
     * vision se structured summary. Key nahi hai to snapshot/node-tree-only analysis + ye bata kar.
     * Screenshot nahi mila to key hone par node text se Gemini text analysis.
     */
    fun analyseScreen(c: Context): String {
        val acc = VaaniAccess.inst ?: return needAccess(c)
        val snap = try { ScreenModel.snapshot(acc) } catch (_: Exception) { null }
        val node = snap?.rawText?.take(3000) ?: nodeText(acc)
        if (ScreenModel.isDangerous(node)) return DANGER_MSG
        if (node.isBlank()) return "Screen par kuch padhne layak nahi mila."
        val key = P.of(c).getString("key", "").orEmpty()
        if (key.isEmpty()) {
            return localAnalysis(node, snap) +
                "\n(API key nahi hai, isliye ye analysis sirf screen ke text se ki gayi hai — screenshot wali detail ke liye key chahiye.)"
        }
        val bm = try { acc.shot() } catch (_: Exception) { null }
        if (bm != null) {
            try {
                val prompt = "Is Android screenshot ko analyse karo aur sirf JSON mein jawab do: " +
                    "{\"app\":\"...\",\"screen\":\"...\",\"actions\":[\"...\"],\"important\":[\"...\"]}. " +
                    "app = kaun si app lag rahi hai, screen = kaun sa page/screen hai (jaise Instagram home, chat list, Rohit se chat), " +
                    "actions = yahan kya-kya kar sakte ho (clickable cheezein, 5 tak), " +
                    "important = zaroori content — unread message, error, price, warning (3 tak, na ho to khali list). " +
                    "OTP, PIN, password, payment details kabhi mat likho. Hinglish mein likho."
                return formatAnalysisJson(askImage(key, toJpeg(bm, 1024), prompt, true), node, snap)
            } catch (_: Exception) {
                // Neeche text-analysis fallback par jao.
            }
        }
        return try {
            val prompt = "Neeche ek Android screen ka text hai. Isse analyse karke Hinglish mein short mein batao: " +
                "(a) kaun si app / kaun sa screen lag raha hai, (b) yahan kya-kya kar sakte ho, " +
                "(c) important content (unread message, error, price, warning). OTP/PIN/password kabhi mat likho.\n\n" +
                "SCREEN TEXT:\n${node.take(2500)}"
            val parts = Gemini.ask(key, prompt, false)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            val out = sb.toString().trim()
            if (out.isEmpty()) localAnalysis(node, snap)
            else ScreenWatch.maskSecrets(out).take(1500) +
                "\n(Screenshot nahi mila, isliye ye analysis sirf screen ke text se hai.)"
        } catch (e: Exception) {
            localAnalysis(node, snap) + "\n(Analysis nahi ho payi: ${e.message?.take(60)})"
        }
    }
}
