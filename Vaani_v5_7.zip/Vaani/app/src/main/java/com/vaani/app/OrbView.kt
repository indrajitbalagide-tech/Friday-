package com.vaani.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.min
import kotlin.math.sin

/** Sci-fi centre orb: rotating segmented rings + glowing V. Bright cyan when hands-free is ON, dim steel-blue when OFF. */
class OrbView(ctx: Context) : View(ctx) {
    var active = false
    private var rot = 0f
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val vPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val oval = RectF()
    private val anim = object : Runnable {
        override fun run() { rot = (rot + 1.2f) % 360f; invalidate(); postDelayed(this, 50) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(anim) }
    override fun onDetachedFromWindow() { removeCallbacks(anim); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val cx = width / 2f; val cy = height / 2f
        val base = if (active) Color.parseColor("#FF2E4D") else Color.parseColor("#2A6E8A")
        val pulse = if (active) (1f + 0.03f * sin(rot * 0.11).toFloat()) else 1f
        val r = min(width, height) / 2f * 0.92f * pulse
        // soft glow behind the orb
        fill.shader = RadialGradient(cx, cy, r * 1.18f,
            Color.argb(if (active) 90 else 36, 25, 200, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.18f, fill); fill.shader = null
        // outer segmented ring (rotating)
        ring.color = base; ring.strokeWidth = r * 0.055f; ring.alpha = 230
        oval.set(cx - r, cy - r, cx + r, cy + r)
        var a = rot
        repeat(4) { c.drawArc(oval, a, 58f, false, ring); a += 90f }
        // middle thin ring (counter-rotating, longer arcs)
        ring.strokeWidth = r * 0.02f; ring.alpha = 150
        val r2 = r * 0.80f; oval.set(cx - r2, cy - r2, cx + r2, cy + r2)
        a = -rot * 0.7f
        repeat(3) { c.drawArc(oval, a, 84f, false, ring); a += 120f }
        // inner disc + rim
        fill.color = Color.parseColor("#04182B"); c.drawCircle(cx, cy, r * 0.62f, fill)
        ring.strokeWidth = r * 0.025f; ring.alpha = 255; c.drawCircle(cx, cy, r * 0.62f, ring)
        // the V
        val w = r * 0.30f; val h = r * 0.36f
        val path = Path().apply { moveTo(cx - w, cy - h * 0.7f); lineTo(cx, cy + h * 0.6f); lineTo(cx + w, cy - h * 0.7f) }
        vPaint.color = base; vPaint.strokeWidth = r * 0.075f
        c.drawPath(path, vPaint)
    }
}

/** Animated waveform strip: bars dance while hands-free is ON, flat dim line when OFF. */
class WaveView(ctx: Context) : View(ctx) {
    var active = false
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF2E4D"); strokeCap = Paint.Cap.ROUND
    }
    private val anim = object : Runnable {
        override fun run() { t += 0.35f; invalidate(); postDelayed(this, 90) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(anim) }
    override fun onDetachedFromWindow() { removeCallbacks(anim); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val bars = 36; val bw = width / bars.toFloat(); val mid = height / 2f
        p.strokeWidth = bw * 0.45f
        p.alpha = if (active) 200 else 80
        for (i in 0 until bars) {
            val h = if (active) 2f + (height * 0.42f) * kotlin.math.abs(sin((t + i * 0.55f).toDouble())).toFloat() else 2f
            c.drawLine(i * bw + bw / 2f, mid - h / 2f, i * bw + bw / 2f, mid + h / 2f, p)
        }
    }
}
