package com.vaani.app

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.accessibilityservice.AccessibilityService
import org.json.JSONArray
import org.json.JSONObject

/**
 * Group C — Feature 7: Smart UI Navigation (`screen_navigate`).
 *
 * Goal-directed navigation: user ek goal bolta hai ("Settings me jao",
 * "Rohit ki chat kholo", "peeche jao, phir search dabao") aur Vaani live
 * ScreenModel snapshot se plan karke ek-ek step chalati hai — max 8 steps.
 *
 * Har step: fresh snapshot -> plan -> execute -> ~1200ms wait -> verify.
 * Verify = expected element/text screen par dikhe, YA screen ka text pehle
 * se badal gaya ho. Dono na ho to wahin RUK kar batata hai: kaun sa step,
 * kya expected tha, screen par kya dikh raha hai. Andha-aage kabhi nahi badhta.
 * (AppAction.runFlow ka verification pattern hi reuse hota hai.)
 *
 * SAFETY:
 * - Payment / password / PIN / OTP screen dikhte hi ruk jata hai (wahi standard
 *   message; check ScreenModel.isDangerous se — regex ki yahan koi copy nahi).
 * - Password / PIN / OTP field par kabhi tap nahi karta, kabhi secret type nahi karta.
 * - send / pay / delete / buy wale goal par Safety.kt Confirm.gate pehle ROKO
 *   karta hai (Actions.run line ~58 se call hota hai); plain navigation
 *   (Settings / back / search / scroll) par gate nahi lagta.
 * - Sirf background thread se bulao (Gemini askAgent thread) — is mein Thread.sleep hai.
 *
 * WIRING (coordinator ke liye - is file mein koi aur file edit nahi ki gayi):
 *   Gemini.kt `tools` lazy block mein:  for (d in ScreenNavTools.decls()) if (seen.add(d.optString("name"))) fd.put(d)
 *   Actions.kt chain mein:               ScreenNavTools.dispatch(c, name, a) ?: ... (AppActionTools.dispatch ke paas)
 *   Safety.kt Confirm.gate mein:         "screen_navigate" -> sirf risky verbs (send/pay/delete/buy) par gate
 */
object ScreenNav {
    private const val MAX_STEPS = 8
    private const val WAIT_MS = 1200L

    private const val DANGER_MSG =
        "Ye screen payment/password/PIN jaisi lag rahi hai - yahan main khud aage nahi badhungi. Aap haath se kar lo."

    /** Password / PIN / OTP jaisa field — is par kabhi tap nahi karna. */
    private val SECRET_FIELD = Regex("(?i)(password|passcode|\\bpin\\b|upi pin|\\botp\\b|cvv)")

    private fun needAccess(c: Context): String {
        c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Pehle Accessibility mein Vaani ko ON karo, settings khol di."
    }

    /** Ek planned step: kya karna hai + verify ke liye kya expected hai. */
    private data class Step(val action: String, val text: String = "", val expect: String = "")

    /** Goal ko segments mein todo: comma / "phir" / "then" se alag-alag sub-goal. */
    internal fun splitGoal(goal: String): List<String> =
        goal.split(Regex(",|\\s+phir\\s+|\\s+then\\s+|;"))
            .map { it.trim() }.filter { it.isNotEmpty() }

    /** Segment se stop-words hatakar target text nikalo. */
    private fun targetOf(seg: String, drop: Set<String>): String {
        val stop = setOf(
            "kholo", "khol", "jao", "jaye", "jau", "karo", "kar", "dabao", "daba",
            "par", "mein", "me", "ko", "ki", "ke", "ka", "se", "aur", "pe", "dikhao",
            "chalao", "chalo", "open", "tap", "click", "press", "go", "to", "the"
        ) + drop
        return seg.lowercase().split(Regex("\\s+"))
            .filter { it !in stop }.joinToString(" ").trim()
    }

    /** Ek segment ke liye agla step plan karo (live snapshot dekh kar). */
    private fun planSegment(seg: String, snap: Snapshot?): Step? {
        val s = seg.lowercase().trim()
        if (s.isEmpty()) return null
        // 1) Peeche / back.
        if (s.contains("peeche") || s.contains("pichhe") || s.contains("wapas") ||
            s == "back" || s.startsWith("back ") || s.contains(" go back")
        ) return Step("back", expect = "")
        // 2) Home.
        if (s.contains("home") && (s.contains("jao") || s.contains("jaye") || s.contains("screen") || s == "home"))
            return Step("home", expect = "")
        // 3) Scroll.
        if (s.contains("scroll") || s.contains("neeche scroll") || s.contains("upar scroll")) {
            val up = s.contains("upar") || s.contains("up ") || s.contains("upar scroll")
            return Step(if (up) "scroll_up" else "scroll_down", expect = "")
        }
        // 4) Search (query ke saath ya bina).
        if (s.contains("search") || s.contains("khojo") || s.contains("dhoondo")) {
            val q = targetOf(s, setOf("search", "khojo", "dhoondo"))
            return Step("search", text = q, expect = q)
        }
        // 5) Settings.
        if (s.contains("settings") || s.contains("setting"))
            return Step("tap_text", text = "Settings", expect = "Settings")
        // 6) "<name> ki chat kholo" — naam nikal kar us par tap.
        if (s.contains("chat")) {
            val name = targetOf(s, setOf("chat"))
            if (name.isNotEmpty()) return Step("tap_text", text = name, expect = name)
        }
        // 7) Tap / dabao / kholo + target.
        val target = targetOf(s, emptySet())
        if (target.isNotEmpty()) return Step("tap_text", text = target, expect = target)
        return null
    }

    /** Step chalao. Returns true agar execute hua (verify alag se hota hai). */
    private fun execute(c: Context, acc: VaaniAccess, snap: Snapshot?, step: Step): Boolean {
        return when (step.action) {
            "back" -> acc.global(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> acc.global(AccessibilityService.GLOBAL_ACTION_HOME)
            "scroll_down" -> acc.scroll(true)
            "scroll_up" -> acc.scroll(false)
            "search" -> {
                // Search dabao (na mile to EditText tap), phir query type karo.
                var ok = acc.tapText("Search")
                if (!ok) ok = acc.tapRole("EditText", 1)
                if (step.text.isNotEmpty()) {
                    Thread.sleep(600)
                    if (!acc.typeText(step.text)) {
                        acc.tapText("Search"); Thread.sleep(700)
                        acc.typeText(step.text)
                    } else true
                } else ok
            }
            "tap_text" -> {
                val el = snap?.let { ScreenModel.findByText(it, step.text) }
                if (el != null) {
                    // Secret field par kabhi tap nahi.
                    if (SECRET_FIELD.containsMatchIn(el.text + " " + el.desc)) return false
                    acc.tapEl(el)
                } else {
                    // Snapshot mein na mile to purana tapText fallback.
                    if (SECRET_FIELD.containsMatchIn(step.text)) return false
                    acc.tapText(step.text)
                }
            }
            "tap_role" -> acc.tapRole(step.text, 1)
            "wait" -> true
            "open_app" -> {
                if (step.text.isEmpty()) false
                else !Actions.run(c, "open_app", JSONObject().put("app", step.text)).contains("nahi mila")
            }
            else -> false
        }
    }

    /**
     * Goal-directed navigation loop. Explicit steps mile hon to wahi chalao
     * (har step: {action, text, expect, wait_ms}), warna goal se plan karo.
     */
    fun navigate(c: Context, goal: String, stepsJson: String): String {
        val acc = VaaniAccess.inst ?: return needAccess(c)
        if (goal.isBlank() && stepsJson.isBlank()) return "Goal ya steps do - kahan jana hai, ye nahi mila."

        // Explicit steps: JSON array string -> Step list.
        val explicit: List<Step>? = if (stepsJson.isNotBlank()) {
            try {
                val arr = JSONArray(stepsJson)
                val list = ArrayList<Step>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        Step(
                            action = o.optString("action").trim().lowercase(),
                            text = o.optString("text").ifEmpty { o.optString("value") },
                            expect = o.optString("expect").trim()
                        )
                    )
                }
                list
            } catch (_: Exception) {
                return "Steps samajh nahi aaye - JSON array bhej, jaise [{\"action\":\"tap_text\",\"text\":\"Settings\",\"expect\":\"Settings\"}]."
            }
        } else null

        // Explicit steps na hon to goal ke tukde (comma / "phir" / "then" se) plan queue hain;
        // har tukde ki planning loop ke andar fresh snapshot se hoti hai.
        val planQueue: ArrayList<Any> = ArrayList()
        if (explicit != null) planQueue.addAll(explicit) else planQueue.addAll(splitGoal(goal))

        var done = 0
        var stepNo = 0
        for (item in planQueue) {
            if (stepNo >= MAX_STEPS) break
            stepNo++
            // Fresh snapshot har step se pehle.
            val beforeSnap = try { acc.model() } catch (_: Exception) { null }
            val beforeRaw = beforeSnap?.rawText ?: acc.screenText(2000)
            if (ScreenModel.isDangerous(beforeRaw)) return DANGER_MSG

            val step: Step = when (item) {
                is Step -> item
                is String -> planSegment(item, beforeSnap)
                    ?: return "Step $stepNo ('$item') samajh nahi aaya - kya dabana / kholna hai, ye saaf nahi. Ab screen par: ${beforeRaw.take(120)}"
                else -> return "Step $stepNo samajh nahi aaya."
            }

            // "Settings" tap na mile to system Settings kholo (fallback, sirf settings ke liye).
            var ok = execute(c, acc, beforeSnap, step)
            if (!ok && step.action == "tap_text" && step.text.equals("Settings", ignoreCase = true)) {
                try {
                    c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    ok = true
                } catch (_: Exception) { ok = false }
            }
            // "kholo" wala target screen par na mile to app open karke dekho.
            if (!ok && step.action == "tap_text" && goal.lowercase().contains("kholo")) {
                ok = execute(c, acc, beforeSnap, Step("open_app", text = step.text))
            }
            if (!ok) {
                val snapNow = try { acc.model() } catch (_: Exception) { null }
                val nowRaw = snapNow?.rawText ?: acc.screenText(2000)
                return "Step $stepNo (${step.action} '${step.text}') nahi ho paya - ruk gaya. " +
                    "Expected: '${step.text.ifEmpty { "screen badalna" }}' milna chahiye tha. " +
                    "Ab screen par: ${nowRaw.take(150)}"
            }

            Thread.sleep(WAIT_MS)

            // Verify: expected element/text dikhe, YA screen ka text pehle se badla ho.
            val afterSnap = try { acc.model() } catch (_: Exception) { null }
            val afterRaw = afterSnap?.rawText ?: acc.screenText(2000)
            if (ScreenModel.isDangerous(afterRaw)) return DANGER_MSG
            val expect = step.expect.ifEmpty { step.text }
            val expectedSeen = expect.isNotEmpty() && afterRaw.contains(expect, ignoreCase = true)
            val changed = afterRaw != beforeRaw
            if (!expectedSeen && !changed) {
                return "Step $stepNo (${step.action} '${step.text}') ke baad verify nahi hua - ruk gaya. " +
                    "Expected: '${if (expect.isNotEmpty()) expect else "screen badalna"}' dikhna chahiye tha, " +
                    "par screen waisi ki waisi hai. Ab screen par: ${afterRaw.take(150)}"
            }
            done++
            if (explicit == null && stepNo >= planQueue.size) break
        }

        if (done == 0) return "Koi step poora nahi hua - goal samajh nahi aaya ya screen par kuch nahi mila."
        val finalSnap = try { acc.model() } catch (_: Exception) { null }
        val finalRaw = finalSnap?.rawText ?: acc.screenText(2000)
        val where = when {
            finalSnap?.label?.isNotBlank() == true -> finalSnap.label
            finalSnap?.pkg?.isNotBlank() == true -> finalSnap.pkg
            else -> ""
        }
        return "Ho gaya - '$goal' poora hua, $done step${if (done > 1) "s" else ""} mein." +
            (if (where.isNotEmpty()) " Ab $where khula hai." else "") +
            (if (finalRaw.isNotBlank()) " Screen par: ${finalRaw.take(120)}" else "")
    }
}

/** `screen_navigate` tool ki declaration + dispatch. EK hi tool hai. */
object ScreenNavTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)

    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("screen_navigate",
            "Screen par khud navigate karo: goal bolo jaise 'Settings me jao', 'Rohit ki chat kholo', " +
                "'peeche jao, phir search dabao' — Vaani live screen dekh kar ek-ek step chalati hai, har step ke baad " +
                "verify karti hai, aur step fail ho to wahin ruk jati hai. Zyada se zyada 8 steps. " +
                "Payment/password/PIN wali screen par khud ruk jati hai. Accessibility ON honi chahiye.",
            mapOf(
                "goal" to sp("kahan jana / kya karna hai, jaise 'Settings me jao' ya 'Rohit ki chat kholo'"),
                "steps" to sp("optional JSON array string for explicit steps: [{\"action\":\"tap_text\",\"text\":\"Settings\",\"expect\":\"Settings\"}] — actions: tap_text, tap_role, back, home, scroll_down, scroll_up, search, wait, open_app")
            ),
            listOf("goal"))
    )

    /** Sirf "screen_navigate" pakdo, baaki ke liye null (taaki chain aage badh sake). */
    fun dispatch(c: Context, name: String, a: JSONObject): String? {
        if (name != "screen_navigate") return null
        return ScreenNav.navigate(c, a.optString("goal"), a.optString("steps"))
    }
}
