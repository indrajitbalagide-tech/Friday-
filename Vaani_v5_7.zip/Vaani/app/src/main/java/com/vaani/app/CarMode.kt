package com.vaani.app

import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager

/*
 * FEATURE 6 — Car mode.
 *
 * Kaise kaam karta hai:
 * - CarModeReceiver (manifest mein registered) Bluetooth car-audio se connect /
 *   disconnect sunta hai. Car pehchanna: device ka naam (Car/Honda/Maruti/...) ya
 *   Bluetooth class AUDIO_VIDEO_CAR_AUDIO.
 * - Connect hote hi prefs mein "car_mode"=true, volume tez (media stream ~80%),
 *   aur CarMode.active=true. Voice layer is flag ko padhkar chhote jawab deta
 *   hai (shortReply). Disconnect par sab wapas normal.
 * - Navigation / call / message ke liye KOI naya tool nahi banaya — pehle se
 *   maujood tools reuse hote hain: navigate (Google Maps), call, whatsapp, sms.
 *   Voice flow: "Vaani, ghar le chalo" -> navigate tool; "Rahul ko call karo"
 *   -> call tool; "Mummy ko message bhejo..." -> pehle Safety confirm-first
 *   (ROKO), user haan bole tabhi sms/whatsapp tool. Car mode mein bhi ye
 *   confirm-first rule NAHI badalta.
 * - Incoming messages car mein zor se padhna: NotifService ko EDIT nahi kar
 *   sakte (group rule), isiliye CarMode.shouldReadAloud() expose kiya hai.
 *   Wiring ke liye NotifService.fireBurst() mein ek line chahiye — snippet
 *   is file ke neeche + README/report mein hai.
 * - Auto-reply: car mode mein bhi SIRF confirmation ke baad. Kabhi auto-send nahi.
 *   (Safety.Confirm.gate + NotifService ka pending_reply flow hi use hota hai.)
 * - Permission: BLUETOOTH + BLUETOOTH_CONNECT (Android 12+ par device ka naam
 *   padhne ke liye runtime permission chahiye). Permission na ho to receiver
 *   chupchap kuch nahi karta — crash nahi hota.
 */

/** Car mode ka state + helpers. Voice layer yahi flag padhta hai. */
object CarMode {
    @Volatile var active: Boolean = false

    fun isActive(c: Context): Boolean = active || P.of(c).getBoolean("car_mode", false)

    /** Car connect: hands-free on, volume tez, chhote jawab. */
    fun onCarConnected(c: Context, deviceName: String?) {
        active = true
        P.of(c).edit().putBoolean("car_mode", true).putString("car_device", deviceName ?: "").apply()
        boostVolume(c)
        VaaniService.log?.invoke("🚗 Car mode on${if (!deviceName.isNullOrBlank()) " — $deviceName" else ""}. Chhote jawab, tez awaaz.")
        AgentStatus.worker = "car mode on • ${AgentStatus.time()}"; AgentStatus.workerAt = System.currentTimeMillis()
    }

    /** Car disconnect: normal mode wapas. */
    fun onCarDisconnected(c: Context) {
        active = false
        P.of(c).edit().putBoolean("car_mode", false).remove("car_device").apply()
        VaaniService.log?.invoke("🚗 Car mode off — gaadi se disconnect ho gaya.")
    }

    /** Media stream ko ~80% par le jao taaki gaadi mein awaaz saaf sunai de. */
    fun boostVolume(c: Context) {
        try {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * 0.8f).toInt(), 0)
        } catch (e: Exception) { /* volume set na ho to bhi car mode chalta rahega */ }
    }

    /**
     * Car mode mein jawab chhota rakho: pehle 1-2 vakya, zyada se zyada ~140
     * akshar. Driving ke waqt lamba jawab khatarnak hota hai.
     */
    fun shortReply(text: String): String {
        val t = text.trim()
        val sentences = t.split(Regex("(?<=[.!?।])\\s+")).filter { it.isNotBlank() }
        val short = sentences.take(2).joinToString(" ")
        return if (short.length <= 160) short else short.take(157) + "…"
    }

    /**
     * NotifService.fireBurst() se bulane ke liye: kya ye message car mein zor
     * se padhna chahiye? Car mode off ho to hamesha false (purana vyavhaar:
     * sirf "message aaya hai" batana, content nahi padhna).
     * priority: "high" (bank/payment/delivery/OTP-type ya family) ya "normal".
     * Sirf high priority + car mode par hi content padho; baaki par sirf
     * headline — taaki gaadi mein har notification chillakar na padha jaye.
     */
    fun shouldReadAloud(c: Context, priority: String): Boolean {
        if (!isActive(c)) return false
        if (P.of(c).getBoolean("car_read_all", false)) return true
        return priority.lowercase().trim() == "high"
    }

    /** Car mode mein auto-reply kabhi auto-send nahi — hamesha confirm-first. */
    fun autoReplyNeedsConfirm(): Boolean = true
}

/**
 * Bluetooth car-connection receiver. Manifest mein registered hai:
 * BluetoothA2dp / BluetoothHeadset CONNECTION_STATE_CHANGED + ACL_CONNECTED /
 * ACL_DISCONNECTED. Sirf car-audio device par react karta hai — headphone ya
 * speaker se car mode on nahi hota.
 */
class CarModeReceiver : BroadcastReceiver() {

    private val CAR_NAMES = listOf("car", "honda", "maruti", "suzuki", "toyota", "hyundai", "kia",
        "mahindra", "tata", "ford", "car audio", "car kit", "handsfree", "carkit")

    /** Naam ya Bluetooth class se car-audio pehchano. */
    fun isCarDevice(device: BluetoothDevice?): Boolean {
        if (device == null) return false
        val name = try { device.name.orEmpty().lowercase() } catch (e: SecurityException) { "" }
        if (CAR_NAMES.any { name.contains(it) }) return true
        return try {
            device.bluetoothClass?.deviceClass == BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO
        } catch (e: Exception) { false }
    }

    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        val device: BluetoothDevice? = try {
            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        } catch (e: SecurityException) { null } catch (e: Exception) { null }
        when (i.action) {
            BluetoothAdapter.ACTION_CONNECTION_STATE_CHANGED,
            BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED,
            BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED -> {
                val state = i.getIntExtra(BluetoothAdapter.EXTRA_CONNECTION_STATE, -1)
                if (state == BluetoothAdapter.STATE_CONNECTED && isCarDevice(device)) {
                    CarMode.onCarConnected(c, device?.name)
                    // Vaani ko jagao taaki user bolkar navigate/call kar sake.
                    VaaniService.forceStart = true
                } else if (state == BluetoothAdapter.STATE_DISCONNECTED && isCarDevice(device)) {
                    CarMode.onCarDisconnected(c)
                }
            }
            BluetoothDevice.ACTION_ACL_CONNECTED -> {
                if (isCarDevice(device)) CarMode.onCarConnected(c, device?.name)
            }
            BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                if (isCarDevice(device)) CarMode.onCarDisconnected(c)
            }
        }
    }
}

/*
 * ---- WIRING SNIPPET (coordinator / NotifService owner ke liye) ----
 * NotifService.fireBurst() ke shuru mein, pendingRead* set karne ke baad:
 *
 *   // CAR MODE: high-priority message ho to content zor se padho, warna sirf headline.
 *   if (CarMode.shouldReadAloud(this, if (b.chat) "high" else "normal")) {
 *       Speaker.speak(this, "${b.app} par ${b.sender} ka message: ${b.latest}")
 *       return   // content padh diya — neeche wala "batau kya?" wala flow skip karo
 *   }
 *
 * NOTE: `return` sirf fireBurst se bahar nikalta hai; auto-reply wala hissa
 * bhi skip hota hai is case mein — car mein auto-reply waise bhi confirm-first
 * hai, isiliye ye safe hai. Agar auto-reply bhi chahiye to `return` ki jagah
 * sirf Speaker.speak wali line rakho aur neeche ka flow chalne do.
 *
 * ---- VOICE FLOW (koi naya tool nahi — existing tools reuse) ----
 * "Ghar le chalo" / "XYZ jana hai"  -> navigate tool (Google Maps)
 * "Rahul ko call karo"              -> call tool
 * "Mummy ko message bhejo ..."     -> Safety confirm-first (ROKO) -> haan par sms/whatsapp tool
 * Incoming message padhna           -> NotifService.fireBurst + CarMode.shouldReadAloud (upar)
 */
