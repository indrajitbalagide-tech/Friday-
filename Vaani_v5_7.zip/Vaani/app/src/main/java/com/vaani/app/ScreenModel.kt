package com.vaani.app

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import org.json.JSONArray
import org.json.JSONObject

/**
 * ScreenModel (Group A, Vaani v5.1 screen-intelligence upgrade).
 *
 * Accessibility tree ka structured model: windows + UI elements, coordinates
 * 0..1000 scale par (screen size se relative), taaki Gemini / dusre groups
 * element ko pehchan kar tap kar sakein.
 *
 * SAFETY:
 * - Password fields ka text kabhi nahi liya jata (isPassword nodes -> "***").
 * - snapshot() kabhi throw nahi karta - failure par null lautata hai.
 * - OTP / PIN / payment jaisi screen ka pata isDangerous() se lagta hai;
 *   uska content kabhi bola / log nahi karna chahiye (ScreenTools wahi karta hai).
 *
 * NOTE: coordinates 0..1000 mein hain; wapas pixels mein badalne ke liye
 * VaaniAccess.tapEl() use karo (wahi displayMetrics se convert karta hai).
 */
data class UiEl(
    val text: String,
    val desc: String,
    val className: String,
    val role: String,
    val clickable: Boolean,
    val editable: Boolean,
    val scrollable: Boolean,
    val enabled: Boolean,
    val visible: Boolean,
    val x: Int,
    val y: Int,
    val w: Int,
    val h: Int,
    val windowPkg: String,
    val index: Int
)

data class WinInfo(
    val pkg: String,
    val title: String,
    val type: String,
    val isForeground: Boolean,
    val isKeyboard: Boolean
)

data class Snapshot(
    val pkg: String,
    val label: String,
    val windows: List<WinInfo>,
    val elements: List<UiEl>,
    val rawText: String
)

object ScreenModel {
    val DANGER: Regex = Regex("(?i)(upi pin|enter pin|enter upi|password|passcode|\\botp\\b|pay now|send money|transfer|confirm payment|delete account|factory reset|erase all|uninstall|cvv)")

    fun isDangerous(text: String): Boolean = DANGER.containsMatchIn(text)

    /** className se role: Button, EditText, Image, Text, List, CheckBox, Switch, SeekBar, Other. */
    fun roleOf(className: String): String {
        val c = className.substringAfterLast('.')
        return when {
            c.contains("EditText") -> "EditText"
            c.contains("CheckBox") -> "CheckBox"
            c.contains("Switch") -> "Switch"
            c.contains("SeekBar") -> "SeekBar"
            c.contains("RecyclerView") || c.contains("ListView") || c.contains("Spinner") ||
                c.contains("GridView") || c == "List" -> "List"
            c.contains("Button") -> "Button"
            c.contains("Image") -> "Image"
            c.contains("TextView") || c.contains("Text") -> "Text"
            else -> "Other"
        }
    }

    /** VaaniAccess.windowsInfo() isi se banta hai (internal - public API ka hissa nahi). */
    internal fun windowsInfo(acc: VaaniAccess): List<WinInfo> {
        return try {
            acc.windows.map { w ->
                val root = try { w.root } catch (_: Exception) { null }
                val pkg = try { root?.packageName?.toString() } catch (_: Exception) { null }.orEmpty()
                val title = try { w.title?.toString() } catch (_: Exception) { null }.orEmpty()
                val typeInt = try { w.type } catch (_: Exception) { AccessibilityWindowInfo.TYPE_APPLICATION }
                val isKeyboard = typeInt == AccessibilityWindowInfo.TYPE_INPUT_METHOD
                val type = when (typeInt) {
                    AccessibilityWindowInfo.TYPE_INPUT_METHOD -> "keyboard"
                    AccessibilityWindowInfo.TYPE_APPLICATION -> "app"
                    AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY,
                    AccessibilityWindowInfo.TYPE_SYSTEM -> "overlay"
                    else -> "system"
                }
                val fg = try { w.isFocused || w.isActive } catch (_: Exception) { false }
                WinInfo(pkg = pkg, title = title, type = type, isForeground = fg, isKeyboard = isKeyboard)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Active window + saari windows ka snapshot. Cap ~200 elements.
     * Invisible / khaali nodes skip hote hain, jab tak clickable + desc na ho.
     * Password node ka text "***" hota hai. Kabhi throw nahi karta.
     */
    fun snapshot(acc: VaaniAccess?): Snapshot? {
        if (acc == null) return null
        return try {
            val dm = acc.resources.displayMetrics
            val sw = dm.widthPixels.coerceAtLeast(1)
            val sh = dm.heightPixels.coerceAtLeast(1)
            val wins = windowsInfo(acc)

            val elements = ArrayList<UiEl>(200)
            val seen = HashSet<String>()
            val raw = StringBuilder()

            fun addElement(n: AccessibilityNodeInfo, windowPkg: String) {
                if (elements.size >= 200) return
                val textRaw = try { n.text?.toString() } catch (_: Exception) { null }.orEmpty()
                val desc = try { n.contentDescription?.toString() } catch (_: Exception) { null }.orEmpty()
                val className = try { n.className?.toString() } catch (_: Exception) { null }.orEmpty()
                val clickable = try { n.isClickable } catch (_: Exception) { false }
                val visible = try { n.isVisibleToUser } catch (_: Exception) { false }
                // Khaali + invisible node skip karo - jab tak clickable ho aur desc ho.
                if (textRaw.isBlank() && desc.isBlank()) return
                if (!visible && !(clickable && desc.isNotBlank())) return
                val isPassword = try { n.isPassword } catch (_: Exception) { false }
                val text = if (isPassword) "***" else textRaw
                val rect = Rect()
                try { n.getBoundsInScreen(rect) } catch (_: Exception) { return }
                val cx = ((rect.centerX().toFloat() / sw) * 1000).toInt().coerceIn(0, 1000)
                val cy = ((rect.centerY().toFloat() / sh) * 1000).toInt().coerceIn(0, 1000)
                val w = ((rect.width().toFloat() / sw) * 1000).toInt().coerceIn(0, 1000)
                val h = ((rect.height().toFloat() / sh) * 1000).toInt().coerceIn(0, 1000)
                val key = "$text|$desc|$className|$cx|$cy"
                if (!seen.add(key)) return
                val el = UiEl(
                    text = text, desc = desc, className = className,
                    role = roleOf(className),
                    clickable = clickable,
                    editable = try { n.isEditable } catch (_: Exception) { false },
                    scrollable = try { n.isScrollable } catch (_: Exception) { false },
                    enabled = try { n.isEnabled } catch (_: Exception) { false },
                    visible = visible,
                    x = cx, y = cy, w = w, h = h,
                    windowPkg = windowPkg, index = elements.size
                )
                elements.add(el)
                if (text.isNotBlank() && text != "***") {
                    if (raw.length < 4000) raw.append(text).append(". ")
                }
            }

            fun walk(n: AccessibilityNodeInfo?, windowPkg: String) {
                if (n == null || elements.size >= 200) return
                addElement(n, windowPkg)
                val count = try { n.childCount } catch (_: Exception) { 0 }
                for (i in 0 until count) {
                    if (elements.size >= 200) break
                    val child = try { n.getChild(i) } catch (_: Exception) { null }
                    walk(child, windowPkg)
                }
            }

            // 1) Active window ka root (sabse bharosemand source).
            val root = try { acc.rootInActiveWindow } catch (_: Exception) { null }
            val rootPkg = try { root?.packageName?.toString() } catch (_: Exception) { null }.orEmpty()
            walk(root, rootPkg)

            // 2) Baaki windows (overlay / dialog / keyboard / split-screen) bhi.
            try {
                for (w in acc.windows) {
                    if (elements.size >= 200) break
                    val wRoot = try { w.root } catch (_: Exception) { null } ?: continue
                    val wPkg = try { wRoot.packageName?.toString() } catch (_: Exception) { null }.orEmpty()
                    // Root window dobara walk karne se duplicate aate hain - seen-set rok leta hai,
                    // par phir bhi sirf tab walk karo jab pkg alag ho ya root null tha.
                    if (root != null && wPkg == rootPkg && w.isFocused) continue
                    walk(wRoot, wPkg)
                }
            } catch (_: Exception) {
            }

            if (elements.isEmpty() && root == null && wins.isEmpty()) return null
            val pkg = rootPkg.ifEmpty { wins.firstOrNull { it.isForeground }?.pkg ?: "" }
            val label = try {
                if (pkg.isNotEmpty()) {
                    val ai = acc.packageManager.getApplicationInfo(pkg, 0)
                    acc.packageManager.getApplicationLabel(ai)?.toString() ?: pkg
                } else ""
            } catch (_: Exception) { pkg }
            Snapshot(
                pkg = pkg,
                label = label,
                windows = wins,
                elements = elements,
                rawText = raw.toString().trim().take(4000)
            )
        } catch (_: Exception) {
            null
        }
    }

    fun toJson(s: Snapshot): JSONObject {
        val j = JSONObject()
        j.put("pkg", s.pkg)
        j.put("label", s.label)
        j.put("rawText", s.rawText)
        val wa = JSONArray()
        for (w in s.windows) {
            wa.put(JSONObject()
                .put("pkg", w.pkg)
                .put("title", w.title)
                .put("type", w.type)
                .put("isForeground", w.isForeground)
                .put("isKeyboard", w.isKeyboard))
        }
        j.put("windows", wa)
        val ea = JSONArray()
        for (e in s.elements) {
            ea.put(JSONObject()
                .put("text", e.text)
                .put("desc", e.desc)
                .put("className", e.className)
                .put("role", e.role)
                .put("clickable", e.clickable)
                .put("editable", e.editable)
                .put("scrollable", e.scrollable)
                .put("enabled", e.enabled)
                .put("visible", e.visible)
                .put("x", e.x)
                .put("y", e.y)
                .put("w", e.w)
                .put("h", e.h)
                .put("windowPkg", e.windowPkg)
                .put("index", e.index))
        }
        j.put("elements", ea)
        return j
    }

    /** nth 1-based hai (nth=1 pehla match). Role case-insensitive match hota hai. */
    fun findByRole(s: Snapshot, role: String, nth: Int): UiEl? {
        val n = nth.coerceAtLeast(1)
        var seen = 0
        for (e in s.elements) {
            if (e.role.equals(role, ignoreCase = true)) {
                seen++
                if (seen == n) return e
            }
        }
        return null
    }

    /** Pehle exact text match, phir text/desc mein contains (case-insensitive). */
    fun findByText(s: Snapshot, text: String): UiEl? {
        if (text.isBlank()) return null
        for (e in s.elements) if (e.text.equals(text, ignoreCase = true)) return e
        for (e in s.elements) if (e.text.contains(text, ignoreCase = true)) return e
        for (e in s.elements) if (e.desc.contains(text, ignoreCase = true)) return e
        return null
    }
}
