package com.vaani.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Agents board ke liye har "employee" ki live haalat.
 * Har hissa (service, notifications, calls, speaker...) apni line khud update karta hai -
 * board jo dikhata hai, woh asal mein ho raha hota hai.
 */
object AgentStatus {
    @Volatile var brain = "Intezaar mein"
    @Volatile var worker = "Koi kaam nahi"
    @Volatile var khabar = "Koi khabar nahi"
    @Volatile var call = "Koi call nahi"
    @Volatile var voice = "Chup hai"
    @Volatile var files = "Koi file kaam nahi"
    @Volatile var home = "Ghar shaant hai"
    @Volatile var cam = "Kuch dekha nahi"
    @Volatile var stt = "Koi command nahi suna"
    @Volatile var workerAt = 0L
    @Volatile var khabarAt = 0L
    @Volatile var callAt = 0L
    @Volatile var voiceAt = 0L
    @Volatile var filesAt = 0L
    @Volatile var homeAt = 0L
    @Volatile var camAt = 0L
    @Volatile var sttAt = 0L
    fun time(): String = SimpleDateFormat("HH:mm", Locale.US).format(Date())
}
