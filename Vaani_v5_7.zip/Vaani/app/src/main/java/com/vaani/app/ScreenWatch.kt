package com.vaani.app

import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * Group B — Feature 1: Real-Time Screen Reading (live screen watcher).
 *
 * Kaise kaam karta hai:
 * - start() par VaaniAccess.onScreenDelta listener lagta hai (debounced ~1s, sirf tab
 *   fire hota hai jab listener set ho — VaaniAccess.kt, Group A wiring). Har delta ek hi
 *   entry point se guzarta hai: onDelta(ctx, newText). Baseline current screen ka snapshot
 *   hota hai (jo pehle se dikh raha hai, use dobara nahi bola jata), phir har delta par
 *   SIRF nayi lines boli jati hain (zyada se zyada 3 per event).
 * - Payment/password/PIN/OTP wali screen dikhte hi khud ruk jata hai + bol kar batata hai
 *   (check ScreenModel.isDangerous se hota hai — DANGER regex ki yahan koi copy nahi hai).
 * - 10 minute tak koi naya change na aaye to ek halka idle-watchdog apne aap band kar deta hai.
 * - Koi service nahi: state sirf @Volatile vars mein hai, isliye watcher sirf tab tak
 *   zinda rehta hai jab tak app/service ka process zinda hai. Accessibility service
 *   rebind ho (inst badle) to live padhna dobara start karna padega.
 *
 * Threading: start()/stop()/status() Gemini askAgent thread se aate hain; delta listener
 * main looper par chalta hai, isliye onDelta mein sirf diff + Speaker.speak hota hai
 * (Speaker khud apna thread banata hai, isliye kuch block nahi hota). Idle-watchdog sirf
 * 30 sec mein ek baar time check karta hai, screen nahi padhta.
 */
object ScreenWatch {
    /** Danger check — seedha Group A ke ScreenModel se (yahan regex ki copy nahi hai). */
    internal fun isDangerous(text: String): Boolean = ScreenModel.isDangerous(text)

    /**
     * OTP / PIN / password ke aas-paas ke digit runs chhupao ("OTP 482913" -> "OTP ***").
     * Aam numbers (price, count, date) ko nahi chhedata — sirf secret contexts mask hote hain.
     */
    internal fun maskSecrets(text: String): String {
        val secretCtx = Regex("(?i)(otp|one[- ]time password|verification code|\\bpin\\b|upi pin|passcode|cvv|password)\\s*[:\\-]?\\s*\\d{3,8}")
        return secretCtx.replace(text) { m -> m.value.replace(Regex("\\d+"), "***") }
    }

    /** Screen text ko "items" mein todo — snapshot rawText items ko ". " se jodta hai. */
    internal fun splitItems(text: String): List<String> =
        text.split(". ", "\n").map { it.trim().trimEnd('.').trim() }
            .filter { it.length >= 2 }.distinct()

    private const val IDLE_MS = 10 * 60 * 1000L   // 10 minute bina change -> auto-stop
    private const val IDLE_CHECK_MS = 30_000L
    private const val MAX_NEW_PER_EVENT = 3

    @Volatile private var live = false
    @Volatile private var lastSpoken: Set<String> = emptySet()
    @Volatile private var lastChangeAt = 0L
    @Volatile private var startedAt = 0L
    @Volatile private var spokenCount = 0
    @Volatile private var appCtx: Context? = null
    private val lock = Any()

    private fun needAccess(c: Context): String {
        c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Pehle Accessibility mein Vaani ko ON karo, settings khol di."
    }

    /**
     * Live padhna shuru karo. Baseline current screen hoti hai (pehle se dikh raha content
     * nahi bola jata). Listener VaaniAccess.onScreenDelta par lagta hai.
     * Returns Hinglish status (agent ye result user ko bol deta hai).
     */
    fun start(c: Context): String {
        synchronized(lock) {
            val acc = VaaniAccess.inst ?: return needAccess(c)
            if (live) return "Live padhna pehle se ON hai. Band karne ke liye 'stop' bolo."
            val app = c.applicationContext
            appCtx = app
            // Baseline: snapshot ka rawText (password nodes pehle se "***", duplicates nahi).
            lastSpoken = try {
                (ScreenModel.snapshot(acc)?.rawText ?: acc.screenText(2500)).let { splitItems(it).toSet() }
            } catch (_: Exception) {
                emptySet()
            }
            startedAt = System.currentTimeMillis()
            lastChangeAt = startedAt
            spokenCount = 0
            live = true
            acc.onScreenDelta = { t -> onDelta(app, t) }
            Thread({ idleWatchdog() }, "vaani-screenwatch-idle").apply { isDaemon = true; start() }
            return "Live padhna shuru ho gaya — screen par jo naya aayega, main bol kar bataungi. Band karne ke liye 'stop' bolo."
        }
    }

    /** Live padhna band karo (listener bhi hata do). */
    fun stop(): String {
        synchronized(lock) {
            if (!live) return "Live padhna pehle se band hai."
            live = false
            lastSpoken = emptySet()
            clearListener()
            return "Live padhna band kar diya."
        }
    }

    fun isLive(): Boolean = live

    fun status(): String {
        if (!live) return "Live padhna band hai. Shuru karne ke liye 'start' bolo."
        val mins = (System.currentTimeMillis() - startedAt) / 60_000
        return "Live padhna ON hai — $mins minute se chal raha hai, ab tak $spokenCount nayi cheezein boli. Band karne ke liye 'stop' bolo."
    }

    /**
     * DELTA ENTRY POINT — VaaniAccess.onScreenDelta listener yahin call karta hai
     * (main looper, ~1s debounce). Kaam chhota rakha hai: danger check -> diff -> speak.
     */
    fun onDelta(ctx: Context, newText: String) {
        if (!live) return
        if (isDangerous(newText)) {
            stopInternal(ctx, "Payment/password wali screen aa gayi, live padhna band kar diya.")
            return
        }
        val items = splitItems(newText)
        if (items.isEmpty()) return
        // CHANGED lines only: jo pehle boli ja chuki hain, unhe dobara mat bolo.
        val fresh = items.filter { it !in lastSpoken }.take(MAX_NEW_PER_EVENT)
        lastSpoken = items.toSet()
        if (fresh.isEmpty()) return
        lastChangeAt = System.currentTimeMillis()
        spokenCount += fresh.size
        val speakText = "Naya: " + fresh.joinToString(". ") { maskSecrets(it).take(120) }
        Speaker.speak(ctx.applicationContext, speakText)
    }

    /** Danger / idle / Accessibility-off par rukna: state band + listener hatao + ek closing line bolna. */
    private fun stopInternal(ctx: Context, line: String) {
        synchronized(lock) {
            if (!live) return
            live = false
            lastSpoken = emptySet()
            clearListener()
        }
        Speaker.speak(ctx.applicationContext, line)
    }

    private fun clearListener() {
        try { VaaniAccess.inst?.onScreenDelta = null } catch (_: Exception) {}
    }

    /** Sirf idle check karta hai (screen nahi padhta): 10 min bina change -> auto-stop. */
    private fun idleWatchdog() {
        val ctx = appCtx ?: return
        while (live) {
            try {
                Thread.sleep(IDLE_CHECK_MS)
                if (live && System.currentTimeMillis() - lastChangeAt > IDLE_MS) {
                    stopInternal(ctx, "10 minute se screen par kuch naya nahi aaya, live padhna band kar diya.")
                }
            } catch (_: InterruptedException) {
                break
            } catch (_: Exception) {
                // Agli round mein phir check karo.
            }
        }
    }
}
