pluginManagement { repositories {
    google()
    // repo.maven.apache.org hangs for Java clients behind this sandbox proxy;
    // repo1.maven.org and Google's Maven Central mirror work - same artifacts.
    maven { url = uri("https://repo1.maven.org/maven2") }
    maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2") }
    gradlePluginPortal()
} }
dependencyResolutionManagement { repositories {
    google()
    maven { url = uri("https://repo1.maven.org/maven2") }
    maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2") }
} }
rootProject.name = "Vaani"
include(":app")
