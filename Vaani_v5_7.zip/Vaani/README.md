# Vaani (Android)
Hinglish voice assistant: speech -> Gemini function calling -> real phone actions.
Actions: call, WhatsApp message, open app, YouTube, flashlight, media keys, settings, timer, calendar event.

Build: open this folder in Android Studio (Koala+), let it sync, Run on a phone (minSdk 26).
Then paste your own Gemini API key in the app (get one at aistudio.google.com).
Model name lives in Gemini.kt (MODEL). Change it if Google renames models.
Note: key is stored in app-private SharedPreferences (not hardware-encrypted).

## v1.1 additions
- call_control: "call utha lo" / "call kaat do" / "kaun call kar raha hai" (+ caller name announced automatically when a call rings)
- notifications: "meri WhatsApp notifications padho", "auto reply on karo" (Gemini writes the reply; off by default)
- Notification access must be granted by you once (Vaani opens that settings screen when needed).
- Auto-reply sends AI-written replies in your name. Turn it on only when you are fine with that.

## v2.0: 24h hands-free + Live + overlay
1. Open app -> paste Gemini key -> "Meri awaaz record karo" (quiet room, talk normally for 12 s).
2. Grant: Floating orb permission, Battery Unrestricted, all runtime permissions, Notification access (for message tools).
3. Tap "24h Hands-free START". A persistent notification appears; the service keeps the mic open.
4. Only speech that matches your voice opens a Gemini Live session (closes after 15 s silence). Orb: grey idle, green listening, orange speaking. Tap orb = start without voice check.
Limits: voice check is basic MFCC (weak, not security); Android will not let a mic service auto-start from boot, open the app once after reboot;
LIVE_MODEL in LiveClient.kt may need updating; no barge-in (mic muted while Vaani speaks).

## v2.1
- Hands-free by default: after the one-time setup (API key + voice enrollment) the app starts listening by itself every time it opens. No tap-to-speak.
- Conversation shows live in the small box on the main screen (last ~4000 characters kept).
- Languages: Hindi, Marathi, English, Hinglish. Vaani replies in the language you spoke, default Hinglish.
- Stop button turns auto-start off until you press Start again.

## v3.0 automation pack (tools Vaani can call by voice)
system_control (volume, brightness, silent/vibrate, DND, auto-rotate, battery), screen_control (back/home/recents/notifications/quick settings/
power menu/lock/screenshot/scroll/swipe/tap text/type/read screen; needs Accessibility ON), navigate, web_search, open_url, sms, email, share_text,
alarm, camera, routine (save/run/list/delete named sequences, e.g. "good night" = DND on + brightness 10 + alarm).
First use of a tool that needs a special permission opens the right Android settings screen.
Not possible without root/Shizuku: silently toggling Wi-Fi/Bluetooth/mobile data/airplane mode (blocked since Android 10), silent install/uninstall, call recording.

## v4.0 "Vaani pack"
Naya kya hai (sab voice se, Live aur typed dono raaste mein):
1. **Memory** - `memory` tool: Vaani aapke facts yaad rakhti hai (log, pasand, jagah) aur har session mein use karti hai. Password/PIN/OTP save nahi hote. ⚙ Settings se sab bhula sakte ho.
2. **Asli jaankari** - `web_answer` (Google Search se seedha jawab), `weather`, `calendar_read`, `call_log`, `sms_read`, `my_location`.
3. **Vision** - `look` (camera back/front ya screen dekhkar jawab) aur `screen_agent` (screenshot dekh-kar tap/type/swipe, kisi bhi app mein). Payment/password/PIN/OTP screen dikhte hi ruk jaata hai. Screenshot ke liye Android 11+ aur Accessibility ON.
4. **Proactive** - subah ka briefing (default 07:30), meeting se ~10 min pehle alert, battery <=15% alert, `place` tool se ghar/office save karo; aate-jaate routine `<naam>_aao` / `<naam>_jao` chalti hai (ya ek line bolti hai).
5. **Wake word + barge-in** - Wake word sirf "Vaani" hai (Jarvis wala built-in hata diya gaya). Picovoice key daalo (⚙ Settings, free) aur apna "Vaani" keyword: Picovoice Console par free `.ppn` file bankar `app/src/main/assets/vaani_wake.ppn` naam se rakho - tab "Vaani" bolne par hi jaagti hai. .ppn na ho to wake word band rehta hai, sirf awaaz-match chalta hai. Default: wake word AND aapki awaaz dono chahiye; "Sirf wake word" toggle se awaaz-check band. Barge-in: Vaani bol rahi ho tab zor se bolo to ruk jaati hai (agar khud ko kaat rahi ho to ⚙ mein band karo).
6. **Ghar + PC** - `smart_home` (Home Assistant: light/fan/AC/pardey/scene), `webhook` (ESP32/IFTTT/Node-RED), `pc` (laptop par `pc_agent/vaani_pc.py` chalao; open_app, lock, volume, find_file...). LAN ke liye plain http chalta hai (cleartext on). PC bridge ko internet par expose mat karo.
7. **Offline fallback** - internet na ho to phone ki offline speech se basic commands (torch, volume, battery, call, open app, time, back/home...). Phone mein offline Hindi/English language pack download hona chahiye.
8. **Safety** - delete / auto-reply on / screen_agent / PC shutdown-restart-sleep-run / door lock: pehli call hamesha "ROKO" lautati hai; user ke NAYE jawab ke baad hi chalti hai. File delete sirf Download/Documents/Pictures/DCIM/Movies/Music mein. Har action ka diary: "tumne abhi kya kiya?" (`action_log`).
New permissions: calendar, SMS, camera, location. Agent ab 12 steps tak chalta hai aur pichli baat-cheet yaad rakhta hai (typed mode).

Known limits: voice check abhi bhi basic MFCC hai (security nahi; behtar speaker model ke liye ECAPA/Resemblyzer TFLite file chahiye); offline mode Gemini jaisa smart nahi; geofence har ~3 min check karta hai; Wi-Fi/Bluetooth silently toggle abhi bhi Android ki wajah se possible nahi.

## v5.0 "Jarvis wali feel" upgrade — 12 features + voice screen automation

Sab kuch `com.vaani.app` package mein, Kotlin + JSONObject tools, Hinglish replies. Saare naye tools `Gemini.kt` tools list mein registered hain aur `Actions.kt` dispatch chain mein chalte hain — koi tool sirf declare karke chhoda nahi gaya. Purane tools ke naam nahi badle.

### 1. Conversation context + follow-ups (`Gemini.kt`, `LiveClient.kt`)
- History 10 se badhakar **100 entries = 50 turns**, SharedPreferences `"vaani"` key `"chat_hist"` mein save (restart ke baad bhi), `askAgent()` + Live exchange dono se.
- Live session ko pichhle 8 exchanges ka snapshot + LastRef line setup mein milti hai; Live ke turns `addLiveExchange()` se shared history mein jodte hain.
- **Pronoun/reference resolution:** `LastRef` (aakhri contact/app/screen) — "usko call karo", "wapas wahi dikhao" system prompt ki "Last mentioned" line se sulajhte hain; saaf na ho to model poochhta hai, andaza nahi lagata. Sirf naam/label save hote hain, password/PIN/OTP kabhi nahi.

### 2. Smart notification summary — FIX FIRST (`NotifService.kt`)
- **Root cause:** sirf `EXTRA_TITLE`/`EXTRA_TEXT` padha jata tha. Lambe messages ka poora text Android `EXTRA_BIG_TEXT` mein rakhta hai, group chats mein `EXTRA_TEXT_LINES` mein, WhatsApp/Telegram mein `MessagingStyle` messages mein — isliye content kata hua ya missing milta tha. Har burst par "batau kya?" poochha jata tha aur `pendingRead` mein sirf aakhri chhota text rehta tha.
- **Fix:** `fullText()` — `EXTRA_BIG_TEXT` → `EXTRA_TEXT_LINES` → `MessagingStyle` → `EXTRA_TEXT`, sabse lamba/best text. Timestamped history prefs `"nhist2"` mein `{app, sender, text, time, priority, pkg}`, cap 200 (purani `"nhist"` bhi likhi jaati hai). Priority: otp / bank / work / delivery / spam / normal. Dedup: pkg+sender+text-hash+`sbn.key` (30s), same sender+text (10s). `pendingRead` mein ab burst ka **poora** text (2000 chars tak). OTP par sirf "OTP aaya hai", digits kabhi nahi bole jate. Spam/low sirf log + history, bola nahi.
- Tools: `notif_summary` (optional `since_hours`, default 12 — "Raat mein kya miss hua?" sirf zaroori items, ek line) aur `notif_read` (kisi app/sender ka poora text). NOTE: purana param-less `notif_summary` Extras.kt mein bhi hai — Gemini merge mein naam se dedupe hota hai, naya wala jeet-ta hai; Extras wala dispatch fallback ke roop mein zinda hai.
- Limit: classifier keyword-based hai — naye bank/delivery app ya spam pattern ke liye lists edit karni padengi (`WORK_SENDERS` set abhi khaali hai — boss ke naam/number wahan jodo).

### 3. Reminders + follow-ups (`Reminders.kt`)
- Natural Hinglish time parsing: "kal 5 baje", "aaj shaam 7 baje", "parso subah 9 baje", "10 minute baad", "1 ghante baad", "aadhe ghante baad", "saade/sava/paune X baje", Hindi+English weekday names, "agle somvaar". Bare "5 baje" = agla aane wala 5.
- Time-based: `AlarmManager.setExactAndAllowWhileIdle` + `ReminderReceiver` (bolkar sunata hai) + `ReminderBootReceiver` (reboot par re-schedule). Event-linked: "meeting ke baad invoice bhejna yaad rakhna" — calendar event khatam hote hi fire (`CalendarContract.Instances`, pichhle 24h). Location: "ghar pahunchte hi" — saved places (`place save`) ke ~200m andar fire. `reminder_list` / `reminder_cancel` (alarm bhi cancel). Purani entries (text+at only) abhi bhi padhi jaati hain.
- Tools: `reminder_add`, `reminder_list`, `reminder_cancel` (purana `reminder` tool bhi chalta hai, ab `when_text`/`after_event`/`place` bhi samajhta hai).

### 4. Document + photo understanding (`DocumentShare.kt`)
- Tool `document_understand` (uri_or_text, question). Share-to-Vaani: MainActivity par ACTION_SEND intent-filter (application/pdf, image/*, text/plain) + `launchMode="singleTop"`; share karte hi save hota hai aur jawab milta hai.
- PDF: `PdfRenderer` se pehle 5 pages → Gemini Vision OCR (Android mein PDF text-layer API nahi hai, isliye key chahiye). Images: Gemini Vision. "Ye kitne ka hai" (₹/Rs amounts), "isme deadline kya hai" (date), summary — sab Hinglish mein. Key na ho to saaf note, jhootha text nahi.
- Limits: max 5 PDF pages, scanned/handwritten PDF Vision quality par depend, image EXIF rotation fix nahi, koi on-device OCR nahi.

### 5. Live translation (`Translate.kt`)
- Tools: `translate` (text, from hi/en/mr/auto, to hi/en/mr — `Gemini.ask(..., useTools=false)`, isliye translation kabhi phone action trigger nahi karta) aur `translate_board` ("ye board kya keh raha hai" — `Vision.look` camera_back se ek still photo padhkar translate).
- Live translation mode: `LiveTranslate.startMode/stopMode/pair` (prefs `live_tr_on/a/b`); mode on ho to Live session ke system prompt mein pair ki line jodti hai. Real-time Hindi ↔ English/Marathi.
- Limits: offline translation engine nahi (key + internet chahiye); board reading ek still photo hai, live video OCR nahi.

### 6. Car mode (`CarMode.kt`)
- `CarModeReceiver` (manifest, exported=false): Bluetooth A2DP/headset/ACL connect sunta hai. Car pehchanna jata hai device naam (Car/Honda/Maruti/Suzuki/Toyota/Hyundai/Kia/Mahindra/Tata/Ford/"car audio"/"car kit"/"handsfree") ya Bluetooth class `AUDIO_VIDEO_CAR_AUDIO` se — headphones/speakers trigger nahi karte.
- Connect hote hi: hands-free on, media volume ~80%, chhote jawab (max 2 sentences / ~160 chars), zaroori messages turant padhe jate hain (NotifService hook). Navigation/call/message purane tools reuse hote hain. Auto-reply car mein bhi **confirm-first** hi rehta hai.
- Limits: Android 12+ par device naam padhne ke liye `BLUETOOTH_CONNECT` runtime permission chahiye; ajeeb naam wala car stereo pehchanna na jaye to `CAR_NAMES` mein naam jodo.

### 7. Health + routine tracking (`Health.kt` — NEW)
- `health_summary` (steps, sleep_hours), `health_water` (log/remind/count, 8-glass goal, default step goal 10,000). Paani local prefs mein, local only, koi upload nahi, Memory mein health data kabhi nahi likha. Har reply mein: "Main doctor nahi hoon, ye sirf aapke phone ka data hai."
- **Stub:** `app/build.gradle.kts` mein `androidx.health.connect.client` dependency NAHI hai, isliye live steps/sleep padhna stub hai (`readFromHealthConnect()` null lautata hai). Tab tak steps/sleep wahi dikhte hain jo user khud bataye ya pehle log hue. Dependency add hote hi wahan Steps + SleepSession read likha jayega.
- Setup: "Health Connect by Android" install karo (Android 14+ par built-in), Vaani ko Steps + Sleep permission do.

### 8. Smart suggestions (`Habits.kt`)
- Suggestion ab time AND location par: wahi kaam wahi samay (±1h) par ≥2 alag din, YA wahi jagah par 2 baar — jaise roz 10 baje DND → "Roz 10 baje DND lagate ho, routine bana dun?" Purana "3 repeats" rule purani entries ke liye fallback hai.
- One-tap accept/decline: `habit_suggest` / `habit_decide`. Accept par hi routine banti hai (Automation wali `"routines"` prefs, wahi format) — **Vaani kabhi khud routine nahi banati**. Decline → 7 din ke liye us sujhav ko dabao. Routine sirf single-arg tools ki ban sakti hai (`system_control`, `media`, `settings` jaise `dnd_on`).

### 9. Multi-language voice + different voices (`Voice.kt`)
- `voice_lang`: hi-IN (Hinglish default), mr-IN, en-IN — `TextToSpeech.getVoices()` se best voice (Google neural pehle). Setting prefs `voice_lang`/`voice_name` mein save.
- `voice_tone`: "jaldi" (rate 1.25), "raat" (rate 0.85, pitch 0.9), "normal" (1.0), "auto" (22:00–06:00 dheemi). Tone ab Gemini ki hi awaaz mein (style instruction se: "tez"/"dheemi-narm"). Purane `speak()` signatures same hain.
- Tools: `voice_lang`, `voice_tone`.

### 10. Laptop Jarvis / PC bridge (`pc_agent/vaani_pc.py`, `MultiDevice.kt` → `PcTools`)
- Naye PC commands (purane sab chalte hain): `screenshot` (PC screen photo, `vaani_screenshot.png` + base64 ≤1.5 MB; headless par saaf fail), `list_windows` ("mere desktop par kya khula hai" — Windows PowerShell / macOS osascript / Linux wmctrl→xdotool→process list, max 40), `file_summary` (pehli N lines + kul lines + language guess, 2 MB cap), `file_search` (folder mein naam/pattern, max 50), `open_file`, `open_app_on_pc`.
- Android: `pc` tool ki **ek hi updated declaration** (`PcTools.decls()`) — purane + naye actions, params `path`/`folder`/`pattern`/`lines`. Dispatch `PcTools.dispatch` (purane actions bhi wahi `/do` protocol se). NOTE: purani `pc` declaration Extras.kt mein bhi hai — Gemini merge mein `PcTools` pehle aata hai, isliye nayi wali jeet-ti hai.
- **LAN-only:** PC agent har request ka source IP check karta hai — LAN ke bahar se aaye to token check se pehle 403. Android side bhi `pc_url` ka host check karta hai. PC ko internet par expose / port-forward kabhi mat karo. Token auth waisa hi hai.
- Setup: PC par `python3 pc_agent/vaani_pc.py` (sirf standard library; Pillow ho to screenshot zyada reliable). Token + `http://<PC-IP>:8765` Vaani Settings → PC BRIDGE mein daalo. Dono ek hi WiFi par. Linux par window list ke liye `wmctrl`/`xdotool` install karo, warna process list milegi.

### 11. Multi-device (`MultiDevice.kt`)
- **Kaam karta hai:** JSON export/import — `sync_export` (memory facts + reminders + saved places, share sheet se bhejo; `filesDir/vaani_sync.json` mein bhi save) aur `sync_import` (merge + dedupe: memory key se, reminder text se, place naam se; counts report). Password/PIN/OTP/API key/token/secret wali entries export/import dono mein chhod di jati hain.
- **Stub — Wear OS live sync:** `wear_send` sirf batata hai "Wear app abhi install nahi hai — companion app chahiye". Kaaran: `app/build.gradle.kts` mein Wear dependency nahi aur ghadi par Vaani Wear app nahi hai. Asli live sync ke liye chahiye: Wear OS companion app + Gradle mein `com.google.android.gms:play-services-wearable` + DataClient. Tab tak JSON export/import hi sync ka rasta hai.
- Tools: `sync_export`, `sync_import`, `wear_send`.

### 12. Security layer (`Security.kt`)
- Risky kaam par **do gate**: (1) `Safety.Confirm` turn-based ROKO (pehle se tha), (2) **fingerprint/PIN auth** — `Security.gateRisky()` risky tool (payments, file delete, auto-reply on, PC shutdown/restart/sleep/run, `screen_agent`) par pichhle 5 minute mein confirm na hua ho to rok deta hai. Auth: phone ka system lock screen (`KeyguardManager.createConfirmDeviceCredentialIntent()` — fingerprint/PIN/pattern, jo bhi set hai). `androidx.biometric` dependency app mein NAHI hai, isliye BiometricPrompt library use nahi hui; jab dependency add ho to `Security.requireAuth` ko BiometricPrompt par badla ja sakta hai. Lock set hi na ho to user ko pehle lock lagane ko kaha jata hai. Sirf "kab confirm hua" ka timestamp save hota hai — password/PIN/OTP kabhi nahi.
- Tool: `security_auth` (start/status), `guest_mode` (on/off/status).
- **Guest Mode:** awaaz match na kare (aur awaaz enroll hui ho) to guest mode on — sirf basic tools: weather, open_app, web_search, web_answer, look. Guest ko NO messages, payments, calls, call log, SMS, calendar, notifications, memory, settings. Malik ki awaaz milte hi guest mode off. Enroll hi na hui ho to guest force nahi hota (pehli baar setup).
- `app_action` bhi `Confirm.gate` mein hai (pehli baar send se pehle ROKO).

### PLUS — Voice screen automation (`AppAction.kt`) — TOP FOCUS
- Generic flow `AppAction.runFlow(ctx, steps, defaultWaitMs=1200)`: steps `open_app | search | tap_text | type_text | send | wait | read_screen` — har step ke baad wait, phir `expect` ho to `readScreen()` se verify. Expected text na mile ya step fail ho to wahin ruk jata hai, kaun sa step fail hua ye batata hai — andha-aage nahi badhta. Payment/password/PIN/OTP screen dikhte hi flow ruk jata hai. Sirf background thread se (Gemini `askAgent` thread) — is mein `Thread.sleep` hai. Accessibility mein Vaani ON chahiye.
- Tool: `app_action` (task, steps JSON, ya preset). Preset **`instagram_rohit_hi`** — "Instagram kholo, Rohit ko hi bhejo":
  1. open_app Instagram → 2. wait 2500ms → 3. search "Rohit" → 4. wait 1500ms → 5. tap_text "Rohit" (verify: screen par "Rohit" dikhe) → 6. wait 1200ms → 7. type_text "hi" (Hinglish) → 8. send (verify: "hi" dikhe).
  - Pehli baar Rohit ko bhejne se pehle confirm: pehli call par sirf "Rohit ko pehli baar 'hi' bhejun? Haan bolo to bhejunga" — malik ke "haan" (naya turn + 2.5s) ke baad hi bhejta hai; uske baad Rohit sent-list mein save, dobara confirm nahi.
- Limits: Instagram ka UI (button naam/position) version aur bhasha ke hisaab se badal sakta hai — "Search"/"Send" text na mile to step fail hoga aur flow ruk jayega (galat jagah tap nahi hogi). `send` sirf "Send"/"send" text wala button dabata hai; sirf icon ho to fail hoga. Real phone par test karna baaki hai.

### Nayi permissions (v5.0)
- `SCHEDULE_EXACT_ALARM` + `RECEIVE_BOOT_COMPLETED` — time-based reminders (exact alarm; Android 12+ par Settings > Apps > Vaani > Alarms & reminders mein allow karna hoga, warna inexact + `fireDue()` backup).
- `BLUETOOTH` + `BLUETOOTH_CONNECT` — car mode (Android 12+ par runtime permission bhi chahiye).
- `USE_BIOMETRIC` — security layer ka declaration (Keyguard fallback use hota hai; `USE_FINGERPRINT` deliberately nahi joda — deprecated).
- Koi nayi permission nahi: conversation context, notification summary, document share (ACTION_SEND intent-filter, permission nahi), translation, health (Health Connect app-level permission, manifest nahi), suggestions, voice, sync.

### Setup checklist (ek baar, phone par)
1. Gemini API key (pehle se) + awaaz enroll (guest detection ke liye).
2. **Notification access:** Settings → Notification access → Vaani ON (notification summary/read ke liye).
3. **Accessibility:** Settings → Accessibility → Vaani ON (screen automation, `app_action`, `screen_control`).
4. **Lock screen:** fingerprint/PIN/pattern set karo (security auth ke liye).
5. **Health Connect:** "Health Connect by Android" install (Android 14+ par built-in) → Vaani ko Steps + Sleep permission.
6. **Car:** car stereo Bluetooth se pair karo, Nearby devices / Bluetooth permission do.
7. **PC:** `python3 pc_agent/vaani_pc.py` chalao, token + URL Settings → PC BRIDGE mein daalo, dono ek hi WiFi par.
8. **Wear:** live sync ke liye companion Wear app chahiye (abhi nahi hai) — tab tak JSON export/import use karo.
9. **Exact alarm:** Android 12+ par Settings > Apps > Vaani > Alarms & reminders → allow.

### Honest limits (v5.0)
- **Compile check UNVERIFIED:** is machine par na JDK/kotlinc hai, na Gradle wrapper, na Android SDK — `./gradlew :app:assembleDebug` nahi chal paya. Kotlin files ki brace/paren balance + manual review hua hai; `pc_agent/vaani_pc.py` par `python3 -m py_compile` **PASS** + live HTTP test (status ✅, file_summary ✅, bad token → 401 ✅, LAN check 192.168.1.5 ✅ / 8.8.8.8 ❌ ✅, list_windows fallback ✅, headless screenshot saaf fail ✅). Pehle real build par `gradlew assembleDebug` chalana zaroori hai.
- Health Connect live steps/sleep stub hai (dependency nahi); Wear live sync stub hai (companion app + dependency nahi).
- Notification priority classifier keyword-based hai; `MessagingStyle` kuch apps par khaali aa sakta hai (tab `EXTRA_TEXT` fallback).
- Document: PDF/image text ke liye Gemini key chahiye; max 5 PDF pages; EXIF rotation fix nahi; on-device OCR nahi.
- Translation: offline engine nahi; board reading ek still photo hai, live video OCR nahi.
- Instagram preset real phone par test karna baaki hai (UI text version ke hisaab se badal sakta hai).
- History 50 turns tak hi model ko dikhti hai; `LastRef` pronoun resolution heuristic hai — saaf na ho to model poochhta hai.
- Voice check abhi bhi basic MFCC hai (security nahi); Wi-Fi/Bluetooth silently toggle, silent install/uninstall, call recording Android ki wajah se possible nahi (v3.0 se).

## v5.1 "Screen-intelligence" upgrade — 7 features (ScreenModel shared core)

Sabhi 7 features ek hi shared core par chalte hain: `ScreenModel.kt` (top-level data classes `UiEl`, `WinInfo`, `Snapshot` + `object ScreenModel` — snapshot/toJson/findByRole/findByText/isDangerous/DANGER). `VaaniAccess.kt` par `model()`, `tapEl()`, `tapRole()`, `foregroundPackage()`, `windowsInfo()`, `onScreenDelta` hain. OCR, analysis aur navigation teeno wahi snapshot use karte hain — alag-alag screen model nahi banta.

### 1. Real-time screen reading — `screen_read_live` (`ScreenWatch.kt`)
- `start` / `stop` / `status` (alias `screen_watch` = start). Start par current screen baseline banti hai (pehle se dikh raha dobara nahi bola jata); har naye change par sirf nayi lines (zyada se zyada 3 per event, ~1s debounce) boli jati hain.
- Payment/password/PIN/OTP screen aate hi khud ruk jata hai + bol kar batata hai; 10 minute kuch naya na aaye to auto-stop. Koi service nahi — state sirf memory mein, process marte hi watcher mar jata hai (dobara start karna padega).
- Voice example: "Screen ko live padhna shuru karo" / "Live padhna band karo" / "Live padhna on hai?"

### 2. OCR text extraction — `ocr_screen` (`OcrTools.kt`)
- Screenshot (Android 11+, silent `takeScreenshot`) + Gemini vision se saara visible text + har line ki approximate position (upar/beech/neeche, bayein/beech/dayein), phir ScreenModel node-tree text se merge (dedupe, OCR-only lines "(image se)" flagged).
- Gemini key na ho ya screenshot na mile to sirf node-tree text milta hai + wajah batata hai. Danger screen par poora text nahi padha jata; OTP/PIN/password ke aas-paas ke digits "***" hote hain.
- Voice example: "Screen par kya likha hai, poora padh kar batao"

### 3. Windows + foreground app — `screen_windows`, `screen_app`, `screen_model` (`ScreenTools.kt`)
- `screen_windows`: khuli windows (app / dialog / overlay / keyboard, split-screen pehchan).
- `screen_app`: foreground app **sirf package se** (screen text se kabhi guess nahi); Usage Stats mile to cross-check, na mile to Accessibility wali pehchan. Known apps (Instagram, WhatsApp, YouTube, Maps, Chrome, Gmail, Phone, Messages, Telegram) ki jaani-pehchani screens bhi batata hai.
- `screen_model`: snapshot ka Hinglish summary + role-wise counts + poora JSON (~3000 chars, speech mein nahi bola jata).
- Voice examples: "Screen par kaun si windows khuli hain?" / "Abhi kaun si app khuli hai?" / "Screen ka model batao"

### 4. Screen analysis — `screen_analyse` (`OcrTools.kt`)
- Screenshot + Gemini key ho to structured summary (app, screen/page, kar sakte ho actions, important content — unread message, error, price, warning); warna snapshot/node-text se local heuristic analysis + ye bata kar. Danger screen par refuse.
- Voice example: "Ye screen kya hai, samjha kar batao — yahan kya kar sakti hun?"

### Features 5–6 — Group A/B ke baaki tools upar cover ho gaye hain (Feature 3 ke 3 tools + Features 1, 2, 4); kul 7 tools hain, saaton ke naam Wiring mein list hain.

### 7. Smart UI navigation — `screen_navigate` (`ScreenNav.kt`)
- Goal-directed loop, max 8 steps, Gemini askAgent thread par: har step se pehle fresh ScreenModel snapshot → goal keywords se plan (settings → "Settings" tap; "<name> ki chat kholo" → naam tap; "peeche/back" → global BACK; "search" → Search/EditText tap + query type; "scroll" → scroll up/down) → execute (`VaaniAccess.tapEl` / `tapRole` / `global` / `scroll`) → ~1200ms wait → verify (expected element/text dikhe YA screen ka text pehle se badla ho). Dono na ho to exact step number + expected vs actual screen ke saath wahin ruk jata hai — andha-aage nahi badhta.
- Explicit steps bhi de sakte ho: `steps` JSON array `[{"action":"tap_text","text":"Settings","expect":"Settings"}]` (actions: tap_text, tap_role, back, home, scroll_down, scroll_up, search, wait, open_app). "Settings" tap na mile to system Settings kholne ka fallback hai.
- Safety: danger screen dikhte hi ruk jata hai (wahi standard message); password/PIN/OTP field par kabhi tap nahi, kabhi secret type nahi. Goal mein send/pay/delete/buy (ya "bhej/kharid/payment/transfer") ho to `Confirm.gate` pehle ROKO karta hai — plain navigation (Settings/back/search/scroll) par gate nahi lagta.
- Voice examples: "Settings me jao" / "Rohit ki chat kholo" / "Peeche jao, phir search dabao"

### Wiring (v5.1)
- `Gemini.kt` tools lazy block: `putList(ScreenTools.decls()); putList(ScreenIntelTools.decls()); putList(ScreenNavTools.decls())` — 7 naye tool names (`screen_windows`, `screen_app`, `screen_model`, `screen_read_live`, `ocr_screen`, `screen_analyse`, `screen_navigate`) kisi purane tool se collide nahi karte (dedupe `seen` set bhi hai).
- `Actions.kt` dispatch chain: `ScreenTools.dispatch` → `ScreenIntelTools.dispatch` → `ScreenNavTools.dispatch` (AppActionTools ke baad, Extras.run se pehle).
- `Safety.kt` Confirm.gate: `"screen_navigate"` sirf risky verbs par gate karta hai.
- Compile-bug fix (Group B se): `VaaniAccess.kt` mein `ScreenModel.Snapshot` / `ScreenModel.UiEl` / `ScreenModel.WinInfo` (nested type jaise likhe the) ko top-level naam `Snapshot` / `UiEl` / `WinInfo` kar diya — `ScreenModel.kt` mein ye top-level data classes hain, `ScreenModel` object ke andar nested nahi.

### Nayi permission (v5.1)
- `PACKAGE_USAGE_STATS` — **optional**. Sirf `screen_app` ke Usage Stats cross-check ke liye; app iske bina bhi poori tarah kaam karti hai (pehchan Accessibility se hoti hai). Chaho to Settings > Apps > Vaani > Usage access mein ON karo. Iske alawa koi nayi permission nahi.

### Setup checklist (v5.1, v5.0 ke upar)
1. **Accessibility ON:** Settings → Accessibility → Vaani ON (screen padhna, OCR merge, analysis, navigation — sab ke liye zaroori).
2. **Usage Stats (optional):** Settings > Apps > Vaani > Usage access → allow (sirf `screen_app` cross-check ke liye).
3. **Gemini API key:** OCR (`ocr_screen`) aur screenshot wali analysis (`screen_analyse`) ke liye chahiye; key na ho to sirf node-tree text se kaam chalta hai.
4. **Android 11+:** silent screenshot (`takeScreenshot`) ke liye; usse neeche OCR/analysis mein screenshot nahi milega.

### Honest limits (v5.1)
- **Compile check UNVERIFIED:** is machine par na JDK/kotlinc hai, na Gradle wrapper, na Android SDK — `./gradlew :app:assembleDebug` nahi chal paya. Manifest XML parse + har nayi/badli Kotlin file ki brace/paren balance + tool-name/dispatch/wiring grep + duplicate class/object check hua hai (neeche Verification). Pehle real build par `gradlew assembleDebug` chalana zaroori hai.
- OCR ke liye Gemini key chahiye; positions approximate hain (top/middle/bottom × left/centre/right), pixel-perfect coordinates nahi.
- Live reading event-driven hai (Accessibility events + 1s debounce), pixel-perfect nahi; process marte hi watcher mar jata hai.
- Instagram/dusri apps ka UI text version aur bhasha ke hisaab se badal sakta hai — "Search"/"Send"/chat naam na mile to navigation step fail hoga aur ruk jayega (galat jagah tap nahi hogi).
- ScreenModel snapshot ~200 elements tak capped hai; bahut badi lists ka neeche wala hissa dikh nahi sakta.
- No root / Shizuku — sab kuch Accessibility + Usage Stats (optional) se hota hai.

## v5.2 build fix (2026-11-05) — BUILD SUCCESSFUL
- `./gradlew :app:assembleDebug` verified on this machine: **BUILD SUCCESSFUL in 1m 46s**, APK 4.2 MB (versionCode 18, versionName 4.3, minSdk 26, targetSdk 34).
- Fixed 18 Kotlin errors in 5 files: DocumentShare.kt unclosed comment (`image/*` swallowed the file), NotifService.kt MessagingStyle API (now extras-based), Reminders.kt return-in-expression-body, ScreenModel.kt bogus AccessibilityWindowInfo types, ScreenNav.kt wrong import. Plus preventive fixes (DocumentShare getParcelableExtra cast for API 26-32, VaaniService overlay guard).
- `gradlew` wrapper added (project originally had none — CI calling `./gradlew` would fail without it). Repos in settings.gradle.kts use repo1.maven.org + Google Maven-Central mirror instead of mavenCentral().
- Stubs unchanged: Health Connect live steps/sleep, Wear OS live sync; Instagram preset needs a real-phone test; install + runtime test needs your phone.

## v5.3 real-time notification speaking fix (2026-11-05) — BUILD SUCCESSFUL
- `./gradlew :app:assembleDebug` verified: **BUILD SUCCESSFUL in 1m 7s**, APK 4.2 MB.
- Root causes fixed: (1) fireBurst sirf "message aaya hai, batau kya?" bolta tha aur jawab ka intezaar karta tha — ab poora content (max 200 chars) turant bolta hai, bina gate ke; zaroori (bank/work/delivery/OTP) wale 300ms mein bolte hain. (2) Speaker ka Gemini network call lock ko minute bhar rok deta tha — notifications ke liye alag fast path (Speaker.speakNow, phone ki local TTS, QUEUE_ADD, TTS ready hone tak 3 sec retry). (3) Ek "offer"/"sale" word se legit message spam mein gir jata tha — ab spam ke liye 2+ spam words chahiye. (4) Listener tootne par koi check nahi tha — onListenerConnected/Disconnected + requestRebind, VaaniService har 30 sec check (ghante mein ek baar warning), MainActivity start par hint.
- Naye tools: `notif_status` (listener ON/OFF, aakhri notification, aakhri bolna) aur `notif_test` (test line bolkar report). OTP ke digits kabhi nahi bole jate.
- Phone par zaroori: Notification access ON, Battery Unrestricted, Autostart ON — warna Android listener ko maar deta hai.


## v5.4 — poore app mein sirf Gemini ki awaaz + live chat transcript
- Phone ki robotic TTS (android.speech.tts) poori hata di: notifications (`speakNow`), tone, offline, fallback — sab ab Gemini (Aoede) se. Live conversation ki awaaz bhi Aoede set hai, taaki har jagah ek hi awaaz ho.
- Ek hi voice queue (`Speaker`): notification/call sabse aage, baasi (45 sec+) khabar skip, lambe text sentence-wise todkar bola jata hai. Disk cache: ek baar bani awaaz dobara turant (offline mein bhi) bajti hai.
- Gemini ki awaaz na mile (key/internet/API) to robotic nahi bolta — wajah chat box mein likhi aati hai.
- Live conversation mein STT (aapki baat) aur Vaani ke bolte shabd chat box mein real-time (▌ cursor ke saath) dikhte hain; turn khatam par pakki line ban jati hai.
- Notification: burst delay kam (zaroori 200ms, baaki 1.2s); listener juda na ho to VaaniService khud requestRebind karti hai.
