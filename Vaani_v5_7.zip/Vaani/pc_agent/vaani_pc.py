#!/usr/bin/env python3
"""
Vaani PC bridge - sirf standard library, koi pip install nahi.
Phone se Vaani is PC ko ye kaam bol sakti hai: open_app, open_url, lock, sleep, shutdown, restart,
volume_up/down, mute, play_pause, next, previous, find_file, run (aapki likhi saved command), status,
aur naye: screenshot, list_windows, file_summary, file_search, open_file, open_app_on_pc.

Chalane ka tareeka:   python3 vaani_pc.py
Pehli baar token ban kar print hoga - wahi phone ke Vaani Settings mein daalo, URL = http://<PC-ka-IP>:8765

LAN-ONLY WARNING: Ye bridge SIRF apne ghar ke WiFi / LAN par chalao. Internet par expose MAT karo -
is mein koi internet-facing auth nahi hai, sirf ek shared token hai. Server har request ka source IP
check karta hai aur LAN ke bahar (non-private IP) se aane wali request ko 403 se mana kar deta hai.
Phir bhi: router mein port-forward MAT karo, aur token kisi se share MAT karo.

'run' ke liye vaani_commands.json banao (isi folder mein), jaise:
  {"backup": "rsync -a ~/Documents /mnt/backup", "game": "steam steam://rungameid/12345"}
Sirf isi file ki commands chalti hain - phone se koi bhi shell command nahi chalti.
"""
import base64, fnmatch, hmac, ipaddress, json, os, platform, secrets, shutil, subprocess, sys, time, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN_FILE = os.path.join(HERE, ".vaani_token")
CMD_FILE = os.path.join(HERE, "vaani_commands.json")
PORT = int(os.environ.get("VAANI_PORT", "8765"))
OS = platform.system()  # Windows / Darwin / Linux

if os.path.exists(TOKEN_FILE):
    TOKEN = open(TOKEN_FILE).read().strip()
else:
    TOKEN = secrets.token_urlsafe(24)
    with open(TOKEN_FILE, "w") as f:
        f.write(TOKEN)
    try:
        os.chmod(TOKEN_FILE, 0o600)
    except Exception:
        pass


def sh(cmd, shell=False):
    subprocess.Popen(cmd, shell=shell, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def win_key(code):
    sh(["powershell", "-NoProfile", "-Command", f"(New-Object -ComObject WScript.Shell).SendKeys([char]{code})"])


def open_app(arg):
    if not arg:
        return "Kaun sa app?"
    if OS == "Windows":
        sh(["cmd", "/c", "start", "", arg])
    elif OS == "Darwin":
        sh(["open", "-a", arg])
    else:
        exe = shutil.which(arg) or shutil.which(arg.lower())
        if not exe:
            return f"'{arg}' nahi mila."
        sh([exe])
    return f"{arg} khol diya."


def volume(kind):
    if OS == "Windows":
        win_key({"volume_up": 175, "volume_down": 174, "mute": 173}[kind])
    elif OS == "Darwin":
        script = {"volume_up": "set volume output volume ((output volume of (get volume settings)) + 10)",
                  "volume_down": "set volume output volume ((output volume of (get volume settings)) - 10)",
                  "mute": "set volume output muted not (output muted of (get volume settings))"}[kind]
        sh(["osascript", "-e", script])
    else:
        sh({"volume_up": ["pactl", "set-sink-volume", "@DEFAULT_SINK@", "+10%"],
            "volume_down": ["pactl", "set-sink-volume", "@DEFAULT_SINK@", "-10%"],
            "mute": ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"]}[kind])
    return "Ho gaya."


def media(kind):
    if OS == "Windows":
        win_key({"play_pause": 179, "next": 176, "previous": 177}[kind])
    elif OS == "Darwin":
        return "Mac par media keys abhi support nahi."
    else:
        sh(["playerctl", {"play_pause": "play-pause", "next": "next", "previous": "previous"}[kind]])
    return "Ho gaya."


def find_file(name):
    name = name.lower().strip()
    if not name:
        return "Kaun si file?"
    hits, seen = [], 0
    for root, dirs, files in os.walk(os.path.expanduser("~")):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("node_modules", "AppData", "Library")]
        for fn in files:
            seen += 1
            if name in fn.lower():
                hits.append(os.path.join(root, fn))
        if len(hits) >= 8 or seen > 60000:
            break
    return "; ".join(hits) if hits else f"'{name}' naam ki file nahi mili."


# ---------------- LAN-only check ----------------
# Sirf private/LAN IP (10/8, 172.16/12, 192.168/16, localhost, link-local) se request allowed.
# Bahar se koi bhi request - chahe token sahi ho - 403 se mana kar di jati hai.
def _is_lan(ip):
    try:
        a = ipaddress.ip_address(ip)
        return a.is_private or a.is_loopback or a.is_link_local
    except Exception:
        return False


def _int(v, default):
    try:
        return int(v)
    except Exception:
        return default


# ---------------- Naye commands (Feature 10) ----------------

def screenshot_pc():
    """PC ki screen ka screenshot: file save + base64. Bina GUI wale/headless PC par fail hoga."""
    out = os.path.join(HERE, "vaani_screenshot.png")
    err = None
    # 1) Pillow (PIL) ho to sabse seedha - Windows/macOS/Linux (X11) par chalta hai.
    try:
        from PIL import ImageGrab
        ImageGrab.grab().save(out)
    except Exception as e:
        err = str(e)
        ok = False
        if OS == "Darwin":
            ok = subprocess.run(["screencapture", "-x", out]).returncode == 0
        elif OS == "Windows":
            ps = ("Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; "
                  "$b = New-Object System.Drawing.Bitmap([System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width, "
                  "[System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height); "
                  "$g = [System.Drawing.Graphics]::FromImage($b); $g.CopyFromScreen(0,0,0,0,$b.Size); "
                  f"$b.Save('{out}')")
            ok = subprocess.run(["powershell", "-NoProfile", "-Command", ps]).returncode == 0
        else:
            for cmd in (["scrot", out], ["gnome-screenshot", "-f", out], ["import", "-window", "root", out]):
                if shutil.which(cmd[0]) and subprocess.run(cmd).returncode == 0:
                    ok = True
                    break
        if not ok:
            return ("Screenshot nahi le paya (headless PC ho sakta hai, ya screenshot tool nahi hai). "
                    f"Detail: {err or 'koi tool nahi mila'}")
    try:
        size = os.path.getsize(out)
        with open(out, "rb") as f:
            raw = f.read()
        # Base64 sirf tab jab file chhoti ho (nahi to phone ka jawab bahut bada ho jayega).
        b64 = base64.b64encode(raw).decode() if size <= 1_500_000 else ""
        res = {"result": f"Screenshot save ho gaya: {out} ({size // 1024} KB).", "path": out}
        if b64:
            res["image_b64"] = b64
        else:
            res["result"] += " Base64 nahi bheja (file badi hai) - PC se file le lo."
        return res
    except Exception as e:
        return f"Screenshot save hua par padh nahi paya: {e}"


def list_windows():
    """Mere desktop par kya khula hai - khuli windows/apps ki list (OS ke hisaab se)."""
    titles = []
    note = ""
    try:
        if OS == "Windows":
            ps = ("Get-Process | Where-Object { $_.MainWindowTitle -ne '' } | "
                  "Select-Object -ExpandProperty MainWindowTitle")
            r = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                               capture_output=True, text=True, timeout=15)
            titles = [l.strip() for l in r.stdout.splitlines() if l.strip()]
            if not titles:
                r = subprocess.run(["tasklist", "/v", "/fo", "csv"], capture_output=True, text=True, timeout=15)
                titles = [l.split('","')[-1].strip('"\n') for l in r.stdout.splitlines()[1:]
                          if len(l.split('","')) > 1 and l.split('","')[-1].strip('"\n') not in ("N/A", "")]
                note = " (window title seedha nahi mila, tasklist se liya)"
        elif OS == "Darwin":
            r = subprocess.run(["osascript", "-e",
                                'tell application "System Events" to get name of every process whose visible is true'],
                               capture_output=True, text=True, timeout=15)
            titles = [t.strip() for t in r.stdout.replace(",", "\n").splitlines() if t.strip()]
        else:
            if shutil.which("wmctrl"):
                r = subprocess.run(["wmctrl", "-l"], capture_output=True, text=True, timeout=15)
                titles = [l.split(None, 3)[3] for l in r.stdout.splitlines() if len(l.split(None, 3)) > 3]
            elif shutil.which("xdotool"):
                r = subprocess.run(["xdotool", "search", "--onlyvisible", "--name", ".*",
                                    "getwindowname", "%@"], capture_output=True, text=True, timeout=15)
                titles = [l.strip() for l in r.stdout.splitlines() if l.strip()]
            else:
                note = " (wmctrl/xdotool nahi hai - window list nahi mili, chal rahe programs de raha hu)"
                r = subprocess.run(["ps", "-e", "-o", "comm="], capture_output=True, text=True, timeout=15)
                titles = sorted({l.strip() for l in r.stdout.splitlines() if l.strip()})
    except Exception as e:
        return f"Windows list nahi mili: {e}"
    if not titles:
        return "Koi khuli window nahi dikh rahi." + note
    return "Khula hai" + note + ": " + "; ".join(titles[:40])


_LANGS = {".py": "Python", ".js": "JavaScript", ".ts": "TypeScript", ".java": "Java", ".kt": "Kotlin",
          ".c": "C", ".cpp": "C++", ".h": "C/C++ header", ".html": "HTML", ".css": "CSS",
          ".json": "JSON", ".md": "Markdown", ".sh": "Shell", ".go": "Go", ".rs": "Rust",
          ".txt": "Text", ".xml": "XML", ".yml": "YAML", ".yaml": "YAML"}


def file_summary(path, lines=40):
    """File ka summary: pehli N lines + kul lines + language guess (extension se)."""
    p = os.path.expanduser((path or "").strip())
    if not p:
        return "Kaun si file?"
    if not os.path.isfile(p):
        return f"'{p}' file nahi mili."
    if os.path.getsize(p) > 2_000_000:
        return f"'{p}' bahut badi hai (2 MB se upar) - summary nahi bana sakta."
    try:
        with open(p, encoding="utf-8", errors="replace") as f:
            all_lines = f.read().splitlines()
    except Exception as e:
        return f"File padh nahi paya: {e}"
    n = max(1, min(_int(lines, 40), 200))
    lang = _LANGS.get(os.path.splitext(p)[1].lower(), "unknown")
    head = "\n".join(all_lines[:n])
    return (f"File: {p}\nLanguage (guess): {lang}\nKul lines: {len(all_lines)}\n"
            f"--- pehli {min(n, len(all_lines))} lines ---\n{head}")


def file_search(folder, pattern, limit=20):
    """Naam/pattern se file dhoondo, diye gaye folder ke andar. Natija capped hai."""
    base = os.path.expanduser((folder or "~").strip())
    pat = (pattern or "").strip().lower()
    if not pat:
        return "Kya dhoondhna hai (pattern)?"
    if not os.path.isdir(base):
        return f"'{base}' folder nahi mila."
    lim = max(1, min(_int(limit, 20), 50))
    hits, seen = [], 0
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("node_modules", ".git", "AppData", "Library")]
        for fn in files:
            seen += 1
            if fnmatch.fnmatch(fn.lower(), pat) or pat in fn.lower():
                hits.append(os.path.join(root, fn))
            if len(hits) >= lim or seen > 60000:
                break
        if len(hits) >= lim or seen > 60000:
            break
    if not hits:
        return f"'{pat}' '{base}' mein nahi mili."
    return f"{len(hits)} mili (max {lim}): " + "; ".join(hits)


def open_file(path):
    """File ko uske default app mein kholo (jaise double-click)."""
    p = os.path.expanduser((path or "").strip())
    if not p:
        return "Kaun si file kholu?"
    if not os.path.exists(p):
        return f"'{p}' nahi mili."
    if OS == "Windows":
        os.startfile(p)  # noqa: S606 - sirf user ki khud ki file, phone se token ke saath
    elif OS == "Darwin":
        sh(["open", p])
    else:
        sh(["xdg-open", p])
    return f"'{os.path.basename(p)}' khol di."


def power(kind):
    if OS == "Windows":
        sh({"lock": ["rundll32.exe", "user32.dll,LockWorkStation"],
            "sleep": ["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"],
            "shutdown": ["shutdown", "/s", "/t", "30"], "restart": ["shutdown", "/r", "/t", "30"]}[kind])
    elif OS == "Darwin":
        sh({"lock": ["pmset", "displaysleepnow"], "sleep": ["pmset", "sleepnow"],
            "shutdown": ["osascript", "-e", 'tell app "System Events" to shut down'],
            "restart": ["osascript", "-e", 'tell app "System Events" to restart']}[kind])
    else:
        sh({"lock": ["loginctl", "lock-session"], "sleep": ["systemctl", "suspend"],
            "shutdown": ["systemctl", "poweroff"], "restart": ["systemctl", "reboot"]}[kind])
    return {"lock": "PC lock.", "sleep": "PC sleep.", "shutdown": "PC band ho raha hai.", "restart": "PC restart ho raha hai."}[kind]


def run_saved(name):
    try:
        cmds = json.load(open(CMD_FILE))
    except Exception:
        return "vaani_commands.json nahi mili."
    if name not in cmds:
        return "Ye command saved nahi hai. Saved: " + ", ".join(cmds.keys())
    sh(cmds[name], shell=True)
    return f"'{name}' chala diya."


def handle(action, arg):
    if action == "open_app":
        return open_app(arg)
    if action == "open_url":
        if not arg.startswith(("http://", "https://")):
            return "Sirf http/https link."
        webbrowser.open(arg)
        return "Link khol diya."
    if action in ("lock", "sleep", "shutdown", "restart"):
        return power(action)
    if action in ("volume_up", "volume_down", "mute"):
        return volume(action)
    if action in ("play_pause", "next", "previous"):
        return media(action)
    if action == "find_file":
        return find_file(arg)
    if action == "run":
        return run_saved(arg)
    if action == "status":
        return f"{platform.node()} ({OS}) chal raha hai, samay {time.strftime('%H:%M')}."
    return "Ye action nahi aata."


def handle_req(d):
    """Poori request dict (naye actions ke extra fields: path/folder/pattern/lines/limit ke saath).
    Purana handle(action, arg) abhi bhi chalta hai - purane phone app se kuch nahi tootega."""
    action = str(d.get("action", ""))
    arg = str(d.get("arg", ""))
    if action == "screenshot":
        return screenshot_pc()
    if action == "list_windows":
        return list_windows()
    if action == "file_summary":
        return file_summary(str(d.get("path") or arg), _int(d.get("lines"), 40))
    if action == "file_search":
        return file_search(str(d.get("folder") or "~"), str(d.get("pattern") or arg), _int(d.get("limit"), 20))
    if action == "open_file":
        return open_file(str(d.get("path") or arg))
    if action == "open_app_on_pc":
        return open_app(arg)
    return handle(action, arg)


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def reply(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_POST(self):
        # LAN-only: bahar ki IP se request aaye to token check se pehle hi mana kar do.
        if not _is_lan(self.client_address[0]):
            return self.reply(403, {"result": "Sirf LAN (ghar ka WiFi) se allowed hai."})
        auth = self.headers.get("Authorization", "")
        if not hmac.compare_digest(auth, "Bearer " + TOKEN) or self.path != "/do":
            return self.reply(401, {"result": "Token galat."})
        try:
            n = int(self.headers.get("Content-Length", "0"))
            d = json.loads(self.rfile.read(min(n, 10000)) or b"{}")
            res = handle_req(d)
        except Exception as e:
            res = f"Error: {e}"
        if isinstance(res, dict):  # screenshot jaisa action: result + extra fields (image_b64/path)
            out = {"result": res.get("result", "Ho gaya.")}
            out.update({k: v for k, v in res.items() if k != "result"})
            return self.reply(200, out)
        self.reply(200, {"result": res})


if __name__ == "__main__":
    print(f"Vaani PC bridge chal raha hai: port {PORT}")
    print("LAN-ONLY: sirf ghar ke WiFi se - internet par expose MAT karo, router mein port-forward MAT karo.")
    print(f"Token (phone ke Settings mein daalo): {TOKEN}")
    try:
        ThreadingHTTPServer(("0.0.0.0", PORT), H).serve_forever()
    except KeyboardInterrupt:
        sys.exit(0)
