package com.friday.assistant.actions

import android.content.Context
import com.friday.assistant.screen.ScreenContextService
import org.json.JSONArray
import org.json.JSONObject

/**
 * The bridge between the model and the phone. Every capability FRIDAY has is
 * declared here as a Gemini function; [execute] runs the call on-device and
 * returns a short spoken-style result for the model to relay.
 */
class ActionRouter(private val context: Context) {

    fun execute(name: String, args: JSONObject): String = try {
        when (name) {
            "open_app" -> AppActions.openApp(context, args.optString("app_name"))
            "make_call" -> CallActions.makeCall(context, args.optString("contact_or_number"))
            "answer_call" -> CallActions.answerCall(context)
            "reject_call" -> CallActions.rejectOrEndCall(context)
            "end_call" -> CallActions.rejectOrEndCall(context)
            "control_music" -> MusicActions.control(context, args.optString("action"))
            "now_playing" -> MusicActions.nowPlaying(context)
            "set_volume" -> MusicActions.setVolumePercent(context, args.optInt("percent", 50))
            "read_notifications" -> MessageActions.readNotifications(args.optInt("limit", 5))
            "reply_to_message" -> MessageActions.replyToLatestMessage(
                context, args.optString("app").ifBlank { null }, args.optString("text")
            )
            "send_sms" -> MessageActions.sendSms(
                context, args.optString("contact_or_number"), args.optString("text")
            )
            "get_screen_context" -> ScreenContextService.summary()
            else -> "Unknown action: $name"
        }
    } catch (e: Exception) {
        "That action failed: ${e.message}"
    }

    companion object {
        val SYSTEM_INSTRUCTION = """
            You are FRIDAY, a premium voice assistant living on the user's Android phone.
            Speak naturally, briefly and warmly — one or two short sentences unless asked for more.
            You can do real things on the phone through your tools: open apps, make and answer
            calls, control music, read notifications, reply to messages and texts, and look at
            what is on the screen. When the user asks for something a tool can do, use the tool
            first, then confirm in one short sentence. Never invent results — only report what a
            tool returned. If an incoming call is announced, the user may say "answer it" or
            "reject it" — use the call tools. If asked what is on screen, call get_screen_context
            and use it to help. Keep answers voice-friendly: no lists read aloud beyond three items,
            no markdown, no URLs.
        """.trimIndent()

        fun declarations(): JSONArray {
            fun fn(name: String, desc: String, props: JSONObject, required: JSONArray): JSONObject =
                JSONObject().put("name", name).put("description", desc)
                    .put("parameters", JSONObject().put("type", "OBJECT")
                        .put("properties", props).put("required", required))
            fun str(desc: String) = JSONObject().put("type", "STRING").put("description", desc)
            fun num(desc: String) = JSONObject().put("type", "NUMBER").put("description", desc)

            return JSONArray()
                .put(fn("open_app", "Open an installed app by its spoken name.",
                    JSONObject().put("app_name", str("App name, e.g. WhatsApp, Spotify, Camera")),
                    JSONArray().put("app_name")))
                .put(fn("make_call", "Call a contact by name or a raw phone number.",
                    JSONObject().put("contact_or_number", str("Contact name or phone number")),
                    JSONArray().put("contact_or_number")))
                .put(fn("answer_call", "Answer the currently ringing phone call.",
                    JSONObject(), JSONArray()))
                .put(fn("reject_call", "Reject the currently ringing phone call.",
                    JSONObject(), JSONArray()))
                .put(fn("end_call", "End the current ongoing phone call.",
                    JSONObject(), JSONArray()))
                .put(fn("control_music", "Control music playback in the active media app.",
                    JSONObject().put("action", str("One of: play, pause, next, previous, stop")),
                    JSONArray().put("action")))
                .put(fn("now_playing", "Report what music or media is currently playing or paused.",
                    JSONObject(), JSONArray()))
                .put(fn("set_volume", "Set the media volume as a percentage 0-100.",
                    JSONObject().put("percent", num("Volume percent")),
                    JSONArray().put("percent")))
                .put(fn("read_notifications", "Read the user's latest notifications aloud.",
                    JSONObject().put("limit", num("How many to read (default 5)")),
                    JSONArray()))
                .put(fn("reply_to_message",
                    "Reply to the most recent message notification (WhatsApp, SMS, Telegram...). " +
                    "Use when the user says 'reply ...' after hearing a message.",
                    JSONObject()
                        .put("app", str("Optional app hint: whatsapp, sms, telegram, signal"))
                        .put("text", str("The reply text to send")),
                    JSONArray().put("text")))
                .put(fn("send_sms", "Send a new SMS text message to a contact or number.",
                    JSONObject()
                        .put("contact_or_number", str("Contact name or phone number"))
                        .put("text", str("Message text")),
                    JSONArray().put("contact_or_number").put("text")))
                .put(fn("get_screen_context",
                    "Look at what is currently on the phone screen and describe it. " +
                    "Use when the user asks what is on screen or needs help with visible content.",
                    JSONObject(), JSONArray()))
        }
    }
}
