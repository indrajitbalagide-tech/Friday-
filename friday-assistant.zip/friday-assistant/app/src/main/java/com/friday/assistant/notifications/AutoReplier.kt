package com.friday.assistant.notifications

import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.friday.assistant.FridayApp
import com.friday.assistant.util.ChatLine
import com.friday.assistant.util.RuntimeState
import okhttp3.MediaType.Companion.toMediaType
import com.friday.assistant.voice.Ipv4FirstDns
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Autonomous AI auto-replies (IRIS registry: manage_notification_listener
 * auto-reply mode). Strictly opt-in: runs only when the user switches it on
 * in Configuration AND a Gemini key is set — Gemini writes the reply, and it
 * is sent through the messaging app's own notification reply action.
 * A per-sender cooldown keeps it from ever spamming a conversation.
 */
object AutoReplier {

    private val executor = Executors.newSingleThreadExecutor()
    private val client = OkHttpClient.Builder()
        .dns(Ipv4FirstDns)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    private val lastReplyAt = ConcurrentHashMap<String, Long>()
    private const val COOLDOWN_MS = 60_000L

    fun maybeReply(context: Context, stored: StoredNotification) {
        val settings = FridayApp.instance.settings
        if (!settings.autoReplyEnabled || !settings.hasApiKey) return
        if (!stored.canReply || stored.packageName !in StoredNotification.MESSAGE_PACKAGES) return
        if (stored.text.isBlank()) return
        val now = System.currentTimeMillis()
        val senderKey = stored.packageName + "|" + stored.title
        if (now - (lastReplyAt[senderKey] ?: 0L) < COOLDOWN_MS) return
        lastReplyAt[senderKey] = now
        val apiKey = settings.geminiApiKey
        executor.execute {
            val reply = generateReply(apiKey, stored) ?: return@execute
            if (sendReply(context, stored, reply)) {
                RuntimeState.addLine(
                    ChatLine.Role.SYSTEM,
                    "Auto-reply to ${stored.title} (${stored.appLabel}): \"$reply\""
                )
            }
        }
    }

    private fun generateReply(apiKey: String, stored: StoredNotification): String? = try {
        val prompt = "You are auto-replying on behalf of the user to a chat message. " +
            "Sender: ${stored.title}. Message: \"${stored.text}\". " +
            "Write ONE short, natural, friendly reply in the same language and script " +
            "as the message, maximum 20 words. Output only the reply text, nothing else."
        val body = JSONObject().put(
            "contents",
            JSONArray().put(
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", prompt))
                )
            )
        )
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val json = JSONObject(response.body?.string().orEmpty())
            json.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")
                ?.optJSONObject(0)?.optString("text")
                ?.trim()?.takeIf { it.isNotBlank() }
        }
    } catch (_: Exception) {
        null
    }

    /** Send through the app's own RemoteInput reply action — the supported
     *  way to answer without opening the app. */
    fun sendReply(context: Context, target: StoredNotification, text: String): Boolean = try {
        val intent = Intent()
        val results = Bundle()
        results.putCharSequence(target.replyInput!!.resultKey, text)
        android.app.RemoteInput.addResultsToIntent(arrayOf(target.replyInput), intent, results)
        target.replyIntent!!.send(context, 0, intent)
        true
    } catch (_: Exception) {
        false
    }
}
