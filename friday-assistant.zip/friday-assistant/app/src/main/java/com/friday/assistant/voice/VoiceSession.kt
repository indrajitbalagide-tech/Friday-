package com.friday.assistant.voice

import android.content.Context
import com.friday.assistant.FridayApp
import com.friday.assistant.actions.ActionRouter
import com.friday.assistant.util.ChatLine
import com.friday.assistant.util.RuntimeState
import com.friday.assistant.util.SessionStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * One assistant conversation. Two engines behind one facade:
 *  - Gemini Live (API key present): true realtime voice, natural language,
 *    function calling into ActionRouter.
 *  - On-device (no key / offline): SpeechRecognizer + intent parser + TTS,
 *    same ActionRouter.
 */
class VoiceSession(
    private val context: Context,
    val speaker: Speaker
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val settings get() = FridayApp.instance.settings
    private val router = ActionRouter(context)
    private val audio = AudioEngine()
    private var live: GeminiLiveClient? = null
    private var onDevice: OnDeviceVoice? = null

    val isLive: Boolean get() = live != null

    fun start() {
        if (live != null || onDevice != null) return
        if (settings.hasApiKey) startLive() else startOnDevice()
    }

    fun stop() {
        live?.close(); live = null
        onDevice?.stopListening(); onDevice = null
        audio.release()
        RuntimeState.liveMode.value = false
        RuntimeState.setStatus(SessionStatus.STOPPED, "FRIDAY is stopped")
    }

    /** Push-to-talk for on-device mode; in Live mode the mic is already open. */
    fun talkOnce() {
        if (onDevice != null) {
            speaker.stop()
            onDevice?.startListening()
            RuntimeState.setStatus(SessionStatus.ON_DEVICE, "Listening…")
        }
    }

    /** Announcements (incoming caller, etc.) always use TTS so they work in
     *  both modes and even while a Live turn is in flight. */
    fun announce(text: String) {
        RuntimeState.addLine(ChatLine.Role.SYSTEM, text)
        speaker.speak(text)
    }

    private fun startLive() {
        RuntimeState.setStatus(SessionStatus.CONNECTING, "Connecting to Gemini Live…")
        RuntimeState.liveMode.value = true
        val client = GeminiLiveClient(
            apiKey = settings.geminiApiKey,
            model = settings.liveModel,
            voiceName = settings.voiceName,
            systemInstruction = ActionRouter.SYSTEM_INSTRUCTION,
            functionDeclarations = ActionRouter.declarations(),
            listener = object : GeminiLiveClient.Listener {
                override fun onConnected() {
                    RuntimeState.setStatus(SessionStatus.LISTENING, "Listening — just talk")
                    audio.startPlayback()
                    audio.startCapture { frame ->
                        RuntimeState.micLevel.value = audio.micLevel
                        live?.sendAudio(frame)
                    }
                }

                override fun onAudio(pcm24k: ByteArray) {
                    RuntimeState.setStatus(SessionStatus.SPEAKING, "FRIDAY is speaking…")
                    audio.enqueuePlayback(pcm24k)
                }

                override fun onUserTranscript(text: String) =
                    RuntimeState.addLine(ChatLine.Role.USER, text)

                override fun onAssistantTranscript(text: String) =
                    RuntimeState.addLine(ChatLine.Role.FRIDAY, text)

                override fun onToolCall(id: String, name: String, args: JSONObject) {
                    scope.launch {
                        val result = router.execute(name, args)
                        RuntimeState.addLine(ChatLine.Role.SYSTEM, "$name → $result")
                        live?.sendToolResponse(id, name, result)
                    }
                }

                override fun onInterrupted() {
                    audio.flushPlayback()
                    RuntimeState.setStatus(SessionStatus.LISTENING, "Listening — just talk")
                }

                override fun onTurnComplete() {
                    RuntimeState.setStatus(SessionStatus.LISTENING, "Listening — just talk")
                }

                override fun onError(message: String) {
                    RuntimeState.addLine(ChatLine.Role.SYSTEM, "Live error: $message")
                    RuntimeState.setStatus(SessionStatus.ERROR, "Live connection problem — check key / network")
                }

                override fun onClosed() {
                    if (live != null) {
                        RuntimeState.setStatus(SessionStatus.STOPPED, "Live session closed")
                    }
                }
            }
        )
        live = client
        client.connect()
    }

    private fun startOnDevice() {
        RuntimeState.liveMode.value = false
        RuntimeState.setStatus(SessionStatus.ON_DEVICE, "On-device mode — tap Talk and speak")
        onDevice = OnDeviceVoice(
            context = context,
            router = router,
            speaker = speaker,
            onTranscript = { RuntimeState.addLine(ChatLine.Role.USER, it) },
            onReply = { RuntimeState.addLine(ChatLine.Role.FRIDAY, it) }
        )
        RuntimeState.addLine(
            ChatLine.Role.SYSTEM,
            "On-device mode: no Gemini key set, so I use built-in speech recognition. " +
                "Add a key in Settings for natural realtime conversation."
        )
    }
}
