package com.friday.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.friday.assistant.actions.ActionRouter
import org.json.JSONObject
import java.util.Locale

/**
 * Fully on-device mode (no API key, no internet): Android's SpeechRecognizer
 * feeds a small intent parser that drives the same ActionRouter the Live
 * model uses, and replies go through TextToSpeech. Fast and private, with
 * narrower language understanding than Gemini Live mode.
 */
class OnDeviceVoice(
    private val context: Context,
    private val router: ActionRouter,
    private val speaker: Speaker,
    private val onTranscript: (String) -> Unit,
    private val onReply: (String) -> Unit
) {
    private var recognizer: SpeechRecognizer? = null
    @Volatile var listening = false
        private set

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            val msg = "Speech recognition isn't available on this device."
            onReply(msg); speaker.speak(msg)
            return
        }
        stopListening()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    listening = false
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) {
                        onTranscript(text)
                        handle(text)
                    }
                }
                override fun onError(error: Int) {
                    listening = false
                    if (error != SpeechRecognizer.ERROR_NO_MATCH &&
                        error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    ) {
                        onReply("I didn't catch that — tap the mic and try again.")
                    }
                }
                override fun onReadyForSpeech(params: Bundle?) { listening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer?.startListening(intent)
        listening = true
    }

    fun stopListening() {
        try { recognizer?.stopListening(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        listening = false
    }

    private fun handle(raw: String) {
        val text = raw.trim()
        val lower = text.lowercase()
        val reply: String = when {
            lower.startsWith("open ") || lower.startsWith("launch ") ->
                router.execute("open_app", JSONObject().put("app_name", text.substringAfter(' ').trim()))
            lower.startsWith("call ") ->
                router.execute("make_call", JSONObject().put("contact_or_number", text.substringAfter(' ').trim()))
            lower in setOf("answer", "answer it", "answer the call", "pick up", "accept") ->
                router.execute("answer_call", JSONObject())
            lower in setOf("reject", "reject it", "decline", "hang up", "end call", "end the call") ->
                router.execute("reject_call", JSONObject())
            "pause" in lower && ("music" in lower || "song" in lower || lower == "pause") ->
                router.execute("control_music", JSONObject().put("action", "pause"))
            lower in setOf("play", "resume", "play music") || lower.startsWith("play ") && "music" in lower ->
                router.execute("control_music", JSONObject().put("action", "play"))
            lower in setOf("next", "next song", "skip", "next track") ->
                router.execute("control_music", JSONObject().put("action", "next"))
            lower in setOf("previous", "previous song", "go back") ->
                router.execute("control_music", JSONObject().put("action", "previous"))
            "what's playing" in lower || "what is playing" in lower || "which song" in lower ->
                router.execute("now_playing", JSONObject())
            "notification" in lower ->
                router.execute("read_notifications", JSONObject().put("limit", 5))
            lower.startsWith("reply ") ->
                router.execute("reply_to_message", JSONObject().put("text", text.substringAfter(' ').trim()))
            lower.startsWith("text ") || lower.startsWith("sms ") -> {
                // "text Mom I'll be late" — first word after the verb is the contact
                val rest = text.substringAfter(' ').trim()
                val contact = rest.substringBefore(' ')
                val body = rest.substringAfter(' ', "")
                if (body.isBlank()) "Who should I text, and what should I say?"
                else router.execute("send_sms", JSONObject().put("contact_or_number", contact).put("text", body))
            }
            "screen" in lower || "what do you see" in lower ->
                router.execute("get_screen_context", JSONObject())
            else ->
                "I heard \"$text\". In on-device mode I understand things like " +
                "\"open WhatsApp\", \"call Mom\", \"pause music\", \"read my notifications\" " +
                "or \"what's on my screen\". Add a Gemini API key in Settings for natural conversation."
        }
        onReply(reply)
        speaker.speak(reply)
    }
}
