package com.friday.assistant.actions

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.TelecomManager

/** Real call control via TelecomManager (ANSWER_PHONE_CALLS permission). */
object CallActions {

    @SuppressLint("MissingPermission")
    fun answerCall(context: Context): String {
        val telecom = context.getSystemService(TelecomManager::class.java)
        return try {
            telecom.acceptRingingCall()
            "Call answered."
        } catch (e: Exception) {
            "I couldn't answer the call: ${e.message}"
        }
    }

    @SuppressLint("MissingPermission")
    fun rejectOrEndCall(context: Context): String {
        val telecom = context.getSystemService(TelecomManager::class.java)
        return try {
            if (telecom.isInCall) {
                telecom.endCall()
                "Call ended."
            } else {
                "There's no active call."
            }
        } catch (e: Exception) {
            "I couldn't end the call: ${e.message}"
        }
    }

    @SuppressLint("MissingPermission")
    fun makeCall(context: Context, contactOrNumber: String): String {
        val number = resolveNumber(context, contactOrNumber)
            ?: return "I couldn't find a phone number for $contactOrNumber."
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            "Calling $contactOrNumber."
        } catch (e: Exception) {
            // Fall back to the dialler if direct calling is not permitted.
            try {
                context.startActivity(
                    Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                "I've opened the dialler for $contactOrNumber — direct calling needs the phone permission."
            } catch (e2: Exception) {
                "I couldn't start the call: ${e.message}"
            }
        }
    }

    /** Digits go straight through; names are looked up in contacts. */
    fun resolveNumber(context: Context, query: String): String? {
        val digits = query.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 5) return digits
        return try {
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            context.contentResolver.query(
                uri,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$query%"),
                null
            )?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) {
            null
        }
    }
}
