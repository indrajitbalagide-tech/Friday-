package com.friday.assistant.voice

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Full-duplex PCM pipeline.
 * Capture: 16 kHz mono PCM16 (what the Gemini Live API expects as input).
 * Playback: 24 kHz mono PCM16 (what the Live API returns).
 * System echo cancellation / noise suppression are attached when the
 * hardware exposes them, which keeps barge-in usable on speakerphone.
 */
class AudioEngine {
    private val scope = CoroutineScope(Dispatchers.IO)
    private var captureJob: Job? = null
    private var playbackJob: Job? = null
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private val playQueue = ConcurrentLinkedQueue<ByteArray>()
    private val playing = AtomicBoolean(false)

    /** RMS level of the most recent mic frame, 0f..1f — drives the UI orb. */
    @Volatile var micLevel: Float = 0f
        private set

    @SuppressLint("MissingPermission")
    fun startCapture(onFrame: (ByteArray) -> Unit) {
        stopCapture()
        val minBuf = AudioRecord.getMinBufferSize(
            CAPTURE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            CAPTURE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, FRAME_BYTES * 4)
        )
        if (AcousticEchoCanceler.isAvailable()) {
            AcousticEchoCanceler.create(rec.audioSessionId)?.enabled = true
        }
        if (NoiseSuppressor.isAvailable()) {
            NoiseSuppressor.create(rec.audioSessionId)?.enabled = true
        }
        record = rec
        rec.startRecording()
        captureJob = scope.launch {
            val buf = ByteArray(FRAME_BYTES)
            while (isActive) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) {
                    micLevel = rms(buf, n)
                    onFrame(buf.copyOf(n))
                }
            }
        }
    }

    fun stopCapture() {
        captureJob?.cancel(); captureJob = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release(); record = null
        micLevel = 0f
    }

    fun startPlayback() {
        if (track != null) return
        val minBuf = AudioTrack.getMinBufferSize(
            PLAYBACK_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(PLAYBACK_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, 8192))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        t.play()
        playing.set(true)
        playbackJob = scope.launch {
            while (isActive) {
                val chunk = playQueue.poll()
                if (chunk == null) {
                    Thread.sleep(10)
                } else {
                    t.write(chunk, 0, chunk.size)
                }
            }
        }
    }

    fun enqueuePlayback(pcm: ByteArray) {
        if (track == null) startPlayback()
        playQueue.add(pcm)
    }

    /** Barge-in: drop everything still queued so the assistant stops talking at once. */
    fun flushPlayback() {
        playQueue.clear()
        try {
            track?.pause()
            track?.flush()
            track?.play()
        } catch (_: Exception) {}
    }

    fun stopPlayback() {
        playbackJob?.cancel(); playbackJob = null
        playing.set(false)
        playQueue.clear()
        try { track?.stop() } catch (_: Exception) {}
        track?.release(); track = null
    }

    fun release() {
        stopCapture()
        stopPlayback()
    }

    private fun rms(buf: ByteArray, n: Int): Float {
        var sum = 0.0
        var i = 0
        while (i + 1 < n) {
            val s = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort().toInt()
            sum += s * s
            i += 2
        }
        val count = (n / 2).coerceAtLeast(1)
        return (Math.sqrt(sum / count) / 32768.0).toFloat().coerceIn(0f, 1f)
    }

    companion object {
        const val CAPTURE_RATE = 16000
        const val PLAYBACK_RATE = 24000
        private const val FRAME_BYTES = 3200 // 100 ms of 16 kHz PCM16 mono
    }
}
