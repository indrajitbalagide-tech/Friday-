package com.friday.assistant.actions

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.telephony.SmsManager
import com.friday.assistant.notifications.NotificationStore

/** Quick replies: through the messaging app's own notification reply action
 *  when one exists (WhatsApp, Messages, Telegram...), else direct SMS. */
object MessageActions {

    fun readNotifications(limit: Int): String {
        val items = NotificationStore.snapshot().take(limit.coerceIn(1, 15))
        if (items.isEmpty()) return "You have no notifications right now."
        val sb = StringBuilder("Here are your latest notifications. ")
        items.forEachIndexed { i, n ->
            sb.append("${i + 1}. ${n.appLabel}: ${n.title}")
            if (n.text.isNotBlank() && n.text != n.title) sb.append(" — ${n.text}")
            sb.append(". ")
        }
        return sb.toString().trim()
    }

    fun replyToLatestMessage(context: Context, appHint: String?, text: String): String {
        val pkg = when (appHint?.lowercase()) {
            "whatsapp" -> "com.whatsapp"
            "sms", "messages", "message" -> "com.google.android.apps.messaging"
            "telegram" -> "org.telegram.messenger"
            "signal" -> "org.thoughtcrime.securesms"
            else -> null
        }
        val target = NotificationStore.latestMessage(pkg)
            ?: NotificationStore.latestMessage()
            ?: return "I don't see a recent message I can reply to."
        if (!target.canReply) {
            return "The latest ${target.appLabel} notification doesn't offer a quick reply. " +
                "Open ${target.appLabel} to answer it."
        }
        return try {
            val intent = Intent()
            val results = Bundle()
            results.putCharSequence(target.replyInput!!.resultKey, text)
            // Reuse the app's own RemoteInput so the receiving app matches the
            // result by its resultKey, exactly as its own reply UI would.
            android.app.RemoteInput.addResultsToIntent(
                arrayOf(target.replyInput), intent, results
            )
            target.replyIntent!!.send(context, 0, intent)
            "Replied to ${target.title} on ${target.appLabel}: \"$text\"."
        } catch (e: Exception) {
            "The reply didn't go through: ${e.message}"
        }
    }

    fun sendSms(context: Context, contactOrNumber: String, text: String): String {
        val number = CallActions.resolveNumber(context, contactOrNumber)
            ?: return "I couldn't find a number for $contactOrNumber."
        return try {
            @Suppress("DEPRECATION")
            val sms = SmsManager.getDefault()
            val parts = sms.divideMessage(text)
            sms.sendMultipartTextMessage(number, null, parts, null, null)
            "Text sent to $contactOrNumber."
        } catch (e: Exception) {
            "I couldn't send the text: ${e.message}"
        }
    }
}
