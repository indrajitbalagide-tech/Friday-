package com.friday.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.friday.assistant.service.AssistantService
import com.friday.assistant.ui.CyberOrb
import com.friday.assistant.ui.HoloBackground
import com.friday.assistant.ui.HudPanel
import com.friday.assistant.ui.SpectrumBars
import com.friday.assistant.util.ChatLine
import com.friday.assistant.util.Permissions
import com.friday.assistant.util.RuntimeState
import com.friday.assistant.util.SessionStatus

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent?.getBooleanExtra(EXTRA_AUTOSTART, false) == true) {
            AssistantService.start(this)
        }
        setContent { FridayScreen() }
    }

    companion object {
        const val EXTRA_AUTOSTART = "autostart"
    }
}

private val FridayColors = darkColorScheme(
    primary = Color(0xFF00F0FF),
    secondary = Color(0xFFFF007A),
    tertiary = Color(0xFF7000FF),
    background = Color(0xFF05010B),
    surface = Color(0xFF120826),
    onBackground = Color(0xFFE2E8F0),
    onSurface = Color(0xFFE2E8F0),
    onPrimary = Color(0xFF02141A)
)

@Composable
private fun FridayScreen() {
    val context = LocalContext.current
    val settings = remember { FridayApp.instance.settings }
    val running by RuntimeState.serviceRunning.collectAsState()
    val status by RuntimeState.status.collectAsState()
    val detail by RuntimeState.statusDetail.collectAsState()
    val lines by RuntimeState.transcript.collectAsState()
    val micLevel by RuntimeState.micLevel.collectAsState()
    val liveMode by RuntimeState.liveMode.collectAsState()

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* state recomposes on resume */ }

    var refreshTick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { refreshTick++ }

    MaterialTheme(colorScheme = FridayColors) {
      Box(Modifier.fillMaxSize()) {
        HoloBackground()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Text(
                "F R I D A Y",
                fontSize = 32.sp, fontWeight = FontWeight.Bold,
                color = Color(0xFF00F0FF)
            )
            Text(
                if (liveMode) "GEMINI LIVE // REALTIME VOICE" else "ON-DEVICE VOICE MODE",
                color = Color(0xFFFF007A), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))

            // ---- Cyber orb (IRIS-X style) ----
            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .size(216.dp)
                    .clickable(enabled = running) { AssistantService.talk(context) },
                contentAlignment = Alignment.Center
            ) {
                CyberOrb(
                    level = micLevel,
                    active = running,
                    speaking = status == SessionStatus.SPEAKING,
                    modifier = Modifier.fillMaxSize()
                )
                Icon(
                    Icons.Filled.Mic, contentDescription = "Talk",
                    tint = Color.White, modifier = Modifier.size(52.dp)
                )
            }
            SpectrumBars(
                level = micLevel,
                active = running,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .fillMaxWidth(0.72f)
                    .height(34.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                detail.uppercase(),
                modifier = Modifier.align(Alignment.CenterHorizontally),
                color = Color(0xFF00F0FF), fontSize = 13.sp, fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = {
                        permissionLauncher.launch(Permissions.runtimePermissions())
                        AssistantService.start(context)
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = FridayColors.primary)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Text("Start FRIDAY")
                }
                OutlinedButton(
                    onClick = { AssistantService.stop(context) },
                    modifier = Modifier.weight(1f),
                    enabled = running
                ) {
                    Icon(Icons.Filled.Stop, contentDescription = null)
                    Text("Stop")
                }
            }
            Spacer(Modifier.height(20.dp))

            // ---- Transcript ----
            if (lines.isNotEmpty()) {
                Text("// CONVERSATION", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Color(0xFF00F0FF))
                Spacer(Modifier.height(8.dp))
                HudPanel(Modifier.fillMaxWidth().height(220.dp)) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(lines) { line ->
                            val (label, color) = when (line.role) {
                                ChatLine.Role.USER -> "YOU" to Color(0xFF00F0FF)
                                ChatLine.Role.FRIDAY -> "FRIDAY" to Color(0xFFFF5CA8)
                                ChatLine.Role.SYSTEM -> "//" to Color(0xFF8E8CA8)
                            }
                            Text("$label  ${line.text}", color = color, fontSize = 14.sp)
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
            }

            // ---- Setup checklist ----
            Text("// SYSTEM SETUP", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Color(0xFF00F0FF))
            Spacer(Modifier.height(8.dp))
            HudPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SetupRow("Microphone, calls, contacts, SMS",
                        Permissions.runtimePermissions().all { Permissions.has(context, it) }) {
                        permissionLauncher.launch(Permissions.runtimePermissions())
                    }
                    SetupRow("Floating bubble (overlay)", Permissions.overlayGranted(context)) {
                        context.startActivity(Permissions.overlaySettingsIntent(context))
                    }
                    SetupRow("Notification access (read + quick reply)",
                        Permissions.notificationAccessGranted(context)) {
                        context.startActivity(Permissions.notificationAccessIntent())
                    }
                    SetupRow("Screen awareness (accessibility)",
                        Permissions.accessibilityGranted(context)) {
                        context.startActivity(Permissions.accessibilityIntent())
                    }
                    SetupRow("Run reliably in background (battery)",
                        Permissions.batteryIgnored(context)) {
                        try {
                            context.startActivity(Permissions.batteryIntent(context))
                        } catch (_: Exception) { }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))

            // ---- Settings ----
            Text("// CONFIGURATION", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Color(0xFF00F0FF))
            Spacer(Modifier.height(8.dp))
            HudPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    var key by remember { mutableStateOf(settings.geminiApiKey) }
                    OutlinedTextField(
                        value = key,
                        onValueChange = { key = it; settings.geminiApiKey = it },
                        label = { Text("Gemini API key (for realtime Live mode)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    var voice by remember { mutableStateOf(settings.voiceName) }
                    OutlinedTextField(
                        value = voice,
                        onValueChange = { voice = it; settings.voiceName = it },
                        label = { Text("Live voice (Kore, Puck, Charon, Fenrir, Aoede)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    var announce by remember { mutableStateOf(settings.announceCallers) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Announce caller names aloud", Modifier.weight(1f))
                        Switch(checked = announce, onCheckedChange = {
                            announce = it; settings.announceCallers = it
                        })
                    }
                    var overlayOn by remember { mutableStateOf(settings.overlayEnabled) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Show floating bubble", Modifier.weight(1f))
                        Switch(checked = overlayOn, onCheckedChange = {
                            overlayOn = it; settings.overlayEnabled = it
                        })
                    }
                    Text(
                        "Without an API key FRIDAY still works on-device: \"open WhatsApp\", " +
                            "\"call Mom\", \"pause music\", \"read my notifications\", \"what's on my screen\".",
                        color = Color(0xFFB9B6D9), fontSize = 13.sp
                    )
                }
            }
            Spacer(Modifier.height(28.dp))
        }
      }
    }
}

@Composable
private fun SetupRow(title: String, done: Boolean, onGrant: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Icon(
            if (done) Icons.Filled.CheckCircle else Icons.Filled.Warning,
            contentDescription = null,
            tint = if (done) Color(0xFF00F0FF) else Color(0xFFFF007A),
            modifier = Modifier.size(20.dp)
        )
        Text("  $title", Modifier.weight(1f), fontSize = 14.sp)
        if (!done) {
            OutlinedButton(onClick = onGrant) { Text("Grant") }
        }
    }
}
