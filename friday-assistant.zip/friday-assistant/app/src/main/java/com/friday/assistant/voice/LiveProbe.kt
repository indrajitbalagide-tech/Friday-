package com.friday.assistant.voice

import android.os.Handler
import android.os.Looper
import com.friday.assistant.actions.ActionRouter
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

/**
 * One-shot Gemini Live connection test (Settings -> "Live test karo").
 *
 * Opens the REAL Live WebSocket with the saved key, model and voice, sends
 * the real setup message, and reports the first definite outcome in plain
 * Hinglish: setup complete (the whole pipeline works), a named error, an
 * early close (usually key/model), or a timeout (network not reaching
 * Google's Live server). Built because Live failures on the user's phone
 * were invisible - the assistant silently fell back to robotic TTS and
 * nobody could tell whether the key, the model or the network was at fault.
 */
object LiveProbe {

    private const val TIMEOUT_MS = 30_000L

    fun test(apiKey: String, model: String, voiceName: String, onResult: (String) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        val done = AtomicBoolean(false)
        var client: GeminiLiveClient? = null

        fun finish(msg: String) {
            if (done.compareAndSet(false, true)) {
                try { client?.close() } catch (_: Exception) {}
                main.post { onResult(msg) }
            }
        }

        client = GeminiLiveClient(
            apiKey = apiKey,
            model = model,
            voiceName = voiceName,
            systemInstruction = "You are FRIDAY, a voice assistant. This is a connection test.",
            functionDeclarations = ActionRouter.declarations(),
            listener = object : GeminiLiveClient.Listener {
                override fun onConnected() = finish(
                    "✓ Live jud gaya! WebSocket aur setup dono ho gaye - ab Start " +
                        "dabane par FRIDAY natural awaaz mein real-time baat karegi."
                )

                override fun onAudio(pcm24k: ByteArray) {}
                override fun onUserTranscript(text: String) {}
                override fun onAssistantTranscript(text: String) {}
                override fun onToolCall(id: String, name: String, args: JSONObject) {}
                override fun onInterrupted() {}
                override fun onTurnComplete() {}

                override fun onError(message: String) = finish(
                    "✗ Live nahi juda. Server ki taraf se: $message"
                )

                override fun onClosed() = finish(
                    "✗ Live judne se pehle band ho gaya - aksar iska matlab hai " +
                        "key ya Live model ka naam theek nahi hai."
                )
            }
        )
        client.connect()

        main.postDelayed({
            finish(
                "✗ 30 second mein Live taiyaar nahi hua - phone se Google ke Live " +
                    "server tak ka rasta atak raha hai (network timeout). Wi-Fi par " +
                    "dobara try karke dekho."
            )
        }, TIMEOUT_MS)
    }
}
