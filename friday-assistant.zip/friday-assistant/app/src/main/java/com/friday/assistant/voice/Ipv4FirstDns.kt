package com.friday.assistant.voice

import okhttp3.Dns
import java.net.Inet4Address
import java.net.InetAddress

/**
 * Prefer IPv4 addresses for Google's servers. On several Indian mobile
 * networks (CGNAT, half-configured IPv6) the IPv6 route to
 * generativelanguage.googleapis.com silently black-holes, which surfaces
 * as a WebSocket connect timeout even though "the internet works" - the
 * #1 FRIDAY Live failure (E1). IPv4-first removes that whole failure
 * class; any IPv6 addresses are kept as later fallbacks.
 */
object Ipv4FirstDns : Dns {
    override fun lookup(hostname: String): List<InetAddress> {
        val all = Dns.SYSTEM.lookup(hostname)
        val v4 = all.filterIsInstance<Inet4Address>()
        return if (v4.isEmpty()) all else v4 + (all - v4.toSet())
    }
}
