package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * v5.27 — BRAIN ROUTER: Gemini ke bina bhi dimaag.
 *
 * Order: OpenAI-style free API #1 (jaise Groq) -> #2 (jaise OpenRouter) -> Gemini (aakhri fallback).
 * Jo provider Settings mein set nahi, wo chhod diya jata hai. Koi bhi fail ho to agla try hota hai.
 *
 * Tools: Gemini ki tool list (Gemini.tools) OpenAI format mein badli jati hai, aur har request par sirf
 * sabse kaam ke ~18 tools bheje jate hain (chhote / free models 100+ tools ek saath nahi sambhal paate).
 * Har tool Actions.run se hi chalta hai, isliye guest mode / ROKO confirm / diary sab waise hi lagu hain.
 *
 * NOTE: Live (bolti hui) conversation abhi bhi Gemini Live se hi chalti hai. Router typed / agent raaste mein chalta hai.
 */
object BrainRouter {
    class Provider(val id: String, val label: String, val chatUrl: String, val key: String, val model: String, val timeoutMs: Int)

    /** Tool chalne ke baad provider toot jaye to dobara doosre brain se mat chalao (kaam do baar ho jata). */
    private class PartialFail(msg: String) : RuntimeException(msg)

    private val hist = ArrayList<JSONObject>()   // OpenAI-format {role, content} — chhoti yaadasht
    private const val HIST_MAX = 16
    private const val MAX_STEPS = 8
    private const val MAX_TOOLS = 18

    @Volatile var lastBrain: String = ""

    private val CORE = setOf(
        "memory", "web_answer", "open_app", "call", "whatsapp", "app_agent", "system_control", "weather",
        "timer", "alarm", "reminder_add", "past_search", "team_run", "flashlight", "media", "play_youtube",
        "navigate", "calendar_read", "screen_control"
    )

    private const val AGENT_RULES = " Tum ek agent bhi ho: bade kaam ko khud chhote steps mein todo, tools ek ke baad ek chalao, " +
        "har result dekho aur poora kaam hone tak chalo. Tool fail ho to doosra tareeka try karo. " +
        "Ant mein user ki bhasha mein ek chhoti line mein batao kya hua. " +
        "Agar tool 'ROKO' bole to user se poochho 'kar du?' aur uski haan ke baad hi wahi tool dobara chalao."

    // ---------------------------------------------------------------- providers

    fun providers(c: Context): List<Provider> {
        val p = P.of(c)
        val out = ArrayList<Provider>()
        fun s(k: String) = (p.getString(k, "") ?: "").trim()

        val k1 = s("br_oa_key")
        if (k1.isNotEmpty()) {
            val base = s("br_oa_url").ifEmpty { "https://api.groq.com/openai/v1" }.trimEnd('/')
            val m = s("br_oa_model").ifEmpty { "llama-3.3-70b-versatile" }
            out.add(Provider("oa1", "Free API #1", "$base/chat/completions", k1, m, 30000))
        }
        val k2 = s("br_oa2_key")
        if (k2.isNotEmpty()) {
            val base = s("br_oa2_url").ifEmpty { "https://openrouter.ai/api/v1" }.trimEnd('/')
            val m = s("br_oa2_model").ifEmpty { "meta-llama/llama-3.3-70b-instruct:free" }
            out.add(Provider("oa2", "Free API #2", "$base/chat/completions", k2, m, 30000))
        }
        return out
    }

    /** Koi non-Google brain set hai? */
    fun hasProviders(c: Context): Boolean = providers(c).isNotEmpty()

    // ---------------------------------------------------------------- tool conversion

    private var toolCache: JSONArray? = null

    private fun convSchema(o: JSONObject): JSONObject {
        val r = JSONObject()
        val ks = o.keys()
        while (ks.hasNext()) {
            val k = ks.next()
            val v = o.get(k)
            if (k == "type" && v is String) {
                r.put(k, v.lowercase())
            } else if (v is JSONObject) {
                r.put(k, convSchema(v))
            } else if (v is JSONArray) {
                val na = JSONArray()
                for (i in 0 until v.length()) {
                    val e = v.get(i)
                    na.put(if (e is JSONObject) convSchema(e) else e)
                }
                r.put(k, na)
            } else {
                r.put(k, v)
            }
        }
        return r
    }

    /** Gemini functionDeclarations -> OpenAI tools (ek baar bana kar cache). */
    @Synchronized private fun allTools(): JSONArray {
        toolCache?.let { return it }
        val out = JSONArray()
        try {
            val fd = JSONArray(Gemini.tools).getJSONObject(0).getJSONArray("functionDeclarations")
            for (i in 0 until fd.length()) {
                val d = fd.getJSONObject(i)
                val params = d.optJSONObject("parameters") ?: JSONObject().put("type", "OBJECT").put("properties", JSONObject())
                val f = JSONObject().put("name", d.getString("name"))
                    .put("description", d.optString("description", "").take(400))
                    .put("parameters", convSchema(params))
                out.put(JSONObject().put("type", "function").put("function", f))
            }
        } catch (_: Exception) {}
        toolCache = out
        return out
    }

    private fun words(t: String): Set<String> =
        t.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 }.toSet()

    /** User ki baat se milte sabse kaam ke tools (+ core set). */
    private fun pickTools(text: String): JSONArray {
        val all = allTools()
        val q = words(text)
        val scored = ArrayList<Pair<Int, JSONObject>>()
        for (i in 0 until all.length()) {
            val t = all.getJSONObject(i)
            val f = t.getJSONObject("function")
            val name = f.getString("name")
            val nameLow = name.lowercase()
            val descLow = f.optString("description", "").lowercase()
            var score = 0
            for (w in q) {
                if (nameLow.contains(w)) score += 3
                if (descLow.contains(w)) score += 1
            }
            if (name in CORE) score += 1
            scored.add(Pair(score, t))
        }
        val picked = ArrayList<JSONObject>()
        val seen = HashSet<String>()
        // pehle jo text se match hue, phir core
        for (pr in scored.sortedByDescending { it.first }) {
            if (picked.size >= MAX_TOOLS) break
            val nm = pr.second.getJSONObject("function").getString("name")
            if (pr.first <= 0) continue
            if (seen.add(nm)) picked.add(pr.second)
        }
        val out = JSONArray()
        for (t in picked) out.put(t)
        return out
    }

    // ---------------------------------------------------------------- main entry

    /**
     * Typed / agent raaste ka dimaag. Off the main thread bulao.
     * Koi bhi brain na chale to exception (MainActivity offline fallback sambhalta hai).
     */
    fun askAgent(ctx: Context, geminiKey: String, text: String): String {
        val pvs = providers(ctx)
        val errs = ArrayList<String>()
        for (pv in pvs) {
            try {
                val r = runProvider(ctx, pv, text)
                if (r.isNotBlank()) {
                    lastBrain = pv.label
                    LongMem.record(ctx, text, r)
                    return r
                }
                errs.add(pv.label + ": khali jawab")
            } catch (e: PartialFail) {
                lastBrain = pv.label
                return e.message ?: "Kaam beech mein ruk gaya."
            } catch (e: Exception) {
                errs.add(pv.label + ": " + (e.message ?: "error").take(70))
            }
        }
        if (geminiKey.isNotEmpty() && P.of(ctx).getBoolean("br_gemini", true)) {
            lastBrain = "Gemini"
            return Gemini.askAgent(ctx, geminiKey, text)   // Gemini.askAgent khud LongMem mein record karta hai
        }
        throw RuntimeException(if (errs.isEmpty()) "Koi brain set nahi hai (Settings > BRAIN ROUTER ya Gemini key)." else errs.joinToString(" | "))
    }

    // ---------------------------------------------------------------- one provider, full agent loop

    private fun runProvider(ctx: Context, pv: Provider, userText: String): String {
        Confirm.newTurn()
        AgentStatus.brain = "Soch raha hai (${pv.label})…"
        val resolved = Gemini.LastRef.resolve(ctx, userText)
        val past = LongMem.relevantText(ctx, userText)
        val sys = Brain.system(ctx, false) + AGENT_RULES + Gemini.LastRef.line(ctx) +
            (if (past.isNotEmpty()) " Purani baat-cheet se milti-julti yaadein (sirf kaam ki ho to use karo): $past" else "")

        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", sys))
        synchronized(hist) { for (h in hist) msgs.put(h) }
        val userMsg = JSONObject().put("role", "user").put("content", resolved)
        msgs.put(userMsg)

        var tools = pickTools(userText)
        var toolsRan = false
        var finalText = ""

        try {
            for (step in 0 until MAX_STEPS) {
                val body = JSONObject().put("model", pv.model).put("messages", msgs).put("temperature", 0.4)
                if (tools.length() > 0) body.put("tools", tools).put("tool_choice", "auto")

                val headers = HashMap<String, String>()
                if (pv.key.isNotEmpty()) headers["Authorization"] = "Bearer " + pv.key
                if (pv.id == "oa2") { headers["X-Title"] = "Vaani" }

                val txt = try {
                    Net.request("POST", pv.chatUrl, body.toString(), headers, pv.timeoutMs)
                } catch (e: RuntimeException) {
                    // Kuch models tools support nahi karte (HTTP 400/422) — pehle step par bina tools ke dobara try.
                    val m = e.message ?: ""
                    if (step == 0 && tools.length() > 0 && (m.contains("HTTP 400") || m.contains("HTTP 422"))) {
                        tools = JSONArray()
                        continue
                    }
                    throw e
                }

                val msg = JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
                val content = if (msg.isNull("content")) "" else msg.optString("content", "")
                val calls = msg.optJSONArray("tool_calls")

                if (calls == null || calls.length() == 0) {
                    finalText = content.trim()
                    break
                }

                if (content.isNotBlank()) finalText = content.trim()

                val asst = JSONObject().put("role", "assistant")
                asst.put("content", if (content.isBlank()) JSONObject.NULL else content)
                asst.put("tool_calls", calls)
                msgs.put(asst)

                for (i in 0 until calls.length()) {
                    val tc = calls.getJSONObject(i)
                    val id = tc.optString("id", "call_$i")
                    val fn = tc.getJSONObject("function")
                    val name = fn.getString("name")
                    val raw = fn.optString("arguments", "{}")
                    val args = try { JSONObject(if (raw.isBlank()) "{}" else raw) } catch (_: Exception) { JSONObject() }
                    toolsRan = true
                    val res = try { Actions.run(ctx, name, args) } catch (e: Exception) { "Error: ${e.message}" }
                    Gemini.noteToolCall(ctx, name, args, res)
                    msgs.put(JSONObject().put("role", "tool").put("tool_call_id", id).put("name", name).put("content", res.take(3000)))
                }
            }
        } catch (e: PartialFail) {
            throw e
        } catch (e: Exception) {
            val why = (e.message ?: "").take(60)
            if (toolsRan) throw PartialFail(pv.label + " beech mein ruk gaya (" + why + "). Kuch kaam ho chuka hai — adhura raha ho to dobara bolo.")
            throw e
        } finally {
            AgentStatus.brain = "Intezaar mein"
        }

        val out = finalText.ifEmpty { if (toolsRan) "Ho gaya." else "" }
        if (out.isNotEmpty()) {
            synchronized(hist) {
                hist.add(JSONObject().put("role", "user").put("content", userText))
                hist.add(JSONObject().put("role", "assistant").put("content", out))
                while (hist.size > HIST_MAX) hist.removeAt(0)
            }
        }
        return out
    }

    // ---------------------------------------------------------------- status

    fun status(c: Context): String {
        val pvs = providers(c)
        val sb = StringBuilder("Brain Router:\n")
        if (pvs.isEmpty()) sb.append("• Koi free brain set nahi (Settings > BRAIN ROUTER).\n")
        for (pv in pvs) {
            sb.append("• ").append(pv.label).append(" — model ").append(pv.model)
            sb.append(" — key set hai")
            sb.append("\n")
        }
        val gem = (P.of(c).getString("key", "") ?: "").isNotEmpty() && P.of(c).getBoolean("br_gemini", true)
        sb.append("• Gemini (aakhri fallback): ").append(if (gem) "ON" else "OFF").append("\n")
        sb.append("• Remote access: ").append(RemoteLink.status).append("\n")
        if (lastBrain.isNotEmpty()) sb.append("Aakhri jawab: ").append(lastBrain)
        return sb.toString().trimEnd()
    }
}
