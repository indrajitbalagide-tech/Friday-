package com.vaani.app

import android.content.Context
import org.json.JSONObject
import java.net.URL

/**
 * v5.28 — REMOTE ACCESS (PC bridge ki jagah).
 *
 * Phone apne private Vaani Remote Server (remote_server/ folder) se bahar ki taraf juda rehta hai
 * (long-poll), isliye router / port-forwarding / PC ki zaroorat nahi. Website ya browser se jo text ya
 * awaaz (mic) aati hai wo yahan aakar wahi dimaag (BrainRouter -> Gemini) se chalti hai jo typed
 * commands ke liye chalta hai, to Safety.Confirm ("kar du?") jaise saare rules waise hi lagu hain.
 *
 * Settings: rl_url (https://...) aur rl_token (server ka DEVICE_TOKEN). Vaani 24h mode ON ho tab chalta hai.
 */
object RemoteLink {
    @Volatile private var running = false
    @Volatile var status: String = "band"
    @Volatile var lastCmdAt: Long = 0L

    private class Cfg(val base: String, val token: String)

    private fun cfg(c: Context): Cfg? {
        val p = P.of(c)
        val url = p.getString("rl_url", "").orEmpty().trim().trimEnd('/')
        val tok = p.getString("rl_token", "").orEmpty().trim()
        if (url.isEmpty() || tok.isEmpty()) return null
        return Cfg(url, tok)
    }

    /** https zaroori hai (token + commands saaf internet par na jayein). Ghar ke LAN / localhost par http chalega. */
    private fun urlProblem(base: String): String? {
        val u = try { URL(base) } catch (e: Exception) { return "Remote URL galat hai." }
        if (u.protocol == "https") return null
        val h = (u.host ?: "").lowercase()
        val lan = h == "localhost" || h.endsWith(".local") || h.startsWith("10.") || h.startsWith("192.168.") || h.startsWith("127.")
        return if (lan) null else "Remote URL https:// se shuru hona chahiye."
    }

    fun configured(c: Context) = cfg(c) != null

    fun start(c: Context) {
        val app = c.applicationContext
        if (running || !configured(app)) return
        running = true
        status = "juda ho raha hai…"
        Thread { loop(app) }.also { it.isDaemon = true; it.name = "vaani-remote" }.start()
    }

    fun stop() { running = false; status = "band" }

    private fun loop(c: Context) {
        var fails = 0
        while (running) {
            val cf = cfg(c)
            if (cf == null) { status = "set nahi hai"; running = false; break }
            val bad = urlProblem(cf.base)
            if (bad != null) { status = bad; running = false; break }
            if (!Net.online(c)) { status = "internet nahi"; sleep(5000); continue }
            try {
                val auth = mapOf("Authorization" to "Bearer ${cf.token}")
                val raw = Net.request("GET", cf.base + "/device/next", null, auth, 35000)
                fails = 0; status = "juda hai ✅"
                val j = if (raw.isBlank()) JSONObject() else JSONObject(raw)
                val text = j.optString("text").trim()
                if (text.isEmpty()) continue
                lastCmdAt = System.currentTimeMillis()
                val reply = run(c, text)
                try { Net.request("POST", cf.base + "/device/reply", JSONObject().put("id", j.optString("id")).put("text", reply).toString(), auth, 15000) }
                catch (_: Exception) { /* jawab na ja paye to agla poll sahi hai */ }
            } catch (e: Exception) {
                fails++
                val m = e.message.orEmpty()
                status = if (m.contains("HTTP 401")) "token galat ❌ (server ka DEVICE_TOKEN check karo)" else "server nahi mil raha (${m.take(40)})"
                sleep(minOf(30_000L, 2_000L * fails))
            }
        }
        running = false
    }

    private fun run(c: Context, text: String): String {
        val key = P.of(c).getString("key", "").orEmpty()
        return try {
            if (key.isEmpty() && !BrainRouter.hasProviders(c)) "Phone mein koi brain set nahi hai (Gemini key ya Settings > BRAIN ROUTER)."
            else BrainRouter.askAgent(c, key, text).ifBlank { "Ho gaya." }
        } catch (e: Exception) {
            Offline.parse(c, text) ?: "Phone par kaam nahi ho paya: ${e.message?.take(160)}"
        }
    }

    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (_: InterruptedException) {} }
}
