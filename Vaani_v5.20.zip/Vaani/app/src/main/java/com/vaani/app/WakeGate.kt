package com.vaani.app

import android.content.Context

/**
 * v5.8 WAKE GATE — "Hey Vaani" / "Vaani" ke bina Vaani na bole, na koi kaam kare.
 *
 * v5.11 BADLAV: asal gate ab MALIK KI AWAAZ hai (VoicePrint), transcript wala wake word nahi.
 * Isliye `wake_strict` ka DEFAULT ab OFF hai — malik ki awaaz match hote hi Vaani har baat ka
 * jawab degi, "Hey Vaani" bolna zaroori nahi. Strict ON karne par purana vyavhaar wapas:
 * transcript mein "Vaani" na ho to awaaz + tools dono band, session turant band.
 * (Picovoice wake word abhi bhi band hai — assets/vaani_wake.ppn file app mein nahi hai.
 *  On-device "Hey Vaani" ke liye Picovoice Console (free) se "Vaani" keyword ki .ppn file
 *  banao, app/src/main/assets/ mein rakho, aur Settings mein Picovoice access key daalo.)
 *
 * Do jagah bina wake word ke bhi chalta hai (kyunki Vaani ne khud poochha ya aapne khud jagaya):
 *  1. Follow-up window: Vaani ne sawal poocha ("answer karun?", "bhej dun?") -> agle ~9 sec ka jawab
 *  2. Explicit start: orb tap, Picovoice wake word hit, bajti call, car-mode connect -> ~12 sec
 * Settings mein "Sirf 'Hey Vaani' par jawab do" toggle (wake_strict, default OFF) se sakht kar sakte ho.
 */
object WakeGate {
    private val DEFAULT_WORDS = setOf("vaani", "vani", "vaanee", "vanee", "wani", "waani", "vany", "vaany",
        "vanni", "vaanii", "baani", "bhaani", "bani", "banni", "vanny", "wanny",
        "वाणी", "वानी", "वाणि", "वाँणी")
    private val FILLER = setOf("hey", "hi", "hello", "ok", "okay", "oye", "are", "arre", "sun", "suno", "listen", "ji",
        "हे", "हाय", "हेलो", "ओके", "सुनो", "सुन", "ओए", "अरे", "जी")
    private val SPLIT = Regex("[^\\p{L}\\p{M}\\p{N}]+")
    private val QUESTION = Regex("(?i)(\\?|karun|kar dun|bhejun|bhej dun|batau|bataun|padhun|padh dun|haan bolo|bolo na|chalu karun)")

    /** Is waqt tak bina wake word ke agla jawab maana jayega. */
    @Volatile var followUpUntil = 0L
    @Volatile var lastReject = 0L

    fun strict(c: Context): Boolean = P.of(c).getBoolean("wake_strict", false)

    private fun words(c: Context): Set<String> {
        val extra = (P.of(c).getString("wake_words", "") ?: "").split(",")
            .map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        return DEFAULT_WORDS + extra
    }

    private fun tokens(text: String): List<String> =
        text.lowercase().split(SPLIT).filter { it.isNotEmpty() }

    /** Transcript mein koi wake word token hai? (v5.11: galat suna gaya shabd bhi pakdo — substring bhi chalega.) */
    fun matches(c: Context, text: String): Boolean {
        if (text.isBlank()) return false
        val w = words(c)
        return tokens(text).any { t -> t in w || (t.length >= 4 && w.any { w2 -> t.contains(w2) || w2.contains(t) }) }
    }

    /** Sirf "Hey Vaani" / "Vaani sun" jaisa — command baad mein aayega. */
    fun isWakeOnly(c: Context, text: String): Boolean {
        val w = words(c)
        val rest = tokens(text).filter { it !in w && it !in FILLER }
        return matches(c, text) && rest.isEmpty()
    }

    /** Vaani ne sawal poochha ho to True (jawab ka follow-up window khulega). */
    fun looksLikeQuestion(botText: String): Boolean = QUESTION.containsMatchIn(botText)

    fun openFollowUp(ms: Long) { followUpUntil = maxOf(followUpUntil, System.currentTimeMillis() + ms) }
    fun followUpOpen(): Boolean = System.currentTimeMillis() < followUpUntil
    fun consumeFollowUp() { followUpUntil = 0L }
}
