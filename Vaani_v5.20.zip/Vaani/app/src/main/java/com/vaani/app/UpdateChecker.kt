package com.vaani.app

import android.app.DownloadManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * v5.9 — IN-APP UPDATE.
 *
 * Problem ye tha: naya APK install karne ke liye purana version DELETE karna padta tha.
 * Root cause: har machine/runner apni alag debug key se sign karta hai (GitHub Actions ka
 * runner har baar nayi debug key banata hai). Android same package ko alag key se update
 * nahi karne deta (INSTALL_FAILED_UPDATE_INCOMPATIBLE) — isliye uninstall karna padta hai.
 * Permanent fix: EK HI release keystore har jagah use karo (build.gradle.kts signingConfigs
 * + .github/workflows/build.yml + README "Release signing" section dekho).
 *
 * Ye updater uske baad kaam karta hai:
 *  1. Settings mein UPDATE CHECK URL daalo — ek chhoti JSON file ka link, format:
 *     {"versionCode": 25, "versionName": "5.10", "apkUrl": "https://.../app-release.apk", "notes": "kya naya hai"}
 *     (GitHub repo mein update.json file rakh kar uska raw.githubusercontent.com link use karo.)
 *  2. "update check karo" bolo ya Settings ka button dabao — naya version ho to batayega.
 *  3. "update install karo" bolo — APK download hoke Android ka install screen khulega;
 *     wahan Install dabate hi purana version bina delete kiye update ho jayega (same key ho to).
 *  Install ke liye phone mein Vaani ko "Install unknown apps" ki permission ek baar deni hogi.
 *
 * Tools: "update_check", "update_install". Dispatch Actions.kt ke else-chain mein hai.
 *
 * v5.11 AUTO-UPDATE: VaaniService har 6 ghante mein khud check karta hai (auto_update toggle,
 * default ON) — naya version mile to khud download karke install screen khol deta hai. Iske liye
 * Settings mein UPDATE CHECK URL set hona zaroori hai (neeche dekho).
 */
object UpdateChecker {
    private const val KEY_URL = "update_json_url"
    /** v5.16 — DEFAULT update URL (user ka GitHub repo: indrajitbalagide-tech/Friday-).
     *  DHYAN: repo ka naam "Friday-" hai — aakhir mein hyphen hai (v5.14/5.15 mein bina hyphen
     *  ke "Friday" likha tha, jo 404 deta tha). Settings mein URL ho to wahi jeetega;
     *  khali ho to ye chalega — Settings mein daalna zaroori nahi. */
    const val DEFAULT_UPDATE_URL = "https://raw.githubusercontent.com/indrajitbalagide-tech/Friday-/main/update.json"
    private const val KEY_CODE = "update_code"
    private const val KEY_APK = "update_apk"
    private const val KEY_NAME = "update_name"
    private const val KEY_NOTES = "update_notes"
    private const val KEY_LAST = "update_last"
    /** v5.19 — "Baad mein" dabane par 24 ghante tak dobara dialog na dikhao. */
    private const val KEY_DISMISS = "update_dismissed_until"

    /** Saved check mein naya version pending hai? (check() ke baad ke prefs padho.) */
    fun hasPending(ctx: Context): Boolean {
        val code = P.of(ctx).getInt(KEY_CODE, 0)
        return code > 0 && code > currentCode(ctx) && P.of(ctx).getString(KEY_APK, "").orEmpty().isNotBlank()
    }

    fun pendingName(ctx: Context): String = P.of(ctx).getString(KEY_NAME, "") ?: ""
    fun pendingNotes(ctx: Context): String = P.of(ctx).getString(KEY_NOTES, "") ?: ""

    fun pendingText(ctx: Context): String {
        val n = pendingName(ctx); val notes = pendingNotes(ctx)
        return "⬆ Naya version $n aaya hai!" + if (notes.isNotBlank()) "\nIsme: $notes" else ""
    }

    fun dismissed(ctx: Context): Boolean =
        System.currentTimeMillis() < P.of(ctx).getLong(KEY_DISMISS, 0L)

    fun dismiss(ctx: Context) {
        P.of(ctx).edit().putLong(KEY_DISMISS, System.currentTimeMillis() + 24 * 3600_000L).apply()
    }

    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)

    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("update_check", "Vaani ka naya version hai ya nahi check karo. Settings mein UPDATE CHECK URL set hona chahiye (version JSON ka link). Naya version mile to version aur notes batayega; install ke liye update_install use karo."),
        fn("update_install", "Naya version download karke install karo. Pehle update_check se confirm karo ki naya version hai. Android ka install screen khulega — wahan Install dabane par purana version bina delete kiye update hoga (same signing key ho to).")
    )

    fun dispatch(ctx: Context, name: String, args: JSONObject): String? = when (name) {
        "update_check" -> check(ctx)
        "update_install" -> install(ctx)
        else -> null
    }

    @Suppress("DEPRECATION")
    fun currentCode(ctx: Context): Int = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
    } catch (_: Exception) { 0 }

    fun currentName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }

    /** Naya version check karo. Result prefs mein save hota hai (install usi ko use karta hai). */
    fun check(ctx: Context): String {
        // v5.14: Settings mein URL khali ho to inbuilt default repo URL use karo.
        val url = P.of(ctx).getString(KEY_URL, "").orEmpty().trim().ifEmpty { DEFAULT_UPDATE_URL }
        return try {
            val j = JSONObject(Net.get(url, timeout = 15000))
            val code = j.optInt("versionCode", -1)
            val apk = j.optString("apkUrl", "").trim()
            if (code < 0 || apk.isEmpty()) return "Update file samajh nahi aayi — usme versionCode aur apkUrl hone chahiye."
            val name = j.optString("versionName", "code $code")
            val notes = j.optString("notes", "")
            val cur = currentCode(ctx)
            P.of(ctx).edit().putInt(KEY_CODE, code).putString(KEY_APK, apk)
                .putString(KEY_NAME, name).putString(KEY_NOTES, notes)
                .putLong(KEY_LAST, System.currentTimeMillis()).apply()
            if (code > cur) "Naya version mil gaya: $name (code $code, abhi ${currentName(ctx)} code $cur hai)." +
                (if (notes.isNotBlank()) " Isme: $notes." else "") +
                " Install karne ke liye 'update install karo' bolo."
            else "Vaani already latest hai — $name (code $code) hi installed hai."
        } catch (e: Exception) {
            "Update check nahi ho paya: ${e.message?.take(100)} — link aur internet check karo."
        }
    }

    /** Aakhri check wala APK download karke PackageInstaller se install karo. */
    fun install(ctx: Context): String {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            try {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                    .setData(android.net.Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
            return "Pehle Vaani ko 'Install unknown apps' ki permission do — settings khol di hai, wahan ON karo, phir dobara 'update install karo' bolo."
        }
        val apkUrl = P.of(ctx).getString(KEY_APK, "").orEmpty()
        val code = P.of(ctx).getInt(KEY_CODE, 0)
        if (apkUrl.isBlank() || code <= currentCode(ctx)) {
            return "Install karne layak naya version nahi mila. Pehle 'update check karo' bolo."
        }
        return try {
            val apkFile = File(ctx.cacheDir, "vaani-update.apk")
            downloadTo(apkUrl, apkFile)
            if (apkFile.length() < 100_000) return "Download gadbad lag rahi hai (file bahut chhoti hai) — update check dobara karo."
            val installer = ctx.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            val sessionId = installer.createSession(params)
            installer.openSession(sessionId).use { session ->
                FileInputStream(apkFile).use { inp ->
                    session.openWrite("apk", 0, apkFile.length()).use { out ->
                        inp.copyTo(out); session.fsync(out)
                    }
                }
                val pi = PendingIntent.getBroadcast(ctx, 0,
                    Intent(ctx, UpdateInstallReceiver::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                session.commit(pi.intentSender)
            }
            "Naya version download ho gaya — install screen khul rahi hai. Wahan Install dabao, purana version delete kiye bina update ho jayega."
        } catch (e: Exception) {
            "Update install nahi ho paya: ${e.message?.take(100)}"
        }
    }

    private fun downloadTo(url: String, dest: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 30000; c.readTimeout = 60000
        c.instanceFollowRedirects = true
        val code = c.responseCode
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        c.inputStream.use { inp -> dest.outputStream().use { out -> inp.copyTo(out) } }
    }
}

/** PackageInstaller ka result — sirf log/toast ke liye; install screen khud user dikhata hai. */
class UpdateInstallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)
        val msg = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
        when (status) {
            PackageInstaller.STATUS_SUCCESS -> {
                VaaniService.log?.invoke("✅ Vaani update install ho gaya.")
                Toast.makeText(c, "Vaani update ho gayi", Toast.LENGTH_LONG).show()
            }
            PackageInstaller.STATUS_FAILURE, PackageInstaller.STATUS_FAILURE_ABORTED,
            PackageInstaller.STATUS_FAILURE_BLOCKED, PackageInstaller.STATUS_FAILURE_CONFLICT,
            PackageInstaller.STATUS_FAILURE_INCOMPATIBLE, PackageInstaller.STATUS_FAILURE_INVALID,
            PackageInstaller.STATUS_FAILURE_STORAGE -> {
                VaaniService.log?.invoke("⚠ Update install fail: $msg — agar 'conflicting signature' likha hai to naya APK purane wali key se sign nahi hai; same release key use karo (README dekho).")
                Toast.makeText(c, "Update install nahi hua: ${msg.take(80)}", Toast.LENGTH_LONG).show()
            }
            else -> VaaniService.log?.invoke("Update install status: $status $msg")
        }
    }
}
