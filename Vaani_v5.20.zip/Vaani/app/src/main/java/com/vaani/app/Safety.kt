package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Risky kaam ke liye do-step confirmation. Pehli call hamesha "ROKO" lautati hai.
 * Dobara chalne ke liye (1) user ki NAYI baat aani chahiye (turn badhna) aur (2) kam se kam 2.5 sec guzarna chahiye.
 * Yaani model akele hi "haan" maan kar aage nahi badh sakta.
 */
object Confirm {
    @Volatile var turn = 0
    private var pendingWhat: String? = null
    private var pendingTurn = 0
    private var pendingAt = 0L

    fun newTurn() { turn++ }

    /** what = risky kaam ka saaf naam. null = chalne do, warna ROKO ka message. */
    @Synchronized fun need(what: String): String? {
        val now = System.currentTimeMillis()
        if (what == pendingWhat && turn > pendingTurn && now - pendingAt in 2500L..90_000L) { pendingWhat = null; return null }
        pendingWhat = what; pendingTurn = turn; pendingAt = now
        return "ROKO: ye risky hai ($what). Abhi kuch mat karo. Malik se bolkar poochho 'kar du?' aur uska jawab sunne ke baad hi " +
            "yahi tool wahi arguments ke saath dobara bulao. Na bole to mat bulao."
    }

    private val PC_RISKY = setOf("shutdown", "restart", "sleep", "run")

    fun gate(c: Context, name: String, a: JSONObject): String? {
        // v5.11 AUTO-DECIDE (default ON): routine kaam khud ho jayein — confirm sirf risky verbs par.
        // Hamesha gated rehte hain: file delete, auto-reply on, PC shutdown/restart (neeche wala when).
        if (P.of(c).getBoolean("auto_decide", true) && name in setOf("app_action", "screen_agent", "screen_navigate")) {
            val risky = listOf("send", "pay", "delete", "buy", "bhej", "kharid", "khareed", "payment", "transfer", "uninstall", "mita")
            val g = (a.optString("goal") + " " + a.optString("task") + " " + a.optString("steps")).lowercase()
            if (risky.none { g.contains(it) }) return null
        }
        val what: String? = when (name) {
            "files" -> if (a.optString("action") == "delete") "file delete: ${a.optString("path")}" else null
            "notifications" -> if (a.optString("action") == "enable_auto_reply") "auto-reply on (aapke naam se jawab jayenge)" else null
            "screen_agent" -> "phone par khud steps chalana: ${a.optString("goal").take(60)}"
            "app_action" -> "phone par khud steps chalana: ${a.optString("task").take(60)}"
            "screen_navigate" -> {
                // Sirf risky verbs par gate: send / pay / delete / buy (Hinglish bhi).
                // Plain navigation (Settings / back / search / scroll) par gate nahi lagta.
                val g = (a.optString("goal") + " " + a.optString("steps")).lowercase()
                val risky = listOf("send", "pay", "delete", "buy", "bhej", "kharid", "khareed", "payment", "transfer", "uninstall", "mita")
                if (risky.any { g.contains(it) }) "screen par navigate karke: ${a.optString("goal").take(60)}" else null
            }
            "pc" -> if (a.optString("action") in PC_RISKY) "PC par ${a.optString("action")} ${a.optString("arg")}".trim() else null
            else -> null
        }
        return if (what == null) null else need(what)
    }
}

/** Vaani ne kya-kya kiya, uska chhota diary (sirf phone mein). "Tumne abhi kya kiya?" ka jawab yahin se. */
object ActionLog {
    private val lock = Any()

    fun add(c: Context, name: String, a: JSONObject, result: String) {
        try {
            val args = if (name == "screen_control" && a.optString("action") == "type_text") "type_text ***" else a.toString().take(80)
            val line = SimpleDateFormat("dd HH:mm", Locale.US).format(Date()) + " $name$args -> " + result.replace('\n', ' ').take(70)
            synchronized(lock) {
                val arr = try { JSONArray(P.of(c).getString("alog", "[]")) } catch (e: Exception) { JSONArray() }
                arr.put(line); while (arr.length() > 60) arr.remove(0)
                P.of(c).edit().putString("alog", arr.toString()).apply()
            }
        } catch (_: Exception) {}
    }

    fun recent(c: Context, n: Int): String = synchronized(lock) {
        val arr = try { JSONArray(P.of(c).getString("alog", "[]")) } catch (e: Exception) { JSONArray() }
        if (arr.length() == 0) "Abhi tak kuch nahi kiya." else
            (maxOf(0, arr.length() - n.coerceIn(1, 20)) until arr.length()).joinToString(" | ") { arr.getString(it) }
    }
}
