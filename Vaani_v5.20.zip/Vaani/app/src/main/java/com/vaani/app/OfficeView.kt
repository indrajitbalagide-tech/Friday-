package com.vaani.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin

/**
 * v5.6 Chalta-phirta office:
 * - Employee chhote hain aur asal mein chalte hain (pair + haath ka jhoola).
 * - Kaam (command) milte hi employee desk se uthkar FILE leke BOSS CABIN jata hai, Vaani ko deta hai, phir apni desk par wapas aakar kaam karta hai.
 * - Khaali baitha agent kuch der (~20-35 sec) baad CAFE POINT par coffee peene jata hai (ek saath max 2), phir wapas.
 * - Vaani sahi chal rahi ho (service ON) to boss cabin mein baithi dikhti hai aur "ONLINE" likha aata hai; band ho to cabin khaali + "OFFLINE".
 * Haalat nakli nahi: MainActivity AgentStatus ke asli timestamps se working[] bharata hai.
 * v5.20: MANAGER bhi hai — aisle par patrol karta hai, har ~12 sec kisi desk par jaakar FILE deta hai ("JOB ✓"),
 * matlab agents ko kaam pe lagata hai. Boss cabin thoda chhota kar diya gaya hai.
 */
class OfficeView(ctx: Context) : View(ctx) {
    var working = BooleanArray(11)
    var bossOn = false
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private val path = Path()
    private var tick = 0
    private val anim = object : Runnable {
        override fun run() { tick++; invalidate(); postDelayed(this, 70) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(anim) }
    override fun onDetachedFromWindow() { removeCallbacks(anim); super.onDetachedFromWindow() }

    companion object {
        val NAMES = listOf("Ears", "Speech", "Brain", "Hands", "Eyes", "Phone", "Mouth", "Memory", "Files", "Home", "Camera")
        private val SHIRTS = listOf("#FF2E4D", "#26A69A", "#B388FF", "#FFB74D", "#4DD0E1", "#81C784", "#F48FB1",
            "#90A4AE", "#AED581", "#FF8A65", "#64B5F6")
        private val SKIN = listOf("#F1C27D", "#E0AC69", "#C68642", "#FFDBAC")
        private val HAIR = listOf("#14100E", "#241611", "#2E2A26", "#191410")
    }

    private enum class St { SEAT, TO_BOSS, AT_BOSS, TO_CAFE, COFFEE, BACK }

    private class Ag(val idx: Int) {
        var st = St.SEAT; var x = 0f; var y = 0f; var inited = false
        val path = ArrayList<FloatArray>()
        var until = 0L; var prevWk = false; var idleSince = 0L; var slot = -1; var face = 1f; var carry = false
        val idleLimit = 18_000L + (idx * 4_300L) % 17_000L
    }
    private val ags = Array(11) { Ag(it) }
    private val slotOwner = intArrayOf(-1, -1)

    // ---- MANAGER (v5.20): aisle par patrol karta hai, har ~12 sec kisi desk par
    // jaakar FILE deta hai ("JOB ✓") — agents ko kaam pe lagata hai. ----
    private enum class MgrSt { PATROL, TO_DESK, AT_DESK }
    private class Mgr {
        var st = MgrSt.PATROL; var x = 0f; var y = 0f; var inited = false
        var dir = 1f; var face = 1f; var targetDesk = -1; var until = 0L
        val path = ArrayList<FloatArray>()
    }
    private val mgr = Mgr()

    private fun mgrMove(): Boolean {
        val wp = mgr.path.firstOrNull() ?: return false
        val dx = wp[0] - mgr.x; val dy = wp[1] - mgr.y; val dist = hypot(dx, dy)
        val sp = 2.2f * d
        if (dist <= sp) { mgr.x = wp[0]; mgr.y = wp[1]; mgr.path.removeAt(0) }
        else { mgr.x += dx / dist * sp; mgr.y += dy / dist * sp }
        if (abs(dx) > 0.5f) mgr.face = if (dx > 0) 1f else -1f
        return true
    }

    private fun updateManager(w: Float, h: Float) {
        val now = SystemClock.uptimeMillis()
        val ay = aisleY(h)
        if (!mgr.inited) { mgr.x = w * 0.08f; mgr.y = ay; mgr.inited = true; mgr.until = now + 8000 }
        when (mgr.st) {
            MgrSt.PATROL -> {
                mgr.x += mgr.dir * 1.5f * d; mgr.face = mgr.dir
                if (mgr.x > w * 0.60f) mgr.dir = -1f
                if (mgr.x < w * 0.06f) mgr.dir = 1f
                if (now > mgr.until) {
                    mgr.targetDesk = (0..10).random()
                    val tx = seatX(mgr.targetDesk, w)
                    mgr.path.clear()
                    if (abs(tx - mgr.x) > 1f) mgr.path.add(floatArrayOf(tx, ay))
                    mgr.st = MgrSt.TO_DESK
                }
            }
            MgrSt.TO_DESK -> if (!mgrMove()) { mgr.st = MgrSt.AT_DESK; mgr.until = now + 2600 }
            MgrSt.AT_DESK -> if (now > mgr.until) { mgr.st = MgrSt.PATROL; mgr.until = now + 12000 }
        }
    }

    // ---- geometry ----
    private fun col(s: String) = Color.parseColor(s)
    private fun backW(w: Float) = w * 0.61f / 5f
    private fun frontW(w: Float) = w * 0.80f / 6f
    private fun seatX(i: Int, w: Float) = if (i >= 6) w * 0.04f + backW(w) * ((i - 6) + 0.5f) else w * 0.015f + frontW(w) * (i + 0.5f)
    private fun deskY(i: Int, h: Float) = if (i >= 6) h * 0.50f else h * 0.84f
    private fun feetY(i: Int, h: Float) = deskY(i, h) + 13 * d
    private fun aisleY(h: Float) = h * 0.665f
    private fun cabinX0(w: Float) = w * 0.72f   // v5.20 — boss cabin thoda chhota (pehle 0.685)
    private fun cabinX1(w: Float) = w * 0.978f
    private fun bossStopX(w: Float) = cabinX0(w) + (cabinX1(w) - cabinX0(w)) * 0.22f
    private fun bossStopY(h: Float) = h * 0.52f
    private fun cafeSpotX(s: Int, w: Float) = if (s == 0) w * 0.845f else w * 0.80f
    private fun cafeSpotY(s: Int, h: Float) = if (s == 0) h * 0.775f else h * 0.735f

    private fun walkTo(a: Ag, tx: Float, ty: Float, h: Float) {
        a.path.clear()
        val ay = aisleY(h)
        if (abs(a.y - ay) > 2 * d) a.path.add(floatArrayOf(a.x, ay))
        if (abs(tx - a.x) > 1f) a.path.add(floatArrayOf(tx, ay))
        a.path.add(floatArrayOf(tx, ty))
    }

    /** Raste par ek kadam. true = abhi chal raha hai. */
    private fun move(a: Ag): Boolean {
        val wp = a.path.firstOrNull() ?: return false
        val dx = wp[0] - a.x; val dy = wp[1] - a.y; val dist = hypot(dx, dy)
        val sp = 2.5f * d
        if (dist <= sp) { a.x = wp[0]; a.y = wp[1]; a.path.removeAt(0) }
        else { a.x += dx / dist * sp; a.y += dy / dist * sp }
        if (abs(dx) > 0.5f) a.face = if (dx > 0) 1f else -1f
        return true
    }

    private fun releaseSlot(a: Ag) { if (a.slot >= 0) { slotOwner[a.slot] = -1; a.slot = -1 } }

    private fun update(w: Float, h: Float) {
        val now = SystemClock.uptimeMillis()
        for (a in ags) {
            val i = a.idx; val sx = seatX(i, w); val sy = feetY(i, h)
            val wk = working.getOrElse(i) { false }
            if (!a.inited) { a.x = sx; a.y = sy; a.inited = true; a.idleSince = now; a.prevWk = wk }
            if (wk) a.idleSince = now
            val rising = wk && !a.prevWk; a.prevWk = wk
            // Naya kaam mila: file leke boss ke paas jao.
            if (rising && bossOn && a.st != St.TO_BOSS && a.st != St.AT_BOSS) {
                releaseSlot(a); a.carry = true; a.st = St.TO_BOSS; walkTo(a, bossStopX(w), bossStopY(h), h)
            }
            when (a.st) {
                St.SEAT -> if (!wk && now - a.idleSince > a.idleLimit &&
                    ags.count { it.st == St.TO_CAFE || it.st == St.COFFEE } < 2) {
                    val s = if (slotOwner[0] == -1) 0 else if (slotOwner[1] == -1) 1 else -1
                    if (s >= 0) { slotOwner[s] = i; a.slot = s; a.st = St.TO_CAFE; walkTo(a, cafeSpotX(s, w), cafeSpotY(s, h), h) }
                }
                St.TO_BOSS -> if (!move(a)) { a.st = St.AT_BOSS; a.until = now + 2600 }
                St.AT_BOSS -> if (now > a.until) { a.carry = false; a.st = St.BACK; walkTo(a, sx, sy, h) }
                St.TO_CAFE -> if (!move(a)) { a.st = St.COFFEE; a.until = now + 9000 + (i % 3) * 2500L }
                St.COFFEE -> if (now > a.until || wk) { releaseSlot(a); a.st = St.BACK; walkTo(a, sx, sy, h) }
                St.BACK -> if (!move(a)) { a.st = St.SEAT; a.x = sx; a.y = sy; a.idleSince = now }
            }
        }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (w == 0f || h == 0f) return
        update(w, h)
        updateManager(w, h)   // v5.20 — Manager patrol + desk visit
        val phase = tick * 0.2f
        drawRoom(c, w, h)
        drawPlant(c, w * 0.022f, h * 0.575f)
        val atBoss = ags.any { it.st == St.AT_BOSS }
        drawCabin(c, w, h, phase, atBoss)
        drawCoffeePoint(c, w, h, phase)
        // Desks + baithe hue log (peeche wali row pehle)
        for (idx in listOf(6, 7, 8, 9, 10, 0, 1, 2, 3, 4, 5)) {
            val a = ags[idx]; val cx = seatX(idx, w); val dy = deskY(idx, h)
            val wk = working.getOrElse(idx) { false }
            if (a.st == St.SEAT) drawSeated(c, cx, dy, idx, wk, phase)
            drawDesk(c, cx, dy, wk, phase, idx)
        }
        // Chalte-phirte employee (neeche wale upar)
        for (a in ags.filter { it.st != St.SEAT }.sortedBy { it.y }) drawWalker(c, a, phase)
        drawManager(c, phase)   // v5.20 — Manager sabke upar dikhe
    }

    /** Kamra: halki deewar, badi khidkiyan (aasman + skyline + sooraj), ceiling lights, lakdi ka farsh, ghadi. */
    private fun drawRoom(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#F6E7D2"); c.drawRect(0f, 0f, w, h * 0.60f, p)
        p.color = Color.parseColor("#EAC79C"); c.drawRect(0f, h * 0.60f, w, h, p)
        p.color = Color.parseColor("#D89B6A"); p.alpha = 70
        rf.set(w * 0.06f, h * 0.76f, w * 0.80f, h * 0.83f); c.drawOval(rf, p); p.alpha = 255
        p.color = Color.parseColor("#C89B6A"); c.drawRect(0f, h * 0.60f, w, h * 0.60f + 1.4f * d, p)
        // Ceiling lights
        p.color = Color.parseColor("#FFF3D6")
        for (lx in listOf(0.20f, 0.48f)) { rf.set(w * lx, h * 0.012f, w * (lx + 0.13f), h * 0.012f + 3.2f * d); c.drawRoundRect(rf, 1.6f * d, 1.6f * d, p) }
        // Khidkiyan — aasman, sooraj, badal, sheher
        val wx = w * 0.03f; val wy = h * 0.05f; val ww = w * 0.63f; val wh = h * 0.25f
        p.color = Color.parseColor("#BDE9FF"); rf.set(wx, wy, wx + ww, wy + wh); c.drawRoundRect(rf, 3 * d, 3 * d, p)
        p.color = Color.parseColor("#FFD54F"); c.drawCircle(wx + ww * 0.86f, wy + wh * 0.28f, 6.5f * d, p)
        p.color = Color.parseColor("#FFFFFF"); p.alpha = 235
        for ((bx, by, bs) in listOf(Triple(0.16f, 0.26f, 1f), Triple(0.52f, 0.18f, 0.8f))) {
            c.drawCircle(wx + ww * bx, wy + wh * by, 4.4f * d * bs, p)
            c.drawCircle(wx + ww * bx + 4.6f * d * bs, wy + wh * by + 0.8f * d, 3.4f * d * bs, p)
        }
        p.alpha = 255
        p.color = Color.parseColor("#8FB8D8")
        val base = wy + wh
        val bw = ww / 9f
        val heights = listOf(0.34f, 0.52f, 0.42f, 0.62f, 0.38f, 0.55f, 0.45f, 0.60f, 0.36f)
        for (i in 0 until 9) c.drawRect(wx + i * bw + 1f, base - wh * heights[i], wx + (i + 1) * bw - 1f, base, p)
        p.color = Color.parseColor("#E8F6FF"); p.alpha = 190
        for (i in 0 until 9) for (r in 0 until 2) c.drawRect(wx + i * bw + bw * 0.3f, base - wh * heights[i] + (3 + r * 5) * d, wx + i * bw + bw * 0.55f, base - wh * heights[i] + (4.6f + r * 5) * d, p)
        p.alpha = 255
        p.style = Paint.Style.STROKE; p.color = Color.parseColor("#FFFFFF"); p.strokeWidth = 2.2f * d
        rf.set(wx, wy, wx + ww, wy + wh); c.drawRoundRect(rf, 3 * d, 3 * d, p)
        c.drawLine(wx + ww / 3f, wy, wx + ww / 3f, wy + wh, p); c.drawLine(wx + 2 * ww / 3f, wy, wx + 2 * ww / 3f, wy + wh, p)
        p.style = Paint.Style.FILL
        // Ghadi (asal samay)
        val cal = Calendar.getInstance()
        val gx = w * 0.345f; val gy = h * 0.375f; val gr = 8.5f * d
        p.color = Color.parseColor("#FFFFFF"); c.drawCircle(gx, gy, gr, p)
        p.style = Paint.Style.STROKE; p.color = Color.parseColor("#5A3A28"); p.strokeWidth = 1.4f * d; c.drawCircle(gx, gy, gr, p)
        fun hand(frac: Double, len: Float, widthPx: Float, col: Int) {
            val a = frac * 2 * Math.PI - Math.PI / 2
            p.strokeWidth = widthPx; p.color = col
            c.drawLine(gx, gy, gx + (Math.cos(a) * len).toFloat(), gy + (Math.sin(a) * len).toFloat(), p)
        }
        hand((cal.get(Calendar.HOUR) % 12 + cal.get(Calendar.MINUTE) / 60.0) / 12.0, gr * 0.52f, 1.7f * d, Color.parseColor("#5A3A28"))
        hand(cal.get(Calendar.MINUTE) / 60.0, gr * 0.78f, 1.2f * d, Color.parseColor("#5A3A28"))
        hand((cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000.0) / 60.0, gr * 0.88f, 0.7f * d, Color.parseColor("#FF2E4D"))
        p.style = Paint.Style.FILL
    }

    /** Farsh par rakha paudha. */
    private fun drawPlant(c: Canvas, cx: Float, base: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#C96F4A")
        path.reset(); path.moveTo(cx - 4.5f * d, base); path.lineTo(cx + 4.5f * d, base)
        path.lineTo(cx + 3.4f * d, base - 6 * d); path.lineTo(cx - 3.4f * d, base - 6 * d); path.close(); c.drawPath(path, p)
        p.color = Color.parseColor("#43A047")
        c.drawCircle(cx, base - 11 * d, 4.6f * d, p); c.drawCircle(cx - 4.4f * d, base - 8.6f * d, 3.4f * d, p); c.drawCircle(cx + 4.4f * d, base - 8.6f * d, 3.4f * d, p)
    }


    /** BOSS CABIN - sheeshe ke andar Vaani ki desk. Service ON = Vaani baithi + ONLINE; OFF = khaali + OFFLINE.
     *  v5.20 — cabin thoda chhota: upar se h*0.05 se h*0.50 tak (pehle 0.045–0.56). Andar ki cheezein rect se proportional hain. */
    private fun drawCabin(c: Canvas, w: Float, h: Float, phase: Float, nod: Boolean) {
        val x0 = cabinX0(w); val x1 = cabinX1(w); val y0 = h * 0.05f; val y1 = h * 0.50f
        val cw = x1 - x0; val base = y0 + (y1 - y0) * 0.88f
        val dx0 = x0 + cw * 0.42f; val dx1 = x1 - cw * 0.05f; val dy = y0 + (y1 - y0) * 0.70f; val bx = (dx0 + dx1) / 2f - 3 * d
        p.style = Paint.Style.FILL
        p.color = col("#F1DDBE"); c.drawRect(x0, y0, x1, y1, p)
        // kursi
        p.color = col("#8D6E63"); rf.set(bx - 8 * d, dy - 16 * d, bx + 8 * d, dy + 1 * d); c.drawRoundRect(rf, 3 * d, 3 * d, p)
        if (bossOn) {
            val bob = sin((phase * (if (nod) 2.2f else 0.8f)).toDouble()).toFloat() * (if (nod) 1.4f else 0.7f) * d
            p.color = col("#17100C"); rf.set(bx - 6 * d, dy - 24 * d + bob, bx + 6 * d, dy - 6 * d + bob); c.drawRoundRect(rf, 3 * d, 3 * d, p)   // baal
            p.color = col("#FF2E4D"); rf.set(bx - 6.5f * d, dy - 12 * d + bob, bx + 6.5f * d, dy + bob * 0.3f); c.drawRoundRect(rf, 3 * d, 3 * d, p)
            p.color = col("#FFDBAC"); c.drawCircle(bx, dy - 17 * d + bob, 4.4f * d, p)
            p.color = col("#17100C"); rf.set(bx - 4.6f * d, dy - 22 * d + bob, bx + 4.6f * d, dy - 16.5f * d + bob); c.drawArc(rf, 180f, 180f, true, p)
            p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 2.4f * d; p.color = col("#FF2E4D")
            c.drawLine(bx - 5 * d, dy - 9 * d + bob, bx - 2 * d, dy + 0.5f * d, p); c.drawLine(bx + 5 * d, dy - 9 * d + bob, bx + 2 * d, dy + 0.5f * d, p)
            p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
        }
        // desk + monitor
        p.color = col("#A9743F"); c.drawRect(dx0, dy, dx1, dy + 3 * d, p)
        c.drawRect(dx0 + 2 * d, dy + 3 * d, dx0 + 4.5f * d, base, p); c.drawRect(dx1 - 4.5f * d, dy + 3 * d, dx1 - 2 * d, base, p)
        p.color = col("#263238"); rf.set(bx + 6 * d, dy - 12 * d, bx + 19 * d, dy - 1.5f * d); c.drawRoundRect(rf, 1.5f * d, 1.5f * d, p)
        p.color = if (bossOn) col("#FFB3C0") else col("#78909C"); rf.set(bx + 7 * d, dy - 11 * d, bx + 18 * d, dy - 2.5f * d); c.drawRoundRect(rf, 1f * d, 1f * d, p)
        tp.color = if (bossOn) col("#C2183F") else col("#8A7A6A"); tp.textSize = 8.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText("VAANI", (dx0 + dx1) / 2f, base + 11 * d, tp)
        // ONLINE / OFFLINE badge
        val bcx = (dx0 + dx1) / 2f; val by0 = y0 + 14 * d
        p.color = if (bossOn) col("#E8F8EC") else col("#ECEFF1"); rf.set(bcx - 19 * d, by0, bcx + 19 * d, by0 + 9.5f * d); c.drawRoundRect(rf, 4.7f * d, 4.7f * d, p)
        val pulse = if (bossOn) (0.6f + 0.4f * sin((phase * 2f).toDouble()).toFloat()) else 1f
        p.color = if (bossOn) Color.argb((255 * pulse).toInt(), 46, 158, 79) else col("#90A4AE"); c.drawCircle(bcx - 12.5f * d, by0 + 4.75f * d, 2.3f * d, p)
        tp.color = if (bossOn) col("#1B7A3A") else col("#607D8B"); tp.textSize = 6.8f * d
        c.drawText(if (bossOn) "ONLINE" else "OFFLINE", bcx + 3 * d, by0 + 7.2f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
        // sheesha + frame + plate
        p.color = col("#D9F2FF"); p.alpha = 46; c.drawRect(x0, y0, x1, y1, p); p.alpha = 255
        p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeWidth = 1.8f * d
        c.drawRect(x0, y0, x1, y1, p); c.drawLine(x1 - cw * 0.28f, y0, x1 - cw * 0.28f, y1, p)
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        val cx = (x0 + x1) / 2f
        rf.set(cx - 23 * d, y0 + 2.5f * d, cx + 23 * d, y0 + 11.5f * d); c.drawRoundRect(rf, 1.5f * d, 1.5f * d, p)
        tp.color = col("#37474F"); tp.textSize = 6.8f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText("BOSS CABIN", cx, y0 + 9.3f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
    }

    /** CAFE POINT - counter par coffee machine, bhaap ke saath. */
    private fun drawCoffeePoint(c: Canvas, w: Float, h: Float, phase: Float) {
        val x0 = w * 0.875f; val x1 = w * 0.992f; val cTop = h * 0.70f; val base = h * 0.865f
        p.style = Paint.Style.FILL
        p.color = col("#8D5524"); c.drawRect(x0 - 2 * d, cTop, x1, cTop + 3 * d, p)
        p.color = col("#A9743F"); c.drawRect(x0, cTop + 3 * d, x1, base, p)
        val mx0 = x0 + (x1 - x0) * 0.2f; val mx1 = x0 + (x1 - x0) * 0.8f; val my0 = cTop - 22 * d
        p.color = col("#37474F"); rf.set(mx0, my0, mx1, cTop); c.drawRoundRect(rf, 2.5f * d, 2.5f * d, p)
        val glow = 0.6f + 0.4f * sin((phase * 1.6f).toDouble()).toFloat()
        p.color = Color.argb(255, (120 * glow).toInt(), (230 * glow).toInt(), (255 * glow).toInt())
        rf.set(mx0 + 4 * d, my0 + 4 * d, mx1 - 4 * d, my0 + 8.5f * d); c.drawRoundRect(rf, 1f * d, 1f * d, p)
        p.color = col("#FFFFFF"); val mc = (mx0 + mx1) / 2f
        rf.set(mc - 3 * d, my0 + 14 * d, mc + 3 * d, my0 + 19 * d); c.drawRoundRect(rf, 0.8f * d, 0.8f * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f * d; p.strokeCap = Paint.Cap.ROUND; p.color = Color.WHITE
        for (s in 0 until 2) {
            val bx = mc + (s - 0.5f) * 3.4f * d; val rise = ((tick * 1 + s * 14) % 40) / 40f
            p.alpha = (170 * (1f - rise)).toInt().coerceIn(0, 170)
            path.reset(); path.moveTo(bx, my0 + 13 * d - rise * 2 * d)
            path.quadTo(bx + 2f * d * sin((phase + s * 2f).toDouble()).toFloat(), my0 + 9 * d - rise * 4 * d, bx, my0 + 5 * d - rise * 5 * d)
            c.drawPath(path, p)
        }
        p.alpha = 255; p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
        tp.color = col("#5A3A28"); tp.textSize = 7f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText("CAFE POINT", (x0 + x1) / 2, base + 9.5f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
    }

    /** Desk + keyboard + monitor (monitor tab ON jab us agent ka kaam chal raha ho). */
    private fun drawDesk(c: Canvas, cx: Float, dy: Float, wk: Boolean, phase: Float, idx: Int) {
        p.style = Paint.Style.FILL; p.color = col("#A9743F")
        c.drawRect(cx - 15 * d, dy, cx + 15 * d, dy + 3 * d, p)
        c.drawRect(cx - 14 * d, dy + 3 * d, cx - 12 * d, dy + 11 * d, p); c.drawRect(cx + 12 * d, dy + 3 * d, cx + 14 * d, dy + 11 * d, p)
        p.color = col("#263238"); rf.set(cx - 9 * d, dy - 1.2f * d, cx - 1 * d, dy + 0.2f * d); c.drawRoundRect(rf, 0.6f * d, 0.6f * d, p)
        p.color = col("#263238"); rf.set(cx + 3 * d, dy - 10 * d, cx + 13 * d, dy - 1f * d); c.drawRoundRect(rf, 1.2f * d, 1.2f * d, p)
        if (wk) {
            val g = 0.82f + 0.18f * sin((phase * 1.4f + idx * 2.1f).toDouble()).toFloat()
            p.color = Color.argb(255, (170 * g).toInt(), (225 * g).toInt(), 255)
        } else p.color = col("#78909C")
        rf.set(cx + 4 * d, dy - 9 * d, cx + 12 * d, dy - 2f * d); c.drawRoundRect(rf, 0.8f * d, 0.8f * d, p)
        tp.color = if (wk) col("#4E342E") else col("#6D4C41"); tp.textSize = 7.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(NAMES[idx], cx, dy + 20 * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
        p.color = if (wk) col("#2E9E4F") else col("#B09A88"); c.drawCircle(cx, dy + 23.5f * d, 1.2f * d, p)
    }

    /** Desk par baitha agent (chhota, saamne se). Kaam = typing + bubble; khaali = oongh + Z. */
    private fun drawSeated(c: Canvas, cx: Float, dy: Float, idx: Int, wk: Boolean, phase: Float) {
        val px = cx - 5 * d
        val bob = if (wk) sin((phase + idx * 1.7f).toDouble()).toFloat() * 0.8f * d else 0f
        val tilt = if (wk) 0f else -1.6f * d
        p.style = Paint.Style.FILL; p.color = col(SHIRTS[idx])
        rf.set(px - 4 * d, dy - 11 * d + bob, px + 4 * d, dy + 0.5f * d); c.drawRoundRect(rf, 2.2f * d, 2.2f * d, p)
        val hx = px + tilt; val hy = dy - 14.5f * d + bob + (if (wk) 0f else 0.8f * d)
        p.color = col(SKIN[idx % SKIN.size]); c.drawCircle(hx, hy, 3.4f * d, p)
        p.color = col(HAIR[idx % HAIR.size]); rf.set(hx - 3.4f * d, hy - 3.8f * d, hx + 3.4f * d, hy + 0.7f * d); c.drawArc(rf, 180f, 180f, true, p)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 2f * d; p.color = col(SHIRTS[idx])
        val ty = dy - 1f * d + (if (wk) sin((phase * 2f + idx).toDouble()).toFloat() * 1.2f * d else 0f)
        c.drawLine(px - 3.4f * d, dy - 8 * d + bob, px - 2 * d, ty, p); c.drawLine(px + 3.4f * d, dy - 8 * d + bob, px + 2 * d, dy - 1f * d, p)
        if (!wk) { p.strokeWidth = 0.9f * d; p.color = col("#4A3428"); c.drawLine(hx - 1.6f * d, hy + 0.3f * d, hx + 1.6f * d, hy + 0.3f * d, p) }
        p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
        if (wk) {
            val bx0 = hx - 2 * d; val by1 = hy - 5.5f * d; val bx1 = hx + 9 * d; val by0 = by1 - 7 * d
            p.color = Color.WHITE; rf.set(bx0, by0, bx1, by1); c.drawRoundRect(rf, 2.5f * d, 2.5f * d, p)
            path.reset(); path.moveTo(hx + 1 * d, by1 - 0.3f * d); path.lineTo(hx + 2.6f * d, by1 + 2.2f * d); path.lineTo(hx + 4f * d, by1 - 0.3f * d); path.close(); c.drawPath(path, p)
            p.color = col("#37474F")
            for (dot in 0 until 3) { p.alpha = if (dot == ((tick / 5 + idx) % 3)) 255 else 110; c.drawCircle(bx0 + (2.6f + dot * 2.8f) * d, (by0 + by1) / 2f, 0.9f * d, p) }
            p.alpha = 255
        } else {
            val f = (tick % 40) / 40f
            tp.color = col("#5C7C99"); tp.alpha = (210 * (1f - f)).toInt().coerceIn(0, 210); tp.textSize = (6.5f + f * 3f) * d
            c.drawText("Z", hx + 5 * d + f * 4 * d, hy - 4 * d - f * 7 * d, tp); tp.alpha = 255
        }
    }

    /** Chalta/khada employee (poora sharir). Haath mein FILE (boss ke paas) ya coffee cup (cafe par). */
    private fun drawWalker(c: Canvas, a: Ag, phase: Float) {
        val i = a.idx; val x = a.x; val y = a.y; val f = a.face
        val moving = a.st == St.TO_BOSS || a.st == St.TO_CAFE || a.st == St.BACK
        val sw = if (moving) sin((phase * 2.6f + i).toDouble()).toFloat() else 0f
        p.style = Paint.Style.FILL; p.color = Color.argb(40, 0, 0, 0); rf.set(x - 5 * d, y - 1 * d, x + 5 * d, y + 1.2f * d); c.drawOval(rf, p)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 2.3f * d; p.color = col("#37474F")
        c.drawLine(x - 1.6f * d, y - 7 * d, x - 1.6f * d + sw * 2.6f * d, y, p); c.drawLine(x + 1.6f * d, y - 7 * d, x + 1.6f * d - sw * 2.6f * d, y, p)
        p.style = Paint.Style.FILL; p.color = col(SHIRTS[i]); rf.set(x - 3.8f * d, y - 16 * d, x + 3.8f * d, y - 6.5f * d); c.drawRoundRect(rf, 2f * d, 2f * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d; p.color = col(SHIRTS[i])
        c.drawLine(x - 3.6f * d * f, y - 14.5f * d, x - 4.4f * d * f - sw * 1.4f * d * f, y - 9.5f * d, p)   // peeche wala haath jhoolta
        val holding = a.carry || a.st == St.COFFEE
        if (holding) c.drawLine(x + 3.6f * d * f, y - 14.5f * d, x + 6.2f * d * f, y - 11.5f * d, p)
        else c.drawLine(x + 3.6f * d * f, y - 14.5f * d, x + 4.4f * d * f + sw * 1.4f * d * f, y - 9.5f * d, p)
        p.style = Paint.Style.FILL
        p.color = col(SKIN[i % SKIN.size]); c.drawCircle(x, y - 19.6f * d, 3.3f * d, p)
        p.color = col(HAIR[i % HAIR.size]); rf.set(x - 3.3f * d, y - 23.3f * d, x + 3.3f * d, y - 18.7f * d); c.drawArc(rf, 180f, 180f, true, p)
        if (a.carry) {   // FILE: orange folder + safed kagaz
            val fx = x + 6.6f * d * f
            p.color = col("#FFB74D"); rf.set(fx - 3.4f * d, y - 14.5f * d, fx + 3.4f * d, y - 7.5f * d); c.drawRoundRect(rf, 0.9f * d, 0.9f * d, p)
            p.color = Color.WHITE; rf.set(fx - 2.5f * d, y - 14f * d, fx + 2.5f * d, y - 10.5f * d); c.drawRect(rf, p)
            p.color = col("#E08A1E"); c.drawRect(fx - 3.4f * d, y - 14.5f * d, fx - 0.4f * d, y - 13.4f * d, p)
        } else if (a.st == St.COFFEE) {   // cup + bhaap
            val cx2 = x + 6.6f * d * f
            p.color = Color.WHITE; rf.set(cx2 - 1.8f * d, y - 14.5f * d, cx2 + 1.8f * d, y - 10.8f * d); c.drawRoundRect(rf, 0.7f * d, 0.7f * d, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 0.8f * d; p.color = Color.WHITE
            val r = ((tick + i * 5) % 30) / 30f; p.alpha = (200 * (1f - r)).toInt().coerceIn(0, 200)
            path.reset(); path.moveTo(cx2, y - 15f * d); path.quadTo(cx2 + 1.5f * d * sin((phase + i).toDouble()).toFloat(), y - 17.5f * d - r * 2 * d, cx2, y - 20f * d - r * 3 * d); c.drawPath(path, p)
            p.alpha = 255; p.style = Paint.Style.FILL
        }
        p.strokeCap = Paint.Cap.BUTT
        if (a.st == St.AT_BOSS) {   // "File de di" bubble
            p.color = Color.WHITE; rf.set(x - 9 * d, y - 36 * d, x + 9 * d, y - 28.5f * d); c.drawRoundRect(rf, 3 * d, 3 * d, p)
            tp.color = col("#2E7D32"); tp.textSize = 6.2f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
            c.drawText("File ✓", x, y - 30.8f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
        } else {
            tp.color = col("#4E342E"); tp.textSize = 6.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
            c.drawText(NAMES[i], x, y - 26 * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
        }
    }

    /** MANAGER (v5.20) — navy suit + laal tie, haath mein FILE, desk par "JOB ✓" bubble. */
    private fun drawManager(c: Canvas, phase: Float) {
        val x = mgr.x; val y = mgr.y; val f = mgr.face
        val moving = mgr.st != MgrSt.AT_DESK
        val sw = if (moving) sin((phase * 2.6f).toDouble()).toFloat() else 0f
        p.style = Paint.Style.FILL; p.color = Color.argb(40, 0, 0, 0); rf.set(x - 5 * d, y - 1 * d, x + 5 * d, y + 1.2f * d); c.drawOval(rf, p)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 2.3f * d; p.color = col("#37474F")
        c.drawLine(x - 1.6f * d, y - 7 * d, x - 1.6f * d + sw * 2.6f * d, y, p); c.drawLine(x + 1.6f * d, y - 7 * d, x + 1.6f * d - sw * 2.6f * d, y, p)
        p.style = Paint.Style.FILL; p.color = col("#1A237E"); rf.set(x - 4.2f * d, y - 16 * d, x + 4.2f * d, y - 6.5f * d); c.drawRoundRect(rf, 2f * d, 2f * d, p)
        p.color = col("#FF2E4D"); rf.set(x - 0.9f * d, y - 15.5f * d, x + 0.9f * d, y - 8 * d); c.drawRoundRect(rf, 0.4f * d, 0.4f * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d; p.color = col("#1A237E")
        c.drawLine(x - 3.8f * d * f, y - 14.5f * d, x - 4.6f * d * f - sw * 1.4f * d * f, y - 9.5f * d, p)
        val carrying = mgr.st == MgrSt.TO_DESK || mgr.st == MgrSt.AT_DESK
        if (carrying) c.drawLine(x + 3.8f * d * f, y - 14.5f * d, x + 6.4f * d * f, y - 11.5f * d, p)
        else c.drawLine(x + 3.8f * d * f, y - 14.5f * d, x + 4.6f * d * f + sw * 1.4f * d * f, y - 9.5f * d, p)
        p.style = Paint.Style.FILL
        p.color = col(SKIN[0]); c.drawCircle(x, y - 19.6f * d, 3.3f * d, p)
        p.color = col(HAIR[0]); rf.set(x - 3.3f * d, y - 23.3f * d, x + 3.3f * d, y - 18.7f * d); c.drawArc(rf, 180f, 180f, true, p)
        if (carrying) {   // FILE: orange folder + safed kagaz
            val fx = x + 6.8f * d * f
            p.color = col("#FFB74D"); rf.set(fx - 3.4f * d, y - 14.5f * d, fx + 3.4f * d, y - 7.5f * d); c.drawRoundRect(rf, 0.9f * d, 0.9f * d, p)
            p.color = Color.WHITE; rf.set(fx - 2.5f * d, y - 14f * d, fx + 2.5f * d, y - 10.5f * d); c.drawRect(rf, p)
        }
        p.strokeCap = Paint.Cap.BUTT
        if (mgr.st == MgrSt.AT_DESK) {
            p.color = Color.WHITE; rf.set(x - 10 * d, y - 36 * d, x + 10 * d, y - 28.5f * d); c.drawRoundRect(rf, 3 * d, 3 * d, p)
            tp.color = col("#2E7D32"); tp.textSize = 6.2f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
            c.drawText("JOB ✓", x, y - 30.8f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
        } else {
            tp.color = col("#1A237E"); tp.textSize = 6.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
            c.drawText("MANAGER", x, y - 26 * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
        }
    }
}
