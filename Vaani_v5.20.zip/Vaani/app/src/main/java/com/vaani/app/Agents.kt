package com.vaani.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.MediaStore
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * v5.18 — 20 AUTOMATION AGENTS + MANAGER AGENT.
 *
 * Har agent ek chhota specialist hai: apna trigger, apna kaam, apna on/off
 * (Settings > Agents). Manager Agent: user ka kaam (bol kar ya `job_create`
 * tool se) ek "job file" mein badalta hai — {id, title, agent, status} —
 * sahi agent (employee) ko deta hai, status track karta hai, ho jane par
 * report karta hai. Jobs prefs "agent_jobs" mein JSON ke roop mein rehti
 * hain (aakhri 20).
 *
 * Voice lock: voice se aane wale kaam pehle se hi v5.17 ke fail-closed
 * voiceprint se guzarte hain — kisi aur ki awaaz se agent nahi chalega.
 * Time / battery / car wale agents user ki apni schedule par chalte hain.
 * WhatsApp auto-reply hamesha alag se gated hai (agent_whatsapp default OFF,
 * pehle user ko Settings se ON karna hoga). OTP digits kabhi nahi bole jate.
 */
object Agents {
    data class Def(val id: String, val name: String, val trigger: String, val desc: String)

    val ALL = listOf(
        Def("subah", "Subah Agent", "Subah 7 baje", "Subah ka briefing: mausam, aaj ke kaam, zaroori messages"),
        Def("raat", "Raat Agent", "Raat 10 baje", "Sone se pehle: DND on, brightness kam, kal ke alarms aur pehla kaam"),
        Def("gaadi", "Gaadi Agent", "Car Bluetooth connect", "DND on, volume tez, messages announce"),
        Def("battery", "Battery Agent", "Battery 20% se kam", "Brightness kam, charger lagane ko bole"),
        Def("health", "Health Agent", "Har 2 ghante (subah 8 – raat 10)", "Paani peene aur chalne ki yaad dilaye"),
        Def("reminder", "Reminder Agent", "Reminder ka time / poochho", "Set reminders ki list aur aaj ke kaam bataye"),
        Def("whatsapp", "WhatsApp Agent", "WhatsApp message aaye", "Recent WhatsApp messages sunaye; auto-reply sirf user ke ON karne par"),
        Def("call", "Call Agent", "Call aaye / poochho", "Aakhri calls bataye"),
        Def("sms", "SMS Agent", "SMS aaye", "Recent SMS padh kar sunaye; OTP kabhi na bole"),
        Def("email", "Email Agent", "Naya email aaye", "Zaroori emails ka headline sunaye"),
        Def("home", "Smart Home Agent", "'Ghar' bolo", "Home Assistant devices ki list — set hone par"),
        Def("security", "Security Agent", "Galat awaaz / poochho", "Voice lock aur phone lock ki status bataye"),
        Def("photo", "Photo Agent", "Nayi photo / poochho", "Aaj kitni photos li"),
        Def("music", "Music Agent", "'Gaana chalao' bolo", "Music play / pause / next"),
        Def("calendar", "Calendar Agent", "Event se pehle / poochho", "Aane wale events bataye"),
        Def("finance", "Finance Agent", "Bill / payment aaye", "Bank/payment notifications ka headline sunaye"),
        Def("shopping", "Shopping Agent", "'Saman chahiye' bolo", "Shopping list banaye aur yaad dilaye"),
        Def("travel", "Travel Agent", "Safar se pehle", "Mausam aur aane wale safar ke kaam bataye"),
        Def("news", "News Agent", "Subah 8 baje / poochho", "Aaj ki khaas khabrein sunaye (Gemini se)"),
        Def("weather", "Weather Agent", "Subah 7 baje / poochho", "Mausam aur baarish ki chetavni"),
        // v5.20 — 10 naye agents (kul 30)
        Def("alarm", "Alarm Agent", "'Alarm lagao' bolo", "Alarm set kare — subah uthane ke liye"),
        Def("notes", "Notes Agent", "'Note likho' bolo", "Voice notes likhe aur yaad dilaye"),
        Def("translate", "Translate Agent", "'Translate karo' bolo", "Hindi/English/Marathi mein translate kare"),
        Def("search", "Search Agent", "'Dhoondho' bolo", "Web se sawal ka jawab dhoondhe"),
        Def("files", "Files Agent", "'Files dikhao' bolo", "Download ki files ki list bataye"),
        Def("pc", "PC Agent", "PC bridge set ho to", "Laptop/PC ka status bataye aur control kare"),
        Def("focus", "Focus Agent", "'Focus mode' bolo", "DND + silent — 25 minute tak disturb nahi"),
        Def("fitness", "Fitness Agent", "'Steps batao' bolo", "Aaj ke steps, paani aur neend ka summary"),
        Def("birthday", "Birthday Agent", "'Birthday jodo' bolo", "Birthdays yaad rakhe aur aane wale bataye"),
        Def("location", "Location Agent", "'Main kahan hoon' bolo", "Tumhari current location bataye")
    )

    private fun def(id: String) = ALL.firstOrNull { it.id == id }

    /** Master switch + har agent ka apna switch. WhatsApp auto-reply default OFF. */
    fun isOn(c: Context, id: String): Boolean {
        if (!P.of(c).getBoolean("agents_on", true)) return false
        return P.of(c).getBoolean("agent_$id", id != "whatsapp")
    }

    fun listText(c: Context): String {
        val sb = StringBuilder("${ALL.size} agents hain (Manager ke alawa):\n")
        for (d in ALL) sb.append(if (isOn(c, d.id)) "✅ " else "⛔ ").append(d.name)
            .append(" — ").append(d.trigger).append("\n")
        sb.append("Manager Agent: job file lekar sahi agent ko deta hai. 'job_create' se kaam do — jaise 'subah ka briefing do'.")
        return sb.toString()
    }

    // ---------- triggers (VaaniService tick, har ~30 sec) ----------
    fun tick(c: Context) {
        if (!P.of(c).getBoolean("agents_on", true)) return
        try {
            val p = P.of(c)
            val now = System.currentTimeMillis()
            val cal = Calendar.getInstance()
            val hour = cal.get(Calendar.HOUR_OF_DAY)
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(now))
            // Subah 7 baje — ek baar roz
            if (hour == 7 && isOn(c, "subah") && p.getString("agent_last_subah", "") != today) {
                p.edit().putString("agent_last_subah", today).apply(); fire(c, "subah")
            }
            // Raat 10 baje — ek baar roz
            if (hour == 22 && isOn(c, "raat") && p.getString("agent_last_raat", "") != today) {
                p.edit().putString("agent_last_raat", today).apply(); fire(c, "raat")
            }
            // News 8 baje — ek baar roz
            if (hour == 8 && isOn(c, "news") && p.getString("agent_last_news", "") != today) {
                p.edit().putString("agent_last_news", today).apply(); fire(c, "news")
            }
            // Health — har 2 ghante, subah 8 se raat 10
            if (hour in 8..22 && isOn(c, "health") && now - p.getLong("agent_last_health", 0L) > 2 * 3600_000L) {
                p.edit().putLong("agent_last_health", now).apply(); fire(c, "health")
            }
            // Battery ≤20% aur charge nahi ho rahi — ek baar per episode
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val pct = if (lvl >= 0) lvl * 100 / sc else -1
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            if (pct in 1..20 && !charging && isOn(c, "battery") && !p.getBoolean("agent_batt_warned", false)) {
                p.edit().putBoolean("agent_batt_warned", true).apply(); fire(c, "battery")
            } else if (pct > 25 || charging) {
                p.edit().putBoolean("agent_batt_warned", false).apply()
            }
            // Gaadi — car connect hote hi ek baar
            if (CarMode.isActive(c) && isOn(c, "gaadi") && !p.getBoolean("agent_car_fired", false)) {
                p.edit().putBoolean("agent_car_fired", true).apply(); fire(c, "gaadi")
            } else if (!CarMode.isActive(c)) {
                p.edit().putBoolean("agent_car_fired", false).apply()
            }
        } catch (_: Exception) {}
    }

    /** Tick se chalao: run karo aur bol kar sunao. */
    private fun fire(c: Context, id: String) {
        try { val r = run(c, id); if (r.isNotBlank()) Speaker.speak(c, r) } catch (_: Exception) {}
    }

    // ---------- agent chalao ----------
    fun run(c: Context, id: String, extra: String = ""): String {
        val d = def(id) ?: return "Aisa koi agent nahi hai. 'agent_list' se saare agents dekho."
        if (!isOn(c, id)) return "${d.name} band hai — Settings mein 'Agents' se on karo."
        return try {
            when (id) {
                "subah" -> Briefing.make(c)
                "raat" -> night(c)
                "gaadi" -> car(c)
                "battery" -> battery(c)
                "health" -> "Health Agent: paani pee lo aur thoda chal lo — 2 ghante ho gaye baithe hue. Sehat pehle."
                "reminder" -> Reminders.listReminders(c)
                "whatsapp" -> recentByApp(c, listOf("whatsapp"), "WhatsApp")
                "call" -> Info.callLog(c, 3)
                "sms" -> Info.sms(c, "", 3)
                "email" -> recentByApp(c, listOf("gmail", "mail", "outlook"), "Email")
                "home" -> Home.run(c, "smart_home", JSONObject().put("action", "list"))
                    ?: "Home Assistant set nahi hai — Settings mein URL aur token daalo."
                "security" -> security(c)
                "photo" -> photosToday(c)
                "music" -> mediaKey(c, KeyEvent.KEYCODE_MEDIA_PLAY)
                "calendar" -> Info.calendar(c, 24)
                "finance" -> recentByApp(c, listOf("hdfc", "sbi", "icici", "paytm", "phonepe", "gpay", "upi", "bank"), "Bank/payment")
                "shopping" -> shopping(c, extra)
                "travel" -> "Travel Agent: ${Info.weather(c, "")} Aane wale kaam: ${Info.calendar(c, 48)}"
                "news" -> news(c)
                "weather" -> "Weather Agent: ${Info.weather(c, "")}"
                // v5.20 — 10 naye agents
                "alarm" -> alarm(c, extra)
                "notes" -> notes(c, extra)
                "translate" -> translate(c, extra)
                "search" -> if (extra.isBlank()) "Search Agent: kya dhoondhna hai? Jaise 'search Vaani kya hai' bolo." else Info.webAnswer(c, extra)
                "files" -> "Files Agent — Download:\n" + Files.run(c, "list", "Download")
                "pc" -> PcTools.dispatch(c, "pc", JSONObject().put("action", "status")) ?: "PC Agent: status nahi mila."
                "focus" -> focus(c, extra)
                "fitness" -> HealthTools.dispatch(c, "health_summary", JSONObject()) ?: "Fitness Agent: summary nahi mila."
                "birthday" -> birthday(c, extra)
                "location" -> location(c)
                else -> "Ye agent abhi taiyaar nahi hai."
            }
        } catch (e: Exception) { "${d.name} nahi chal paya: ${e.message?.take(80)}" }
    }

    /** v5.20 — naye agents ke helpers. */
    private fun alarm(c: Context, extra: String): String {
        val m = Regex("(\\d{1,2})[:.](\\d{2})").find(extra)
            ?: return "Alarm Agent: kis time alarm lagau? Jaise 'alarm 7:30' bolo."
        val hh = m.groupValues[1].toIntOrNull() ?: return "Alarm Agent: time samajh nahi aaya."
        val mm = m.groupValues[2].toIntOrNull() ?: 0
        if (hh !in 0..23 || mm !in 0..59) return "Alarm Agent: time galat hai (0-23 ghante, 0-59 minute)."
        return Automation.run(c, "alarm", JSONObject().put("hour", hh).put("minute", mm).put("label", "Vaani Alarm"))
            ?: "Alarm nahi laga paya."
    }

    private fun notes(c: Context, extra: String): String {
        val p = P.of(c)
        val clean = extra.lowercase(Locale("hi", "IN"))
            .replace("note likho", "").replace("note likh do", "").replace("note", "")
            .replace("likho", "").replace("likh do", "").trim().trim(',', ' ')
        val arr = try { JSONArray(p.getString("agent_notes", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        if (clean.isNotBlank()) {
            arr.put(clean)
            while (arr.length() > 50) arr.remove(0)
            p.edit().putString("agent_notes", arr.toString()).apply()
            return "Notes Agent: note likh liya — '$clean'."
        }
        if (arr.length() == 0) return "Notes Agent: koi note nahi hai. 'Note likho doodh lena hai' bolo."
        val sb = StringBuilder("Notes Agent — tumhare notes:\n")
        for (i in 0 until arr.length()) sb.append("• ").append(arr.optString(i)).append("\n")
        return sb.toString()
    }

    private fun translate(c: Context, extra: String): String {
        val clean = extra
            .replace("translate karo", "", true).replace("translate", "", true)
            .replace("english mein", "", true).replace("hindi mein", "", true)
            .replace("karo", "", true).trim().trim(',', ' ')
        if (clean.isBlank()) return "Translate Agent: kya translate karun? Jaise 'translate good morning' bolo."
        val to = if (extra.contains("english", true)) "en" else "hi"
        return TranslateTools.dispatch(c, "translate", JSONObject().put("text", clean).put("to", to))
            ?: "Translate Agent: translate nahi ho paya."
    }

    private fun focus(c: Context, extra: String): String {
        if (extra.contains("off", true) || extra.contains("band", true)) {
            sys(c, "dnd_off"); sys(c, "ringer_normal")
            return "Focus Agent: focus mode off — ab notifications aayenge."
        }
        sys(c, "dnd_on"); sys(c, "ringer_silent"); sys(c, "brightness_set", 40)
        return "Focus Agent: focus mode on — DND on, phone silent. 25 minute tak disturb nahi karunga."
    }

    private fun birthday(c: Context, extra: String): String {
        val p = P.of(c)
        val months = mapOf("january" to 1, "jan" to 1, "february" to 2, "feb" to 2, "march" to 3, "mar" to 3,
            "april" to 4, "apr" to 4, "may" to 5, "june" to 6, "jun" to 6, "july" to 7, "jul" to 7,
            "august" to 8, "aug" to 8, "september" to 9, "sep" to 9, "october" to 10, "oct" to 10,
            "november" to 11, "nov" to 11, "december" to 12, "dec" to 12)
        val arr = try { JSONArray(p.getString("agent_birthdays", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        // "Rohit ka birthday 5 December" jaisa text ho to jodo.
        val m = Regex("(\\d{1,2})\\s+([A-Za-z]+)").find(extra)
        if (m != null) {
            val day = m.groupValues[1].toIntOrNull() ?: 0
            val mon = months[m.groupValues[2].lowercase()] ?: 0
            val name = extra.substringBefore(m.value).trim()
                .replace("birthday", "", true).replace("janmdin", "", true)
                .replace("ka", "", true).replace("jodo", "", true).replace("add", "", true).trim()
            if (day in 1..31 && mon in 1..12 && name.isNotBlank()) {
                arr.put(JSONObject().put("name", name.take(40)).put("md", "%02d-%02d".format(mon, day)))
                while (arr.length() > 50) arr.remove(0)
                p.edit().putString("agent_birthdays", arr.toString()).apply()
                return "Birthday Agent: $name ka birthday ${m.groupValues[1]} ${m.groupValues[2]} save kar liya."
            }
        }
        if (arr.length() == 0) return "Birthday Agent: koi birthday saved nahi hai. 'Rohit ka birthday 5 December' bolo."
        val cal = Calendar.getInstance()
        val today = cal.get(Calendar.DAY_OF_YEAR)
        val out = ArrayList<Triple<Int, String, String>>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val md = o.optString("md"); val parts = md.split("-")
            if (parts.size != 2) continue
            val mm = parts[0].toIntOrNull() ?: continue; val dd = parts[1].toIntOrNull() ?: continue
            val c2 = Calendar.getInstance().apply { set(Calendar.MONTH, mm - 1); set(Calendar.DAY_OF_MONTH, dd) }
            var diff = c2.get(Calendar.DAY_OF_YEAR) - today
            if (diff < 0) diff += 365
            if (diff <= 30) out.add(Triple(diff, o.optString("name"), "$dd/$mm"))
        }
        if (out.isEmpty()) return "Birthday Agent: agle 30 din mein koi birthday nahi hai."
        out.sortBy { it.first }
        return "Birthday Agent — aane wale birthdays:\n" + out.joinToString("\n") {
            "• ${it.second} — ${it.third} (${if (it.first == 0) "aaj" else "${it.first} din mein"})"
        }
    }

    private fun location(c: Context): String {
        val loc = Loc.last(c) ?: return "Location Agent: location nahi mili — location permission do."
        return "Location Agent: tum abhi ${"%.4f".format(loc.latitude)}, ${"%.4f".format(loc.longitude)} par ho."
    }

    private fun sys(c: Context, action: String, value: Int = 50): String =
        Automation.run(c, "system_control", JSONObject().put("action", action).put("value", value)) ?: ""

    private fun night(c: Context): String {
        sys(c, "dnd_on"); sys(c, "ringer_silent"); sys(c, "brightness_set", 20)
        return "Raat Agent: DND on, phone silent, brightness kam. Shubh ratri. Kal ke kaam: ${Info.calendar(c, 24)}"
    }

    private fun car(c: Context): String {
        sys(c, "dnd_on"); sys(c, "volume_set", 80)
        return "Gaadi Agent: DND on, volume tez. Gaadi chala rahe ho — messages zor se sunaunga, jawab sirf tumhare haan par bhejunga."
    }

    private fun battery(c: Context): String {
        sys(c, "brightness_set", 25)
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (lvl >= 0) lvl * 100 / sc else -1
        return "Battery Agent: battery sirf $pct% reh gayi hai. Brightness kam kar di — charger laga do."
    }

    private fun security(c: Context): String {
        val vp = if (VoicePrint(c).enrolled()) "voice lock ON hai — sirf tumhari awaaz chalegi" else "voice lock enroll nahi hua — Settings se 'Meri awaaz dobara enroll karo'"
        val unlock = if (P.of(c).getBoolean("voice_unlock", false)) "phone voice-unlock ON" else "phone voice-unlock OFF"
        return "Security Agent: $vp; $unlock."
    }

    private fun photosToday(c: Context): String {
        return try {
            val start = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
            val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val cur = c.contentResolver.query(uri, arrayOf(MediaStore.Images.Media._ID),
                "${MediaStore.Images.Media.DATE_TAKEN} >= ?", arrayOf(start.toString()), null)
            val n = cur?.use { it.count } ?: 0
            "Photo Agent: aaj $n photo li hain."
        } catch (_: Exception) { "Photo Agent: photo permission nahi hai — Vaani ko Photos ki permission do." }
    }

    private fun mediaKey(c: Context, code: Int): String {
        return try {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            "Music Agent: gaana chala diya."
        } catch (_: Exception) { "Music Agent: music nahi chala paya." }
    }

    /** Notification history (prefs nhist2) se kisi app ke aakhri messages. OTP digits kabhi nahi. */
    private fun recentByApp(c: Context, keys: List<String>, label: String): String {
        return try {
            val arr = JSONArray(P.of(c).getString("nhist2", "[]") ?: "[]")
            val out = ArrayList<String>()
            for (i in arr.length() - 1 downTo 0) {
                val o = arr.optJSONObject(i) ?: continue
                val app = (o.optString("app") + " " + o.optString("pkg")).lowercase()
                if (keys.none { app.contains(it) }) continue
                val sender = o.optString("sender").takeIf { it.isNotBlank() } ?: o.optString("app")
                var text = o.optString("text")
                if (text.contains("OTP", true)) text = "OTP aaya hai (code nahi bolunga)"
                out.add("$sender: ${text.take(140)}")
                if (out.size >= 3) break
            }
            if (out.isEmpty()) "$label Agent: koi naya message nahi mila."
            else "$label Agent — aakhri messages:\n" + out.joinToString("\n")
        } catch (_: Exception) { "$label Agent: messages nahi padh paya." }
    }

    private fun shopping(c: Context, extra: String): String {
        val p = P.of(c)
        val clean = extra.lowercase(Locale("hi", "IN"))
            .replace("shopping list", "").replace("shopping", "").replace("list mein", "")
            .replace("jodo", "").replace("jod do", "").replace("add karo", "").replace("add", "")
            .replace("saman", "").replace("chahiye", "").trim().trim(',', ' ')
        if (clean.isNotBlank()) {
            val cur = (p.getString("shop_list", "") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
            if (clean !in cur) { cur.add(clean); while (cur.size > 30) cur.removeAt(0) }
            p.edit().putString("shop_list", cur.joinToString(", ")).apply()
            return "Shopping Agent: '$clean' list mein jod diya. Ab list: ${cur.joinToString(", ")}."
        }
        val cur = p.getString("shop_list", "") ?: ""
        return if (cur.isBlank()) "Shopping Agent: list khaali hai. 'Shopping list mein doodh jodo' bolo."
        else "Shopping Agent — list: $cur."
    }

    private fun news(c: Context): String {
        return try {
            val key = P.of(c).getString("key", "") ?: ""
            if (key.isEmpty()) return "News Agent: API key nahi hai."
            val parts = Gemini.ask(key, "Aaj ki 5 sabse khaas khabrein Hindi mein sunao, har khabar ek chhoti line mein. Koi intro/outro nahi.", useTools = false)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val t = parts.optJSONObject(i)?.optString("text") ?: continue
                if (t.isNotBlank()) sb.append(t)
            }
            val txt = sb.toString().trim()
            if (txt.isEmpty()) "News Agent: khabrein nahi mil payi." else "News Agent — aaj ki khabrein:\n$txt"
        } catch (_: Exception) { "News Agent: khabrein abhi nahi mil payi — net check karo." }
    }
}

/**
 * MANAGER AGENT — job file lekar employee (agent) ko deta hai.
 *
 * Kaam aata hai (voice / `job_create`) → Manager keyword se sahi agent
 * chunta hai → job file banta hai (prefs "agent_jobs") → agent ko deta hai
 * → status "chal raha" se "ho gaya" karta hai → user ko report karta hai.
 * Agar kaam kisi agent se match na kare to Manager poochhta hai, andaza nahi lagata.
 */
object Manager {
    private const val JOBS_KEY = "agent_jobs"

    private fun load(c: Context): JSONArray =
        try { JSONArray(P.of(c).getString(JOBS_KEY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }

    private fun save(c: Context, arr: JSONArray) { P.of(c).edit().putString(JOBS_KEY, arr.toString()).apply() }

    /** Keyword routing (Hindi + English). Agent ka naam seedha likha ho to wahi jeetega. */
    private fun route(text: String): String? {
        val t = " " + text.lowercase(Locale("hi", "IN")) + " "
        for (d in Agents.ALL) if (t.contains(d.name.lowercase()) || t.contains(d.id)) return d.id
        val kw: Map<String, List<String>> = mapOf(
            "subah" to listOf("subah", "morning", "uth", "suprabhat", "good morning", "briefing"),
            "raat" to listOf("raat", "night", "so ", "good night", "shubh ratri", "sone"),
            "gaadi" to listOf("gaadi", "car", "drive", "driving", "chala ra"),
            "battery" to listOf("battery", "charge", "charger"),
            "health" to listOf("health", "paani", "sehat", "walk", "exercise", "yoga", "chalo"),
            "reminder" to listOf("yaad", "remind", "reminder", "bhool"),
            "whatsapp" to listOf("whatsapp", "wa "),
            "call" to listOf("call", "phone karo", "bulao"),
            "sms" to listOf("sms", "message", "msg", "text"),
            "email" to listOf("email", "mail", "gmail"),
            "home" to listOf("ghar", "light", "fan", "pankha", "home"),
            "security" to listOf("security", "kho gaya", "chori", "lock", "suraksha"),
            "photo" to listOf("photo", "tasveer", "pic", "camera"),
            "music" to listOf("gaana", "music", "song", "gana", "bajao"),
            "calendar" to listOf("calendar", "schedule", "meeting", "event", "program"),
            "finance" to listOf("paisa", "bill", "payment", "kharcha", "bank", "finance", "rupay"),
            "shopping" to listOf("shopping", "kharid", "saman", "bazaar", "dukaan"),
            "travel" to listOf("safar", "travel", "ticket", "train", "flight", "yatra", "ghumne"),
            "news" to listOf("khabar", "news", "samachar"),
            "weather" to listOf("mausam", "weather", "baarish", "garmi", "thand"),
            // v5.20 — 10 naye agents
            "alarm" to listOf("alarm", "jagao"),
            "notes" to listOf("note", "likho"),
            "translate" to listOf("translate", "anuvad", "tarjuma"),
            "search" to listOf("dhoondho", "search", "google", "sawal"),
            "files" to listOf("files", "file ", "download"),
            "pc" to listOf("pc", "laptop", "computer"),
            "focus" to listOf("focus", "dhyaan", "padhai"),
            "fitness" to listOf("fitness", "steps", "kadam", "workout", "neend"),
            "birthday" to listOf("birthday", "janmdin"),
            "location" to listOf("kahan ho", "location", "kahan hun", "kahan hoon")
        )
        for ((id, words) in kw) if (words.any { t.contains(it) }) return id
        return null
    }

    /** Kaam do → job file banao → sahi agent ko do → status track karo → report karo. */
    fun createJob(c: Context, text: String): String {
        val t = text.trim()
        if (t.isEmpty()) return "Kaam batao — jaise 'subah ka briefing do' ya 'battery check karo'."
        val agentId = route(t)
            ?: return "Kaam samajh nahi aaya — agent ka naam bolo, jaise 'Subah Agent chalao', 'battery check karo' ya 'shopping list mein doodh jodo'."
        val d = Agents.ALL.firstOrNull { it.id == agentId }!!
        val arr = load(c)
        val id = "JOB-" + (System.currentTimeMillis() % 100000)
        val job = JSONObject().put("id", id).put("title", t.take(120)).put("agent", d.name)
            .put("status", "chal raha").put("created", System.currentTimeMillis())
        arr.put(job)
        while (arr.length() > 20) arr.remove(0)
        save(c, arr)
        val res = Agents.run(c, agentId, t)
        job.put("status", "ho gaya").put("result", res.take(200))
        save(c, arr)
        return "Manager: job $id ${d.name} ko diya — ho gaya.\n$res"
    }

    fun listJobs(c: Context): String {
        val arr = load(c)
        if (arr.length() == 0) return "Abhi koi job nahi hai. 'job_create' se kaam do — jaise 'subah ka briefing do'."
        val sb = StringBuilder("Aakhri jobs:\n")
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            sb.append(o.optString("id")).append(" • ").append(o.optString("agent"))
                .append(" • ").append(o.optString("status")).append(" — ").append(o.optString("title")).append("\n")
        }
        return sb.toString()
    }
}

/** Gemini tools: agent_list / agent_run / job_create / job_status. */
object AgentTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject>, req: List<String> = emptyList()): JSONObject {
        val p = JSONObject(); for ((k, v) in props) p.put(k, v)
        val params = JSONObject().put("type", "OBJECT").put("properties", p)
        if (req.isNotEmpty()) params.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("parameters", params)
    }

    fun decls(): List<JSONObject> = listOf(
        fn("agent_list",
            "Saare 20 automation agents aur Manager ki list dikhao — kaun on hai, kaun off, kis ka trigger kya hai.",
            emptyMap()),
        fn("agent_run",
            "Kisi ek agent ko chalao. Agent id: subah, raat, gaadi, battery, health, reminder, whatsapp, call, sms, email, home, security, photo, music, calendar, finance, shopping, travel, news, weather, alarm, notes, translate, search, files, pc, focus, fitness, birthday, location.",
            mapOf("agent" to sp("agent id, jaise subah / battery / whatsapp"), "extra" to sp("agent ke liye extra text, jaise alarm ke liye 7:30, shopping ke liye doodh, search ke liye sawal")),
            listOf("agent")),
        fn("job_create",
            "Manager Agent ko kaam do: job file banegi aur sahi agent (employee) ko milegi, status track hoga. Kaam Hinglish mein bolo.",
            mapOf("text" to sp("kaam, jaise 'subah ka briefing do' ya 'shopping list mein doodh jodo'")),
            listOf("text")),
        fn("job_status",
            "Aakhri jobs ki status dikhao — kaun sa kaam kis agent ko diya, ho gaya ya chal raha.",
            emptyMap())
    )

    /** Unknown naam par null (taaki Actions aage fall-through kar sake). */
    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "agent_list" -> Agents.listText(c)
        "agent_run" -> Agents.run(c, a.optString("agent", ""), a.optString("extra", ""))
        "job_create" -> Manager.createJob(c, a.optString("text", ""))
        "job_status" -> Manager.listJobs(c)
        else -> null
    }
}
