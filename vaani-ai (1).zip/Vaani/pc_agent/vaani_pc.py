#!/usr/bin/env python3
"""
Vaani PC bridge - sirf standard library, koi pip install nahi.
Phone se Vaani is PC ko ye kaam bol sakti hai: open_app, open_url, lock, sleep, shutdown, restart,
volume_up/down, mute, play_pause, next, previous, find_file, run (aapki likhi saved command), status.

Chalane ka tareeka:   python3 vaani_pc.py
Pehli baar token ban kar print hoga - wahi phone ke Vaani Settings mein daalo, URL = http://<PC-ka-IP>:8765
Sirf apne ghar ke WiFi par chalao. Internet par expose MAT karo.

'run' ke liye vaani_commands.json banao (isi folder mein), jaise:
  {"backup": "rsync -a ~/Documents /mnt/backup", "game": "steam steam://rungameid/12345"}
Sirf isi file ki commands chalti hain - phone se koi bhi shell command nahi chalti.
"""
import hmac, json, os, platform, secrets, shutil, subprocess, sys, time, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN_FILE = os.path.join(HERE, ".vaani_token")
CMD_FILE = os.path.join(HERE, "vaani_commands.json")
PORT = int(os.environ.get("VAANI_PORT", "8765"))
OS = platform.system()  # Windows / Darwin / Linux

if os.path.exists(TOKEN_FILE):
    TOKEN = open(TOKEN_FILE).read().strip()
else:
    TOKEN = secrets.token_urlsafe(24)
    with open(TOKEN_FILE, "w") as f:
        f.write(TOKEN)
    try:
        os.chmod(TOKEN_FILE, 0o600)
    except Exception:
        pass


def sh(cmd, shell=False):
    subprocess.Popen(cmd, shell=shell, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def win_key(code):
    sh(["powershell", "-NoProfile", "-Command", f"(New-Object -ComObject WScript.Shell).SendKeys([char]{code})"])


def open_app(arg):
    if not arg:
        return "Kaun sa app?"
    if OS == "Windows":
        sh(["cmd", "/c", "start", "", arg])
    elif OS == "Darwin":
        sh(["open", "-a", arg])
    else:
        exe = shutil.which(arg) or shutil.which(arg.lower())
        if not exe:
            return f"'{arg}' nahi mila."
        sh([exe])
    return f"{arg} khol diya."


def volume(kind):
    if OS == "Windows":
        win_key({"volume_up": 175, "volume_down": 174, "mute": 173}[kind])
    elif OS == "Darwin":
        script = {"volume_up": "set volume output volume ((output volume of (get volume settings)) + 10)",
                  "volume_down": "set volume output volume ((output volume of (get volume settings)) - 10)",
                  "mute": "set volume output muted not (output muted of (get volume settings))"}[kind]
        sh(["osascript", "-e", script])
    else:
        sh({"volume_up": ["pactl", "set-sink-volume", "@DEFAULT_SINK@", "+10%"],
            "volume_down": ["pactl", "set-sink-volume", "@DEFAULT_SINK@", "-10%"],
            "mute": ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"]}[kind])
    return "Ho gaya."


def media(kind):
    if OS == "Windows":
        win_key({"play_pause": 179, "next": 176, "previous": 177}[kind])
    elif OS == "Darwin":
        return "Mac par media keys abhi support nahi."
    else:
        sh(["playerctl", {"play_pause": "play-pause", "next": "next", "previous": "previous"}[kind]])
    return "Ho gaya."


def find_file(name):
    name = name.lower().strip()
    if not name:
        return "Kaun si file?"
    hits, seen = [], 0
    for root, dirs, files in os.walk(os.path.expanduser("~")):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("node_modules", "AppData", "Library")]
        for fn in files:
            seen += 1
            if name in fn.lower():
                hits.append(os.path.join(root, fn))
        if len(hits) >= 8 or seen > 60000:
            break
    return "; ".join(hits) if hits else f"'{name}' naam ki file nahi mili."


def power(kind):
    if OS == "Windows":
        sh({"lock": ["rundll32.exe", "user32.dll,LockWorkStation"],
            "sleep": ["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"],
            "shutdown": ["shutdown", "/s", "/t", "30"], "restart": ["shutdown", "/r", "/t", "30"]}[kind])
    elif OS == "Darwin":
        sh({"lock": ["pmset", "displaysleepnow"], "sleep": ["pmset", "sleepnow"],
            "shutdown": ["osascript", "-e", 'tell app "System Events" to shut down'],
            "restart": ["osascript", "-e", 'tell app "System Events" to restart']}[kind])
    else:
        sh({"lock": ["loginctl", "lock-session"], "sleep": ["systemctl", "suspend"],
            "shutdown": ["systemctl", "poweroff"], "restart": ["systemctl", "reboot"]}[kind])
    return {"lock": "PC lock.", "sleep": "PC sleep.", "shutdown": "PC band ho raha hai.", "restart": "PC restart ho raha hai."}[kind]


def run_saved(name):
    try:
        cmds = json.load(open(CMD_FILE))
    except Exception:
        return "vaani_commands.json nahi mili."
    if name not in cmds:
        return "Ye command saved nahi hai. Saved: " + ", ".join(cmds.keys())
    sh(cmds[name], shell=True)
    return f"'{name}' chala diya."


def handle(action, arg):
    if action == "open_app":
        return open_app(arg)
    if action == "open_url":
        if not arg.startswith(("http://", "https://")):
            return "Sirf http/https link."
        webbrowser.open(arg)
        return "Link khol diya."
    if action in ("lock", "sleep", "shutdown", "restart"):
        return power(action)
    if action in ("volume_up", "volume_down", "mute"):
        return volume(action)
    if action in ("play_pause", "next", "previous"):
        return media(action)
    if action == "find_file":
        return find_file(arg)
    if action == "run":
        return run_saved(arg)
    if action == "status":
        return f"{platform.node()} ({OS}) chal raha hai, samay {time.strftime('%H:%M')}."
    return "Ye action nahi aata."


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def reply(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_POST(self):
        auth = self.headers.get("Authorization", "")
        if not hmac.compare_digest(auth, "Bearer " + TOKEN) or self.path != "/do":
            return self.reply(401, {"result": "Token galat."})
        try:
            n = int(self.headers.get("Content-Length", "0"))
            d = json.loads(self.rfile.read(min(n, 10000)) or b"{}")
            res = handle(str(d.get("action", "")), str(d.get("arg", "")))
        except Exception as e:
            res = f"Error: {e}"
        self.reply(200, {"result": res})


if __name__ == "__main__":
    print(f"Vaani PC bridge chal raha hai: port {PORT}")
    print(f"Token (phone ke Settings mein daalo): {TOKEN}")
    try:
        ThreadingHTTPServer(("0.0.0.0", PORT), H).serve_forever()
    except KeyboardInterrupt:
        sys.exit(0)
