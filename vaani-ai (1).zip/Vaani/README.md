# Vaani (Android)
Hinglish voice assistant: speech -> Gemini function calling -> real phone actions.
Actions: call, WhatsApp message, open app, YouTube, flashlight, media keys, settings, timer, calendar event.

Build: open this folder in Android Studio (Koala+), let it sync, Run on a phone (minSdk 26).
Then paste your own Gemini API key in the app (get one at aistudio.google.com).
Model name lives in Gemini.kt (MODEL). Change it if Google renames models.
Note: key is stored in app-private SharedPreferences (not hardware-encrypted).

## v1.1 additions
- call_control: "call utha lo" / "call kaat do" / "kaun call kar raha hai" (+ caller name announced automatically when a call rings)
- notifications: "meri WhatsApp notifications padho", "auto reply on karo" (Gemini writes the reply; off by default)
- Notification access must be granted by you once (Vaani opens that settings screen when needed).
- Auto-reply sends AI-written replies in your name. Turn it on only when you are fine with that.

## v2.0: 24h hands-free + Live + overlay
1. Open app -> paste Gemini key -> "Meri awaaz record karo" (quiet room, talk normally for 12 s).
2. Grant: Floating orb permission, Battery Unrestricted, all runtime permissions, Notification access (for message tools).
3. Tap "24h Hands-free START". A persistent notification appears; the service keeps the mic open.
4. Only speech that matches your voice opens a Gemini Live session (closes after 15 s silence). Orb: grey idle, green listening, orange speaking. Tap orb = start without voice check.
Limits: voice check is basic MFCC (weak, not security); Android will not let a mic service auto-start from boot, open the app once after reboot;
LIVE_MODEL in LiveClient.kt may need updating; no barge-in (mic muted while Vaani speaks).

## v2.1
- Hands-free by default: after the one-time setup (API key + voice enrollment) the app starts listening by itself every time it opens. No tap-to-speak.
- Conversation shows live in the small box on the main screen (last ~4000 characters kept).
- Languages: Hindi, Marathi, English, Hinglish. Vaani replies in the language you spoke, default Hinglish.
- Stop button turns auto-start off until you press Start again.

## v3.0 automation pack (tools Vaani can call by voice)
system_control (volume, brightness, silent/vibrate, DND, auto-rotate, battery), screen_control (back/home/recents/notifications/quick settings/
power menu/lock/screenshot/scroll/swipe/tap text/type/read screen; needs Accessibility ON), navigate, web_search, open_url, sms, email, share_text,
alarm, camera, routine (save/run/list/delete named sequences, e.g. "good night" = DND on + brightness 10 + alarm).
First use of a tool that needs a special permission opens the right Android settings screen.
Not possible without root/Shizuku: silently toggling Wi-Fi/Bluetooth/mobile data/airplane mode (blocked since Android 10), silent install/uninstall, call recording.
