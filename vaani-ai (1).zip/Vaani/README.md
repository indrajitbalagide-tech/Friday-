# Vaani (Android)
Hinglish voice assistant: speech -> Gemini function calling -> real phone actions.
Actions: call, WhatsApp message, open app, YouTube, flashlight, media keys, settings, timer, calendar event.

Build: open this folder in Android Studio (Koala+), let it sync, Run on a phone (minSdk 26).
Then paste your own Gemini API key in the app (get one at aistudio.google.com).
Model name lives in Gemini.kt (MODEL). Change it if Google renames models.
Note: key is stored in app-private SharedPreferences (not hardware-encrypted).

## v1.1 additions
- call_control: "call utha lo" / "call kaat do" / "kaun call kar raha hai" (+ caller name announced automatically when a call rings)
- notifications: "meri WhatsApp notifications padho", "auto reply on karo" (Gemini writes the reply; off by default)
- Notification access must be granted by you once (Vaani opens that settings screen when needed).
- Auto-reply sends AI-written replies in your name. Turn it on only when you are fine with that.

## v2.0: 24h hands-free + Live + overlay
1. Open app -> paste Gemini key -> "Meri awaaz record karo" (quiet room, talk normally for 12 s).
2. Grant: Floating orb permission, Battery Unrestricted, all runtime permissions, Notification access (for message tools).
3. Tap "24h Hands-free START". A persistent notification appears; the service keeps the mic open.
4. Only speech that matches your voice opens a Gemini Live session (closes after 15 s silence). Orb: grey idle, green listening, orange speaking. Tap orb = start without voice check.
Limits: voice check is basic MFCC (weak, not security); Android will not let a mic service auto-start from boot, open the app once after reboot;
LIVE_MODEL in LiveClient.kt may need updating; no barge-in (mic muted while Vaani speaks).

## v2.1
- Hands-free by default: after the one-time setup (API key + voice enrollment) the app starts listening by itself every time it opens. No tap-to-speak.
- Conversation shows live in the small box on the main screen (last ~4000 characters kept).
- Languages: Hindi, Marathi, English, Hinglish. Vaani replies in the language you spoke, default Hinglish.
- Stop button turns auto-start off until you press Start again.

## v3.0 automation pack (tools Vaani can call by voice)
system_control (volume, brightness, silent/vibrate, DND, auto-rotate, battery), screen_control (back/home/recents/notifications/quick settings/
power menu/lock/screenshot/scroll/swipe/tap text/type/read screen; needs Accessibility ON), navigate, web_search, open_url, sms, email, share_text,
alarm, camera, routine (save/run/list/delete named sequences, e.g. "good night" = DND on + brightness 10 + alarm).
First use of a tool that needs a special permission opens the right Android settings screen.
Not possible without root/Shizuku: silently toggling Wi-Fi/Bluetooth/mobile data/airplane mode (blocked since Android 10), silent install/uninstall, call recording.

## v4.0 "Vaani pack"
Naya kya hai (sab voice se, Live aur typed dono raaste mein):
1. **Memory** - `memory` tool: Vaani aapke facts yaad rakhti hai (log, pasand, jagah) aur har session mein use karti hai. Password/PIN/OTP save nahi hote. ⚙ Settings se sab bhula sakte ho.
2. **Asli jaankari** - `web_answer` (Google Search se seedha jawab), `weather`, `calendar_read`, `call_log`, `sms_read`, `my_location`.
3. **Vision** - `look` (camera back/front ya screen dekhkar jawab) aur `screen_agent` (screenshot dekh-kar tap/type/swipe, kisi bhi app mein). Payment/password/PIN/OTP screen dikhte hi ruk jaata hai. Screenshot ke liye Android 11+ aur Accessibility ON.
4. **Proactive** - subah ka briefing (default 07:30), meeting se ~10 min pehle alert, battery <=15% alert, `place` tool se ghar/office save karo; aate-jaate routine `<naam>_aao` / `<naam>_jao` chalti hai (ya ek line bolti hai).
5. **Wake word + barge-in** - Wake word sirf "Vaani" hai (Jarvis wala built-in hata diya gaya). Picovoice key daalo (⚙ Settings, free) aur apna "Vaani" keyword: Picovoice Console par free `.ppn` file bankar `app/src/main/assets/vaani_wake.ppn` naam se rakho - tab "Vaani" bolne par hi jaagti hai. .ppn na ho to wake word band rehta hai, sirf awaaz-match chalta hai. Default: wake word AND aapki awaaz dono chahiye; "Sirf wake word" toggle se awaaz-check band. Barge-in: Vaani bol rahi ho tab zor se bolo to ruk jaati hai (agar khud ko kaat rahi ho to ⚙ mein band karo).
6. **Ghar + PC** - `smart_home` (Home Assistant: light/fan/AC/pardey/scene), `webhook` (ESP32/IFTTT/Node-RED), `pc` (laptop par `pc_agent/vaani_pc.py` chalao; open_app, lock, volume, find_file...). LAN ke liye plain http chalta hai (cleartext on). PC bridge ko internet par expose mat karo.
7. **Offline fallback** - internet na ho to phone ki offline speech se basic commands (torch, volume, battery, call, open app, time, back/home...). Phone mein offline Hindi/English language pack download hona chahiye.
8. **Safety** - delete / auto-reply on / screen_agent / PC shutdown-restart-sleep-run / door lock: pehli call hamesha "ROKO" lautati hai; user ke NAYE jawab ke baad hi chalti hai. File delete sirf Download/Documents/Pictures/DCIM/Movies/Music mein. Har action ka diary: "tumne abhi kya kiya?" (`action_log`).
New permissions: calendar, SMS, camera, location. Agent ab 12 steps tak chalta hai aur pichli baat-cheet yaad rakhta hai (typed mode).

Known limits: voice check abhi bhi basic MFCC hai (security nahi; behtar speaker model ke liye ECAPA/Resemblyzer TFLite file chahiye); offline mode Gemini jaisa smart nahi; geofence har ~3 min check karta hai; Wi-Fi/Bluetooth silently toggle abhi bhi Android ki wajah se possible nahi.
