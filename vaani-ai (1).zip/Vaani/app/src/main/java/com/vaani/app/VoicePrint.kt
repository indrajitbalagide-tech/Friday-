package com.vaani.app

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.sqrt

/**
 * Basic on-device speaker check (MFCC statistics + distance to your enrolled centre).
 * NOT security-grade: noise, a cold, or a recording of you can fool it. Good enough as a "mostly me" gate.
 */
class VoicePrint(ctx: Context) {
    private val p = ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE)
    private val center: FloatArray? = p.getString("vp_center", null)?.split(",")?.map { it.toFloat() }?.toFloatArray()
    private val thr = p.getFloat("vp_thr", 0f)

    fun enrolled() = center != null && thr > 0f

    fun verify(frames: List<ShortArray>): Boolean {
        val c = center ?: return false
        val all = ShortArray(frames.sumOf { it.size }); var o = 0
        for (f in frames) { f.copyInto(all, o); o += f.size }
        val v = Mfcc.vector(all) ?: return false
        return dist(v, c) <= thr
    }

    companion object {
        private const val MULT = 3.0f   // raise = more permissive, lower = stricter
        fun dist(a: FloatArray, b: FloatArray): Float { var s = 0f; for (i in a.indices) s += (a[i] - b[i]) * (a[i] - b[i]); return sqrt(s) }

        fun enroll(ctx: Context, done: (String) -> Unit) = Thread {
            try {
                val total = 16000 * 12
                val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, 32000)
                val pcm = ShortArray(total); rec.startRecording()
                var n = 0; while (n < total) { val r = rec.read(pcm, n, minOf(1600, total - n)); if (r <= 0) break; n += r }
                rec.stop(); rec.release()
                val chunk = 24000  // 1.5 s, same as live check
                val vs = (0 until total / chunk).mapNotNull { Mfcc.vector(pcm.copyOfRange(it * chunk, (it + 1) * chunk)) }
                if (vs.size < 4) return@Thread done("Awaaz kam/shor zyada tha, shant jagah dobara try karo.")
                val c = FloatArray(24) { i -> vs.map { it[i] }.average().toFloat() }
                val spread = vs.map { dist(it, c) }.average().toFloat()
                ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE).edit()
                    .putString("vp_center", c.joinToString(",")).putFloat("vp_thr", spread * MULT).apply()
                done("Awaaz save ho gayi (${vs.size} samples).")
            } catch (e: Exception) { done("Record nahi hua: ${e.message?.take(80)}") }
        }.start()
    }
}
