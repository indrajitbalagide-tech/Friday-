package com.vaani.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Vaani khud pehal karti hai: subah ka briefing, meeting alert, battery alert, ghar/office aane-jaane par routine. */
object Proactive {
    private val announced = HashSet<String>()
    private var lastBatteryWarn = 0L
    private var lastPlaceCheck = 0L
    private var placeInit = false
    @Volatile private var inPlace: String? = null

    /** Service har ~30 sec mein bulati hai (alag thread se). */
    fun tick(c: Context) {
        try { morning(c) } catch (_: Exception) {}
        try { meetings(c) } catch (_: Exception) {}
        try { battery(c) } catch (_: Exception) {}
        try { places(c) } catch (_: Exception) {}
    }

    private fun morning(c: Context) {
        val p = P.of(c); if (!p.getBoolean("brief_on", true)) return
        val parts = (p.getString("brief_time", "07:30") ?: "07:30").split(":")
        val at = (parts.getOrNull(0)?.trim()?.toIntOrNull() ?: 7) * 60 + (parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 30)
        val cal = Calendar.getInstance(); val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (nowMin in at..(at + 120) && p.getString("brief_day", "") != day) {
            p.edit().putString("brief_day", day).apply()
            Speaker.speak(c, Briefing.make(c))
        }
    }

    private fun meetings(c: Context) {
        val now = System.currentTimeMillis()
        for ((title, begin, _) in Info.events(c, now, now + 12 * 60_000L)) {
            val mins = (begin - now) / 60_000
            if (begin < now + 8 * 60_000L) continue
            if (announced.add("$title$begin")) Speaker.speak(c, "${Brain.title(c)}, '$title' $mins minute mein hai.")
            if (announced.size > 100) announced.clear()
        }
    }

    private fun battery(c: Context) {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val pct = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / maxOf(1, i.getIntExtra(BatteryManager.EXTRA_SCALE, 100))
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val now = System.currentTimeMillis()
        if (!charging && pct in 1..15 && now - lastBatteryWarn > 3 * 3600_000L) {
            lastBatteryWarn = now; Speaker.speak(c, "${Brain.title(c)}, battery sirf $pct% reh gayi hai. Charger laga do.")
        }
    }

    private fun places(c: Context) {
        val now = System.currentTimeMillis(); if (now - lastPlaceCheck < 180_000) return
        lastPlaceCheck = now
        val pl = Memory.places(c); if (pl.length() == 0) return
        val l = Loc.fresh(c) ?: return
        var here: String? = null
        for (k in pl.keys()) { val o = pl.getJSONObject(k)
            if (Loc.dist(l, o.getDouble("lat"), o.getDouble("lon")) < maxOf(o.optDouble("r", 150.0), 100.0)) here = k }
        if (!placeInit) { placeInit = true; inPlace = here; return }
        if (here != inPlace) {
            val old = inPlace; inPlace = here
            if (here != null) fire(c, here, "aao") else if (old != null) fire(c, old, "jao")
        }
    }

    /** Routine '<jagah>_aao' / '<jagah>_jao' ho to wahi chalti hai, warna ek line bolti hai. */
    private fun fire(c: Context, place: String, ev: String) {
        val routines = try { JSONObject(P.of(c).getString("routines", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        val r = "${place}_$ev"
        if (routines.has(r)) Actions.run(c, "routine", JSONObject().put("action", "run").put("name", r))
        else Speaker.speak(c, if (ev == "aao") "Welcome $place, ${Brain.title(c)}." else "$place se nikal gaye, ${Brain.title(c)}.")
    }
}

/** Subah ka briefing: mausam + calendar + battery + naye messages, Vaani ke andaaz mein. */
object Briefing {
    fun make(c: Context): String {
        val key = P.of(c).getString("key", "").orEmpty(); if (key.isEmpty()) return "Good morning, ${Brain.title(c)}."
        val f = StringBuilder()
        f.append("Time: ").append(SimpleDateFormat("EEEE d MMMM, HH:mm", Locale.ENGLISH).format(Date())).append("\n")
        try { f.append("Weather: ").append(Info.weather(c, "")).append("\n") } catch (_: Exception) {}
        try { f.append("Calendar (next 14h): ").append(Info.calendar(c, 14)).append("\n") } catch (_: Exception) {}
        try {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            f.append("Battery: ").append((i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1)).append("%\n")
        } catch (_: Exception) {}
        try { f.append("Recent notifications: ").append(NotifService.recent.takeLast(5).joinToString(". ") { "${it.first}: ${it.second}" }) } catch (_: Exception) {}
        return try {
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                    Brain.system(c, false) + " Ab ek chhota morning briefing do: 3-4 vakya, sirf diye gaye facts se, friendly aur halke wit ke saath. Kuch banao mat."))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", f.toString())))))
            val parts = Gemini.post(key, body).getJSONArray("parts")
            val sb = StringBuilder(); for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            sb.toString().trim().ifEmpty { "Good morning, ${Brain.title(c)}." }
        } catch (e: Exception) { "Good morning, ${Brain.title(c)}." }
    }
}
