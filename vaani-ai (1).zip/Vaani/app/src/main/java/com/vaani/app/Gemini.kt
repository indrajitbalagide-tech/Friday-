package com.vaani.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini REST + function calling. Model name is configurable. */
object Gemini {
    const val MODEL = "gemini-3.5-flash-lite"

    // Tools JSON org.json se banta hai taaki quotes hamesha sahi escape hon.
    // (Purana haath se joda gaya string routine tool ke description wale
    //  double-quotes par toot jata tha - wahi "Unterminated object" error.)
    private fun strProp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun intProp(d: String) = JSONObject().put("type", "INTEGER").put("description", d)

    private fun fn(
        name: String, desc: String,
        props: Map<String, JSONObject> = emptyMap(),
        req: List<String> = emptyList()
    ): JSONObject {
        val properties = JSONObject()
        for ((k, v) in props) properties.put(k, v)
        val params = JSONObject().put("type", "OBJECT").put("properties", properties)
        if (req.isNotEmpty()) params.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("parameters", params)
    }

    val tools: String = JSONArray().put(
        JSONObject().put(
            "functionDeclarations", JSONArray()
                .put(fn("call", "Phone call a contact or number", mapOf("who" to strProp("contact name or number")), listOf("who")))
                .put(fn("whatsapp", "Send a WhatsApp message", mapOf("who" to strProp("contact name or number"), "message" to strProp("text")), listOf("who", "message")))
                .put(fn("open_app", "Open an installed app", mapOf("app" to strProp("app name")), listOf("app")))
                .put(fn("play_youtube", "Search/play something on YouTube", mapOf("query" to strProp("song or video")), listOf("query")))
                .put(fn("flashlight", "Turn flashlight on/off", mapOf("on" to JSONObject().put("type", "BOOLEAN")), listOf("on")))
                .put(fn("media", "Control media playback", mapOf("action" to strProp("play|pause|toggle|next|previous")), listOf("action")))
                .put(fn("settings", "Open a settings screen", mapOf("target" to strProp("wifi|bluetooth|location|hotspot")), listOf("target")))
                .put(fn("timer", "Set a countdown timer", mapOf("seconds" to intProp("duration"), "label" to strProp("label")), listOf("seconds")))
                .put(fn("calendar_event", "Add calendar event", mapOf("title" to strProp("title"), "hours_from_now" to intProp("start offset hours")), listOf("title")))
                .put(fn("call_control", "Answer, reject or announce the incoming phone call", mapOf("action" to strProp("answer|reject|announce")), listOf("action")))
                .put(fn("notifications", "Read latest WhatsApp/Instagram/Telegram/SMS notifications, or turn auto-reply on/off", mapOf("action" to strProp("read_latest|enable_auto_reply|disable_auto_reply")), listOf("action")))
                .put(fn("system_control", "Volume, brightness, silent/vibrate, Do Not Disturb, auto-rotate, battery status", mapOf("action" to strProp("volume_set|volume_up|volume_down|mute|unmute|brightness_set|dnd_on|dnd_off|ringer_silent|ringer_vibrate|ringer_normal|autorotate_on|autorotate_off|battery"), "value" to intProp("0-100 for volume_set / brightness_set")), listOf("action")))
                .put(fn("screen_control", "Control the screen: system buttons, scroll, swipe, tap an on-screen text, type into focused field, read screen", mapOf("action" to strProp("back|home|recents|notifications|quick_settings|power_menu|lock_screen|screenshot|scroll_up|scroll_down|swipe_up|swipe_down|swipe_left|swipe_right|tap_text|type_text|read_screen"), "text" to strProp("text to tap or type")), listOf("action")))
                .put(fn("navigate", "Start Google Maps navigation", mapOf("place" to strProp("destination")), listOf("place")))
                .put(fn("web_search", "Google search", mapOf("query" to strProp("query")), listOf("query")))
                .put(fn("open_url", "Open an http/https link", mapOf("url" to strProp("link")), listOf("url")))
                .put(fn("sms", "Open SMS compose with text", mapOf("who" to strProp("contact name or number"), "message" to strProp("text")), listOf("who", "message")))
                .put(fn("email", "Open email compose", mapOf("to" to strProp("address"), "subject" to strProp("subject"), "body" to strProp("body")), listOf("to")))
                .put(fn("share_text", "Open the share sheet with text", mapOf("text" to strProp("text")), listOf("text")))
                .put(fn("alarm", "Set an alarm at a clock time", mapOf("hour" to intProp("0-23"), "minute" to intProp("0-59"), "label" to strProp("label")), listOf("hour", "minute")))
                .put(fn("camera", "Open the camera app", mapOf("mode" to strProp("photo|video"))))
                .put(fn("routine", "Save, run, list or delete a named routine (a sequence of tool calls)", mapOf("action" to strProp("save|run|list|delete"), "name" to strProp("routine name"), "steps" to strProp("for save: JSON array like [{\"name\":\"system_control\",\"args\":{\"action\":\"dnd_on\"}}]")), listOf("action")))
        )
    ).toString()

    private const val SYSTEM = "You are Vaani, a phone assistant. Understand Hindi, Marathi, English and Hinglish and reply in the language " +
        "the user used (default Hinglish). Use tools for device actions. Otherwise answer in one or two short sentences."

    /** Returns parts of the first candidate (text or functionCall objects). Call off the main thread. */
    fun ask(key: String, userText: String, useTools: Boolean = true): JSONArray {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userText)))))

        if (useTools) body.put("tools", JSONArray(tools))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val txt = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode !in 200..299) throw RuntimeException("API ${c.responseCode}: ${txt.take(300)}")
        return JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
    }
}
