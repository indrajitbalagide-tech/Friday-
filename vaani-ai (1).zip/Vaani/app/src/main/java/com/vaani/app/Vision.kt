package com.vaani.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.provider.Settings
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Vaani ki aankhein: camera / screen ko Gemini ko dikhana, aur screenshot-dekh-kar-tap wala screen agent. */
object Vision {
    private val DANGER = Regex("(?i)(upi pin|enter pin|enter upi|password|passcode|\\botp\\b|pay now|send money|transfer|confirm payment|" +
        "delete account|factory reset|erase all|uninstall|cvv)")

    private fun toJpeg(b: Bitmap, maxSide: Int, rot: Int = 0): ByteArray {
        var bm = b
        if (rot != 0) { val m = Matrix(); m.postRotate(rot.toFloat()); bm = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true) }
        val s = maxSide.toFloat() / maxOf(bm.width, bm.height)
        if (s < 1f) bm = Bitmap.createScaledBitmap(bm, (bm.width * s).toInt(), (bm.height * s).toInt(), true)
        val o = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.JPEG, 80, o); return o.toByteArray()
    }

    private fun askImage(key: String, jpeg: ByteArray, prompt: String, json: Boolean = false): String {
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray()
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))))
            .put(JSONObject().put("text", prompt)))))
        if (json) body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val parts = Gemini.post(key, body).getJSONArray("parts")
        val sb = StringBuilder(); for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString().trim()
    }

    private fun needAccess(c: Context): String {
        c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Pehle Accessibility mein Vaani ko ON karo, settings khol di."
    }

    /** Camera ya screen dekhkar sawaal ka jawab. */
    fun look(c: Context, source: String, question: String): String {
        val key = P.of(c).getString("key", "").orEmpty(); if (key.isEmpty()) return "API key nahi hai."
        val prompt = (if (question.isBlank()) "Is image mein kya hai? Short mein batao." else question) +
            " Reply in the user's language (Hinglish default), 2-3 short sentences, plain text."
        val jpeg: ByteArray = if (source == "screen") {
            val acc = VaaniAccess.inst ?: return needAccess(c)
            val bm = acc.shot() ?: return "Screenshot nahi le paya (Android 11+ aur accessibility ON chahiye)."
            toJpeg(bm, 1280)
        } else {
            val shot = cameraShot(c, source.contains("front")) ?: return "Camera se photo nahi mili (camera permission do, ya koi aur app camera use kar raha hai)."
            val bm = BitmapFactory.decodeByteArray(shot.first, 0, shot.first.size) ?: return "Photo samajh nahi aayi."
            toJpeg(bm, 1280, shot.second)
        }
        return try { askImage(key, jpeg, prompt).ifEmpty { "Kuch dikha nahi." } } catch (e: Exception) { "Dekh nahi paya: ${e.message?.take(80)}" }
    }

    @SuppressLint("MissingPermission")
    fun cameraShot(c: Context, front: Boolean): Pair<ByteArray, Int>? {
        if (!Perm.has(c, Manifest.permission.CAMERA)) return null
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val want = if (front) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == want } ?: return null
        val rot = cm.getCameraCharacteristics(id).get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        val ht = HandlerThread("vaani-cam").also { it.start() }; val h = Handler(ht.looper)
        val reader = ImageReader.newInstance(1280, 960, ImageFormat.JPEG, 3)
        val done = CountDownLatch(1); var out: ByteArray? = null; var n = 0
        var cam: CameraDevice? = null
        reader.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            if (img != null) {
                n++
                if (n >= 6 && out == null) {   // shuru ke frames andhere hote hain, exposure set hone do
                    val buf = img.planes[0].buffer; val b = ByteArray(buf.remaining()); buf.get(b); out = b; done.countDown()
                }
                img.close()
            }
        }, h)
        try {
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    cam = d
                    try {
                        @Suppress("DEPRECATION")
                        d.createCaptureSession(listOf(reader.surface), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                try {
                                    val rq = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                                    rq.addTarget(reader.surface)
                                    rq.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                                    s.setRepeatingRequest(rq.build(), null, h)
                                } catch (e: Exception) { done.countDown() }
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) { done.countDown() }
                        }, h)
                    } catch (e: Exception) { done.countDown() }
                }
                override fun onDisconnected(d: CameraDevice) { d.close(); done.countDown() }
                override fun onError(d: CameraDevice, e: Int) { d.close(); done.countDown() }
            }, h)
            done.await(9, TimeUnit.SECONDS)
        } catch (_: Exception) {
        } finally {
            try { cam?.close() } catch (_: Exception) {}
            try { reader.close() } catch (_: Exception) {}
            ht.quitSafely()
        }
        return out?.let { Pair(it, rot) }
    }

    /**
     * Screen agent: screenshot -> Gemini ek action chunta hai -> Vaani tap/type/swipe karti hai -> repeat.
     * Payment / password / PIN / OTP jaisi screen dikhte hi khud ruk jaati hai.
     */
    fun agent(c: Context, goal: String): String {
        val key = P.of(c).getString("key", "").orEmpty(); if (key.isEmpty()) return "API key nahi hai."
        val acc = VaaniAccess.inst ?: return needAccess(c)
        val hist = StringBuilder()
        for (step in 1..15) {
            val txt = acc.screenText(2500)
            if (DANGER.containsMatchIn(txt)) return "Ye screen payment/password/PIN jaisi lag rahi hai - yahan main khud aage nahi badhungi. Aap haath se kar lo."
            val bm = acc.shot() ?: return "Screenshot nahi mil paya (Android 11+ aur accessibility ON chahiye)."
            val prompt = "You control an Android phone to achieve this GOAL: $goal\nActions so far: ${hist.toString().ifEmpty { "none" }}\n" +
                "Look at the screenshot and choose the single next action. Reply ONLY with JSON: " +
                "{\"action\":\"tap|type|swipe_up|swipe_down|swipe_left|swipe_right|back|home|open_app|wait|done|fail\",\"x\":0,\"y\":0,\"text\":\"\",\"why\":\"\",\"summary\":\"\"}. " +
                "x and y are the target position scaled to 0..1000 (x from left, y from top). For type: text is what to type (tap the input field first using x,y). " +
                "For open_app: text is the app name. Use done with a one-line Hinglish summary when the goal is complete, fail if impossible. " +
                "NEVER enter passwords, PINs, OTPs or confirm payments or deletions."
            val reply = try { askImage(key, toJpeg(bm, 768), prompt, true) } catch (e: Exception) { return "Agent ruk gaya: ${e.message?.take(80)}" }
            val j = try { JSONObject(reply.removePrefix("```json").removeSuffix("```").trim()) } catch (e: Exception) { return "Agent ka jawab samajh nahi aaya." }
            val act = j.optString("action"); val px = j.optDouble("x", 500.0) / 1000.0 * bm.width; val py = j.optDouble("y", 500.0) / 1000.0 * bm.height
            hist.append("$step) $act ${j.optString("text")} (${j.optString("why").take(40)}); ")
            AgentStatus.worker = "agent: $act • ${AgentStatus.time()}"; AgentStatus.workerAt = System.currentTimeMillis()
            when (act) {
                "done" -> return j.optString("summary").ifEmpty { "Ho gaya." }
                "fail" -> return j.optString("summary").ifEmpty { "Ye kaam nahi ho paya." }
                "tap" -> acc.tapXY(px.toFloat(), py.toFloat())
                "type" -> { if (j.has("x")) { acc.tapXY(px.toFloat(), py.toFloat()); Thread.sleep(700) }; acc.typeText(j.optString("text")) }
                "swipe_up", "swipe_down", "swipe_left", "swipe_right" -> acc.swipe(act.removePrefix("swipe_"))
                "back" -> acc.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                "home" -> acc.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
                "open_app" -> Actions.run(c, "open_app", JSONObject().put("app", j.optString("text")))
                else -> {}
            }
            Thread.sleep(1500)
        }
        return "15 step ho gaye par kaam poora nahi hua. Ab tak: ${hist.toString().takeLast(160)}"
    }
}
