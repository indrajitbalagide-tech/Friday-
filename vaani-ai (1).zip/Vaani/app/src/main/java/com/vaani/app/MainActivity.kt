package com.vaani.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONObject
import java.util.Locale

/** Hands-free by default: opens -> starts listening on its own. Conversation shows in the small box. */
class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var keyBox: EditText
    private lateinit var toggle: Button
    private lateinit var orb: OrbView
    private lateinit var wave: WaveView
    private lateinit var batt: TextView
    private var lastHint = ""
    private val prefs by lazy { getSharedPreferences("vaani", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun panel(radius: Int, fill: String, stroke: String) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat(); setColor(Color.parseColor(fill)); setStroke(dp(1), Color.parseColor(stroke))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this, this)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
            Manifest.permission.ANSWER_PHONE_CALLS, "android.permission.POST_NOTIFICATIONS"), 1)
        window.statusBarColor = Color.parseColor("#020A18")

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(28), dp(16), dp(16)) }

        // Header: VAANI AI + battery (concept top bar)
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        titleRow.addView(TextView(this).apply { text = "VAANI "; textSize = 25f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        titleRow.addView(TextView(this).apply { text = "AI"; textSize = 25f; setTextColor(Color.parseColor("#19C8FF")); typeface = Typeface.DEFAULT_BOLD })
        titleRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        batt = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#8FD8F2")) }
        titleRow.addView(batt)
        root.addView(titleRow)
        root.addView(TextView(this).apply { text = "PERSONAL INTELLIGENCE SYSTEM"; textSize = 9f; letterSpacing = 0.32f
            setTextColor(Color.parseColor("#5FA8C4")); setPadding(0, dp(2), 0, dp(10)) })

        // Middle: glowing orb + avatar card (concept centre)
        val mid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        orb = OrbView(this)
        mid.addView(orb, LinearLayout.LayoutParams(0, dp(185), 1f))
        val avPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = panel(10, "#04121F", "#0E5B73"); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        avPanel.addView(ImageView(this).apply { setImageResource(R.drawable.vaani_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(dp(92), dp(112)))
        avPanel.addView(TextView(this).apply { text = "VAANI"; textSize = 12f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        avPanel.addView(TextView(this).apply { text = "AI ASSISTANT"; textSize = 8f
            setTextColor(Color.parseColor("#5FA8C4")); gravity = Gravity.CENTER })
        mid.addView(avPanel, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(10) })
        root.addView(mid)

        // Status pill (concept: "How can I help you today?")
        status = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = panel(22, "#062A40", "#19C8FF"); setPadding(dp(10), dp(9), dp(10), dp(9)) }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        wave = WaveView(this)
        root.addView(wave, LinearLayout.LayoutParams(-1, dp(24)).apply { topMargin = dp(4) })

        // Conversation panel
        root.addView(TextView(this).apply { text = "LIVE CONVERSATION"; textSize = 8f; letterSpacing = 0.3f
            setTextColor(Color.parseColor("#5FA8C4")) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        log = TextView(this).apply {
            textSize = 15f; setTextColor(Color.parseColor("#CDEFFF")); setPadding(dp(12), dp(10), dp(12), dp(10))
            movementMethod = ScrollingMovementMethod(); isVerticalScrollBarEnabled = true
            background = panel(12, "#03101C", "#0E5B73")
        }
        root.addView(log, LinearLayout.LayoutParams(-1, dp(200)).apply { topMargin = dp(4) })

        val typed = EditText(this).apply { hint = "Type bhi kar sakte ho"; setSingleLine()
            setTextColor(Color.parseColor("#EAF9FF")); setHintTextColor(Color.parseColor("#5FA8C4"))
            background = panel(10, "#04121F", "#0E5B73"); setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnEditorActionListener { v, _, _ -> handle(v.text.toString()); v.text = ""; true } }
        root.addView(typed, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        root.addView(TextView(this).apply { text = "GEMINI API KEY"; textSize = 8f; letterSpacing = 0.3f
            setTextColor(Color.parseColor("#5FA8C4")) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        keyBox = EditText(this).apply { hint = "Gemini API key (daalke Enter dabao)"; setText(prefs.getString("key", "")); setSingleLine()
            textSize = 12f; setTextColor(Color.parseColor("#EAF9FF")); setHintTextColor(Color.parseColor("#5FA8C4"))
            background = panel(10, "#04121F", "#0E5B73"); setPadding(dp(10), dp(8), dp(10), dp(8))
            imeOptions = EditorInfo.IME_ACTION_DONE
            setOnEditorActionListener { _, _, _ -> prefs.edit().putBoolean("manual_stop", false).apply(); autoStart(); true } }
        root.addView(keyBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        toggle = Button(this).apply { setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            background = panel(22, "#0A3A56", "#19C8FF"); setOnClickListener { toggleMode() } }
        root.addView(toggle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        root.addView(btn("🧬 Meri awaaz record karo (12 sec)") { enroll() })
        root.addView(btn("🪟 Floating orb permission") { overlayPerm() })
        root.addView(btn("🔋 Battery: Unrestricted") { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) })
        root.addView(btn("♿ Accessibility ON karo (tap/scroll/type ke liye)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })

        val scroll = ScrollView(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#03101F"), Color.parseColor("#010409")))
            addView(root)
        }
        setContentView(scroll)
        VaaniService.log = { t -> say(t) }
        say("🤖 Namaste! Main Vaani hu. Hindi, मराठी, English ya Hinglish, jo bhi bolo.")
    }

    override fun onResume() { super.onResume(); autoStart() }
    override fun onPause() { prefs.edit().putString("key", keyBox.text.toString().trim()).apply(); super.onPause() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { autoStart() }
    override fun onInit(s: Int) { if (s == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN") }

    private fun say(t: String, speak: Boolean = false) {
        runOnUiThread {
            log.append(t + "\n\n")
            if (log.text.length > 6000) log.text = log.text.takeLast(4000)   // keep memory flat over 24h
            log.layout?.let { l -> log.scrollTo(0, maxOf(0, l.getLineTop(log.lineCount) - log.height + log.paddingTop + log.paddingBottom)) }
        }
        if (speak) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "v")
    }

    private fun hint(t: String) { if (t != lastHint) { lastHint = t; say(t) } }

    private fun batteryPct(): Int {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (level >= 0) level * 100 / scale else -1
    }

    private fun refresh() { runOnUiThread {
        status.text = if (VaaniService.running) "🟢 Hands-free ON, bas bolo" else "⚪ Hands-free band"
        toggle.text = if (VaaniService.running) "⏹ Hands-free band karo" else "▶ Hands-free chalu karo"
        if (::orb.isInitialized) { orb.active = VaaniService.running; wave.active = VaaniService.running }
        val bp = batteryPct(); if (bp >= 0) batt.text = "🔋 $bp%"
    } }

    /** Starts the always-on service by itself whenever setup is complete. */
    private fun autoStart() {
        prefs.edit().putString("key", keyBox.text.toString().trim()).apply()
        refresh()
        if (VaaniService.running || prefs.getBoolean("manual_stop", false)) return
        when {
            prefs.getString("key", "").isNullOrEmpty() -> hint("👋 Pehle Gemini API key daalo.")
            !VoicePrint(this).enrolled() -> hint("🧬 Ab 'Meri awaaz record karo' dabao. Uske baad Vaani apne aap hands-free chalega.")
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED -> hint("🎙 Mic permission allow karo.")
            else -> { startForegroundService(Intent(this, VaaniService::class.java)); window.decorView.postDelayed({ refresh() }, 700) }
        }
    }

    private fun toggleMode() {
        if (VaaniService.running) { prefs.edit().putBoolean("manual_stop", true).apply()
            startService(Intent(this, VaaniService::class.java).setAction("STOP")); window.decorView.postDelayed({ refresh() }, 700) }
        else { prefs.edit().putBoolean("manual_stop", false).apply(); autoStart() }
    }

    private fun enroll() {
        val wasOn = VaaniService.running
        if (wasOn) startService(Intent(this, VaaniService::class.java).setAction("STOP"))
        window.decorView.postDelayed({
            say("🧬 12 second normal awaaz mein kuch bhi bolte raho…")
            VoicePrint.enroll(this) { m -> say(m); runOnUiThread { prefs.edit().putBoolean("manual_stop", false).apply(); autoStart() } }
        }, if (wasOn) 900 else 0)
    }

    private fun overlayPerm() {
        if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        else say("🪟 Overlay permission pehle se hai.")
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.parseColor("#DFF6FF")); textSize = 14f
        background = panel(10, "#062238", "#12718F")
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    }

    /** Typed fallback (REST). Spoken conversation goes through the service + Gemini Live. */
    private fun handle(text: String) {
        if (text.isBlank()) return
        val key = prefs.getString("key", "").orEmpty()
        if (key.isEmpty()) return say("Pehle Gemini API key daalo.")
        say("🧑 $text")
        Thread {
            try {
                val parts = Gemini.ask(key, text)
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("functionCall")) {
                        val f = p.getJSONObject("functionCall")
                        say("🤖 " + Actions.run(this, f.getString("name"), f.optJSONObject("args") ?: JSONObject()), true)
                    } else if (p.has("text")) say("🤖 " + p.getString("text"), true)
                }
            } catch (e: Exception) { say("⚠ ${e.message?.take(240)}") }
        }.start()
    }

    override fun onDestroy() { VaaniService.log = null; tts.shutdown(); super.onDestroy() }
}
