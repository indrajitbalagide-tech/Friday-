package com.vaani.app

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Reads messaging notifications; optionally auto-replies (off by default). */
class NotifService : NotificationListenerService() {
    companion object {
        val recent: MutableList<Pair<String, String>> = java.util.Collections.synchronizedList(mutableListOf())
        private val lastReply = HashMap<String, Long>()
        private val APPS = setOf("com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
            "com.instagram.android", "com.google.android.apps.messaging")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in APPS) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        recent.add(title to text); if (recent.size > 30) recent.removeAt(0)

        val p = getSharedPreferences("vaani", MODE_PRIVATE)
        if (!p.getBoolean("auto", false)) return
        val key = p.getString("key", "").orEmpty(); if (key.isEmpty()) return
        val action = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        val now = System.currentTimeMillis()
        synchronized(lastReply) { if (now - (lastReply[title] ?: 0L) < 60_000) return; lastReply[title] = now }

        Thread {
            try {
                // useTools=false: incoming text can never trigger phone actions.
                val parts = Gemini.ask(key, "Mere dost $title ka message: \"$text\". Meri taraf se ek chhota friendly " +
                    "Hinglish jawab likho. Sirf jawab ka text do.", false)
                val reply = (0 until parts.length()).mapNotNull { parts.getJSONObject(it).optString("text").ifEmpty { null } }
                    .joinToString(" ").trim()
                if (reply.isEmpty()) return@Thread
                val ri = action.remoteInputs[0]; val intent = Intent(); val b = Bundle()
                b.putCharSequence(ri.resultKey, reply)
                RemoteInput.addResultsToIntent(action.remoteInputs, intent, b)
                action.actionIntent.send(this, 0, intent)
            } catch (_: Exception) {}
        }.start()
    }
}
