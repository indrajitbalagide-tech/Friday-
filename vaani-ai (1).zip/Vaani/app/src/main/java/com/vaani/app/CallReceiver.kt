package com.vaani.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.speech.tts.TextToSpeech
import android.telephony.TelephonyManager
import java.util.Locale

/** Announces the caller's name out loud when a call rings. */
class CallReceiver : BroadcastReceiver() {
    companion object { @Volatile var lastCaller: String? = null }

    override fun onReceive(c: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (i.getStringExtra(TelephonyManager.EXTRA_STATE) != TelephonyManager.EXTRA_STATE_RINGING) {
            if (i.getStringExtra(TelephonyManager.EXTRA_STATE) == TelephonyManager.EXTRA_STATE_IDLE) lastCaller = null
            return
        }
        val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: return
        val name = lookup(c, num) ?: num
        if (name == lastCaller) return
        lastCaller = name
        if (!c.getSharedPreferences("vaani", Context.MODE_PRIVATE).getBoolean("announce", true)) return
        var t: TextToSpeech? = null
        t = TextToSpeech(c.applicationContext) { s ->
            if (s == TextToSpeech.SUCCESS) {
                t?.language = Locale("hi", "IN")
                t?.speak("$name ka call aa raha hai", TextToSpeech.QUEUE_FLUSH, null, "call")
                Handler(Looper.getMainLooper()).postDelayed({ t?.shutdown() }, 6000)
            }
        }
    }

    private fun lookup(c: Context, num: String): String? = try {
        c.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) { null }
}
