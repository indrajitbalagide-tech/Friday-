package com.vaani.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import java.util.Calendar
import kotlin.math.sin

/**
 * Asli bada office room (2D): sabse peeche BOSS VAANI ki badi desk, phir 2 kataaron mein 10 agents
 * apni-apni desk + desktop par. Dayein kone mein coffee machine - khaali agent baari-baari wahan
 * coffee break par khada dikhta hai. Deewar ghadi mein asal samay chalta hai.
 * Kaam ki haalat nakli nahi hai: MainActivity AgentStatus ke asli timestamps se working[] bharata hai.
 * Kaam wala = seedha baitha typing + chamakti screen; khaali = kursi par leta aaram + "Z" ya coffee break.
 */
class OfficeView(ctx: Context) : View(ctx) {
    var working = BooleanArray(10)
    var bossOn = false
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private val path = Path()
    private var tick = 0
    private val anim = object : Runnable {
        override fun run() { tick++; invalidate(); postDelayed(this, 120) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(anim) }
    override fun onDetachedFromWindow() { removeCallbacks(anim); super.onDetachedFromWindow() }

    companion object {
        val NAMES = listOf("Ears", "Brain", "Hands", "Eyes", "Phone", "Mouth", "Memory", "Files", "Home", "Camera")
        private val SHIRTS = listOf("#FF2E4D", "#B388FF", "#FFB74D", "#4DD0E1", "#81C784", "#F48FB1",
            "#90A4AE", "#AED581", "#FF8A65", "#64B5F6")
        private val SKIN = listOf("#F1C27D", "#E0AC69", "#C68642", "#FFDBAC")
        private val HAIR = listOf("#14100E", "#241611", "#2E2A26", "#191410")
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (w == 0f || h == 0f) return
        drawRoom(c, w, h)
        val phase = tick * 0.28f
        // Coffee break: har ~24 sec mein baari badalti hai; sirf KHAALI agent hi break par jaata hai.
        val breakIdx = (tick / 200) % 10
        val onBreak = !working.getOrElse(breakIdx) { false }
        drawBoss(c, w * 0.40f, h * 0.345f, w * 0.30f, phase)
        drawCoffeeMachine(c, w, h, phase)
        if (onBreak) drawStanding(c, w * 0.795f, h * 0.575f, (w / 5f) * 0.08f, breakIdx)
        val seatW = w / 5f
        for (i in 0 until 5) { val idx = i + 5
            if (!(onBreak && idx == breakIdx)) drawSeat(c, seatW * (i + 0.5f), h * 0.575f, seatW * 0.80f, idx, phase)
            else drawEmptySeat(c, seatW * (i + 0.5f), h * 0.575f, seatW * 0.80f, idx) }
        for (i in 0 until 5) { val idx = i
            if (!(onBreak && idx == breakIdx)) drawSeat(c, seatW * (i + 0.5f), h * 0.885f, seatW, idx, phase)
            else drawEmptySeat(c, seatW * (i + 0.5f), h * 0.885f, seatW, idx) }
    }

    /** Kamra: deewar, khidki (raat), asal samay wali ghadi, farsh par halki si darri. */
    private fun drawRoom(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#20060D"); c.drawRect(0f, 0f, w, h * 0.60f, p)
        p.color = Color.parseColor("#12030A"); c.drawRect(0f, h * 0.60f, w, h, p)
        p.color = Color.parseColor("#FF2E4D"); p.alpha = 40
        rf.set(w * 0.08f, h * 0.775f, w * 0.92f, h * 0.845f); c.drawOval(rf, p); p.alpha = 255
        p.color = Color.parseColor("#FF2E4D"); p.alpha = 46
        c.drawRect(0f, h * 0.60f, w, h * 0.60f + 1.6f * d, p); p.alpha = 255
        // Khidki
        val wx = w * 0.045f; val wy = h * 0.05f; val ww = w * 0.27f; val wh = h * 0.235f
        p.color = Color.parseColor("#0B1E33"); rf.set(wx, wy, wx + ww, wy + wh); c.drawRoundRect(rf, 4 * d, 4 * d, p)
        val tw = 0.55f + 0.45f * sin((tick * 0.35f).toDouble()).toFloat()
        p.color = Color.parseColor("#BFE9FF"); p.alpha = (120 + 100 * tw).toInt().coerceIn(0, 255)
        c.drawCircle(wx + ww * 0.25f, wy + wh * 0.30f, 1.3f * d, p)
        c.drawCircle(wx + ww * 0.62f, wy + wh * 0.58f, 1.1f * d, p)
        p.alpha = 255
        p.color = Color.parseColor("#FFD54F"); c.drawCircle(wx + ww * 0.80f, wy + wh * 0.30f, 5.5f * d, p)
        p.style = Paint.Style.STROKE; p.color = Color.parseColor("#70101F"); p.strokeWidth = 1.6f * d
        rf.set(wx, wy, wx + ww, wy + wh); c.drawRoundRect(rf, 4 * d, 4 * d, p)
        c.drawLine(wx + ww / 2f, wy, wx + ww / 2f, wy + wh, p)
        // Ghadi - asal samay, second ki sui ghumti hai
        val cal = Calendar.getInstance()
        val gx = w * 0.665f; val gy = h * 0.105f; val gr = 9f * d
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#F5F0E8"); c.drawCircle(gx, gy, gr, p)
        p.style = Paint.Style.STROKE; p.color = Color.parseColor("#3D0A14")
        fun hand(frac: Double, len: Float, widthPx: Float, col: Int) {
            val a = frac * 2 * Math.PI - Math.PI / 2
            p.strokeWidth = widthPx; p.color = col
            c.drawLine(gx, gy, gx + (Math.cos(a) * len).toFloat(), gy + (Math.sin(a) * len).toFloat(), p)
        }
        hand((cal.get(Calendar.HOUR) % 12 + cal.get(Calendar.MINUTE) / 60.0) / 12.0, gr * 0.52f, 1.8f * d, Color.parseColor("#3D0A14"))
        hand(cal.get(Calendar.MINUTE) / 60.0, gr * 0.78f, 1.3f * d, Color.parseColor("#3D0A14"))
        hand((cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000.0) / 60.0, gr * 0.88f, 0.7f * d, Color.parseColor("#FF2E4D"))
        p.style = Paint.Style.FILL
    }

    /** Coffee machine (dayein peeche kone mein) - bhaap udti hai, batti chamakti hai. */
    private fun drawCoffeeMachine(c: Canvas, w: Float, h: Float, phase: Float) {
        val x0 = w * 0.865f; val x1 = w * 0.985f; val y0 = h * 0.335f; val y1 = h * 0.575f
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#3A2A20"); c.drawRect(x0 - 3 * d, y1 - 3 * d, x1 + 3 * d, y1, p)      // counter
        p.color = Color.parseColor("#191920"); rf.set(x0, y0, x1, y1 - 2 * d); c.drawRoundRect(rf, 3 * d, 3 * d, p)
        p.color = Color.parseColor("#FF2E4D"); c.drawRect(x0, y0, x1, y0 + 4.5f * d, p)                  // upar ki patti
        p.color = Color.parseColor("#23232E"); rf.set(x0 + 3 * d, y0 + 8 * d, x1 - 3 * d, y0 + 21 * d); c.drawRoundRect(rf, 2 * d, 2 * d, p)
        val glow = 0.6f + 0.4f * sin((phase * 1.6f).toDouble()).toFloat()
        p.color = Color.argb(255, (80 * glow).toInt(), (255 * glow).toInt(), (140 * glow).toInt())
        c.drawCircle(x0 + 7 * d, y0 + 14.5f * d, 1.8f * d, p)                                           // hari batti
        p.color = Color.parseColor("#8A8A93"); c.drawCircle(x1 - 7 * d, y0 + 14.5f * d, 1.8f * d, p)
        p.color = Color.parseColor("#C9CCD4"); c.drawRect(x0 + (x1 - x0) / 2 - 1.5f * d, y0 + 23 * d, x0 + (x1 - x0) / 2 + 1.5f * d, y0 + 27 * d, p)  // nozzle
        p.color = Color.parseColor("#F5F0E8"); rf.set(x0 + (x1 - x0) / 2 - 3.6f * d, y0 + 27 * d, x0 + (x1 - x0) / 2 + 3.6f * d, y0 + 33 * d); c.drawRoundRect(rf, 1 * d, 1 * d, p)  // cup
        // Bhaap: do lehrati rekhaayein
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.1f * d; p.strokeCap = Paint.Cap.ROUND
        p.color = Color.parseColor("#DFF6FF")
        for (s in 0 until 2) {
            val bx = x0 + (x1 - x0) / 2 + (s - 0.5f) * 4 * d
            val rise = ((tick * 2 + s * 14) % 44) / 44f
            p.alpha = (130 * (1f - rise)).toInt().coerceIn(0, 130)
            path.reset(); path.moveTo(bx, y0 + 26 * d - rise * 3 * d)
            path.quadTo(bx + 2.2f * d * sin((phase + s * 2f).toDouble()).toFloat(), y0 + 20 * d - rise * 5 * d, bx, y0 + 14 * d - rise * 7 * d)
            c.drawPath(path, p)
        }
        p.alpha = 255; p.strokeCap = Paint.Cap.BUTT
        tp.color = Color.parseColor("#C9A0AA"); tp.textSize = 7.5f * d
        c.drawText("COFFEE", (x0 + x1) / 2, y1 + 9 * d, tp)
    }

    /** Coffee break par khada agent - haath mein cup. */
    private fun drawStanding(c: Canvas, cx: Float, feet: Float, s: Float, idx: Int) {
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#232733")                                                            // pair
        c.drawRect(cx - 4.5f * s, feet - 21 * s, cx - 1 * s, feet, p)
        c.drawRect(cx + 1 * s, feet - 21 * s, cx + 4.5f * s, feet, p)
        p.color = Color.parseColor(SHIRTS[idx])                                                          // dhad
        rf.set(cx - 6 * s, feet - 41 * s, cx + 6 * s, feet - 20 * s); c.drawRoundRect(rf, 3 * s, 3 * s, p)
        val hx = cx; val hy = feet - 47 * s
        p.color = Color.parseColor(SKIN[idx % SKIN.size]); c.drawCircle(hx, hy, 6.8f * s, p)
        p.color = Color.parseColor(HAIR[idx % HAIR.size])
        rf.set(hx - 6.8f * s, hy - 7.6f * s, hx + 6.8f * s, hy + 1.2f * s); c.drawArc(rf, 180f, 180f, true, p)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4 * s
        p.color = Color.parseColor(SHIRTS[idx])
        c.drawLine(cx + 4 * s, feet - 36 * s, cx + 10 * s, feet - 29 * s, p)           // baah cup ki taraf
        p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
        p.color = Color.parseColor("#F5F0E8")                                                            // cup
        rf.set(cx + 8.6f * s, feet - 32.5f * s, cx + 12.6f * s, feet - 28.5f * s); c.drawRoundRect(rf, 0.8f * s, 0.8f * s, p)
        tp.color = Color.parseColor("#C9A0AA"); tp.textSize = 10.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(NAMES[idx], cx, feet + 13.5f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
    }

    /** BOSS VAANI - sabse peeche badi desk, lambe baal, laal poshaak. Band ho to kursi khaali. */
    private fun drawBoss(c: Canvas, cx: Float, base: Float, sw: Float, phase: Float) {
        val u = sw / 100f
        val deskY = base - 36 * u
        if (bossOn) { p.style = Paint.Style.FILL; p.color = Color.parseColor("#FF2E4D"); p.alpha = 26
            c.drawCircle(cx, deskY - 14 * u, 44 * u, p); p.alpha = 255 }
        // Kursi
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#2E222B")
        rf.set(cx - 38 * u, deskY - 20 * u, cx - 30 * u, deskY + 18 * u); c.drawRoundRect(rf, 3 * u, 3 * u, p)
        c.drawRect(cx - 36 * u, deskY + 16 * u, cx - 33 * u, base - 3 * u, p)
        if (bossOn) {
            val bob = sin((phase * 0.8f).toDouble()).toFloat() * 0.9f * u
            // Pair
            p.color = Color.parseColor("#2A1420")
            rf.set(cx - 29 * u, deskY + 7 * u, cx - 2 * u, deskY + 13 * u); c.drawRoundRect(rf, 3 * u, 3 * u, p)
            c.drawRect(cx - 7.5f * u, deskY + 11 * u, cx - 4 * u, base - 3 * u, p)
            p.color = Color.parseColor("#0E0C10"); c.drawRect(cx - 9 * u, base - 3.4f * u, cx + 1.5f * u, base - 1 * u, p)
            // Lambe baal (peeche) + dhad
            val hx = cx - 25 * u; val hy = deskY - 34 * u + bob
            p.color = Color.parseColor("#17100C")
            rf.set(hx - 9.5f * u, hy - 9 * u, hx + 9.5f * u, hy + 17 * u); c.drawRoundRect(rf, 4.5f * u, 4.5f * u, p)
            p.color = Color.parseColor("#FF2E4D")
            rf.set(cx - 34 * u, deskY - 26 * u + bob, cx - 16 * u, deskY + 10 * u); c.drawRoundRect(rf, 5.5f * u, 5.5f * u, p)
            // Chehra
            p.color = Color.parseColor("#FFDBAC"); c.drawCircle(hx, hy, 8.4f * u, p)
            p.color = Color.parseColor("#17100C")
            rf.set(hx - 8.4f * u, hy - 9.4f * u, hx + 8.4f * u, hy + 0.8f * u); c.drawArc(rf, 180f, 180f, true, p)
            // Baah keyboard ki taraf
            p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 5 * u
            p.color = Color.parseColor("#FF2E4D")
            c.drawLine(cx - 20 * u, deskY - 18 * u + bob, cx - 5 * u, deskY - 4 * u, p)
            p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
        }
        // Badi desk
        p.color = Color.parseColor("#5A3A28")
        c.drawRect(cx - 56 * u, deskY, cx + 58 * u, deskY + 4.2f * u, p)
        c.drawRect(cx - 53 * u, deskY + 4.2f * u, cx - 49 * u, base - 1 * u, p)
        c.drawRect(cx + 52 * u, deskY + 4.2f * u, cx + 56 * u, base - 1 * u, p)
        // Desk par chhota paudha
        p.color = Color.parseColor("#8D5524"); c.drawRect(cx - 51 * u, deskY - 3.4f * u, cx - 46.5f * u, deskY, p)
        p.color = Color.parseColor("#43A047")
        c.drawCircle(cx - 48.7f * u, deskY - 5.6f * u, 2.6f * u, p); c.drawCircle(cx - 51 * u, deskY - 4.2f * u, 1.9f * u, p); c.drawCircle(cx - 46.4f * u, deskY - 4.2f * u, 1.9f * u, p)
        // Keyboard + bada monitor
        p.color = Color.parseColor("#151318"); rf.set(cx - 10 * u, deskY - 2 * u, cx + 10 * u, deskY + 0.4f * u); c.drawRoundRect(rf, 1 * u, 1 * u, p)
        val mx0 = cx + 18 * u; val my0 = deskY - 30 * u; val mx1 = cx + 48 * u; val my1 = deskY - 6 * u
        p.color = Color.parseColor("#0B0B0E"); rf.set(mx0, my0, mx1, my1); c.drawRoundRect(rf, 2 * u, 2 * u, p)
        if (bossOn) {
            val glow = 0.82f + 0.18f * sin((phase * 1.2f).toDouble()).toFloat()
            p.color = Color.argb(255, (255 * glow).toInt(), (170 * glow).toInt(), (190 * glow).toInt())
            rf.set(mx0 + 1.8f * u, my0 + 1.8f * u, mx1 - 1.8f * u, my1 - 1.8f * u); c.drawRoundRect(rf, 1.4f * u, 1.4f * u, p)
            p.color = Color.parseColor("#5C1220")
            for (r in 0 until 3) c.drawRect(mx0 + 4 * u, my0 + (5f + r * 6.5f) * u, mx0 + (13f + ((r * 5) % 4) * 3f) * u, my0 + (7f + r * 6.5f) * u, p)
        } else {
            p.color = Color.parseColor("#1C1C22"); rf.set(mx0 + 1.8f * u, my0 + 1.8f * u, mx1 - 1.8f * u, my1 - 1.8f * u); c.drawRoundRect(rf, 1.4f * u, 1.4f * u, p)
        }
        p.color = Color.parseColor("#0B0B0E"); c.drawRect(cx + 31.5f * u, my1, cx + 34.5f * u, deskY - 1.5f * u, p)
        // BOSS plate + naam
        p.color = Color.parseColor("#3D0A14"); rf.set(cx - 12 * u, deskY + 6.5f * u, cx + 12 * u, deskY + 14.5f * u); c.drawRoundRect(rf, 1.6f * u, 1.6f * u, p)
        tp.color = Color.parseColor("#FFD7DE"); tp.textSize = 7f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText("BOSS", cx, deskY + 12.8f * u, tp)
        tp.color = if (bossOn) Color.parseColor("#FF8FA3") else Color.parseColor("#8A8A93"); tp.textSize = 11.5f * d
        c.drawText("VAANI", cx, base + 13.5f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
    }

    /** Khaali seat (agent coffee break par gaya hai). */
    private fun drawEmptySeat(c: Canvas, cx: Float, base: Float, sw: Float, idx: Int) {
        val u = sw / 100f; val deskY = base - 34 * u
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#26222A")
        rf.set(cx - 34 * u, deskY - 16 * u, cx - 28.5f * u, deskY + 16 * u); c.drawRoundRect(rf, 2.5f * u, 2.5f * u, p)
        c.drawRect(cx - 33 * u, deskY + 14 * u, cx - 30 * u, base - 3 * u, p)
        p.color = Color.parseColor("#4A3226")
        c.drawRect(cx - 40 * u, deskY, cx + 42 * u, deskY + 3.6f * u, p)
        c.drawRect(cx - 38 * u, deskY + 3.6f * u, cx - 35 * u, base - 1 * u, p)
        c.drawRect(cx + 38 * u, deskY + 3.6f * u, cx + 41 * u, base - 1 * u, p)
        p.color = Color.parseColor("#0B0B0E")
        rf.set(cx + 16 * u, deskY - 27 * u, cx + 40 * u, deskY - 5 * u); c.drawRoundRect(rf, 1.8f * u, 1.8f * u, p)
        tp.color = Color.parseColor("#8A8A93"); tp.textSize = 10.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(NAMES[idx], cx, base + 13.5f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
    }

    /** Ek workstation: kursi par baitha insaan (side view), saamne desk + monitor + keyboard. */
    private fun drawSeat(c: Canvas, cx: Float, base: Float, sw: Float, idx: Int, phase: Float) {
        val wk = working.getOrElse(idx) { false }
        val u = sw / 100f
        val deskY = base - 34 * u
        val bob = if (wk) sin((phase + idx * 1.7f).toDouble()).toFloat() * 1.1f * u else 0f

        // Kursi
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#26222A")
        rf.set(cx - 34 * u, deskY - 16 * u, cx - 28.5f * u, deskY + 16 * u); c.drawRoundRect(rf, 2.5f * u, 2.5f * u, p)
        c.drawRect(cx - 33 * u, deskY + 14 * u, cx - 30 * u, base - 3 * u, p)
        c.drawRect(cx - 38 * u, base - 3.5f * u, cx - 25 * u, base - 1.2f * u, p)
        // Pair
        p.color = Color.parseColor("#232733")
        rf.set(cx - 27 * u, deskY + 6 * u + bob * 0.3f, cx - 2 * u, deskY + 11.5f * u); c.drawRoundRect(rf, 2.5f * u, 2.5f * u, p)
        c.drawRect(cx - 7 * u, deskY + 10 * u, cx - 3.6f * u, base - 2.5f * u, p)
        p.color = Color.parseColor("#0E0C10"); c.drawRect(cx - 8.5f * u, base - 3 * u, cx + 1.5f * u, base - 0.8f * u, p)
        // Badan + sir (aaram wala peeche leta hua)
        val lean = if (wk) 0f else -16f
        c.save()
        c.translate(cx - 24 * u, deskY + 8 * u); c.rotate(lean); c.translate(-(cx - 24 * u), -(deskY + 8 * u))
        p.color = Color.parseColor(SHIRTS[idx])
        rf.set(cx - 31 * u, deskY - 24 * u + bob, cx - 16 * u, deskY + 9 * u); c.drawRoundRect(rf, 5 * u, 5 * u, p)
        val hx = cx - 23.5f * u; val hy = deskY - 31 * u + bob
        p.color = Color.parseColor(SKIN[idx % SKIN.size]); c.drawCircle(hx, hy, 7.6f * u, p)
        p.color = Color.parseColor(HAIR[idx % HAIR.size])
        rf.set(hx - 7.6f * u, hy - 8.6f * u, hx + 7.6f * u, hy + 1.5f * u); c.drawArc(rf, 180f, 180f, true, p)
        if (!wk) {
            p.style = Paint.Style.STROKE; p.color = Color.parseColor("#4A3428"); p.strokeWidth = 1.1f * u
            c.drawLine(hx + 2.5f * u, hy + 0.5f * u, hx + 6 * u, hy + 0.5f * u, p)
            p.style = Paint.Style.FILL
        }
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4.6f * u
        p.color = Color.parseColor(SHIRTS[idx])
        if (wk) {
            val ty = deskY - 4 * u + sin((phase * 2f + idx).toDouble()).toFloat() * 1.4f * u
            c.drawLine(cx - 19 * u, deskY - 17 * u + bob, cx - 4 * u, ty, p)
        } else {
            c.drawLine(cx - 20 * u, deskY - 18 * u, cx - 30 * u, deskY - 33 * u, p)
        }
        p.strokeCap = Paint.Cap.BUTT
        c.restore()
        // Desk
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#4A3226")
        c.drawRect(cx - 40 * u, deskY, cx + 42 * u, deskY + 3.6f * u, p)
        c.drawRect(cx - 38 * u, deskY + 3.6f * u, cx - 35 * u, base - 1 * u, p)
        c.drawRect(cx + 38 * u, deskY + 3.6f * u, cx + 41 * u, base - 1 * u, p)
        p.color = Color.parseColor("#151318"); rf.set(cx - 9 * u, deskY - 1.8f * u, cx + 9 * u, deskY + 0.4f * u)
        c.drawRoundRect(rf, 1 * u, 1 * u, p)
        // Monitor
        val mx0 = cx + 16 * u; val my0 = deskY - 27 * u; val mx1 = cx + 40 * u; val my1 = deskY - 5 * u
        p.color = Color.parseColor("#0B0B0E"); rf.set(mx0, my0, mx1, my1); c.drawRoundRect(rf, 1.8f * u, 1.8f * u, p)
        if (wk) {
            val glow = 0.82f + 0.18f * sin((phase * 1.4f + idx * 2.1f).toDouble()).toFloat()
            p.color = Color.argb(255, (140 * glow + 60).toInt(), (215 * glow).toInt(), (255 * glow).toInt())
            rf.set(mx0 + 1.6f * u, my0 + 1.6f * u, mx1 - 1.6f * u, my1 - 1.6f * u); c.drawRoundRect(rf, 1.2f * u, 1.2f * u, p)
            p.color = Color.parseColor("#0B3B52")
            for (r in 0 until 3) c.drawRect(mx0 + 3.4f * u, my0 + (4.5f + r * 5.5f) * u,
                mx0 + (10f + ((idx + r * 3) % 4) * 2.6f) * u, my0 + (6.3f + r * 5.5f) * u, p)
        } else {
            p.color = Color.parseColor("#1C1C22"); rf.set(mx0 + 1.6f * u, my0 + 1.6f * u, mx1 - 1.6f * u, my1 - 1.6f * u)
            c.drawRoundRect(rf, 1.2f * u, 1.2f * u, p)
        }
        p.color = Color.parseColor("#0B0B0E"); c.drawRect(cx + 26.5f * u, my1, cx + 29.5f * u, deskY - 1.5f * u, p)
        // Aaram wale ke sir par "Z"
        if (!wk) {
            val floatY = (tick % 36) / 36f
            tp.color = Color.parseColor("#9FB7C9"); tp.alpha = (200 * (1f - floatY)).toInt().coerceIn(0, 200)
            tp.textSize = (8f + floatY * 3.5f) * d
            c.drawText("Z", cx - 8 * u + floatY * 5 * u, deskY - 44 * u - floatY * 8 * u, tp)
            tp.alpha = 255
        }
        // Naam + kaam ka bindu
        p.color = if (wk) Color.parseColor("#51E07A") else Color.parseColor("#55555E")
        c.drawCircle(cx, base + 4.2f * d, 1.5f * d, p)
        tp.color = if (wk) Color.parseColor("#FFD7DE") else Color.parseColor("#8A8A93")
        tp.textSize = 10.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(NAMES[idx], cx, base + 13.5f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
    }
}
