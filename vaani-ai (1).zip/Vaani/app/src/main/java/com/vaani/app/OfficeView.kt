package com.vaani.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.sin

/**
 * Asli office room: 7 agents apni-apni desk par baithe hue - saamne desktop (monitor + keyboard).
 * Jo agent asal mein kaam kar raha hai (AgentStatus ke asli timestamps se faisla MainActivity karta hai),
 * woh seedha baithkar typing karta hai aur uski screen chamakti hai.
 * Jo khaali hai, woh kursi par peeche letkar aaram karta hai - screen band, sir par "Z z" uddte hain.
 * Koi nakli animation nahi: haalat hamesha asal kaam se judi hai, bas saans/typing ki halki harkat hai.
 */
class OfficeView(ctx: Context) : View(ctx) {
    var working = BooleanArray(7)
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private var tick = 0
    private val anim = object : Runnable {
        override fun run() { tick++; invalidate(); postDelayed(this, 120) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(anim) }
    override fun onDetachedFromWindow() { removeCallbacks(anim); super.onDetachedFromWindow() }

    companion object {
        val NAMES = listOf("Suno", "Dimaag", "Haath", "Khabar", "Call", "Awaaz", "Yaad")
        private val SHIRTS = listOf("#FF2E4D", "#B388FF", "#FFB74D", "#4DD0E1", "#81C784", "#F48FB1", "#90A4AE")
        private val SKIN = listOf("#F1C27D", "#E0AC69", "#C68642", "#FFDBAC")
        private val HAIR = listOf("#14100E", "#241611", "#2E2A26", "#191410")
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (w == 0f || h == 0f) return
        drawRoom(c, w, h)
        val phase = tick * 0.28f
        // Peeche wali row (3 agents, thode chhote + upar) aur saamne wali row (4 agents).
        val backBase = h * 0.44f; val frontBase = h * 0.86f
        val seatW = w / 4f
        for (i in 0 until 3) drawSeat(c, seatW * (i + 0.5f) + seatW * 0.5f, backBase, seatW * 0.80f, i + 4, phase)
        for (i in 0 until 4) drawSeat(c, seatW * (i + 0.5f), frontBase, seatW, i, phase)
    }

    /** Kamra: peeche ki deewar, ek khidki, ghadi, aur farsh. */
    private fun drawRoom(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#20060D"); c.drawRect(0f, 0f, w, h * 0.62f, p)          // deewar
        p.color = Color.parseColor("#12030A"); c.drawRect(0f, h * 0.62f, w, h, p)          // farsh
        p.color = Color.parseColor("#FF2E4D"); p.alpha = 46
        c.drawRect(0f, h * 0.62f, w, h * 0.62f + 1.6f * d, p); p.alpha = 255              // farsh ki rekha
        // Khidki (raat ka aasmaan)
        val wx = w * 0.06f; val wy = h * 0.07f; val ww = w * 0.30f; val wh = h * 0.30f
        p.color = Color.parseColor("#0B1E33"); rf.set(wx, wy, wx + ww, wy + wh); c.drawRoundRect(rf, 4 * d, 4 * d, p)
        p.color = Color.parseColor("#DFF6FF")
        val star = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#BFE9FF") }
        c.drawCircle(wx + ww * 0.25f, wy + wh * 0.30f, 1.3f * d, star)
        c.drawCircle(wx + ww * 0.62f, wy + wh * 0.55f, 1.1f * d, star)
        c.drawCircle(wx + ww * 0.80f, wy + wh * 0.22f, 1.4f * d, star)
        p.color = Color.parseColor("#FFD54F"); c.drawCircle(wx + ww * 0.82f, wy + wh * 0.68f, 5.5f * d, p)  // chaand
        p.strokeStyle(); p.color = Color.parseColor("#70101F"); p.strokeWidth = 1.6f * d
        rf.set(wx, wy, wx + ww, wy + wh); c.drawRoundRect(rf, 4 * d, 4 * d, p)
        c.drawLine(wx + ww / 2f, wy, wx + ww / 2f, wy + wh, p)
        // Deewar ghadi
        val gx = w * 0.90f; val gy = h * 0.16f; val gr = 8.5f * d
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#F5F0E8"); c.drawCircle(gx, gy, gr, p)
        p.strokeStyle(); p.color = Color.parseColor("#3D0A14"); p.strokeWidth = 1.2f * d
        c.drawLine(gx, gy, gx + gr * 0.55f, gy, p); c.drawLine(gx, gy, gx, gy - gr * 0.65f, p)
        // Board par naam
        tp.color = Color.parseColor("#FF8FA3"); tp.textSize = 9.5f * d
        tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText("VAANI OFFICE", w * 0.60f, h * 0.145f, tp)
        tp.typeface = android.graphics.Typeface.DEFAULT
    }

    private fun Paint.strokeStyle() { style = Paint.Style.STROKE }

    /**
     * Ek workstation: kursi par baitha insaan (side view), saamne desk + monitor + keyboard.
     * cx = seat ka centre x, base = farsh ki line (pairon ke neeche), sw = seat ki chaudaai.
     */
    private fun drawSeat(c: Canvas, cx: Float, base: Float, sw: Float, idx: Int, phase: Float) {
        val wk = working.getOrElse(idx) { false }
        val u = sw / 100f                                   // scale unit
        val deskY = base - 34 * u                           // desk ki satah
        val bob = if (wk) sin((phase + idx * 1.7f).toDouble()).toFloat() * 1.1f * u else 0f

        // ---- Kursi ----
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#26222A")
        rf.set(cx - 34 * u, deskY - 16 * u, cx - 28.5f * u, deskY + 16 * u); c.drawRoundRect(rf, 2.5f * u, 2.5f * u, p)  // peeth
        c.drawRect(cx - 33 * u, deskY + 14 * u, cx - 30 * u, base - 3 * u, p)                                          // taang
        c.drawRect(cx - 38 * u, base - 3.5f * u, cx - 25 * u, base - 1.2f * u, p)                                      // pahiya-line

        // ---- Pair (side view: jaangh aage, pindli neeche) ----
        p.color = Color.parseColor("#232733")
        rf.set(cx - 27 * u, deskY + 6 * u + bob * 0.3f, cx - 2 * u, deskY + 11.5f * u); c.drawRoundRect(rf, 2.5f * u, 2.5f * u, p)
        c.drawRect(cx - 7 * u, deskY + 10 * u, cx - 3.6f * u, base - 2.5f * u, p)
        p.color = Color.parseColor("#0E0C10"); c.drawRect(cx - 8.5f * u, base - 3 * u, cx + 1.5f * u, base - 0.8f * u, p)  // joota

        // ---- Badan + sir (aaram wala peeche leta hua) ----
        val lean = if (wk) 0f else -16f
        c.save()
        c.translate(cx - 24 * u, deskY + 8 * u)             // kursi ke seat-point ke aas-paas ghumao
        c.rotate(lean)
        c.translate(-(cx - 24 * u), -(deskY + 8 * u))
        // Dhad (shirt)
        p.color = Color.parseColor(SHIRTS[idx])
        rf.set(cx - 31 * u, deskY - 24 * u + bob, cx - 16 * u, deskY + 9 * u); c.drawRoundRect(rf, 5 * u, 5 * u, p)
        // Sir
        val hx = cx - 23.5f * u; val hy = deskY - 31 * u + bob
        p.color = Color.parseColor(SKIN[idx % SKIN.size]); c.drawCircle(hx, hy, 7.6f * u, p)
        p.color = Color.parseColor(HAIR[idx % HAIR.size])
        rf.set(hx - 7.6f * u, hy - 8.6f * u, hx + 7.6f * u, hy + 1.5f * u); c.drawArc(rf, 180f, 180f, true, p)           // baal
        if (!wk) { // band aankh ki rekha (so raha/aaram)
            p.strokeStyle(); p.color = Color.parseColor("#4A3428"); p.strokeWidth = 1.1f * u
            c.drawLine(hx + 2.5f * u, hy + 0.5f * u, hx + 6 * u, hy + 0.5f * u, p)
            p.style = Paint.Style.FILL
        }
        // Baahen
        p.strokeStyle(); p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4.6f * u
        p.color = Color.parseColor(SHIRTS[idx])
        if (wk) {
            val ty = deskY - 4 * u + sin((phase * 2f + idx).toDouble()).toFloat() * 1.4f * u   // typing ki harkat
            c.drawLine(cx - 19 * u, deskY - 17 * u + bob, cx - 4 * u, ty, p)                    // haath keyboard ki taraf
        } else {
            c.drawLine(cx - 20 * u, deskY - 18 * u, cx - 30 * u, deskY - 33 * u, p)              // haath sir ke peeche - aaram
        }
        p.strokeCap = Paint.Cap.BUTT
        c.restore()

        // ---- Desk ----
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#4A3226")
        c.drawRect(cx - 40 * u, deskY, cx + 42 * u, deskY + 3.6f * u, p)                        // satah
        c.drawRect(cx - 38 * u, deskY + 3.6f * u, cx - 35 * u, base - 1 * u, p)
        c.drawRect(cx + 38 * u, deskY + 3.6f * u, cx + 41 * u, base - 1 * u, p)
        // Keyboard
        p.color = Color.parseColor("#151318"); rf.set(cx - 9 * u, deskY - 1.8f * u, cx + 9 * u, deskY + 0.4f * u)
        c.drawRoundRect(rf, 1 * u, 1 * u, p)
        // Monitor
        val mx0 = cx + 16 * u; val my0 = deskY - 27 * u; val mx1 = cx + 40 * u; val my1 = deskY - 5 * u
        p.color = Color.parseColor("#0B0B0E"); rf.set(mx0, my0, mx1, my1); c.drawRoundRect(rf, 1.8f * u, 1.8f * u, p)
        if (wk) { // chamakti screen + code ki lines
            val glow = 0.82f + 0.18f * sin((phase * 1.4f + idx * 2.1f).toDouble()).toFloat()
            p.color = Color.argb(255, (140 * glow + 60).toInt(), (215 * glow).toInt(), (255 * glow).toInt())
            rf.set(mx0 + 1.6f * u, my0 + 1.6f * u, mx1 - 1.6f * u, my1 - 1.6f * u); c.drawRoundRect(rf, 1.2f * u, 1.2f * u, p)
            p.color = Color.parseColor("#0B3B52")
            for (r in 0 until 3) c.drawRect(mx0 + 3.4f * u, my0 + (4.5f + r * 5.5f) * u,
                mx0 + (10f + ((idx + r * 3) % 4) * 2.6f) * u, my0 + (6.3f + r * 5.5f) * u, p)
        } else { // band screen
            p.color = Color.parseColor("#1C1C22"); rf.set(mx0 + 1.6f * u, my0 + 1.6f * u, mx1 - 1.6f * u, my1 - 1.6f * u)
            c.drawRoundRect(rf, 1.2f * u, 1.2f * u, p)
        }
        p.color = Color.parseColor("#0B0B0E"); c.drawRect(cx + 26.5f * u, my1, cx + 29.5f * u, deskY - 1.5f * u, p)  // stand

        // ---- Aaram wale ke sir par "Z z" ----
        if (!wk) {
            val floatY = (tick % 36) / 36f
            tp.color = Color.parseColor("#9FB7C9"); tp.alpha = (200 * (1f - floatY)).toInt().coerceIn(0, 200)
            tp.textSize = (8f + floatY * 3.5f) * d
            c.drawText("Z", cx - 8 * u + floatY * 5 * u, deskY - 44 * u - floatY * 8 * u, tp)
            tp.alpha = 255
        }

        // ---- Naam (pairon ke neeche) + kaam ka bindu ----
        p.color = if (wk) Color.parseColor("#51E07A") else Color.parseColor("#55555E")
        c.drawCircle(cx, base + 4.2f * d, 1.5f * d, p)
        tp.color = if (wk) Color.parseColor("#FFD7DE") else Color.parseColor("#8A8A93")
        tp.textSize = 10.5f * d
        tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(NAMES[idx], cx, base + 13.5f * d, tp)
        tp.typeface = android.graphics.Typeface.DEFAULT
    }
}
