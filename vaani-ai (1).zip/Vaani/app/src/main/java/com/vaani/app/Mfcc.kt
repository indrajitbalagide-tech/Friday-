package com.vaani.app

import kotlin.math.*

/** Tiny MFCC extractor -> 24-dim voice vector (mean + std of c1..c12). */
object Mfcc {
    private const val SR = 16000; private const val WIN = 400; private const val HOP = 160
    private const val NFFT = 512; private const val NM = 26; private const val NC = 13
    private val win = DoubleArray(WIN) { 0.54 - 0.46 * cos(2 * PI * it / (WIN - 1)) }
    private val dct = Array(NC) { c -> DoubleArray(NM) { m -> cos(PI * c * (m + 0.5) / NM) } }
    private val fb: Array<DoubleArray> = run {
        fun mel(f: Double) = 2595 * log10(1 + f / 700)
        fun inv(m: Double) = 700 * (10.0.pow(m / 2595) - 1)
        val pts = DoubleArray(NM + 2) { inv(mel(0.0) + (mel(8000.0) - mel(0.0)) * it / (NM + 1)) }
        val bins = IntArray(NM + 2) { floor((NFFT + 1) * pts[it] / SR).toInt() }
        Array(NM) { m -> DoubleArray(NFFT / 2 + 1).also { f ->
            for (k in bins[m] until bins[m + 1]) f[k] = (k - bins[m]).toDouble() / max(1, bins[m + 1] - bins[m])
            for (k in bins[m + 1] until bins[m + 2]) f[k] = (bins[m + 2] - k).toDouble() / max(1, bins[m + 2] - bins[m + 1]) } }
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size; var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val t = re[i]; re[i] = re[j]; re[j] = t; val u = im[i]; im[i] = im[j]; im[j] = u }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len; val wr = cos(ang); val wi = sin(ang); var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val a = i + k; val b = a + len / 2
                    val xr = re[b] * cr - im[b] * ci; val xi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - xr; im[b] = im[a] - xi; re[a] += xr; im[a] += xi
                    val nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr
                }
                i += len
            }
            len = len shl 1
        }
    }

    fun vector(x: ShortArray): FloatArray? {
        if (x.size < WIN + HOP * 20) return null
        val rms = ArrayList<Double>(); val feats = ArrayList<DoubleArray>()
        val re = DoubleArray(NFFT); val im = DoubleArray(NFFT)
        var s = 0
        while (s + WIN <= x.size) {
            java.util.Arrays.fill(re, 0.0); java.util.Arrays.fill(im, 0.0)
            var e = 0.0
            for (i in 0 until WIN) {
                val p = if (s + i > 0) x[s + i - 1].toDouble() else 0.0
                val v = x[s + i] - 0.97 * p
                re[i] = v * win[i]; e += x[s + i].toDouble() * x[s + i]
            }
            fft(re, im)
            val pw = DoubleArray(NFFT / 2 + 1) { re[it] * re[it] + im[it] * im[it] }
            val lm = DoubleArray(NM) { m -> var a = 0.0; for (k in pw.indices) a += fb[m][k] * pw[k]; ln(max(a, 1e-10)) }
            feats.add(DoubleArray(NC) { c -> var a = 0.0; for (m in 0 until NM) a += dct[c][m] * lm[m]; a })
            rms.add(sqrt(e / WIN)); s += HOP
        }
        val top = rms.sortedDescending().take(max(1, rms.size * 3 / 10))
        val thr = 0.3 * top.average()
        val keep = feats.filterIndexed { i, _ -> rms[i] >= thr }
        if (keep.size < 30) return null
        val out = FloatArray(24)
        for (c in 1..12) {
            val m = keep.sumOf { it[c] } / keep.size
            val sd = sqrt(keep.sumOf { (it[c] - m) * (it[c] - m) } / keep.size)
            out[c - 1] = m.toFloat(); out[c + 11] = sd.toFloat()
        }
        return out
    }
}
