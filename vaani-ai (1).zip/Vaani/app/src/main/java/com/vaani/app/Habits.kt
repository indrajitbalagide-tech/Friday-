package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * Vaani ki "seekhne" wali diary: kaun-sa kaam baar-baar ho raha hai, ye note karti hai.
 * Ye koi neural-network training nahi hai - ye pattern-memory hai, jisse Vaani
 * user ki aadatein pehchankar samay par sujhav de sakti hai.
 */
object Habits {
    private fun prefs(c: Context) = c.getSharedPreferences("vaani", Context.MODE_PRIVATE)

    /** Har tool-call yaha note hota hai (Actions.run se). Galti ho to bhi asli kaam nahi rukna chahiye. */
    fun record(c: Context, tool: String, detail: String) {
        try {
            val p = prefs(c)
            val all = JSONObject(p.getString("habits", "{}") ?: "{}")
            val key = tool + "|" + detail.take(24).lowercase()
            val e = all.optJSONObject(key) ?: JSONObject().put("n", 0).put("h", JSONArray())
            e.put("n", e.optInt("n") + 1)
            val hrs = e.getJSONArray("h"); hrs.put(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))
            while (hrs.length() > 12) hrs.remove(0)
            all.put(key, e)
            if (all.length() > 40) {   // diary zyada badi na ho - sabse kam-use wali entry hatao
                var worst: String? = null; var wn = Int.MAX_VALUE
                val it = all.keys(); while (it.hasNext()) { val k = it.next()
                    val n = all.getJSONObject(k).optInt("n"); if (n < wn) { wn = n; worst = k } }
                worst?.let { all.remove(it) }
            }
            p.edit().putString("habits", all.toString()).apply()
        } catch (e: Exception) { /* seekhna kabhi asli kaam na roke */ }
    }

    /** Teen baar dohraaya gaya kaam: ek baar sujhav do, phir dobara tang mat karo. */
    fun suggestion(c: Context): String? {
        val p = prefs(c)
        val all = JSONObject(p.getString("habits", "{}") ?: "{}")
        val told = p.getStringSet("habit_told", emptySet()) ?: emptySet()
        val it = all.keys()
        while (it.hasNext()) {
            val k = it.next(); val n = all.getJSONObject(k).optInt("n")
            if (n >= 3 && k !in told) {
                p.edit().putStringSet("habit_told", told + k).apply()
                val parts = k.split("|", limit = 2)
                val what = if (parts.size > 1 && parts[1].isNotEmpty()) "'${parts[1]}'" else parts[0]
                return "Vaani ne seekha hai: tum aksar $what wala kaam karte ho ($n baar ho gaya). Chaho to iski routine bana du — phir bas ek baar bolna hoga."
            }
        }
        return null
    }
}
