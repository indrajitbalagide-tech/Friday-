package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** v4.0 ke saare naye tools ka dispatcher + Gemini ko dikhane wali tool declarations. */
object Extras {
    fun run(c: Context, name: String, a: JSONObject): String? =
        Info.run(c, name, a) ?: Home.run(c, name, a) ?: when (name) {
            "memory" -> when (a.optString("action")) {
                "remember" -> Memory.remember(c, a.optString("key"), a.optString("value"))
                "forget" -> Memory.forget(c, a.optString("key"))
                else -> Memory.recall(c, a.optString("key"))
            }
            "look" -> Vision.look(c, a.optString("source", "camera_back"), a.optString("question"))
            "screen_agent" -> Vision.agent(c, a.getString("goal"))
            "briefing" -> Briefing.make(c)
            "place" -> place(c, a)
            "action_log" -> ActionLog.recent(c, a.optInt("count", 8))
            else -> null
        }

    private fun place(c: Context, a: JSONObject): String {
        val pl = Memory.places(c); val n = a.optString("name").lowercase().trim()
        return when (a.optString("action")) {
            "save" -> {
                if (n.isEmpty()) return "Jagah ka naam batao (jaise ghar, office)."
                val l = Loc.fresh(c) ?: return "Location nahi mili - location permission/GPS check karo."
                pl.put(n, JSONObject().put("lat", l.latitude).put("lon", l.longitude).put("r", 150))
                Memory.savePlaces(c, pl); "'$n' ki jagah save ho gayi. Routine '${n}_aao' / '${n}_jao' bana do to aate-jaate wahi chalegi."
            }
            "delete" -> { pl.remove(n); Memory.savePlaces(c, pl); "'$n' hata di." }
            else -> if (pl.length() == 0) "Koi jagah save nahi hai." else pl.keys().asSequence().joinToString(", ")
        }
    }

    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun ip(d: String) = JSONObject().put("type", "INTEGER").put("description", d)

    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("memory", "Malik ke baare mein lambi yaadasht: remember (fact save), recall (yaad dekho), forget. Password/PIN save nahi hota.",
            mapOf("action" to sp("remember|recall|forget"), "key" to sp("chhota naam jaise 'bhai', 'ghar_address', 'pasandida_khana'"), "value" to sp("remember ke liye fact")), listOf("action")),
        fn("web_answer", "Internet (Google Search) se taaza jaankari ka seedha jawab: news, score, rate, kisi bhi cheez ke facts.", mapOf("query" to sp("sawaal")), listOf("query")),
        fn("weather", "Mausam. Place khali ho to user ki current location ka.", mapOf("place" to sp("shehar ka naam, optional"))),
        fn("calendar_read", "Aane wale calendar events padho.", mapOf("hours" to ip("kitne ghante aage tak, default 24"))),
        fn("call_log", "Haal ke calls (missed/aaye/gaye).", mapOf("count" to ip("kitne, default 6"))),
        fn("sms_read", "Inbox ke naye SMS padho.", mapOf("from" to sp("sender ka naam/number, optional"), "count" to ip("kitne, default 4"))),
        fn("my_location", "User abhi kahan hai (pata)."),
        fn("look", "Camera ya screen dekhkar sawaal ka jawab: 'ye kya hai', 'is screen par kya likha hai', 'saamne kya hai'.",
            mapOf("source" to sp("camera_back|camera_front|screen"), "question" to sp("kya jaanna hai")), listOf("source")),
        fn("screen_agent", "Kisi bhi app ke andar ka multi-step kaam khud karo (screen dekhkar tap/type/swipe). Jab seedha tool na ho tab use karo.",
            mapOf("goal" to sp("poora kaam ek line mein")), listOf("goal")),
        fn("briefing", "Abhi ka briefing: mausam, calendar, battery, naye messages."),
        fn("place", "Jagah save karo (ghar, office) - current location se. Aate-jaate '<naam>_aao' / '<naam>_jao' routine chalti hai.",
            mapOf("action" to sp("save|list|delete"), "name" to sp("jagah ka naam")), listOf("action")),
        fn("smart_home", "Ghar ke devices (Home Assistant): light, fan, AC, pardey, scene... on/off/toggle/set/state/list.",
            mapOf("action" to sp("on|off|toggle|set|state|list"), "target" to sp("device ka naam jaise 'bedroom light'"), "value" to ip("set ke liye 0-100 ya temperature")), listOf("action")),
        fn("webhook", "Saved webhook (ESP32/IFTTT/Node-RED) chalao ya save/list/delete karo.",
            mapOf("action" to sp("call|save|list|delete"), "name" to sp("naam"), "url" to sp("save ke liye http(s) URL"), "data" to sp("optional body")), listOf("action")),
        fn("pc", "Laptop/PC control: open_app, open_url, lock, sleep, shutdown, restart, volume_up, volume_down, mute, play_pause, next, previous, find_file, run (saved command), status.",
            mapOf("action" to sp("action ka naam"), "arg" to sp("app/url/file naam/command naam")), listOf("action")),
        fn("action_log", "Vaani ne haal mein kya-kya kiya, uski list.", mapOf("count" to ip("kitne, default 8")))
    )
}
