package com.vaani.app

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/** Extra Android automation. Returns null for unknown tool names so Actions can fall through. */
object Automation {
    private fun go(c: Context, i: Intent) = c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun run(c: Context, name: String, a: JSONObject): String? = when (name) {
        "system_control" -> system(c, a.getString("action"), a.optInt("value", 50))
        "screen_control" -> screen(c, a.getString("action"), a.optString("text"))
        "routine" -> routine(c, a)
        "navigate" -> { val p = Uri.encode(a.getString("place"))
            try { go(c, Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$p")).setPackage("com.google.android.apps.maps")) }
            catch (e: Exception) { go(c, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$p"))) }
            "Navigation shuru." }
        "web_search" -> { go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.getString("query"))))); "Search khol diya." }
        "open_url" -> { val u = a.getString("url"); if (!u.startsWith("http")) "Sirf http/https link khol sakta hu."
            else { go(c, Intent(Intent.ACTION_VIEW, Uri.parse(u))); "Link khol diya." } }
        "sms" -> Actions.number(c, a.getString("who"))?.let {
            go(c, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(it))).putExtra("sms_body", a.getString("message")))
            "SMS ready hai, send dabao." } ?: "Contact nahi mila."
        "email" -> { go(c, Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + a.getString("to")))
            .putExtra(Intent.EXTRA_SUBJECT, a.optString("subject")).putExtra(Intent.EXTRA_TEXT, a.optString("body"))); "Email draft khol diya." }
        "share_text" -> { go(c, Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, a.getString("text")), null)); "Share sheet khol di." }
        "alarm" -> { go(c, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
            .putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute")).putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Vaani"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)); "Alarm set." }
        "camera" -> { go(c, Intent(if (a.optString("mode") == "video") MediaStore.INTENT_ACTION_VIDEO_CAMERA
            else MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); "Camera khol diya." }
        else -> null
    }

    private fun system(c: Context, act: String, v: Int): String {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val nm = c.getSystemService(NotificationManager::class.java)
        val pct = v.coerceIn(0, 100)
        fun needWrite(): String? = if (Settings.System.canWrite(c)) null else {
            go(c, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}")))
            "Pehle 'Modify system settings' allow karo, screen khol di." }
        fun needDnd(): String? = if (nm.isNotificationPolicyAccessGranted) null else {
            go(c, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); "Pehle Do Not Disturb access allow karo, screen khol di." }
        return when (act) {
            "volume_set" -> { am.setStreamVolume(AudioManager.STREAM_MUSIC, pct * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) / 100, AudioManager.FLAG_SHOW_UI); "Volume $pct%." }
            "volume_up" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "Volume badha diya." }
            "volume_down" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "Volume kam kar diya." }
            "mute" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "Mute." }
            "unmute" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI); "Unmute." }
            "brightness_set" -> needWrite() ?: let {
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, pct * 255 / 100); "Brightness $pct%." }
            "autorotate_on" -> needWrite() ?: let { Settings.System.putInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1); "Auto-rotate on." }
            "autorotate_off" -> needWrite() ?: let { Settings.System.putInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0); "Auto-rotate off." }
            "dnd_on" -> needDnd() ?: let { nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE); "Do Not Disturb on." }
            "dnd_off" -> needDnd() ?: let { nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL); "Do Not Disturb off." }
            "ringer_silent" -> needDnd() ?: let { am.ringerMode = AudioManager.RINGER_MODE_SILENT; "Phone silent." }
            "ringer_vibrate" -> { am.ringerMode = AudioManager.RINGER_MODE_VIBRATE; "Vibrate mode." }
            "ringer_normal" -> { am.ringerMode = AudioManager.RINGER_MODE_NORMAL; "Ringer on." }
            "battery" -> {
                val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1; val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
                val ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
                "Battery ${lvl * 100 / sc}%" + if (ch) ", charge ho rahi hai." else "."
            }
            else -> "Ye system action nahi aata."
        }
    }

    private fun screen(c: Context, act: String, text: String): String {
        // Screen lock: device admin ON ho to usi se pakka lock, warna accessibility wala rasta.
        if (act == "lock_screen") {
            val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (dpm.isAdminActive(ComponentName(c, AdminReceiver::class.java))) { dpm.lockNow(); return "Screen lock (device admin)." }
        }
        val s = VaaniAccess.inst ?: run {
            go(c, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return "Pehle Accessibility mein Vaani ko ON karo, settings khol di." }
        fun ok(b: Boolean, m: String) = if (b) m else "Ye nahi ho paya."
        return when (act) {
            "back" -> ok(s.global(AccessibilityService.GLOBAL_ACTION_BACK), "Back.")
            "home" -> ok(s.global(AccessibilityService.GLOBAL_ACTION_HOME), "Home.")
            "recents" -> ok(s.global(AccessibilityService.GLOBAL_ACTION_RECENTS), "Recent apps.")
            "notifications" -> ok(s.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS), "Notifications khol di.")
            "quick_settings" -> ok(s.global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS), "Quick settings khol di.")
            "power_menu" -> ok(s.global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG), "Power menu.")
            "lock_screen" -> ok(s.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN), "Screen lock.")
            "screenshot" -> ok(s.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT), "Screenshot le liya.")
            "scroll_down" -> ok(s.scroll(true), "Scroll down.")
            "scroll_up" -> ok(s.scroll(false), "Scroll up.")
            "swipe_up" -> ok(s.swipe("up"), "Swipe up.")
            "swipe_down" -> ok(s.swipe("down"), "Swipe down.")
            "swipe_left" -> ok(s.swipe("left"), "Swipe left.")
            "swipe_right" -> ok(s.swipe("right"), "Swipe right.")
            "tap_text" -> ok(s.tapText(text), "'$text' dabaya.")
            "type_text" -> ok(s.typeText(text), "Likh diya.")
            "read_screen" -> s.readScreen()
            else -> "Ye screen action nahi aata."
        }
    }

    private fun routine(c: Context, a: JSONObject): String {
        val p = c.getSharedPreferences("vaani", Context.MODE_PRIVATE)
        val all = JSONObject(p.getString("routines", "{}") ?: "{}")
        val n = a.optString("name").lowercase()
        fun store() = p.edit().putString("routines", all.toString()).apply()
        return when (a.getString("action")) {
            "save" -> { val steps = JSONArray(a.getString("steps")); all.put(n, steps); store(); "Routine '$n' save ho gayi (${steps.length()} steps)." }
            "delete" -> { all.remove(n); store(); "Routine '$n' hata di." }
            "list" -> if (all.length() == 0) "Koi routine nahi hai." else all.keys().asSequence().joinToString(", ")
            else -> {
                val steps = all.optJSONArray(n) ?: return "Routine '$n' nahi mili."
                Thread {
                    for (i in 0 until steps.length()) {
                        val st = steps.getJSONObject(i)
                        if (st.getString("name") != "routine") Actions.run(c, st.getString("name"), st.optJSONObject("args") ?: JSONObject())
                        Thread.sleep(1500)
                    }
                }.start()
                "Routine '$n' chala raha hu."
            }
        }
    }
}
