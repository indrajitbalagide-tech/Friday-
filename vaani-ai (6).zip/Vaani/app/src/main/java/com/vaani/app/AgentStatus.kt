package com.vaani.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Agents board ke liye har "employee" ki live haalat.
 * Har hissa (service, notifications, calls, speaker...) apni line khud update karta hai -
 * board jo dikhata hai, woh asal mein ho raha hota hai.
 */
object AgentStatus {
    @Volatile var brain = "Intezaar mein"
    @Volatile var worker = "Koi kaam nahi"
    @Volatile var khabar = "Koi khabar nahi"
    @Volatile var call = "Koi call nahi"
    @Volatile var voice = "Chup hai"
    fun time(): String = SimpleDateFormat("HH:mm", Locale.US).format(Date())
}
