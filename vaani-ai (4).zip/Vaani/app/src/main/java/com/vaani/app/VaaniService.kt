package com.vaani.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Always-on foreground service. Mic -> energy VAD -> your-voice check -> only then Gemini Live session opens.
 * Session closes after 15 s of silence; the gate re-arms. Nothing is sent to Google while the gate is closed.
 */
class VaaniService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var forceStart = false
        var log: ((String) -> Unit)? = null
    }

    @Volatile private var stop = false
    @Volatile private var live: LiveClient? = null
    private var lastVoice = 0L
    private lateinit var overlay: Overlay
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun say(t: String) { log?.invoke(t) }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stop = true; stopSelf(); return START_NOT_STICKY }
        if (running) return START_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vaani", "Vaani 24h", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0, Intent(this, VaaniService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val openPi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "vaani").setContentTitle("Vaani sun raha hai").setContentText("Sirf aapki awaaz par jaagta hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true)
            .setContentIntent(openPi).setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Stop", stopPi).build()).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vaani:mic").also { it.acquire() }
        running = true; stop = false
        overlay = Overlay(this); overlay.show { forceStart = true }
        Thread { loop() }.start()
        return START_STICKY
    }

    private fun startLive() {
        val key = getSharedPreferences("vaani", MODE_PRIVATE).getString("key", "").orEmpty()
        if (key.isEmpty()) return say("API key nahi mili.")
        live = LiveClient(this, key) { say(it) }.also { it.connect() }
        lastVoice = System.currentTimeMillis()
    }

    private fun loop() {
        val fr = 320
        val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, fr * 40))
        rec.startRecording()
        val vp = VoicePrint(this)
        val buf = ShortArray(fr)
        val pre = java.util.ArrayDeque<ShortArray>(); val utter = ArrayList<ShortArray>(); val batch = ArrayList<ShortArray>()
        var noise = 200.0; var inSpeech = false; var quiet = 0; var checked = false; var shown = -1
        say("24h mode chalu. Aapki awaaz ka intezaar…")

        fun tryVerify() {
            checked = true
            if (vp.verify(utter)) {
                say("✅ Aapki awaaz pehchani"); startLive(); live?.sendAudio(ArrayList(utter))
            } else say("🚫 Awaaz match nahi hui, ignore kiya")
            utter.clear()
        }

        while (!stop) {
            val n = rec.read(buf, 0, fr); if (n <= 0) continue
            val f = buf.copyOf(n)
            var s = 0.0; for (x in f) s += x * x.toDouble()
            val rms = Math.sqrt(s / n)
            val voice = rms > maxOf(noise * 2.5, 350.0)
            if (!voice) noise = 0.98 * noise + 0.02 * rms
            val now = System.currentTimeMillis()
            val l = live

            if (l != null) {
                if (l.closed) { live = null; continue }
                if (voice) lastVoice = now
                val speaking = now < l.speakingUntil
                val st = if (speaking) 2 else 1
                if (st != shown) { shown = st; overlay.state(st) }
                if (!speaking && now - lastVoice > 15000) { l.close(); live = null; shown = 0; overlay.state(0); say("Session band, intezaar…"); continue }
                if (speaking) { batch.clear(); continue }   // half-duplex: don't feed Vaani its own voice
                batch.add(f); if (batch.size >= 5) { l.sendAudio(ArrayList(batch)); batch.clear() }
                continue
            }
            if (shown != 0) { shown = 0; overlay.state(0) }
            if (forceStart) { forceStart = false; startLive(); continue }

            if (voice) {
                quiet = 0
                if (!inSpeech) { inSpeech = true; checked = false; utter.clear(); utter.addAll(pre) }
                if (!checked) { utter.add(f); if (utter.size >= 75) tryVerify() }
            } else {
                if (inSpeech && ++quiet > 40) { if (!checked && utter.size >= 40) tryVerify(); inSpeech = false; checked = false; utter.clear() }
                pre.addLast(f); if (pre.size > 15) pre.removeFirst()
            }
        }
        rec.stop(); rec.release()
    }

    override fun onDestroy() {
        stop = true; running = false
        live?.close(); overlay.hide(); wake?.let { if (it.isHeld) it.release() }
        say("24h mode band."); super.onDestroy()
    }
}
