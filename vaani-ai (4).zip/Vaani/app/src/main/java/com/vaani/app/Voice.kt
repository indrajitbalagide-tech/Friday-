package com.vaani.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Friendly voice: Gemini's natural TTS voice (Aoede) over REST.
 * If the Gemini voice is unreachable, falls back to the phone's own TTS so a message is never lost.
 */
object GeminiVoice {
    // Do model isliye: ek band/404 ho to dusra try hoga, awaaz kabhi robotic par atki nahi rahegi.
    private val MODELS = listOf("gemini-2.5-flash-preview-tts", "gemini-3.1-flash-tts-preview")
    private const val VOICE = "Aoede"

    /** Blocking call - background thread se bulao. true = Gemini ki awaaz bol gayi. */
    fun speak(key: String, text: String): Boolean {
        for (model in MODELS) {
            try { if (speakWith(model, key, text)) return true } catch (_: Exception) {}
        }
        return false
    }

    private fun speakWith(model: String, key: String, text: String): Boolean {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", VOICE)))))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode !in 200..299) return false
        val txt = c.inputStream.bufferedReader().readText()
        val data = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getJSONObject("inlineData").getString("data")
        val pcm = Base64.decode(data, Base64.DEFAULT)
        play(pcm)
        return true
    }

    private fun play(pcm: ByteArray) {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, pcm.size))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        track.setVolume(1f)
        track.play()
        track.write(pcm, 0, pcm.size)
        Thread.sleep(pcm.size / 2 * 1000L / 24000 + 250)   // bajne ka intezaar
        try { track.stop() } catch (_: Exception) {}
        track.release()
    }
}

/** Shared speaker for announcements (calls, messages, typed replies): pehle Gemini ki friendly awaaz, warna phone ki TTS. */
object Speaker {
    private val lock = Any()
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false

    fun speak(ctx: Context, text: String) {
        val app = ctx.applicationContext
        Thread {
            synchronized(lock) {
                val key = app.getSharedPreferences("vaani", Context.MODE_PRIVATE).getString("key", "").orEmpty()
                val ok = key.isNotEmpty() && GeminiVoice.speak(key, text)
                if (!ok) deviceTts(app, text)
            }
        }.start()
    }

    private fun deviceTts(ctx: Context, text: String) {
        if (tts == null) {
            tts = TextToSpeech(ctx) { s -> if (s == TextToSpeech.SUCCESS) { tts?.language = Locale("hi", "IN"); ttsReady = true } }
            Thread.sleep(700)
        }
        if (!ttsReady) tts?.language = Locale("hi", "IN")
        // Fallback awaaz bhi bade speaker (media stream) par, full volume mein.
        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1f)
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "sp")
    }
}
