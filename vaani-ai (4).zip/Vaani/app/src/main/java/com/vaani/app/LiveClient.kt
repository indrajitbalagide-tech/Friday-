package com.vaani.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Gemini Live (bidirectional audio WebSocket). Mic frames in, voice out, tool calls run real phone actions. */
class LiveClient(private val ctx: Context, private val key: String, private val say: (String) -> Unit) {
    companion object {
        // Check the current Live model name in Google's docs; change here if the server rejects it.
        const val LIVE_MODEL = "models/gemini-3.1-flash-live-preview"
        private const val URL = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
        private const val SYS = "You are Vaani, the owner's always-on voice assistant. Understand Hindi, Marathi, English and Hinglish. " +
            "Always reply in the same language the user just spoke; if unclear, default to Hinglish. " +
            "Keep replies very short. Use tools for phone actions. If speech is not meant for you, stay silent."
    }

    @Volatile var closed = false
    @Volatile var speakingUntil = 0L
    @Volatile private var ready = false
    private val pending = ArrayList<String>()
    private var ws: WebSocket? = null
    private val sbIn = StringBuilder(); private val sbOut = StringBuilder()
    private val track = AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
        .setBufferSizeInBytes(AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT) * 8)
        .setTransferMode(AudioTrack.MODE_STREAM).build().also { it.setVolume(1f); it.play() }

    fun connect() {
        val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
        ws = client.newWebSocket(Request.Builder().url("$URL?key=$key").build(), object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                // Chalti hui haalat bhi bata do: bajti call / pending jawab - taaki Vaani seedha unhi par baat kare.
                val extra = StringBuilder()
                CallReceiver.ringingNow?.let { extra.append(" IMPORTANT: Abhi $it ka call baj raha hai. User se turant poochho: answer karun ya reject karun? User ke jawab par call_control tool bulao (answer ya reject).") }
                NotifService.pendingSender?.let { s -> NotifService.pendingDraft?.let { d ->
                    extra.append(" IMPORTANT: $s ke message ka ye jawab bhejna pending hai: \"$d\". User haan bole to pending_reply tool se send karo, naa bole to drop karo.") } }
                val setup = JSONObject().put("setup", JSONObject()
                    .put("model", LIVE_MODEL)
                    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO")))
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS + extra.toString()))))
                    .put("tools", JSONArray(Gemini.tools))
                    .put("inputAudioTranscription", JSONObject()).put("outputAudioTranscription", JSONObject()))
                w.send(setup.toString())
            }
            override fun onMessage(w: WebSocket, text: String) = handle(JSONObject(text))
            override fun onMessage(w: WebSocket, bytes: ByteString) = handle(JSONObject(bytes.utf8()))
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) { say("Live error: ${t.message?.take(100)}"); close() }
            override fun onClosed(w: WebSocket, code: Int, reason: String) { close() }
        })
    }

    private fun handle(m: JSONObject) {
        if (m.has("setupComplete")) { synchronized(pending) { ready = true; pending.forEach { ws?.send(it) }; pending.clear() } }
        m.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) { track.pause(); track.flush(); track.play(); speakingUntil = 0 }
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { ps ->
                for (i in 0 until ps.length()) ps.getJSONObject(i).optJSONObject("inlineData")?.let {
                    val pcm = Base64.decode(it.getString("data"), Base64.DEFAULT)
                    track.write(pcm, 0, pcm.size)
                    val now = System.currentTimeMillis()
                    speakingUntil = maxOf(speakingUntil, now) + pcm.size / 2 * 1000L / 24000 + 100
                }
            }
            sc.optJSONObject("inputTranscription")?.optString("text")?.let { sbIn.append(it) }
            sc.optJSONObject("outputTranscription")?.optString("text")?.let { sbOut.append(it) }
            if (sc.optBoolean("turnComplete")) {
                if (sbIn.isNotBlank()) say("🧑 ${sbIn.toString().trim()}"); if (sbOut.isNotBlank()) say("🤖 ${sbOut.toString().trim()}")
                sbIn.setLength(0); sbOut.setLength(0)
            }
        }
        m.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { fc ->
            val out = JSONArray()
            for (i in 0 until fc.length()) {
                val f = fc.getJSONObject(i)
                val res = Actions.run(ctx, f.getString("name"), f.optJSONObject("args") ?: JSONObject())
                say("⚙ ${f.getString("name")}: $res")
                out.put(JSONObject().put("id", f.optString("id")).put("name", f.getString("name"))
                    .put("response", JSONObject().put("result", res)))
            }
            ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", out)).toString())
        }
    }

    fun sendAudio(frames: List<ShortArray>) {
        if (closed) return
        val n = frames.sumOf { it.size }; val b = ByteArray(n * 2); var o = 0
        for (f in frames) for (s in f) { b[o++] = (s.toInt() and 0xFF).toByte(); b[o++] = (s.toInt() shr 8).toByte() }
        val msg = JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
            .put("data", Base64.encodeToString(b, Base64.NO_WRAP)).put("mimeType", "audio/pcm;rate=16000"))).toString()
        synchronized(pending) { if (!ready) { if (pending.size < 150) pending.add(msg); return } }
        ws?.send(msg)
    }

    fun close() {
        if (closed) return
        closed = true
        try { ws?.close(1000, null) } catch (_: Exception) {}
        try { track.stop(); track.release() } catch (_: Exception) {}
    }
}
