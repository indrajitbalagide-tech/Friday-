package com.vaani.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONObject

/**
 * Do hisse:
 * 1) SETUP / LOGIN screen - API key verify + saari permissions ki checklist. Sab green hue bina entry nahi.
 * 2) DASHBOARD - sirf live conversation (header, status aur type-box ke saath). Koi faltu gardi nahi.
 */
class MainActivity : Activity() {
    // dashboard views
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var wave: WaveView
    private lateinit var batt: TextView
    // setup views
    private lateinit var keyBox: EditText
    private lateinit var setupHint: TextView
    private lateinit var checkList: LinearLayout
    private lateinit var enterBtn: Button
    private lateinit var setupRoot: ScrollView
    private lateinit var dashRoot: LinearLayout
    private var dashBuilt = false
    private var onDashboard = false
    private var greeted = false
    private var lastHint = ""
    private val prefs by lazy { getSharedPreferences("vaani", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun panel(radius: Int, fill: String, stroke: String) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat(); setColor(Color.parseColor(fill)); setStroke(dp(1), Color.parseColor(stroke))
    }
    private fun bgGrad() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.parseColor("#03101F"), Color.parseColor("#010409")))

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
            Manifest.permission.ANSWER_PHONE_CALLS, "android.permission.POST_NOTIFICATIONS"), 1)
        window.statusBarColor = Color.parseColor("#020A18")
        // Lockscreen ke upar bhi app khule (unlock nahi hota - sirf Vaani ki screen dikhti hai)
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        buildSetup()
        VaaniService.log = { t -> say(t) }
        if (allChecks().all { it.second }) showDashboard() else { setContentView(setupRoot); refreshSetup() }
    }

    // ---------- SETUP / LOGIN ----------

    private fun buildSetup() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(30), dp(18), dp(18)) }
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        titleRow.addView(TextView(this).apply { text = "VAANI "; textSize = 25f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        titleRow.addView(TextView(this).apply { text = "AI"; textSize = 25f; setTextColor(Color.parseColor("#19C8FF")); typeface = Typeface.DEFAULT_BOLD })
        root.addView(titleRow)
        root.addView(TextView(this).apply { text = "PERSONAL INTELLIGENCE SYSTEM"; textSize = 9f; letterSpacing = 0.32f
            setTextColor(Color.parseColor("#5FA8C4")); setPadding(0, dp(2), 0, dp(14)) })
        root.addView(TextView(this).apply { text = "PEHLE SETUP — API VERIFY AUR SAARI PERMISSIONS KE BINA ENTRY NAHI"; textSize = 10f
            letterSpacing = 0.12f; setTextColor(Color.parseColor("#8FD8F2")); setPadding(0, 0, 0, dp(8)) })

        root.addView(TextView(this).apply { text = "GEMINI API KEY"; textSize = 8f; letterSpacing = 0.3f; setTextColor(Color.parseColor("#5FA8C4")) })
        keyBox = EditText(this).apply { hint = "API key yahan daalo"; setText(prefs.getString("key", "")); setSingleLine()
            textSize = 13f; setTextColor(Color.parseColor("#EAF9FF")); setHintTextColor(Color.parseColor("#5FA8C4"))
            background = panel(10, "#04121F", "#0E5B73"); setPadding(dp(10), dp(9), dp(10), dp(9))
            imeOptions = EditorInfo.IME_ACTION_DONE
            setOnEditorActionListener { _, _, _ -> verifyKey(); true } }
        root.addView(keyBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        val verifyBtn = Button(this).apply { text = "✅ API VERIFY KARO"; setTextColor(Color.WHITE); textSize = 14f
            typeface = Typeface.DEFAULT_BOLD; background = panel(12, "#0A3A56", "#19C8FF"); setOnClickListener { verifyKey() } }
        root.addView(verifyBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        setupHint = TextView(this).apply { textSize = 13f; setTextColor(Color.parseColor("#FFD9A0")); setPadding(0, dp(10), 0, dp(4)) }
        root.addView(setupHint)

        root.addView(TextView(this).apply { text = "CHECKLIST — JO BAAKI HO, USI LINE PAR TAP KARO"; textSize = 8f; letterSpacing = 0.25f
            setTextColor(Color.parseColor("#5FA8C4")); setPadding(0, dp(8), 0, dp(2)) })
        checkList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(checkList)

        enterBtn = Button(this).apply { text = "🚀 VAANI KHOLO"; setTextColor(Color.WHITE); textSize = 16f
            typeface = Typeface.DEFAULT_BOLD; background = panel(14, "#0A3A56", "#19C8FF")
            setOnClickListener { if (allChecks().all { it.second }) showDashboard() } }
        root.addView(enterBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        setupRoot = ScrollView(this).apply { background = bgGrad(); addView(root) }
    }

    private fun verifiedKey(): Boolean {
        val k = if (::keyBox.isInitialized) keyBox.text.toString().trim() else prefs.getString("key", "").orEmpty()
        return k.isNotEmpty() && prefs.getBoolean("key_verified", false) && prefs.getString("verified_key", "") == k
    }

    private fun allChecks(): List<Triple<String, Boolean, () -> Unit>> {
        val pm = getSystemService(PowerManager::class.java)
        return listOf(
            Triple("API key verify", verifiedKey()) { verifyKey() },
            Triple("Mic permission", checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2) },
            Triple("Meri awaaz enrolled", VoicePrint(this).enrolled()) { enroll() },
            Triple("Notification access", (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            Triple("Floating orb permission", Settings.canDrawOverlays(this)) { overlayPerm() },
            Triple("Battery unrestricted", pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) },
            Triple("Accessibility on", (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        )
    }

    private fun refreshSetup() {
        if (!::checkList.isInitialized) return
        val checks = allChecks()
        checkList.removeAllViews()
        for ((label, ok, action) in checks) {
            checkList.addView(TextView(this).apply {
                text = (if (ok) "✅  " else "⬜  ") + label + if (ok) "" else "   → tap karo"
                textSize = 15f; setTextColor(Color.parseColor(if (ok) "#9FE8B1" else "#DFF6FF"))
                background = panel(10, "#04121F", if (ok) "#1E7A46" else "#0E5B73")
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }
        val missing = checks.count { !it.second }
        enterBtn.isEnabled = missing == 0
        enterBtn.alpha = if (missing == 0) 1f else 0.45f
        enterBtn.text = if (missing == 0) "🚀 VAANI KHOLO" else "🚀 VAANI KHOLO  (abhi $missing cheez baaki)"
    }

    private fun verifyKey() {
        val key = keyBox.text.toString().trim()
        if (key.isEmpty()) { setupHint.text = "⚠ Pehle API key daalo."; return }
        prefs.edit().putString("key", key).putBoolean("key_verified", false).apply()
        setupHint.text = "⏳ Google se verify ho raha hai…"
        Thread {
            try {
                Gemini.ask(key, "hi", false)
                prefs.edit().putBoolean("key_verified", true).putString("verified_key", key).apply()
                runOnUiThread { setupHint.text = "✅ API verify ho gaya!"; refreshSetup() }
            } catch (e: Exception) {
                runOnUiThread { setupHint.text = "❌ Verify fail: ${e.message?.take(200)}"; refreshSetup() }
            }
        }.start()
    }

    // ---------- DASHBOARD (sirf conversation) ----------

    private fun buildDashboard() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(20), dp(14), dp(12)); background = bgGrad() }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply { text = "VAANI "; textSize = 17f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        header.addView(TextView(this).apply { text = "AI"; textSize = 17f; setTextColor(Color.parseColor("#19C8FF")); typeface = Typeface.DEFAULT_BOLD })
        header.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        batt = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#8FD8F2")) }
        header.addView(batt)
        header.addView(Button(this).apply { text = "🔑"; textSize = 13f; setTextColor(Color.parseColor("#DFF6FF"))
            background = panel(10, "#062238", "#12718F"); setOnClickListener { logout() } })
        root.addView(header)

        status = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = panel(22, "#062A40", "#19C8FF"); setPadding(dp(10), dp(9), dp(10), dp(9)) }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        wave = WaveView(this)
        root.addView(wave, LinearLayout.LayoutParams(-1, dp(22)).apply { topMargin = dp(4) })

        log = TextView(this).apply {
            textSize = 15f; setTextColor(Color.parseColor("#CDEFFF")); setPadding(dp(12), dp(10), dp(12), dp(10))
            movementMethod = ScrollingMovementMethod(); isVerticalScrollBarEnabled = true
            background = panel(12, "#03101C", "#0E5B73")
        }
        root.addView(log, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })

        val typed = EditText(this).apply { hint = "Type bhi kar sakte ho"; setSingleLine()
            setTextColor(Color.parseColor("#EAF9FF")); setHintTextColor(Color.parseColor("#5FA8C4"))
            background = panel(10, "#04121F", "#0E5B73"); setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnEditorActionListener { v, _, _ -> handle(v.text.toString()); v.text = ""; true } }
        root.addView(typed, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        toggle = Button(this).apply { setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            background = panel(22, "#0A3A56", "#19C8FF"); setOnClickListener { toggleMode() } }
        root.addView(toggle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        dashRoot = root; dashBuilt = true
    }

    private fun showDashboard() {
        if (!dashBuilt) buildDashboard()
        onDashboard = true
        setContentView(dashRoot)
        if (!greeted) { greeted = true; say("🤖 Namaste! Main Vaani hu. Hindi, मराठी, English ya Hinglish, jo bhi bolo.") }
        autoStart()
    }

    private fun logout() {
        prefs.edit().putBoolean("key_verified", false).apply()
        if (VaaniService.running) startService(Intent(this, VaaniService::class.java).setAction("STOP"))
        onDashboard = false
        setContentView(setupRoot); refreshSetup()
        setupHint.text = "🔑 Key dobara verify karke ghuso."
    }

    // ---------- shared logic ----------

    override fun onResume() { super.onResume(); if (onDashboard) autoStart() else refreshSetup() }
    override fun onPause() { if (::keyBox.isInitialized) prefs.edit().putString("key", keyBox.text.toString().trim()).apply(); super.onPause() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { if (onDashboard) autoStart() else refreshSetup() }

    private fun say(t: String, speak: Boolean = false) {
        if (onDashboard && ::log.isInitialized) runOnUiThread {
            log.append(t + "\n\n")
            if (log.text.length > 6000) log.text = log.text.takeLast(4000)   // keep memory flat over 24h
            log.layout?.let { l -> log.scrollTo(0, maxOf(0, l.getLineTop(log.lineCount) - log.height + log.paddingTop + log.paddingBottom)) }
        } else if (::setupHint.isInitialized) runOnUiThread { setupHint.text = t }
        if (speak) Speaker.speak(this, t)
    }

    private fun hint(t: String) { if (t != lastHint) { lastHint = t; say(t) } }

    private fun batteryPct(): Int {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (level >= 0) level * 100 / scale else -1
    }

    private fun refresh() { if (!onDashboard) return; runOnUiThread {
        status.text = if (VaaniService.running) "🟢 Hands-free ON, bas bolo" else "⚪ Hands-free band"
        toggle.text = if (VaaniService.running) "⏹ Hands-free band karo" else "▶ Hands-free chalu karo"
        if (::wave.isInitialized) wave.active = VaaniService.running
        val bp = batteryPct(); if (bp >= 0 && ::batt.isInitialized) batt.text = "🔋 $bp%"
    } }

    /** Dashboard par hi chalta hai: setup poora hue bina yahan koi nahi ghusta. */
    private fun autoStart() {
        if (!onDashboard) return
        refresh()
        if (VaaniService.running || prefs.getBoolean("manual_stop", false)) return
        when {
            prefs.getString("key", "").isNullOrEmpty() -> hint("👋 Pehle Gemini API key daalo.")
            !VoicePrint(this).enrolled() -> hint("🧬 Awaaz enrolled nahi hai — 🔑 se setup mein jaakar record karo.")
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED -> hint("🎙 Mic permission allow karo.")
            else -> { startForegroundService(Intent(this, VaaniService::class.java)); window.decorView.postDelayed({ refresh() }, 700) }
        }
    }

    private fun toggleMode() {
        if (VaaniService.running) { prefs.edit().putBoolean("manual_stop", true).apply()
            startService(Intent(this, VaaniService::class.java).setAction("STOP")); window.decorView.postDelayed({ refresh() }, 700) }
        else { prefs.edit().putBoolean("manual_stop", false).apply(); autoStart() }
    }

    private fun enroll() {
        val wasOn = VaaniService.running
        if (wasOn) startService(Intent(this, VaaniService::class.java).setAction("STOP"))
        window.decorView.postDelayed({
            say("🧬 12 second normal awaaz mein kuch bhi bolte raho…")
            VoicePrint.enroll(this) { m -> say(m); runOnUiThread {
                prefs.edit().putBoolean("manual_stop", false).apply()
                if (onDashboard) autoStart() else refreshSetup()
            } }
        }, if (wasOn) 900 else 0)
    }

    private fun overlayPerm() {
        if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        else say("🪟 Overlay permission pehle se hai.")
    }

    /** Typed fallback (REST). Spoken conversation goes through the service + Gemini Live. */
    private fun handle(text: String) {
        if (text.isBlank()) return
        val key = prefs.getString("key", "").orEmpty()
        if (key.isEmpty()) return say("Pehle Gemini API key daalo.")
        say("🧑 $text")
        Thread {
            try {
                val parts = Gemini.ask(key, text)
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("functionCall")) {
                        val f = p.getJSONObject("functionCall")
                        say("🤖 " + Actions.run(this, f.getString("name"), f.optJSONObject("args") ?: JSONObject()), true)
                    } else if (p.has("text")) say("🤖 " + p.getString("text"), true)
                }
            } catch (e: Exception) { say("⚠ ${e.message?.take(240)}") }
        }.start()
    }

    override fun onDestroy() { VaaniService.log = null; super.onDestroy() }
}
