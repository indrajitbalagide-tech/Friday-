plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.vaani.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.vaani.app"; minSdk = 26; targetSdk = 34; versionCode = 7; versionName = "1.3.2" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
