package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/*
 * FEATURE 12 — Security layer (v5.24: SIRF AWAAZ).
 *
 * App mein login sirf voice enrollment hai — fingerprint / PIN / pattern
 * ka koi rasta nahi. Risky kaam (payment, delete, auto-reply, PC shutdown,
 * screen agent) se pehle Vaani malik ki awaaz verify karti hai:
 * - VaaniService har baar jab VoicePrint.verify() sahi bataye, tab
 *   Security.markVoiceAuthenticated() bulata hai (session khulne par,
 *   pehli awaaz par aur session ke dauran har ~1.5 sec ki dobara-check par).
 * - Auth window: awaaz se confirm hone ke 5 minute tak risky kaam chal
 *   sakta hai (prefs "voice_auth_at"). 5 minute baad dobara bolna padega.
 * - Kabhi bhi password / PIN / OTP save nahi hota — sirf "kab awaaz se
 *   confirm hua" ka timestamp save hota hai (long).
 * - Fingerprint/PIN wala purana rasta (KeyguardManager confirm screen)
 *   v5.24 mein hata diya gaya — Security.requireAuth / authIntent /
 *   onAuthResult ab nahi hain.
 *
 * Voiceprint: GuestMode sirf VoicePrint.enrolled() / verify() ka natija
 * padhta hai. Voiceprint data (vp_center / vp_sd / vp_thr) pehle se hi app-
 * private SharedPreferences ("vaani", MODE_PRIVATE) mein hai — use kahin
 * aur copy / upload / export nahi kiya jata. Ye file voiceprint ko haath
 * nahi lagati.
 */

/** Risky actions ke liye sirf awaaz se confirm (voice enrollment). */
object Security {
    const val AUTH_REQUEST_CODE = 9001   // purana lock-screen code — ab istemal nahi hota (compat ke liye rakha hai)
    private const val AUTH_WINDOW_MS = 5 * 60 * 1000L  // 5 minute
    private const val KEY_VOICE_AUTH_AT = "voice_auth_at"

    /** Kaun se tool risky hain — in par confirm-first + auth dono lagte hain. */
    fun isRisky(toolName: String): Boolean = toolName.lowercase().trim() in setOf(
        // Payment / paise (aaj inme se kuch tools hain nahi, par naam aate hi gate lagega)
        "payment", "upi_pay", "send_money", "pay", "transfer",
        // Delete
        "files",            // sirf delete action par (gateRisky mein action bhi check hota hai)
        "delete",
        // Auto-reply: aapke naam se jawab jayenge
        "notifications",    // sirf enable_auto_reply action par
        // PC shutdown / control
        "pc",               // sirf shutdown/restart/sleep/run action par
        "screen_agent"      // phone par khud steps chalana
    )

    /** Is (tool + args) combo par auth chahiye ya nahi — action-level check. */
    fun needsAuth(toolName: String, args: JSONObject): Boolean {
        return when (toolName.lowercase().trim()) {
            "files" -> args.optString("action") == "delete"
            "notifications" -> args.optString("action") == "enable_auto_reply"
            "pc" -> args.optString("action") in setOf("shutdown", "restart", "sleep", "run")
            "payment", "upi_pay", "send_money", "pay", "transfer", "delete", "screen_agent" -> true
            else -> false
        }
    }

    /** Pichhle 5 minute mein awaaz se confirm hua ho to true. */
    fun isAuthenticated(c: Context): Boolean {
        val at = P.of(c).getLong(KEY_VOICE_AUTH_AT, 0L)
        return at > 0L && System.currentTimeMillis() - at < AUTH_WINDOW_MS
    }

    /** Awaaz verify hone par bulao — VaaniService ke verify-success points se.
     *  5 minute ki window shuru hoti hai. */
    fun markVoiceAuthenticated(c: Context) {
        P.of(c).edit().putLong(KEY_VOICE_AUTH_AT, System.currentTimeMillis()).apply()
    }

    /**
     * Tool dispatch ke andar ka gate: risky kaam ho aur pichhle 5 minute mein
     * auth na hua ho to proceed() chalaye bina Hinglish mein roko; warna
     * proceed() chalao aur uska result lautao. Ye Safety.Confirm (turn-based
     * ROKO) ki jagah nahi leta — dono lagte hain: pehle Confirm, phir auth.
     */
    fun gateRisky(c: Context, toolName: String, args: JSONObject, proceed: () -> String): String {
        if (!needsAuth(toolName, args)) return proceed()
        if (isAuthenticated(c)) return proceed()
        return "Pehle apni awaaz se confirm karo — kuch bolo, main tumhari awaaz pehchan lungi, phir dobara bolo. " +
            "Bina awaaz-confirm kiye ye kaam nahi karungi."
    }
}

/**
 * Guest Mode: malik ki awaaz match na kare (ya guest mode on ho) to sirf
 * basic tools. Guest ko kabhi nahi milta: messages, payments, personal data
 * (memory / call log / SMS / calendar / notifications), call (malik ke
 * contacts guest ke nahi hote — isiliye call bhi allowed list mein NAHI hai).
 */
object GuestMode {
    /** Guest mode on hai ya nahi (prefs "guest_mode"). */
    fun isGuest(c: Context): Boolean = P.of(c).getBoolean("guest_mode", false)

    fun setGuest(c: Context, on: Boolean): String {
        P.of(c).edit().putBoolean("guest_mode", on).apply()
        return if (on) "Guest mode on. Ab sirf basic cheezein chalengi — time, mausam, app kholna, search. " +
            "Messages, payments aur personal data band hai."
        else "Guest mode off. Malik wapas aa gaya — saare features khul gaye."
    }

    /**
     * Voice-match ke natije se guest mode lagao: VoicePrint.verify() false
     * aaye to guest on kar do. frames yahan nahi aate — VaaniService ke
     * tryVerify() wale flow se bulao (snippet README/report mein).
     * enrolled() false ho (awaaz kabhi enroll hi nahi hui) to guest force
     * mat karo — pehli baar setup chal raha hoga.
     */
    fun applyVoiceResult(c: Context, voiceMatched: Boolean): String? {
        val vp = VoicePrint(c)
        if (!vp.enrolled()) return null  // enroll hi nahi hua — guest nahi, setup baaki hai
        return if (voiceMatched) {
            if (isGuest(c)) setGuest(c, false) else null
        } else {
            if (!isGuest(c)) setGuest(c, true) else "Guest mode pehle se on hai."
        }
    }

    /** Guest ko allowed basic tools (sirf ye — baaki sab par checkGuest rokega). */
    fun allowedToolsGuest(): Set<String> = setOf(
        "weather",      // mausam
        "open_app",     // app kholna
        "web_search",   // search
        "web_answer",   // taaza jaankari
        "look"          // camera/screen dekhna (screen par password/PIN dikhe to Vision khud rukta hai)
        // NOTE: "call" jaan-boojhkar NAHI hai — guest ke paas malik ke contacts nahi hote.
        // "time" ka alag tool nahi hai; waqt system prompt mein pehle se aata hai (Brain.system).
    )

    /**
     * Har tool call se pehle bulao (Actions.run / Gemini dispatch mein — snippet
     * README/report mein). Guest ho aur tool allowed list mein na ho to
     * Hinglish refusal lautata hai; warna null (chalne do).
     */
    fun checkGuest(c: Context, toolName: String): String? {
        if (!isGuest(c)) return null
        if (toolName.lowercase().trim() in allowedToolsGuest()) return null
        return "Guest mode on hai — ye kaam sirf malik ke liye hai. " +
            "Messages, payments, calls, personal data aur settings guest ko nahi milte. " +
            "Malik apni awaaz se bolkar guest mode band kar sakta hai."
    }
}

/** Gemini tools: security_auth + guest_mode. */
object SecurityTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("security_auth", "Risky kaam (payment, delete, auto-reply, PC shutdown) se pehle apni awaaz se confirm karo.",
            mapOf("action" to sp("start | status"), "reason" to sp("kis kaam ke liye confirm kar rahe ho (optional)")),
            listOf("action")),
        fn("guest_mode", "Guest mode on/off karo ya status dekho. Guest ko sirf basic tools milte hain.",
            mapOf("action" to sp("on | off | status")), listOf("action"))
    )

    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "security_auth" -> when (a.optString("action")) {
            "status" -> if (Security.isAuthenticated(c))
                "Auth abhi valid hai (pichhle 5 minute mein awaaz se confirm hua tha)."
            else
                "Abhi auth nahi hua hai. Risky kaam se pehle apni awaaz se confirm karna padega — kuch bolo, jaise 'haan, confirm karo'."
            // v5.24 — "start": ab koi lock screen nahi khulti. Awaaz se confirm karne ke liye
            // bas bolna hai — VaaniService har verify hui awaaz par markVoiceAuthenticated()
            // bulata hai; uske baad 5 minute tak risky kaam chalenge.
            "start" -> {
                if (Security.isAuthenticated(c))
                    "Awaaz se confirm ho chuka hai — abhi risky kaam kar sakte ho (5 minute ki window)."
                else
                    "Awaaz se confirm karne ke liye kuch bolo — jaise 'haan, confirm karo'. " +
                        "Tumhari awaaz verify hote hi 5 minute ke liye auth valid ho jayega, phir dobara bolo."
            }
            else -> "security_auth: action 'start' ya 'status' do."
        }
        "guest_mode" -> when (a.optString("action")) {
            "on" -> GuestMode.setGuest(c, true)
            "off" -> GuestMode.setGuest(c, false)
            "status" -> if (GuestMode.isGuest(c))
                "Guest mode ON hai — sirf basic tools (mausam, app kholna, search) chalenge."
            else
                "Guest mode OFF hai — malik mode mein ho."
            else -> "guest_mode: action 'on', 'off' ya 'status' do."
        }
        else -> null
    }
}
