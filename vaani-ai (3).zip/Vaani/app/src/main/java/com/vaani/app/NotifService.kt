package com.vaani.app

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Messaging notifications:
 * - Naya message aaye to sirf BATATA hai ("X ka message aaya hai") - poora content khud nahi padhta.
 * - Auto-reply ON ho to jawab soch kar pehle POOCHTA hai; bhejta sirf tab hai jab user haan bole
 *   (pending_reply tool se, Actions ke through).
 */
class NotifService : NotificationListenerService() {
    companion object {
        val recent: MutableList<Pair<String, String>> = java.util.Collections.synchronizedList(mutableListOf())
        private val lastReply = HashMap<String, Long>()
        private val APPS = setOf("com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
            "com.instagram.android", "com.google.android.apps.messaging")

        // Permission wala pending jawab - user ke haan bolne ka intezaar karta hai.
        @Volatile var pendingSender: String? = null
        @Volatile var pendingDraft: String? = null
        @Volatile private var pendingAction: Notification.Action? = null
        @Volatile private var pendingCtx: Context? = null

        /** User ne faisla diya: send=true to pending jawab bhej do, warna gira do. */
        fun respondPending(send: Boolean): String {
            val action = pendingAction; val sender = pendingSender; val draft = pendingDraft; val ctx = pendingCtx
            pendingAction = null; pendingSender = null; pendingDraft = null; pendingCtx = null
            if (sender == null || draft == null) return "Koi jawab pending nahi hai."
            if (!send) return "$sender ko jawab nahi bheja."
            if (action == null || ctx == null) return "Us message ka reply button nahi mila, bhej nahi paya."
            return try {
                val ri = action.remoteInputs[0]; val intent = Intent(); val b = Bundle()
                b.putCharSequence(ri.resultKey, draft)
                RemoteInput.addResultsToIntent(action.remoteInputs, intent, b)
                action.actionIntent.send(ctx, 0, intent)
                "$sender ko jawab bhej diya: \"$draft\""
            } catch (e: Exception) { "Jawab bhejne mein dikkat: ${e.message?.take(60)}" }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in APPS) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        recent.add(title to text); if (recent.size > 30) recent.removeAt(0)

        // 1) Sirf aane ki khabar do - content khud mat padho.
        VaaniService.log?.invoke("📩 $title ka message aaya hai")
        Speaker.speak(this, "$title ka message aaya hai")

        // 2) Auto-reply: jawab socho, lekin bhejne se pehle user se poochho.
        val p = getSharedPreferences("vaani", MODE_PRIVATE)
        if (!p.getBoolean("auto", false)) return
        val key = p.getString("key", "").orEmpty(); if (key.isEmpty()) return
        val action = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        val now = System.currentTimeMillis()
        synchronized(lastReply) { if (now - (lastReply[title] ?: 0L) < 60_000) return; lastReply[title] = now }

        Thread {
            try {
                // useTools=false: incoming text can never trigger phone actions.
                val parts = Gemini.ask(key, "Mere dost $title ka message: \"$text\". Meri taraf se ek chhota friendly " +
                    "Hinglish jawab likho. Sirf jawab ka text do.", false)
                val reply = (0 until parts.length()).mapNotNull { parts.getJSONObject(it).optString("text").ifEmpty { null } }
                    .joinToString(" ").trim()
                if (reply.isEmpty()) return@Thread
                pendingSender = title; pendingDraft = reply; pendingAction = action; pendingCtx = applicationContext
                VaaniService.log?.invoke("💬 $title ke liye jawab socha hai: \"$reply\" — bolna hai to \"bhej do\" bolo")
                Speaker.speak(this, "$title ko ye jawab socha hai: $reply. Bhej dun?")
            } catch (_: Exception) {}
        }.start()
    }
}
