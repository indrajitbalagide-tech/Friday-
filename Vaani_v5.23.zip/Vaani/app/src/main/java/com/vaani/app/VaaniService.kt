package com.vaani.app

import ai.picovoice.porcupine.Porcupine
import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.telephony.TelephonyManager
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Always-on foreground service.
 * Gate: (wake word "Vaani", agar Picovoice key + custom .ppn file ho) AUR (aapki awaaz ka match) -> tabhi Gemini Live session khulta hai.
 * Wake word na ho to sirf voice-match gate. Internet na ho to offline basic commands.
 * Barge-in: Vaani bol rahi ho tab bhi zor se bologe to wo ruk jaati hai.
 */
class VaaniService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var forceStart = false
        var log: ((String) -> Unit)? = null
        /** Live baat-cheet ka adhura text chat box mein dikhane ke liye: ("user"|"bot", ab tak ka text; "" = hatao). */
        var partial: ((String, String) -> Unit)? = null
    }

    @Volatile private var stop = false
    @Volatile private var live: LiveClient? = null
    private var lastVoice = 0L
    private var lastListenerWarn = 0L
    private lateinit var overlay: Overlay
    private var wake: PowerManager.WakeLock? = null
    private var porcupine: Porcupine? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun say(t: String) { log?.invoke(t) }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stop = true; stopSelf(); return START_NOT_STICKY }
        if (running) return START_STICKY
        Gemini.ensureKey(this)   // v5.10: inbuilt key — service boot par bhi key khali na rahe.
        if (callRx == null) { val rx = CallReceiver(); callRx = rx
            try { registerReceiver(rx, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)) } catch (e: Exception) {} }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vaani", "Vaani 24h", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0, Intent(this, VaaniService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val openPi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "vaani").setContentTitle("Vaani sun rahi hai").setContentText("Sirf aapki awaaz par jaagti hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true)
            .setContentIntent(openPi).setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Stop", stopPi).build()).build()
        if (Build.VERSION.SDK_INT >= 29) {
            // Camera/location type tabhi jodo jab permission ho - warna Android service hi start nahi hone deta.
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (Perm.has(this, Manifest.permission.CAMERA)) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (Perm.has(this, Manifest.permission.ACCESS_FINE_LOCATION)) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            startForeground(1, n, type)
        } else startForeground(1, n)
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vaani:mic").also { it.acquire() }
        running = true; stop = false
        overlay = Overlay(this); overlay.show { forceStart = true }; overlay.state(1)
        Thread { loop() }.start()
        return START_STICKY
    }

    private fun startLive() {
        val key = P.of(this).getString("key", "").orEmpty()
        if (key.isEmpty()) return say("API key nahi mili.")
        Speaker.stop()   // koi notification/jawab bol raha ho to ruk jaye - ab user baat karega
        live = LiveClient(this, key) { say(it) }.also { it.connect(); AgentStatus.brain = "Live baat ho rahi hai" }
        lastVoice = System.currentTimeMillis()
    }

    /** Wake word engine (Picovoice). Wake word sirf "Vaani" hai - uske liye custom keyword file
     *  assets/vaani_wake.ppn chahiye (Picovoice Console par free banti hai). "Jarvis" wala built-in
     *  keyword user ke kehne par HATA diya gaya hai - file na ho to wake word band, sirf awaaz-match. */
    private fun initWake() {
        val k = P.of(this).getString("pv_key", "").orEmpty().trim(); if (k.isEmpty()) return
        try {
            if (assets.list("")?.contains("vaani_wake.ppn") == true) {
                val f = File(filesDir, "vaani_wake.ppn")
                assets.open("vaani_wake.ppn").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                porcupine = Porcupine.Builder().setAccessKey(k).setKeywordPath(f.absolutePath).build(this)
                say("🟢 Wake word ON — \"Vaani\" bolo.")
            } else {
                porcupine = null
                say("ℹ️ Wake word \"Vaani\" ke liye custom file (vaani_wake.ppn) app mein nahi hai — Jarvis wala purana rasta band hai. Ab sirf awaaz-match chalega.")
            }
        } catch (e: Exception) { porcupine = null; say("Wake word chalu nahi hua (${e.message?.take(80)}) - sirf awaaz-match mode chalega.") }
    }

    private fun loop() {
        initWake()
        Speaker.warmCache(this)   // offline ke liye kuch jumle Gemini awaaz mein pehle se bana lo
        val pp = porcupine
        // v5.22 — openWakeWord fallback ("Hey Jarvis", bina signup, on-device, offline).
        // Porcupine (.ppn + key) ho to wahi jeetega; OWW us waqt hi banta hai jab pp null ho.
        val oww: OpenWakeWord? = if (pp == null && P.of(this).getBoolean("oww_on", true)) try {
            OpenWakeWord(this).let { if (it.ready) it else null }
        } catch (_: Exception) { null } else null
        val fr = 320
        val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, fr * 40))
        // Echo cancel + noise suppress: barge-in ke liye zaroori.
        val aecOk = AcousticEchoCanceler.isAvailable()
        try { if (aecOk) AcousticEchoCanceler.create(rec.audioSessionId)?.enabled = true } catch (_: Exception) {}
        try { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId)?.enabled = true } catch (_: Exception) {}
        val bargeIn = P.of(this).getBoolean("bargein", aecOk)
        val wakeOnly = (pp != null || oww != null) && P.of(this).getBoolean("wake_only", false)
        rec.startRecording()
        val vp = VoicePrint(this)
        // v5.11 VOICE LOCK: session khulne ke baad bhi awaaz dobara check hoti hai.
        // ownerVerified=false = explicit open (orb tap / call / car) — pehli awaaz verify hone tak audio Live ko nahi jata.
        var ownerVerified = false
        val verifyBuf = ArrayList<ShortArray>()
        var verifyRunning = false
        val buf = ShortArray(fr)
        val pre = java.util.ArrayDeque<ShortArray>(); val utter = ArrayList<ShortArray>(); val batch = ArrayList<ShortArray>()
        val ring = java.util.ArrayDeque<ShortArray>(); val bargeBuf = ArrayList<ShortArray>()
        var lastUtter: List<ShortArray> = emptyList()
        var noise = 200.0; var inSpeech = false; var quiet = 0; var checked = false; var shown = -1
        val wf = ShortArray(pp?.frameLength ?: 512); var wpos = 0
        var lastWake = 0L; var okAt = 0L; var bargeHits = 0
        var lastTick = 0L; var tickBusy = false
        say("24h mode chalu. " + if (pp != null) "\"Vaani\" bolo..." else if (oww != null) "\"Hey Jarvis\" bolo (on-device)..." else "Aapki awaaz ka intezaar…")

        fun offlineTurn() {
            rec.stop()
            val latch = CountDownLatch(1)
            Handler(Looper.getMainLooper()).post { Offline.listen(this) { latch.countDown() } }
            latch.await(15, TimeUnit.SECONDS)
            if (!stop) rec.startRecording()
        }

        // explicit = aapne khud jagaya (orb tap / Picovoice "Vaani" / call / car): ~12 sec bina "Hey Vaani" ke bhi suno.
        // explicit=false = sirf awaaz-match: LiveClient transcript mein "Vaani" dhoondhega, na mile to chup + band.
        fun openGate(initial: List<ShortArray>, explicit: Boolean) {
            lastWake = 0; okAt = 0
            // v5.17 VOICE LOCK FAIL-CLOSED: enrolled na ho to explicit open bhi verified NAHI —
            // pehli awaaz verify hone tak Live ko audio nahi jata. (Pehle `|| !vp.enrolled()` tha,
            // jisse bina enroll kiye koi bhi orb tap karke Vaani chala leta tha.)
            ownerVerified = !explicit
            verifyBuf.clear()
            if (explicit) WakeGate.openFollowUp(12_000)
            if (Net.online(this)) { startLive(); if (initial.isNotEmpty()) live?.sendAudio(ArrayList(initial)) }
            else if (explicit || !WakeGate.strict(this)) offlineTurn()
            else if (oww != null) say("ℹ️ Offline hoon — 'Hey Jarvis' bolo ya orb tap karo.")
            else say("ℹ️ Offline mein 'Hey Vaani' pehchanne ke liye Picovoice wake word chahiye — abhi chup hoon (orb tap karo).")
        }

        fun maybeOpen() {
            if (lastWake == 0L) return
            if (wakeOnly) { openGate(ArrayList(ring), true); return }
            if (okAt != 0L && Math.abs(okAt - lastWake) < 6000) openGate(lastUtter, true)
        }

        fun tryVerify() {
            checked = true
            // v5.17: enrolled nahi hai to "match nahi hui" kehkar ignore karne ke bajay seedha enroll karne ko bolo.
            if (!vp.enrolled()) {
                say("🔒 Awaaz enrolled nahi hai — pehle apni awaaz enroll karo. Settings mein 'Meri awaaz dobara enroll karo' dabao, phir main sirf tumhari awaaz sunungi.")
                utter.clear()
                return
            }
            if (vp.verify(utter)) {
                say("✅ Aapki awaaz pehchani")
                // v5.0 Guest mode: malik ki awaaz mili to guest mode off ho jata hai.
                GuestMode.applyVoiceResult(this, true)?.let { say(it) }
                AgentStatus.stt = "Command suna • ${AgentStatus.time()}"; AgentStatus.sttAt = System.currentTimeMillis()
                lastUtter = ArrayList(utter); okAt = System.currentTimeMillis()
                PhoneLock.ownerOkAt = okAt   // v5.8: voice-unlock sirf malik ki verified awaaz ke baad
                if (pp == null) openGate(lastUtter, false) else maybeOpen()
            } else {
                say("🚫 Awaaz match nahi hui (score ${"%.1f".format(VoicePrint.lastScore)}, limit ${"%.1f".format(VoicePrint.lastLimit)}) — ignore kiya.")
                // v5.0 Guest mode: awaaz match na ho aur awaaz enroll hui ho to guest mode on.
                GuestMode.applyVoiceResult(this, false)?.let { say(it) }
            }
            utter.clear()
        }

        while (!stop) {
            val n = rec.read(buf, 0, fr); if (n <= 0) continue
            val f = buf.copyOf(n)
            var s = 0.0; for (x in f) s += x * x.toDouble()
            val rms = Math.sqrt(s / n)
            val voice = rms > maxOf(noise * 2.5, 350.0)
            if (!voice) noise = 0.98 * noise + 0.02 * rms
            val now = System.currentTimeMillis()

            // Proactive kaam (briefing, alerts, jagah) alag thread mein, har ~30 sec
            if (now - lastTick > 30_000 && !tickBusy) {
                lastTick = now; tickBusy = true
                Thread { try {
                    Proactive.tick(this)
                    Agents.tick(this)   // v5.18 — 20 agents ke time/battery/car triggers
                    // v5.11 AUTO-UPDATE: naya version ho to khud download karo (6 ghante mein ek baar, Live session band ho tabhi).
                    // v5.21 FIX: background service se install screen nahi khulti (Android block karta hai) — isliye
                    // service sirf CHECK + DownloadManager download karti hai; install notification/app-open se hota hai.
                    // NOTE: Android normal app ko bina user ke chup-chaap update nahi karne deta — install screen par ek baar Install dabana hoga.
                    // v5.14: update URL inbuilt hai (UpdateChecker.DEFAULT_UPDATE_URL), isliye Settings check ki zarurat nahi.
                    // v5.21: failed check 30 minute mein dobara try hota hai (pehle 6 ghante ka gate fail par bhi atak jata tha).
                    if (live == null && P.of(this).getBoolean("auto_update", true)) {
                        val gap = if (UpdateChecker.lastError(this).isNotBlank()) 30 * 60_000L else 6 * 3600_000L
                        if (now - P.of(this).getLong("update_auto_last_try", 0L) > gap) {
                            val r = UpdateChecker.check(this)
                            P.of(this).edit().putLong("update_auto_last_try", now).apply()
                            if (r.startsWith("Naya version")) { say("⬆ $r Download kar rahi hoon."); UpdateChecker.startDownload(this) }
                        }
                    }
                    // v5.3 listener watchdog: notification access band ho to ghante mein ek baar bolo.
                    // Access ON hai par listener juda nahi (battery-kill/update ke baad) -> dobara bind karwao.
                    if (NotifService.listenerOn(this) && P.of(this).getString("notif_listener_on", "") != "true") {
                        try { android.service.notification.NotificationListenerService.requestRebind(
                            android.content.ComponentName(this, NotifService::class.java)) } catch (_: Exception) {}
                    }
                    if (!NotifService.listenerOn(this) && now - lastListenerWarn > 3_600_000) {
                        lastListenerWarn = now
                        say("⚠ Notification access band hai — Settings mein Vaani ko notification access do, warna notifications bol nahi paungi.")
                    }
                } finally { tickBusy = false } }.start()
            }

            // Wake word engine har frame dekhta hai (sasta hai); kaam tabhi karta hai jab session band ho.
            var wakeHit = false
            if (pp != null) {
                ring.addLast(f); if (ring.size > 40) ring.removeFirst()
                for (sm in f) { wf[wpos++] = sm
                    if (wpos == wf.size) { wpos = 0; try { if (pp.process(wf) >= 0) wakeHit = true } catch (_: Exception) {} } }
            }
            // v5.22 — openWakeWord ("Hey Jarvis") fallback.
            if (!wakeHit && oww != null) {
                try { if (oww.process(f)) wakeHit = true } catch (_: Exception) {}
            }

            val l = live
            if (l != null) {
                if (l.closed) { live = null; ownerVerified = false; verifyBuf.clear(); continue }
                if (voice) lastVoice = now
                if (l.busyTools > 0) lastVoice = now   // lambe tool ke dauran session zinda rakho
                val speaking = now < l.speakingUntil
                val st = if (speaking) 2 else 1
                if (st != shown) { shown = st; overlay.state(st) }
                if (!speaking && now - lastVoice > 15000) { l.close(); live = null; ownerVerified = false; verifyBuf.clear(); shown = 1; overlay.state(1); AgentStatus.brain = "Intezaar mein"; say("Session band, intezaar…"); continue }
                var send = true
                if (speaking) {
                    // Barge-in: bahut zor ki awaaz lagatar ~120ms -> Vaani ko roko, user ki baat bhejo
                    if (bargeIn && rms > maxOf(noise * 6.0, 2500.0)) {
                        bargeBuf.add(f)
                        if (++bargeHits >= 6) { l.interrupt(); batch.addAll(bargeBuf); bargeBuf.clear(); bargeHits = 0; lastVoice = now }
                        else send = false
                    } else { bargeHits = 0; bargeBuf.clear(); send = false }
                } else { bargeHits = 0; bargeBuf.clear() }
                if (!send) { if (bargeHits == 0) batch.clear(); continue }
                batch.add(f); if (batch.size >= 5) {
                    val chunk = ArrayList(batch); batch.clear()
                    if (!ownerVerified) {
                        // v5.11: explicit open ke baad pehli awaaz verify hone tak audio roko — kisi aur ki awaaz Live tak na pahunche.
                        verifyBuf.addAll(chunk)
                        if (verifyBuf.size >= 75 && !verifyRunning) {
                            val buf = ArrayList(verifyBuf); verifyBuf.clear()
                            verifyRunning = true
                            Thread {
                                // v5.17 FAIL-CLOSED: verify() enrolled na hone par khud false deta hai —
                                // `else true` wala escape hataya gaya (wo bina enroll kiye kisi ko bhi andar aane deta tha).
                                val ok = vp.verify(buf)
                                verifyRunning = false
                                if (ok) { ownerVerified = true; live?.sendAudio(buf) }
                                else {
                                    say("🚫 Ye awaaz aapki nahi hai — session band kar diya.")
                                    GuestMode.applyVoiceResult(this, false)
                                    live?.close(); live = null; ownerVerified = false
                                }
                            }.start()
                        }
                    } else {
                        l.sendAudio(chunk)
                        // v5.17: session ke dauran har ~1.5 sec ki boli hui awaaz dobara verify karo —
                        // beech mein koi aur bolne lage to session turant band. (Pehle ~3 sec tha —
                        // chhota command uske beech mein slip ho jata tha.)
                        if (vp.enrolled()) {
                            verifyBuf.addAll(chunk)
                            if (verifyBuf.size >= 75 && !verifyRunning) {
                                val buf = ArrayList(verifyBuf); verifyBuf.clear()
                                verifyRunning = true
                                Thread {
                                    val ok = vp.verify(buf)
                                    verifyRunning = false
                                    if (!ok) {
                                        say("🚫 Ye awaaz aapki nahi hai — session band kar diya.")
                                        GuestMode.applyVoiceResult(this, false)
                                        live?.close(); live = null; ownerVerified = false
                                    }
                                }.start()
                            }
                        }
                    }
                }
                continue
            }
            if (shown != 1) { shown = 1; overlay.state(1) }
            if (forceStart) { forceStart = false; openGate(ArrayList(ring), true); continue }
            if (wakeHit) { lastWake = now; say("🎙 Wake word suna"); maybeOpen(); if (live != null) continue }

            if (wakeOnly) continue   // sirf wake word mode: awaaz-match pipeline band

            if (voice) {
                quiet = 0
                if (!inSpeech) { inSpeech = true; checked = false; utter.clear(); utter.addAll(pre) }
                if (!checked) { utter.add(f); if (utter.size >= 75) tryVerify() }
            } else {
                // v5.11: chhota "Hey Vaani" (~0.5 sec) bhi verify ho — pehle 40 frames (0.8s) chahiye the, isliye chhota wake miss hota tha.
                if (inSpeech && ++quiet > 40) { if (!checked && utter.size >= 25) tryVerify(); inSpeech = false; checked = false; utter.clear() }
                pre.addLast(f); if (pre.size > 15) pre.removeFirst()
            }
        }
        try { rec.stop() } catch (_: Exception) {}
        rec.release()
        try { pp?.delete() } catch (_: Exception) {}
    }

    private var callRx: CallReceiver? = null

    override fun onDestroy() {
        callRx?.let { try { unregisterReceiver(it) } catch (e: Exception) {} }; callRx = null
        stop = true; running = false
        live?.close(); if (::overlay.isInitialized) overlay.hide(); wake?.let { if (it.isHeld) it.release() }
        say("24h mode band."); super.onDestroy()
    }
}
