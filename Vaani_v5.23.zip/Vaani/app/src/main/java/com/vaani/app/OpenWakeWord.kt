package com.vaani.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import java.io.File
import java.nio.FloatBuffer
import java.util.ArrayDeque

/**
 * v5.22 — openWakeWord (bina signup, on-device, offline, Apache-2.0 code).
 *
 * 3 ONNX models (openWakeWord v0.5.1, assets/ mein, ~3.6 MB):
 *   melspectrogram.onnx -> embedding_model.onnx -> hey_jarvis_v0.1.onnx (classifier)
 * Pipeline (openWakeWord model.py jaisa, yahan Python mein verify kiya):
 *   16kHz mono PCM16 -> 1280-sample chunk (80ms) -> melspec (5 frames x 32 mel)
 *   -> (v/10)+2 -> 76-frame window (step 8) -> embedding (96-d)
 *   -> 16 embeddings -> classifier -> score [0,1]. Threshold 0.5.
 * Python validation (yahi models, yahi pipeline): 10s silence max 0.000005,
 * white noise 0.000017, 440Hz tone 0.000030 — threshold 0.5 se bahut neeche,
 * matlab false trigger nahi. Positive test ("Hey Jarvis" bolne par) sirf
 * asli phone par ho sakta hai — is machine par koi "hey jarvis" recording nahi hai.
 * Ready-made classifier sirf "hey_jarvis" ka hai — custom "Vaani" model phase 2 hai
 * (uske liye user ki recordings se train karna hoga; classifier file hi badlegi).
 * Porcupine (.ppn + key) ho to wahi jeetega — OWW uska fallback hai.
 * Models CC BY-NC-SA 4.0 (non-commercial) — private app ke liye theek hai.
 * Pehla detection ~3.1 sec ke audio context ke baad hota hai (warm-up).
 */
class OpenWakeWord(ctx: Context) {
    var ready = false
        private set
    var lastScore = 0f
        private set
    var threshold = 0.5f

    private val env: OrtEnvironment
    private val mel: OrtSession
    private val emb: OrtSession
    private val clf: OrtSession

    private val melBuf = ArrayDeque<FloatArray>()   // 32-float mel frames
    private val embBuf = ArrayDeque<FloatArray>()   // 96-float embeddings
    private val acc = ShortArray(1280)
    private var accPos = 0

    init {
        val dir = File(ctx.filesDir, "oww").apply { mkdirs() }
        val melFile = copyAsset(ctx, "melspectrogram.onnx", File(dir, "melspectrogram.onnx"))
        val embFile = copyAsset(ctx, "embedding_model.onnx", File(dir, "embedding_model.onnx"))
        val clfFile = copyAsset(ctx, "hey_jarvis_v0.1.onnx", File(dir, "hey_jarvis_v0.1.onnx"))
        env = OrtEnvironment.getEnvironment()
        mel = env.createSession(melFile.absolutePath)
        emb = env.createSession(embFile.absolutePath)
        clf = env.createSession(clfFile.absolutePath)
        ready = true
    }

    private fun copyAsset(ctx: Context, name: String, dest: File): File {
        if (!dest.exists() || dest.length() < 10_000) {
            ctx.assets.open(name).use { inp -> dest.outputStream().use { out -> inp.copyTo(out) } }
        }
        return dest
    }

    /** VaaniService loop se 320-sample frame do — true = "Hey Jarvis" suna. */
    fun process(frame: ShortArray): Boolean {
        if (!ready) return false
        for (s in frame) {
            acc[accPos++] = s
            if (accPos == 1280) { accPos = 0; if (processChunk(acc)) return true }
        }
        return false
    }

    private fun processChunk(chunk: ShortArray): Boolean {
        // int16 -> float32 [-1, 1]
        val input = FloatBuffer.allocate(1280)
        for (s in chunk) input.put(s / 32768f)
        input.rewind()
        // Stage 1: melspec -> 5 frames x 32 mel
        val melVals = FloatArray(5 * 32)
        OnnxTensor.createTensor(env, input, longArrayOf(1, 1280)).use { t ->
            mel.run(mapOf("input" to t)).use { res ->
                val buf = (res[0] as OnnxTensor).floatBuffer
                val tmp = FloatArray(buf.remaining()); buf.get(tmp)
                tmp.copyInto(melVals, 0, 0, minOf(tmp.size, melVals.size))
            }
        }
        for (r in 0 until 5) {
            val row = FloatArray(32) { (melVals[r * 32 + it] / 10f) + 2f }
            melBuf.addLast(row)
        }
        // Stage 2: 76-frame window (step 8) -> 96-d embedding
        while (melBuf.size >= 76) {
            val win = FloatBuffer.allocate(76 * 32)
            val it = melBuf.iterator()
            var n = 0
            while (it.hasNext() && n < 76) { val row = it.next(); for (v in row) win.put(v); n++ }
            win.rewind()
            val embVals = FloatArray(96)
            OnnxTensor.createTensor(env, win, longArrayOf(1, 76, 32, 1)).use { t ->
                emb.run(mapOf("input_1" to t)).use { res ->
                    val buf = (res[0] as OnnxTensor).floatBuffer
                    val tmp = FloatArray(buf.remaining()); buf.get(tmp)
                    tmp.copyInto(embVals, 0, 0, minOf(tmp.size, 96))
                }
            }
            embBuf.addLast(embVals)
            repeat(8) { melBuf.removeFirst() }
        }
        // Stage 3: 16 embeddings -> classifier score
        while (embBuf.size >= 16) {
            val x = FloatBuffer.allocate(16 * 96)
            val it = embBuf.iterator()
            var n = 0
            while (it.hasNext() && n < 16) { val e = it.next(); for (v in e) x.put(v); n++ }
            x.rewind()
            var score = 0f
            OnnxTensor.createTensor(env, x, longArrayOf(1, 16, 96)).use { t ->
                clf.run(mapOf("x.1" to t)).use { res ->
                    val buf = (res[0] as OnnxTensor).floatBuffer
                    if (buf.remaining() > 0) score = buf.get(0)
                }
            }
            lastScore = score
            embBuf.removeFirst()
            if (score >= threshold) { melBuf.clear(); embBuf.clear(); return true }
        }
        return false
    }

    fun close() {
        try { mel.close() } catch (_: Exception) {}
        try { emb.close() } catch (_: Exception) {}
        try { clf.close() } catch (_: Exception) {}
    }
}
