package com.friday.assistant.data

import android.content.Context

/** FRIDAY's long-term memory of user facts (IRIS registry: save_core_memory,
 *  access_core_memory). Facts are kept only on this device, in plain
 *  SharedPreferences, and only when the user explicitly asks to remember. */
object FridayMemory {

    private const val PREFS = "friday_facts"
    private const val KEY_FACTS = "facts"

    fun save(context: Context, fact: String): String {
        val clean = fact.trim()
        if (clean.isBlank()) return "Kya yaad rakhna hai, woh batao."
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val facts = prefs.getStringSet(KEY_FACTS, emptySet())!!.toMutableSet()
        facts.add(clean)
        prefs.edit().putStringSet(KEY_FACTS, facts).apply()
        return "Yaad kar liya: $clean"
    }

    fun recall(context: Context, query: String): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val facts = prefs.getStringSet(KEY_FACTS, emptySet())!!.toList().sorted()
        if (facts.isEmpty()) return "Abhi tak tumne mujhe kuch yaad rakhne ko nahi kaha."
        val q = query.lowercase()
        val words = q.split(Regex("\\W+")).filter { it.length > 2 }
        val hits = if (words.isEmpty()) facts else facts.filter { f ->
            words.any { w -> f.lowercase().contains(w) }
        }
        val list = if (hits.isEmpty()) facts else hits
        return "Ye yaad hai mujhe: " + list.joinToString(". ")
    }
}
