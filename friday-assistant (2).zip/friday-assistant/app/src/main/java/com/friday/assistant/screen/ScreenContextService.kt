package com.friday.assistant.screen

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Read-only screen awareness. When the user asks "what's on my screen?" or
 * "help me with this", FRIDAY summarises the visible text of the foreground
 * app and hands it to the model as context. It never performs gestures and
 * never captures passwords (password fields are skipped by design).
 */
class ScreenContextService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Context is pulled on demand; no event processing needed.
    }

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    fun currentScreenSummary(maxChars: Int = 1800): String {
        val root = rootInActiveWindow ?: return "I can't see the screen right now."
        val appLabel = try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(root.packageName?.toString() ?: "", 0)
            ).toString()
        } catch (_: Exception) {
            root.packageName?.toString() ?: "unknown app"
        }
        val texts = ArrayList<String>()
        collectText(root, texts, 0)
        val body = texts.distinct().joinToString(separator = " · ").take(maxChars)
        return if (body.isBlank()) "You're in $appLabel, but there's no readable text on screen."
        else "You're in $appLabel. On screen: $body"
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 12 || out.size > 120) return
        if (!node.isPassword) {
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { out.add(it) }
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { out.add(it) }
        }
        for (i in 0 until node.childCount) {
            collectText(node.getChild(i), out, depth + 1)
        }
    }

    companion object {
        @Volatile var instance: ScreenContextService? = null
            private set

        fun summary(): String =
            instance?.currentScreenSummary()
                ?: "Screen awareness is off. Enable FRIDAY in Settings → Accessibility to let me see what's on screen."
    }
}
