package com.friday.assistant.call

import android.annotation.SuppressLint
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

/**
 * Watches telephony state. On an incoming call it resolves the number to a
 * contact name and reports it, so the assistant can announce
 * "Call from Mom" and accept/reject by voice.
 */
class CallWatcher(
    private val context: Context,
    private val onIncomingCall: (callerName: String, number: String) -> Unit,
    private val onCallEnded: () -> Unit
) {
    private val tm = context.getSystemService(TelephonyManager::class.java)
    private var callback: TelephonyCallback? = null
    private var legacyListener: PhoneStateListener? = null
    private var wasRinging = false

    @SuppressLint("MissingPermission")
    fun start() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) = handle(state)
            }
            callback = cb
            try { tm.registerTelephonyCallback(context.mainExecutor, cb) } catch (_: Exception) {}
        } else {
            @Suppress("DEPRECATION")
            val listener = object : PhoneStateListener() {
                @Deprecated("legacy")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) = handle(state)
            }
            legacyListener = listener
            try { tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE) } catch (_: Exception) {}
        }
    }

    fun stop() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            callback?.let { try { tm.unregisterTelephonyCallback(it) } catch (_: Exception) {} }
            callback = null
        } else {
            @Suppress("DEPRECATION")
            legacyListener?.let { try { tm.listen(it, PhoneStateListener.LISTEN_NONE) } catch (_: Exception) {} }
            legacyListener = null
        }
    }

    private fun handle(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                if (!wasRinging) {
                    wasRinging = true
                    // The ringing broadcast carries the number more reliably than
                    // the callback, so the service also passes it via CallStateStore.
                    val number = CallStateStore.incomingNumber.orEmpty()
                    onIncomingCall(contactName(number), number)
                }
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                if (wasRinging) onCallEnded()
                wasRinging = false
            }
        }
    }

    fun contactName(number: String): String {
        if (number.isBlank()) return "Unknown caller"
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            context.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { c: Cursor ->
                if (c.moveToFirst()) c.getString(0) else null
            } ?: number
        } catch (_: Exception) {
            number
        }
    }
}

/** Filled by the phone-state broadcast receiver inside AssistantService,
 *  because TelephonyCallback does not deliver the incoming number. */
object CallStateStore {
    @Volatile var incomingNumber: String? = null
}
