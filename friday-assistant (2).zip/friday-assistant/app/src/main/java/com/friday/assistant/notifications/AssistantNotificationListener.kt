package com.friday.assistant.notifications

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat

/**
 * NotificationListenerService backing "read my notifications" and
 * quick replies. Messaging apps (WhatsApp, SMS apps, Telegram, Signal)
 * expose a RemoteInput reply action on their notifications — FRIDAY reuses
 * that action, which is the supported way to reply without opening the app.
 */
class AssistantNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val (replyIntent, replyInput) = extractReply(n)
        val label = try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(sbn.packageName, 0)
            ).toString()
        } catch (_: Exception) {
            sbn.packageName
        }
        NotificationStore.add(
            StoredNotification(
                key = sbn.key,
                packageName = sbn.packageName,
                appLabel = label,
                title = title,
                text = text,
                postedAt = sbn.postTime,
                replyIntent = replyIntent,
                replyInput = replyInput
            )
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        NotificationStore.remove(sbn.key)
    }

    private fun extractReply(n: Notification): Pair<android.app.PendingIntent?, android.app.RemoteInput?> {
        val candidates = mutableListOf<Notification.Action>()
        n.actions?.let { candidates.addAll(it) }
        try {
            val wearable = NotificationCompat.WearableExtender(n)
            @Suppress("DEPRECATION")
            candidates.addAll(wearable.actions)
        } catch (_: Exception) {
            // non-wearable notification; the standard actions above are enough
        }
        for (action in candidates) {
            val inputs = action.remoteInputs ?: continue
            for (input in inputs) {
                if (input.resultKey != null) return action.actionIntent to input
            }
        }
        return null to null
    }

    companion object {
        fun componentName(context: Context): ComponentName =
            ComponentName(context, AssistantNotificationListener::class.java)

        fun isEnabled(context: Context): Boolean {
            val enabled = android.provider.Settings.Secure.getString(
                context.contentResolver, "enabled_notification_listeners"
            ).orEmpty()
            return enabled.contains(context.packageName)
        }
    }
}
