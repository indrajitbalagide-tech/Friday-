package com.friday.assistant.service

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.friday.assistant.FridayApp
import com.friday.assistant.MainActivity
import com.friday.assistant.R

/**
 * Android 15 forbids starting a microphone foreground service from
 * BOOT_COMPLETED, so after a reboot FRIDAY posts a tap-to-start notification
 * instead of crashing or silently failing.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val tap = PendingIntent.getActivity(
            context, 7,
            Intent(context, MainActivity::class.java).putExtra(MainActivity.EXTRA_AUTOSTART, true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, FridayApp.CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_friday)
            .setContentTitle("FRIDAY is ready when you are")
            .setContentText("Tap to start your voice assistant")
            .setContentIntent(tap)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(1001, n)
        } catch (_: SecurityException) {
            // POST_NOTIFICATIONS not granted yet; nothing more we can do.
        }
    }
}
