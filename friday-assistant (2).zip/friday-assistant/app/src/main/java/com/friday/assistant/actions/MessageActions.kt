package com.friday.assistant.actions

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.telephony.SmsManager
import com.friday.assistant.notifications.NotificationStore

/** Quick replies: through the messaging app's own notification reply action
 *  when one exists (WhatsApp, Messages, Telegram...), else direct SMS. */
object MessageActions {

    fun readNotifications(limit: Int): String {
        val items = NotificationStore.snapshot().take(limit.coerceIn(1, 15))
        if (items.isEmpty()) return "You have no notifications right now."
        val sb = StringBuilder("Here are your latest notifications. ")
        items.forEachIndexed { i, n ->
            sb.append("${i + 1}. ${n.appLabel}: ${n.title}")
            if (n.text.isNotBlank() && n.text != n.title) sb.append(" — ${n.text}")
            sb.append(". ")
        }
        return sb.toString().trim()
    }

    fun replyToLatestMessage(context: Context, appHint: String?, text: String): String {
        val pkg = when (appHint?.lowercase()) {
            "whatsapp" -> "com.whatsapp"
            "sms", "messages", "message" -> "com.google.android.apps.messaging"
            "telegram" -> "org.telegram.messenger"
            "signal" -> "org.thoughtcrime.securesms"
            else -> null
        }
        val target = NotificationStore.latestMessage(pkg)
            ?: NotificationStore.latestMessage()
            ?: return "I don't see a recent message I can reply to."
        if (!target.canReply) {
            return "The latest ${target.appLabel} notification doesn't offer a quick reply. " +
                "Open ${target.appLabel} to answer it."
        }
        return if (com.friday.assistant.notifications.AutoReplier.sendReply(context, target, text)) {
            "Replied to ${target.title} on ${target.appLabel}: \"$text\"."
        } else {
            "The reply didn't go through."
        }
    }

    /** Open a WhatsApp chat with a contact, message pre-filled (wa.me link).
     *  WhatsApp does not let other apps send fully in the background, so the
     *  user taps send once — FRIDAY says so honestly in its result. */
    fun sendWhatsApp(context: Context, contactName: String, message: String): String {
        val number = CallActions.resolveNumber(context, contactName)
            ?: return "I couldn't find a number for $contactName."
        val digits = number.filter { it.isDigit() }
        val intl = when {
            digits.length == 10 -> "91$digits"               // Indian local number
            digits.length == 11 && digits.startsWith("0") -> "91" + digits.drop(1)
            else -> digits                                   // already has a country code
        }
        val url = "https://wa.me/$intl?text=${android.net.Uri.encode(message)}"
        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
                    .setPackage("com.whatsapp")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "WhatsApp par $contactName ki chat khol di hai — message bhara hua hai, " +
                "bas bhejne wala button (send) dabana hai."
        } catch (e: Exception) {
            try {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                "WhatsApp chat for $contactName is open with your message filled in — tap send."
            } catch (e2: Exception) {
                "I couldn't open WhatsApp: ${e2.message}"
            }
        }
    }

    fun sendSms(context: Context, contactOrNumber: String, text: String): String {
        val number = CallActions.resolveNumber(context, contactOrNumber)
            ?: return "I couldn't find a number for $contactOrNumber."
        return try {
            @Suppress("DEPRECATION")
            val sms = SmsManager.getDefault()
            val parts = sms.divideMessage(text)
            sms.sendMultipartTextMessage(number, null, parts, null, null)
            "Text sent to $contactOrNumber."
        } catch (e: Exception) {
            "I couldn't send the text: ${e.message}"
        }
    }
}
