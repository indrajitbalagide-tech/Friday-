package com.friday.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.friday.assistant.data.Settings

class FridayApp : Application() {
    lateinit var settings: Settings
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        settings = Settings(this)
        createChannels()
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ASSISTANT, "FRIDAY assistant", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Persistent notification while FRIDAY is running" }
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ALERTS, "FRIDAY alerts", NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Call and message announcements" }
        )
    }

    companion object {
        const val CHANNEL_ASSISTANT = "friday_assistant"
        const val CHANNEL_ALERTS = "friday_alerts"
        lateinit var instance: FridayApp
            private set
    }
}
