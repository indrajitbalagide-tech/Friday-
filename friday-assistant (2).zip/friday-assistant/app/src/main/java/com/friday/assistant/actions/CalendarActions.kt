package com.friday.assistant.actions

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Calendar read + create (IRIS registry: check_schedule, schedule_new_event). */
object CalendarActions {

    private fun has(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    private val fmt = SimpleDateFormat("EEE, d MMM 'at' h:mm a", Locale.ENGLISH)

    fun readSchedule(context: Context): String {
        if (!has(context, Manifest.permission.READ_CALENDAR)) {
            return "Calendar permission nahi mili hai — FRIDAY ke Setup se " +
                "permissions dobara grant karo, phir pucho."
        }
        val now = System.currentTimeMillis()
        val until = now + 48L * 60 * 60 * 1000
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
            .also { ContentUris.appendId(it, now); ContentUris.appendId(it, until) }
            .build()
        val events = mutableListOf<String>()
        return try {
            context.contentResolver.query(
                uri,
                arrayOf(
                    CalendarContract.Instances.TITLE,
                    CalendarContract.Instances.BEGIN,
                    CalendarContract.Instances.EVENT_LOCATION
                ),
                null, null, "${CalendarContract.Instances.BEGIN} ASC"
            )?.use { c ->
                while (c.moveToNext() && events.size < 8) {
                    val title = c.getString(0)?.takeIf { it.isNotBlank() } ?: "Untitled event"
                    val begin = c.getLong(1)
                    val loc = c.getString(2)?.takeIf { it.isNotBlank() }
                    events.add("$title — ${fmt.format(Date(begin))}" + (loc?.let { " at $it" } ?: ""))
                }
            }
            if (events.isEmpty()) "Agle 48 ghante mein calendar par kuch nahi hai."
            else "Agle 48 ghante ka schedule: " + events.joinToString(". ")
        } catch (e: Exception) {
            "Calendar padh nahi paya: ${e.message}"
        }
    }

    fun createEvent(context: Context, title: String, hoursFromNow: Long, durationMinutes: Int): String {
        if (!has(context, Manifest.permission.WRITE_CALENDAR)) {
            return "Calendar permission nahi mili hai — FRIDAY ke Setup se " +
                "permissions dobara grant karo, phir bolo."
        }
        if (title.isBlank()) return "Event ka title batao — kis baare mein hai?"
        val calendarId = firstCalendarId(context)
            ?: return "Phone par koi calendar hi nahi mila jisme event dalu."
        val start = System.currentTimeMillis() + hoursFromNow.coerceAtLeast(0) * 3600_000L
        val end = start + durationMinutes.coerceIn(5, 24 * 60) * 60_000L
        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, start)
            put(CalendarContract.Events.DTEND, end)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.CALENDAR_ID, calendarId)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }
        return try {
            context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            "Event bana diya: \"$title\" — ${fmt.format(Date(start))}, $durationMinutes minute ke liye."
        } catch (e: Exception) {
            "Event nahi bana paya: ${e.message}"
        }
    }

    private fun firstCalendarId(context: Context): Long? = try {
        context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID),
            "${CalendarContract.Calendars.VISIBLE} = 1", null, null
        )?.use { c -> if (c.moveToFirst()) c.getLong(0) else null }
    } catch (_: Exception) {
        null
    }
}
