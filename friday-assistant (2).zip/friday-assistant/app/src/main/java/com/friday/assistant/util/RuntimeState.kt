package com.friday.assistant.util

import kotlinx.coroutines.flow.MutableStateFlow

data class ChatLine(val role: Role, val text: String) {
    enum class Role { USER, FRIDAY, SYSTEM }
}

enum class SessionStatus { STOPPED, CONNECTING, LISTENING, SPEAKING, ON_DEVICE, ERROR }

/** Process-wide observable state shared by the service (writer) and the
 *  Compose UI + overlay (readers). Keeps the UI decoupled from the service. */
object RuntimeState {
    val serviceRunning = MutableStateFlow(false)
    val status = MutableStateFlow(SessionStatus.STOPPED)
    val statusDetail = MutableStateFlow("FRIDAY is stopped")
    val transcript = MutableStateFlow<List<ChatLine>>(emptyList())
    val micLevel = MutableStateFlow(0f)
    val liveMode = MutableStateFlow(false)

    fun addLine(role: ChatLine.Role, text: String) {
        if (text.isBlank()) return
        val current = transcript.value
        // Merge consecutive partial transcripts from the same role.
        if (current.isNotEmpty() && current.last().role == role &&
            (role == ChatLine.Role.FRIDAY || role == ChatLine.Role.USER)
        ) {
            val merged = current.dropLast(1) + ChatLine(role, text)
            transcript.value = merged.takeLast(60)
        } else {
            transcript.value = (current + ChatLine(role, text)).takeLast(60)
        }
    }

    fun setStatus(s: SessionStatus, detail: String) {
        status.value = s
        statusDetail.value = detail
    }
}
