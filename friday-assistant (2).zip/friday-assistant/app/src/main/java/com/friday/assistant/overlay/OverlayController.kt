package com.friday.assistant.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import com.friday.assistant.MainActivity
import com.friday.assistant.R
import kotlin.math.abs

/**
 * The floating FRIDAY bubble. Drag to move, tap to talk, long-press to open
 * the app. On Android 15 a *visible* overlay window is also what allows the
 * assistant's foreground service to be (re)started from the background, so
 * the bubble doubles as the compliant background entry point.
 */
class OverlayController(
    private val context: Context,
    private val onTap: () -> Unit
) {
    private val wm = context.getSystemService(WindowManager::class.java)
    private var bubble: View? = null
    private var params: WindowManager.LayoutParams? = null

    fun canDraw(): Boolean = Settings.canDrawOverlays(context)

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (bubble != null || !canDraw()) return
        val size = (64 * context.resources.displayMetrics.density).toInt()
        val view = ImageView(context).apply {
            setImageResource(R.drawable.ic_stat_friday)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF2A0A54.toInt())
                setStroke(3, 0xFF00F0FF.toInt())
            }
            setPadding(28, 28, 28, 28)
            elevation = 12f
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (context.resources.displayMetrics.widthPixels - size - 24)
            y = context.resources.displayMetrics.heightPixels / 3
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var downTime = 0L
        view.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y; downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - downX).toInt()
                    lp.y = startY + (e.rawY - downY).toInt()
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = abs(e.rawX - downX) + abs(e.rawY - downY)
                    val dt = System.currentTimeMillis() - downTime
                    if (moved < 12f) {
                        if (dt > 450) { // long press → open the app
                            context.startActivity(
                                Intent(context, MainActivity::class.java)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } else {
                            onTap()
                        }
                    }
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(view, lp)
            bubble = view
            params = lp
        } catch (_: Exception) {
            bubble = null
        }
    }

    fun hide() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }

    fun setActive(active: Boolean) {
        (bubble as? ImageView)?.let { v ->
            (v.background as? GradientDrawable)?.setColor(
                if (active) 0xFF00F0FF.toInt() else 0xFF2A0A54.toInt()
            )
        }
    }
}
