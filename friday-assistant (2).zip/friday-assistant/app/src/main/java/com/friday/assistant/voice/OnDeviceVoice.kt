package com.friday.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.friday.assistant.actions.ActionRouter
import com.friday.assistant.FridayApp
import org.json.JSONObject
import java.util.Locale

/**
 * Fully on-device mode (no API key, no internet): Android's SpeechRecognizer
 * feeds a small intent parser that drives the same ActionRouter the Live
 * model uses, and replies go through TextToSpeech. Fast and private, with
 * narrower language understanding than Gemini Live mode.
 */
class OnDeviceVoice(
    private val context: Context,
    private val router: ActionRouter,
    private val speaker: Speaker,
    private val onTranscript: (String) -> Unit,
    private val onReply: (String) -> Unit
) {
    private var recognizer: SpeechRecognizer? = null
    @Volatile var listening = false
        private set

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            val msg = "Speech recognition isn't available on this device."
            onReply(msg); speaker.speak(msg)
            return
        }
        stopListening()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    listening = false
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) {
                        onTranscript(text)
                        handle(text)
                    }
                }
                override fun onError(error: Int) {
                    listening = false
                    if (error != SpeechRecognizer.ERROR_NO_MATCH &&
                        error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    ) {
                        onReply("Sun nahi payi - ek baar phir boliye, main sun rahi hoon.")
                        if (error == SpeechRecognizer.ERROR_NETWORK ||
                            error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                            error == SpeechRecognizer.ERROR_AUDIO ||
                            error == SpeechRecognizer.ERROR_SERVER ||
                            error == SpeechRecognizer.ERROR_CLIENT
                        ) {
                            speaker.speak("Sun nahi payi - ek baar phir boliye, main sun rahi hoon.")
                        }
                    }
                }
                override fun onReadyForSpeech(params: Bundle?) { listening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, FridayApp.instance.settings.recognizerLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer?.startListening(intent)
        listening = true
    }

    fun stopListening() {
        try { recognizer?.stopListening(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        listening = false
    }

    private fun handle(raw: String) {
        val text = raw.trim()
        val lower = text.lowercase()
        val reply: String = when {
            "flashlight" in lower || "torch" in lower -> {
                val act = when {
                    "off" in lower || "band" in lower -> "off"
                    "on" in lower || "jalo" in lower || "jalao" in lower -> "on"
                    else -> "toggle"
                }
                router.execute("control_device_hardware",
                    JSONObject().put("target", "flashlight").put("action", act))
            }
            "settings" in lower && ("wifi" in lower || "wi-fi" in lower) ->
                router.execute("control_device_hardware",
                    JSONObject().put("target", "wifi").put("action", "open"))
            "settings" in lower && "bluetooth" in lower ->
                router.execute("control_device_hardware",
                    JSONObject().put("target", "bluetooth").put("action", "open"))
            "settings" in lower && "location" in lower ->
                router.execute("control_device_hardware",
                    JSONObject().put("target", "location").put("action", "open"))
            "settings" in lower && "hotspot" in lower ->
                router.execute("control_device_hardware",
                    JSONObject().put("target", "hotspot").put("action", "open"))
            lower.startsWith("play ") && "youtube" in lower -> {
                val q = lower.removePrefix("play ").replace("on youtube", "").trim()
                router.execute("open_deep_link",
                    JSONObject().put("target_app", "youtube").put("query", q))
            }
            lower.startsWith("play ") && "spotify" in lower -> {
                val q = lower.removePrefix("play ").replace("on spotify", "").trim()
                router.execute("open_deep_link",
                    JSONObject().put("target_app", "spotify").put("query", q))
            }
            lower.startsWith("whatsapp ") -> {
                val rest = text.substringAfter(' ').trim()
                val restLower = rest.lowercase()
                val idx = restLower.indexOf(" saying ")
                val contact: String
                val msg: String
                if (idx >= 0) {
                    contact = rest.substring(0, idx).trim()
                    msg = rest.substring(idx + " saying ".length).trim()
                } else {
                    contact = rest.substringBefore(' ')
                    msg = rest.substringAfter(' ', "")
                }
                if (msg.isBlank()) "What should I write to $contact on WhatsApp?"
                else router.execute("send_whatsapp_message",
                    JSONObject().put("contact_name", contact).put("message", msg))
            }
            lower.startsWith("remember ") ->
                router.execute("save_core_memory",
                    JSONObject().put("fact", text.substringAfter(' ').trim()))
            lower.startsWith("yaad karo ") ->
                router.execute("save_core_memory",
                    JSONObject().put("fact", text.substring("yaad karo ".length).trim()))
            lower.startsWith("do you remember") || lower.startsWith("what do you remember") ||
                lower.startsWith("recall") ->
                router.execute("access_core_memory", JSONObject().put("query", text))
            "schedule" in lower || "calendar" in lower ->
                router.execute("check_schedule", JSONObject())
            "kaise ho" in lower || "kaisi ho" in lower || "how are you" in lower ->
                "Main bahut badhiya hoon! Aapki awaaz sunkar din ban gaya. Aap sunaiye, sab theek hai na?"
            "tumhara naam" in lower || "your name" in lower ->
                "Mera naam FRIDAY hai - aapki dost, hamesha aapke saath."
            "shukriya" in lower || "dhanyavad" in lower || "dhanyavaad" in lower ||
                "thank you" in lower || "thanks" in lower ->
                "Arey, ismein shukriya kaisa - aapke liye kuch bhi! Aur kuch chahiye to bas bol dijiye."
            "samay" in lower || "time kya" in lower || "time batao" in lower || "what time" in lower -> {
                val now = java.util.Calendar.getInstance()
                val fmt = java.text.SimpleDateFormat("h:mm a", java.util.Locale.ENGLISH)
                "Abhi samay hai " + fmt.format(now.time) + "."
            }
            "kholo" in lower -> {
                val app = lower.replace("kholo", "").replace("open", "").trim()
                if (app.isBlank()) "Kaunsi app kholoon? Naam boliye."
                else router.execute("open_app", JSONObject().put("app_name", app))
            }
            lower.startsWith("call karo ") || lower.startsWith("call lagao ") -> {
                val contact = text.substringAfter(' ').substringAfter(' ').trim().removeSuffix(" ko")
                if (contact.isBlank()) "Kisko call karoon? Naam boliye."
                else router.execute("make_call", JSONObject().put("contact_or_number", contact))
            }
            " ko call" in lower -> {
                val contact = lower.substringBefore(" ko call").trim()
                if (contact.isBlank()) "Kisko call karoon? Naam boliye."
                else router.execute("make_call", JSONObject().put("contact_or_number", contact))
            }
            "gaana chalao" in lower || "gana chalao" in lower || "gaana bajao" in lower ->
                router.execute("control_music", JSONObject().put("action", "play"))
            "gaana band" in lower || "gana band" in lower ->
                router.execute("control_music", JSONObject().put("action", "pause"))
            "agla gaana" in lower || "agla gana" in lower ->
                router.execute("control_music", JSONObject().put("action", "next"))
            "pichla gaana" in lower || "pichla gana" in lower ->
                router.execute("control_music", JSONObject().put("action", "previous"))
            lower.startsWith("open ") || lower.startsWith("launch ") ->
                router.execute("open_app", JSONObject().put("app_name", text.substringAfter(' ').trim()))
            lower.startsWith("call ") ->
                router.execute("make_call", JSONObject().put("contact_or_number", text.substringAfter(' ').trim()))
            lower in setOf("answer", "answer it", "answer the call", "pick up", "accept") ->
                router.execute("answer_call", JSONObject())
            lower in setOf("reject", "reject it", "decline", "hang up", "end call", "end the call") ->
                router.execute("reject_call", JSONObject())
            "pause" in lower && ("music" in lower || "song" in lower || lower == "pause") ->
                router.execute("control_music", JSONObject().put("action", "pause"))
            lower in setOf("play", "resume", "play music") || lower.startsWith("play ") && "music" in lower ->
                router.execute("control_music", JSONObject().put("action", "play"))
            lower in setOf("next", "next song", "skip", "next track") ->
                router.execute("control_music", JSONObject().put("action", "next"))
            lower in setOf("previous", "previous song", "go back") ->
                router.execute("control_music", JSONObject().put("action", "previous"))
            "what's playing" in lower || "what is playing" in lower || "which song" in lower ->
                router.execute("now_playing", JSONObject())
            "notification" in lower ->
                router.execute("read_notifications", JSONObject().put("limit", 5))
            lower.startsWith("reply ") ->
                router.execute("reply_to_message", JSONObject().put("text", text.substringAfter(' ').trim()))
            lower.startsWith("text ") || lower.startsWith("sms ") -> {
                // "text Mom I'll be late" — first word after the verb is the contact
                val rest = text.substringAfter(' ').trim()
                val contact = rest.substringBefore(' ')
                val body = rest.substringAfter(' ', "")
                if (body.isBlank()) "Who should I text, and what should I say?"
                else router.execute("send_sms", JSONObject().put("contact_or_number", contact).put("text", body))
            }
            "screen" in lower || "what do you see" in lower ->
                router.execute("get_screen_context", JSONObject())
            else ->
                if (FridayApp.instance.settings.language == "english")
                    "I heard you. In on-device mode I understand things like: open WhatsApp, " +
                        "call Mom, pause music, read my notifications. Add a Gemini API key " +
                        "in Settings for natural conversation."
                else
                    "Maine suna: " + text + ". Main ye commands samajhti hoon - WhatsApp kholo, " +
                        "Mummy ko call karo, gaana chalao, torch jalao, notification padho, " +
                        "yaad karo. Dil kholkar baatcheet ke liye Settings mein Gemini key daal dijiye."
        }
        onReply(reply)
        speaker.speak(reply)
    }
}
