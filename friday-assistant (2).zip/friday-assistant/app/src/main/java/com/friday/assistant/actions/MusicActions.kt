package com.friday.assistant.actions

import android.content.Context
import android.media.AudioManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.view.KeyEvent
import com.friday.assistant.notifications.AssistantNotificationListener

/** Controls whichever media app is currently playing (Spotify, YouTube Music,
 *  local players) through its media session, with a key-event fallback. */
object MusicActions {

    fun control(context: Context, action: String): String {
        val controller = activeController(context)
        val transport = controller?.transportControls
        return when (action.lowercase()) {
            "play" -> {
                if (transport != null) transport.play() else sendKey(context, KeyEvent.KEYCODE_MEDIA_PLAY)
                "Playing."
            }
            "pause" -> {
                if (transport != null) transport.pause() else sendKey(context, KeyEvent.KEYCODE_MEDIA_PAUSE)
                "Paused."
            }
            "next" -> {
                if (transport != null) transport.skipToNext() else sendKey(context, KeyEvent.KEYCODE_MEDIA_NEXT)
                "Skipped to the next track."
            }
            "previous" -> {
                if (transport != null) transport.skipToPrevious() else sendKey(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                "Back to the previous track."
            }
            "stop" -> {
                if (transport != null) transport.stop() else sendKey(context, KeyEvent.KEYCODE_MEDIA_STOP)
                "Stopped."
            }
            else -> "I don't know the music action '$action'."
        }
    }

    fun nowPlaying(context: Context): String {
        val c = activeController(context) ?: return "Nothing is playing right now."
        val title = c.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
        val artist = c.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
        val state = when (c.playbackState?.state) {
            PlaybackState.STATE_PLAYING -> "playing"
            PlaybackState.STATE_PAUSED -> "paused"
            else -> "loaded"
        }
        return when {
            title != null && artist != null -> "$title by $artist is $state."
            title != null -> "$title is $state."
            else -> "Media is $state in ${c.packageName}."
        }
    }

    fun setVolumePercent(context: Context, percent: Int): String {
        val am = context.getSystemService(AudioManager::class.java)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = (max * percent.coerceIn(0, 100)) / 100
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        return "Volume set to $percent percent."
    }

    private fun activeController(context: Context): MediaController? {
        val component = AssistantNotificationListener.componentName(context)
        return try {
            val msm = context.getSystemService(MediaSessionManager::class.java)
            val sessions = msm.getActiveSessions(component)
            sessions.firstOrNull {
                it.playbackState?.state == PlaybackState.STATE_PLAYING
            } ?: sessions.firstOrNull()
        } catch (_: Exception) {
            null
        }
    }

    private fun sendKey(context: Context, keyCode: Int) {
        val am = context.getSystemService(AudioManager::class.java)
        val now = SystemClock.uptimeMillis()
        am.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
        am.dispatchMediaKeyEvent(KeyEvent(now + 10, now + 10, KeyEvent.ACTION_UP, keyCode, 0))
    }
}
