package com.friday.assistant.notifications

import android.app.PendingIntent
import android.app.RemoteInput

/** One notification FRIDAY can read out and (for messages) reply to. */
data class StoredNotification(
    val key: String,
    val packageName: String,
    val appLabel: String,
    val title: String,
    val text: String,
    val postedAt: Long,
    val replyIntent: PendingIntent?,
    val replyInput: RemoteInput?
) {
    val canReply: Boolean get() = replyIntent != null && replyInput != null
    val isMessage: Boolean
        get() = packageName in MESSAGE_PACKAGES || canReply

    companion object {
        val MESSAGE_PACKAGES = setOf(
            "com.whatsapp",
            "com.whatsapp.w4b",
            "com.google.android.apps.messaging",
            "org.thoughtcrime.securesms",
            "org.telegram.messenger",
            "com.facebook.orca"
        )
    }
}

/** In-memory store shared between the NotificationListenerService (writer)
 *  and the assistant (reader). Kept deliberately small and recent-first. */
object NotificationStore {
    private const val MAX_ITEMS = 30
    private val items = ArrayDeque<StoredNotification>()

    @Synchronized
    fun add(item: StoredNotification) {
        items.removeAll { it.key == item.key }
        items.addFirst(item)
        while (items.size > MAX_ITEMS) items.removeLast()
        listeners.forEach { it(snapshot()) }
    }

    @Synchronized
    fun remove(key: String) {
        items.removeAll { it.key == key }
    }

    @Synchronized
    fun snapshot(): List<StoredNotification> = items.toList()

    fun latestMessage(fromPackage: String? = null): StoredNotification? =
        snapshot().firstOrNull {
            it.isMessage && (fromPackage == null || it.packageName == fromPackage)
        }

    private val listeners = mutableListOf<(List<StoredNotification>) -> Unit>()
    fun addListener(l: (List<StoredNotification>) -> Unit) { listeners.add(l) }
}
