package com.friday.assistant.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.friday.assistant.FridayApp
import com.friday.assistant.MainActivity
import com.friday.assistant.R
import com.friday.assistant.call.CallStateStore
import com.friday.assistant.call.CallWatcher
import com.friday.assistant.overlay.OverlayController
import com.friday.assistant.util.RuntimeState
import com.friday.assistant.voice.Speaker
import com.friday.assistant.voice.VoiceSession

/**
 * The always-available assistant. Runs as a microphone foreground service
 * (started from a visible screen, as Android 14/15 require), owns the voice
 * session, the call watcher and the floating bubble.
 */
class AssistantService : Service() {

    private lateinit var speaker: Speaker
    private lateinit var session: VoiceSession
    private lateinit var overlay: OverlayController
    private var callWatcher: CallWatcher? = null

    private val phoneStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            if (intent?.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
                val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                if (!number.isNullOrBlank()) CallStateStore.incomingNumber = number
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        speaker = Speaker(this)
        session = VoiceSession(this, speaker)
        overlay = OverlayController(this) { session.talkOnce() }
        registerReceiver(
            phoneStateReceiver,
            IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        )
        callWatcher = CallWatcher(
            context = this,
            onIncomingCall = { name, _ ->
                if (FridayApp.instance.settings.announceCallers) {
                    session.announce("Incoming call from $name. Say \"answer it\" or \"reject it\".")
                }
            },
            onCallEnded = { CallStateStore.incomingNumber = null }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopEverything()
                return START_NOT_STICKY
            }
            ACTION_TEST_VOICE -> {
                ensureForeground()
                session.testVoice()
                return START_STICKY
            }
            ACTION_TALK -> {
                ensureForeground()
                session.talkOnce()
                return START_STICKY
            }
            else -> { // ACTION_START / null (restart)
                ensureForeground()
                session.start()
                callWatcher?.start()
                if (FridayApp.instance.settings.overlayEnabled) overlay.show()
                RuntimeState.serviceRunning.value = true
                return START_STICKY
            }
        }
    }

    private fun ensureForeground() {
        val type = when {
            Build.VERSION.SDK_INT >= 34 ->
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            else -> 0
        }
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val talk = PendingIntent.getService(
            this, 1,
            Intent(this, AssistantService::class.java).setAction(ACTION_TALK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 2,
            Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, FridayApp.CHANNEL_ASSISTANT)
            .setSmallIcon(R.drawable.ic_stat_friday)
            .setContentTitle("FRIDAY is on")
            .setContentText(RuntimeState.statusDetail.value)
            .setContentIntent(openApp)
            .setOngoing(true)
            .addAction(R.drawable.ic_stat_friday, "Talk", talk)
            .addAction(R.drawable.ic_stat_friday, "Stop", stop)
            .build()
    }

    private fun stopEverything() {
        session.stop()
        callWatcher?.stop()
        overlay.hide()
        RuntimeState.serviceRunning.value = false
        try { unregisterReceiver(phoneStateReceiver) } catch (_: Exception) {}
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        try { session.stop() } catch (_: Exception) {}
        callWatcher?.stop()
        overlay.hide()
        speaker.shutdown()
        RuntimeState.serviceRunning.value = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.friday.assistant.START"
        const val ACTION_TALK = "com.friday.assistant.TALK"
        const val ACTION_TEST_VOICE = "com.friday.assistant.TEST_VOICE"
        const val ACTION_STOP = "com.friday.assistant.STOP"
        private const val NOTIF_ID = 42

        fun start(context: Context) {
            val i = Intent(context, AssistantService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }

        fun talk(context: Context) {
            context.startService(Intent(context, AssistantService::class.java).setAction(ACTION_TALK))
        }

        fun testVoice(context: Context) {
            val i = Intent(context, AssistantService::class.java).setAction(ACTION_TEST_VOICE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }

        fun stop(context: Context) {
            context.startService(Intent(context, AssistantService::class.java).setAction(ACTION_STOP))
        }
    }
}
