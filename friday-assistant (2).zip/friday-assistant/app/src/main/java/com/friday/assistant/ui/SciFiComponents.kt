package com.friday.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/**
 * IRIS-X-inspired sci-fi visual layer for FRIDAY.
 * Palette sampled from the IRIS-X native views: neon cyan #00F0FF,
 * magenta #FF007A, violet #7000FF over deep space violet-black.
 */
object SciFiPalette {
    val Cyan = Color(0xFF00F0FF)
    val Magenta = Color(0xFFFF007A)
    val Violet = Color(0xFF7000FF)
    val DeepBg = Color(0xFF05010B)
    val PanelBg = Color(0xFF120826)
    val PanelBg2 = Color(0xFF150A21)
    val TextLight = Color(0xFFE2E8F0)
    val TextDim = Color(0xFF9AA3C0)
}

/** Animated holographic background: violet nebula gradient, grid, drifting particles. */
@Composable
fun HoloBackground(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "holo")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(24000, easing = LinearEasing)),
        label = "drift"
    )
    val particles = remember {
        List(46) { i ->
            floatArrayOf(
                (i * 0.61803f) % 1f,          // x fraction
                (i * 0.38197f) % 1f,          // y fraction
                0.5f + (i % 5) * 0.22f,       // speed
                1f + (i % 3)                  // size dp-ish
            )
        }
    }
    Canvas(modifier.fillMaxSize()) {
        drawRect(
            Brush.verticalGradient(
                listOf(SciFiPalette.DeepBg, SciFiPalette.PanelBg, SciFiPalette.DeepBg)
            )
        )
        // nebula glows
        drawCircle(
            Brush.radialGradient(listOf(SciFiPalette.Violet.copy(alpha = 0.20f), Color.Transparent)),
            radius = size.width * 0.75f,
            center = Offset(size.width * 0.85f, size.height * 0.12f)
        )
        drawCircle(
            Brush.radialGradient(listOf(SciFiPalette.Magenta.copy(alpha = 0.10f), Color.Transparent)),
            radius = size.width * 0.6f,
            center = Offset(size.width * 0.08f, size.height * 0.85f)
        )
        // grid
        val step = 46.dp.toPx()
        val gridColor = SciFiPalette.Cyan.copy(alpha = 0.05f)
        var x = 0f
        while (x < size.width) { drawLine(gridColor, Offset(x, 0f), Offset(x, size.height)); x += step }
        var y = 0f
        while (y < size.height) { drawLine(gridColor, Offset(0f, y), Offset(size.width, y)); y += step }
        // particles drift upward and wrap
        particles.forEach { p ->
            val py = ((p[1] - t * 0.05f * p[2]) % 1f + 1f) % 1f
            drawCircle(
                color = SciFiPalette.Cyan.copy(alpha = 0.35f),
                radius = p[3].dp.toPx() * 0.5f,
                center = Offset(p[0] * size.width, py * size.height)
            )
        }
    }
}

/**
 * The cyber orb: layered glowing concentric rings (like the IRIS-X native orb),
 * two counter-rotating arc segments, orbiting particles and a reactive core
 * whose radius follows the live audio [level] (0f..1f).
 */
@Composable
fun CyberOrb(
    level: Float,
    active: Boolean,
    speaking: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "orb")
    val rotA by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "rotA"
    )
    val rotB by transition.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing)),
        label = "rotB"
    )
    val spin by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(
            tween(6000, easing = LinearEasing), RepeatMode.Restart
        ),
        label = "spin"
    )
    val satellites = remember {
        listOf(
            floatArrayOf(0f, 1.30f, 2.2f),
            floatArrayOf(140f, 1.30f, 1.6f),
            floatArrayOf(250f, 1.42f, 2.8f)
        )
    }
    Canvas(modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val base = size.minDimension / 2f
        val coreR = base * (0.42f + level * 0.16f)
        val accent = if (speaking) SciFiPalette.Magenta else SciFiPalette.Cyan

        // outer halo
        drawCircle(
            Brush.radialGradient(listOf(accent.copy(alpha = 0.28f), Color.Transparent)),
            radius = base * 1.5f, center = Offset(cx, cy)
        )
        // static concentric rings (IRIS-X orb signature: r, r+20, r+40)
        listOf(0.86f to 0.50f, 0.97f to 0.32f, 1.08f to 0.18f).forEach { (f, a) ->
            drawCircle(
                color = accent.copy(alpha = a),
                radius = base * f,
                center = Offset(cx, cy),
                style = Stroke(width = 1.6.dp.toPx())
            )
        }
        // rotating arc segments
        drawArc(
            color = accent, startAngle = rotA, sweepAngle = 110f, useCenter = false,
            topLeft = Offset(cx - base * 0.97f, cy - base * 0.97f),
            size = Size(base * 1.94f, base * 1.94f),
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
        )
        drawArc(
            color = SciFiPalette.Violet, startAngle = rotB, sweepAngle = 80f, useCenter = false,
            topLeft = Offset(cx - base * 1.08f, cy - base * 1.08f),
            size = Size(base * 2.16f, base * 2.16f),
            style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round)
        )
        drawArc(
            color = SciFiPalette.Magenta.copy(alpha = 0.85f),
            startAngle = rotA + 200f, sweepAngle = 46f, useCenter = false,
            topLeft = Offset(cx - base * 0.86f, cy - base * 0.86f),
            size = Size(base * 1.72f, base * 1.72f),
            style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round)
        )
        // orbiting satellite particles
        satellites.forEach { s ->
            val ang = Math.toRadians((spin * s[2] + s[0]).toDouble())
            val r = base * s[1]
            drawCircle(
                color = accent,
                radius = 3.dp.toPx(),
                center = Offset(cx + (cos(ang) * r).toFloat(), cy + (sin(ang) * r).toFloat())
            )
        }
        // reactive core
        drawCircle(
            Brush.radialGradient(
                listOf(
                    Color.White,
                    accent.copy(alpha = 0.9f),
                    SciFiPalette.Violet.copy(alpha = 0.55f),
                    Color.Transparent
                )
            ),
            radius = coreR * 1.7f, center = Offset(cx, cy)
        )
        if (!active) {
            drawCircle(
                color = Color.White.copy(alpha = 0.10f),
                radius = base * 1.08f, center = Offset(cx, cy)
            )
        }
    }
}

/** Live spectrum bars driven by the audio [level], IRIS-X spectrum style. */
@Composable
fun SpectrumBars(
    level: Float,
    active: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "spectrum")
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
        label = "phase"
    )
    Canvas(modifier) {
        val bars = 28
        val gap = 3.dp.toPx()
        val barW = (size.width - gap * (bars - 1)) / bars
        val amp = if (active) 0.25f + level * 1.1f else 0.10f
        for (i in 0 until bars) {
            val wave = 0.5f + 0.5f * sin(phase * 2f + i * 0.55f)
            val wave2 = 0.5f + 0.5f * sin(phase * 3.1f + i * 1.3f)
            val h = (0.12f + amp * wave * wave2) * size.height
            val color = when {
                i % 7 == 3 -> SciFiPalette.Magenta
                i % 5 == 2 -> SciFiPalette.Violet
                else -> SciFiPalette.Cyan
            }
            drawRect(
                color = color.copy(alpha = 0.9f),
                topLeft = Offset(i * (barW + gap), size.height - h),
                size = Size(barW, h)
            )
        }
    }
}

/** HUD panel: translucent violet panel, thin cyan border, corner brackets. */
@Composable
fun HudPanel(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(color = SciFiPalette.PanelBg.copy(alpha = 0.82f))
            drawRect(
                color = SciFiPalette.Cyan.copy(alpha = 0.35f),
                style = Stroke(width = 1.dp.toPx())
            )
            val len = 14.dp.toPx()
            val w = 2.2.dp.toPx()
            val c = SciFiPalette.Cyan
            // corner brackets
            drawLine(c, Offset(0f, 0f), Offset(len, 0f), w)
            drawLine(c, Offset(0f, 0f), Offset(0f, len), w)
            drawLine(c, Offset(size.width - len, 0f), Offset(size.width, 0f), w)
            drawLine(c, Offset(size.width, 0f), Offset(size.width, len), w)
            drawLine(c, Offset(0f, size.height - len), Offset(0f, size.height), w)
            drawLine(c, Offset(0f, size.height), Offset(len, size.height), w)
            drawLine(c, Offset(size.width - len, size.height), Offset(size.width, size.height), w)
            drawLine(c, Offset(size.width, size.height - len), Offset(size.width, size.height), w)
        }
        Box(Modifier.fillMaxSize()) { content() }
    }
}
