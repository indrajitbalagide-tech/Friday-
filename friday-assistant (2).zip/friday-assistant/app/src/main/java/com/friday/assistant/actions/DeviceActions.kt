package com.friday.assistant.actions

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.Settings

/** Hardware and settings control (IRIS registry: control_device_hardware,
 *  open_deep_link, close_app). */
object DeviceActions {

    @Volatile private var torchOn = false

    fun hardware(context: Context, target: String, action: String): String = when (target.lowercase()) {
        "flashlight", "torch" -> setTorch(context, action.lowercase())
        "wifi" -> openPanel(context, "Wi-Fi", Settings.ACTION_WIFI_SETTINGS)
        "bluetooth" -> openPanel(context, "Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS)
        "location" -> openPanel(context, "Location", Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        "hotspot" -> openHotspot(context)
        else -> "I can't control $target. I can do: flashlight, wifi, bluetooth, location, hotspot."
    }

    private fun setTorch(context: Context, action: String): String {
        val manager = context.getSystemService(CameraManager::class.java)
        val cameraId = manager.cameraIdList.firstOrNull { id ->
            manager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "This phone has no flashlight I can use."
        val wantOn = when (action) {
            "on" -> true
            "off" -> false
            else -> !torchOn // toggle
        }
        return try {
            manager.setTorchMode(cameraId, wantOn)
            torchOn = wantOn
            if (wantOn) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            "I couldn't switch the flashlight: ${e.message}"
        }
    }

    private fun openPanel(context: Context, label: String, settingsAction: String): String = try {
        context.startActivity(
            Intent(settingsAction).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        "Opened $label settings."
    } catch (e: Exception) {
        "I couldn't open $label settings: ${e.message}"
    }

    private fun openHotspot(context: Context): String = try {
        context.startActivity(
            Intent("android.settings.TETHER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        "Opened hotspot settings."
    } catch (e: Exception) {
        openPanel(context, "wireless", Settings.ACTION_WIRELESS_SETTINGS)
    }

    /** Deep links: jump straight into a search inside YouTube / Spotify /
     *  Maps, or open a web page/search in the browser. */
    fun deepLink(context: Context, targetApp: String, query: String): String {
        val q = query.trim()
        return when (targetApp.lowercase()) {
            "youtube" -> view(
                context,
                "https://www.youtube.com/results?search_query=${Uri.encode(q)}",
                "com.google.android.youtube",
                "Searching YouTube for \"$q\"."
            )
            "spotify" -> try {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(q)}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                "Searching Spotify for \"$q\"."
            } catch (e: Exception) {
                view(context, "https://open.spotify.com/search/${Uri.encode(q)}", null,
                    "Searching Spotify for \"$q\".")
            }
            "maps", "google maps" -> view(
                context, "geo:0,0?q=${Uri.encode(q)}", null, "Showing \"$q\" on the map."
            )
            "chrome", "web", "browser" -> {
                val url = if ('.' in q && ' ' !in q) {
                    if (q.startsWith("http")) q else "https://$q"
                } else {
                    "https://www.google.com/search?q=${Uri.encode(q)}"
                }
                view(context, url, null, "Opening $url.")
            }
            else -> "I can deep-link into YouTube, Spotify, Maps or the web — not $targetApp yet."
        }
    }

    private fun view(context: Context, url: String, pkg: String?, okMsg: String): String = try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) intent.setPackage(pkg)
        context.startActivity(intent)
        okMsg
    } catch (e: Exception) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            okMsg
        } catch (e2: Exception) {
            "I couldn't open that: ${e2.message}"
        }
    }

    /** Android does not let one app force-close another; the honest version
     *  is going home / showing recents so the user can swipe it away. */
    fun closeApp(context: Context): String = try {
        context.startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        "I can't force-close other apps directly — I've taken you Home; " +
            "swipe the app away from Recents to close it fully."
    } catch (e: Exception) {
        "I couldn't do that: ${e.message}"
    }
}
