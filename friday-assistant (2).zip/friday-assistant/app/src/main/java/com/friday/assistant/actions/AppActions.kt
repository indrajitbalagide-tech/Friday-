package com.friday.assistant.actions

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

/** Resolves spoken app names ("WhatsApp", "spotify", "camera") to installed
 *  launchable apps and opens them. */
object AppActions {

    data class AppEntry(val label: String, val packageName: String)

    fun installedApps(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0).map {
            AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName)
        }.distinctBy { it.packageName }
    }

    fun findApp(context: Context, spokenName: String): AppEntry? {
        val needle = spokenName.trim().lowercase()
        if (needle.isEmpty()) return null
        val apps = installedApps(context)
        return apps.firstOrNull { it.label.lowercase() == needle }
            ?: apps.firstOrNull { it.label.lowercase().startsWith(needle) }
            ?: apps.firstOrNull { it.label.lowercase().contains(needle) }
            ?: apps.firstOrNull { it.packageName.contains(needle.replace(" ", ""), ignoreCase = true) }
            ?: WELL_KNOWN[needle]?.let { pkg ->
                apps.firstOrNull { it.packageName == pkg }
            }
    }

    fun openApp(context: Context, spokenName: String): String {
        val app = findApp(context, spokenName)
            ?: return "I couldn't find an installed app called $spokenName."
        val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
            ?: return "${app.label} is installed but can't be opened."
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return "Opened ${app.label}."
    }

    private val WELL_KNOWN = mapOf(
        "whatsapp" to "com.whatsapp",
        "whats app" to "com.whatsapp",
        "spotify" to "com.spotify.music",
        "youtube" to "com.google.android.youtube",
        "yt" to "com.google.android.youtube",
        "maps" to "com.google.android.apps.maps",
        "gmail" to "com.google.android.gm",
        "mail" to "com.google.android.gm",
        "camera" to "com.android.camera2",
        "phone" to "com.google.android.dialer",
        "messages" to "com.google.android.apps.messaging",
        "chrome" to "com.android.chrome",
        "clock" to "com.google.android.deskclock",
        "photos" to "com.google.android.apps.photos",
        "instagram" to "com.instagram.android",
        "x" to "com.twitter.android",
        "twitter" to "com.twitter.android"
    )
}
