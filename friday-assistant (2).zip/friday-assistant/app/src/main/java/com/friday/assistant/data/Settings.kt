package com.friday.assistant.data

import android.content.Context
import android.content.SharedPreferences
import java.util.Locale

/** Simple persisted settings for FRIDAY. The Gemini API key never leaves the device
 *  except to Google's Live API endpoint over TLS. */
class Settings(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE)

    var geminiApiKey: String
        get() = prefs.getString(KEY_API, "").orEmpty()
        set(value) = prefs.edit().putString(KEY_API, value.trim()).apply()

    /** Live API voice name. The getter sanitizes: anything that is not one
     *  of the supported voices (e.g. a user typing "gemini" into the old
     *  free-text field) falls back to Aoede instead of breaking Live setup. */
    var voiceName: String
        get() = prefs.getString(KEY_VOICE, "Aoede").orEmpty().takeIf { it in VOICES } ?: "Aoede"
        set(value) = prefs.edit().putString(KEY_VOICE, value).apply()

    var liveModel: String
        get() = prefs.getString(KEY_MODEL, DEFAULT_MODEL).orEmpty().ifBlank { DEFAULT_MODEL }
        set(value) = prefs.edit().putString(KEY_MODEL, value).apply()

    /** Speak the caller's name aloud when a call arrives. */
    var announceCallers: Boolean
        get() = prefs.getBoolean(KEY_ANNOUNCE, true)
        set(value) = prefs.edit().putBoolean(KEY_ANNOUNCE, value).apply()

    /** Show the floating bubble whenever the assistant service runs. */
    var overlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_OVERLAY, true)
        set(value) = prefs.edit().putBoolean(KEY_OVERLAY, value).apply()

    /** Hands-free: in on-device mode, keep listening on a loop after Start
     *  instead of waiting for the Talk button every time. */
    var handsFree: Boolean
        get() = prefs.getBoolean(KEY_HANDSFREE, true)
        set(value) = prefs.edit().putBoolean(KEY_HANDSFREE, value).apply()

    /** Autonomous AI replies to incoming message notifications. Opt-in only,
     *  and only active when a Gemini key is set (the reply is written by AI). */
    var autoReplyEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTOREPLY, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTOREPLY, value).apply()

    /** Gemini voice (V2.1): speak through Gemini's REST text-to-speech
     *  (natural voice, the picker names become real) instead of the phone's
     *  robotic TTS, whenever a key is set and no Live session is active. */
    var geminiVoiceEnabled: Boolean
        get() = prefs.getBoolean(KEY_GVOICE, true)
        set(value) = prefs.edit().putBoolean(KEY_GVOICE, value).apply()

    /** Wake word: when the service is on but no conversation is running,
     *  FRIDAY listens offline (Vosk) for "Hey FRIDAY" and wakes up. Needs a
     *  one-time ~40 MB offline model download (English small model). */
    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean(KEY_WAKE, true)
        set(value) = prefs.edit().putBoolean(KEY_WAKE, value).apply()

    /** Conversation language the user prefers: drives the speech-recognizer
     *  locale, the TTS voice used for Devanagari lines, and the greeting.
     *  "hinglish" is the default - Hindi-English mix is how the user talks. */
    var language: String
        get() = prefs.getString(KEY_LANGUAGE, "hinglish").orEmpty()
            .takeIf { it in LANGUAGES } ?: "hinglish"
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    /** Speech-recognizer locale tag for the chosen language. */
    fun recognizerLanguageTag(): String = when (language) {
        "hindi" -> "hi-IN"
        "marathi" -> "mr-IN"
        "english" -> "en-IN"
        "hinglish" -> "hi-IN"
        else -> Locale.getDefault().toLanguageTag()
    }

    /** TTS locale for Devanagari-script lines. Hindi and Marathi share the
     *  script; the chosen language decides which voice reads them. */
    fun devanagariLocale(): Locale =
        if (language == "marathi") Locale("mr", "IN") else Locale("hi", "IN")

    val hasApiKey: Boolean get() = geminiApiKey.isNotBlank()

    companion object {
        const val DEFAULT_MODEL = "models/gemini-3.1-flash-live-preview"
        private const val KEY_API = "gemini_api_key"
        private const val KEY_VOICE = "voice_name"
        private const val KEY_MODEL = "live_model"
        private const val KEY_ANNOUNCE = "announce_callers"
        private const val KEY_OVERLAY = "overlay_enabled"
        private const val KEY_HANDSFREE = "hands_free"
        private const val KEY_AUTOREPLY = "auto_reply_enabled"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_WAKE = "wake_word_enabled"
        private const val KEY_GVOICE = "gemini_voice_enabled"
        /** Female voices first - Aoede is the default (primary female). */
        val VOICES = listOf("Aoede", "Kore", "Puck", "Charon", "Fenrir")
        val VOICE_GENDERS = mapOf(
            "Aoede" to "Female", "Kore" to "Female",
            "Puck" to "Male", "Charon" to "Male", "Fenrir" to "Male"
        )
        val LANGUAGES = listOf("hinglish", "hindi", "marathi", "english", "auto")
        val LANGUAGE_LABELS = mapOf(
            "hinglish" to "Hinglish",
            "hindi" to "\u0939\u093f\u0902\u0926\u0940 (Hindi)",
            "marathi" to "\u092e\u0930\u093e\u0920\u0940 (Marathi)",
            "english" to "English",
            "auto" to "Auto"
        )
    }
}
