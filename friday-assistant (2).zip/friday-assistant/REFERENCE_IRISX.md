# IRIS-X repo — standing reference for FRIDAY

Full clone kept at ~/workspace/iris-x-ref (github.com/IRISX-AI/IRIS-X, 288 files,
HEAD 459ff7b, verified up to date 2026-11-04). Role: design/spec reference ONLY —
its license is dual Commercial & Open-Core (core engine proprietary), so no code
is copied into FRIDAY; features are reimplemented in FRIDAY's own Kotlin.

Verified 2026-11-04 (user pointed at android/app/src/main/java/com):
- android/ = package com.x201harsh.IRISMX, ~40 small Kotlin/Java files (26-186
  lines each) — demo-grade shells. IrisSpeechSynthesizer.kt is only a PCM
  AudioTrack player (USAGE_MEDIA + CONTENT_TYPE_SPEECH); no TTS engine, no
  voices, no languages, no persona anywhere in the repo.
- services/text_to_speech/tts_service.go = 24-line Go stub; stt_service.go 37
  lines. No hi-IN/mr-IN locales, no Hindi/Hinglish/Marathi support in repo.
- One pattern adopted into FRIDAY V1.02 (standard Android practice, mirrored
  from IrisSpeechSynthesizer): play assistant audio on USAGE_MEDIA /
  CONTENT_TYPE_SPEECH so it is reliably audible.
