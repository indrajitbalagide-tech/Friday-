package com.vaani.app

import android.app.KeyguardManager
import android.content.Context
import android.os.Bundle
import android.os.PowerManager
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

/**
 * v5.8 Phone lock / unlock agent.
 *
 * "Hey Vaani, phone unlock karo" ya phone idle/locked ho aur aap bolo "Rohit ko message bhejo" -> Vaani pehle phone ko
 * unlock karti hai: screen jagati hai, lockscreen upar kheenchti hai, password field mein aapka password type karti hai
 * (Accessibility se) aur Enter dabati hai. Phir asli kaam (app_agent / open_app / ...) chalta hai.
 *
 * SAFETY (zaroori, kyunki ye lock ko bypass karne jaisa hai):
 *  - Opt-in: Settings mein "Awaaz se phone unlock" ON + password daalna padta hai. Password Vault (Keystore AES-GCM) mein rehta hai.
 *  - Sirf malik ki pehchani hui awaaz par (VoicePrint match, 90 sec ke andar) - guest / "sirf wake word" / orb-tap par nahi.
 *  - Password kabhi log, chat history, ActionLog ya Gemini ko nahi jata.
 *  - Awaaz-match basic MFCC hai (README mein likha hai: security nahi) - isliye ye convenience feature hai, asli lock ka badal nahi.
 */
object PhoneLock {
    /** VaaniService.tryVerify() jab malik ki awaaz pehchanta hai tab set karta hai. */
    @Volatile var ownerOkAt = 0L
    private const val OWNER_WINDOW_MS = 90_000L

    /** Ye tools activity kholte / screen par kaam karte hain - phone lock ho to pehle unlock chahiye. */
    private val UI_TOOLS = setOf("open_app", "whatsapp", "play_youtube", "settings", "calendar_event", "navigate", "web_search",
        "open_url", "sms", "email", "share_text", "camera", "call", "app_agent", "app_action", "screen_agent", "screen_navigate",
        "screen_control", "screen_read_live", "ocr_screen", "screen_analyse", "look")

    private fun km(c: Context) = c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

    fun isLocked(c: Context): Boolean = try { km(c).isKeyguardLocked } catch (_: Exception) { false }

    fun enabled(c: Context): Boolean = P.of(c).getBoolean("voice_unlock", false) && Vault.has(c, "unlock_pw")

    /** Is tool ke liye unlock chahiye? (lock/wake/unlock wale khud kuch nahi maangte.) */
    private fun needsUnlock(name: String, a: JSONObject): Boolean {
        if (name !in UI_TOOLS) return false
        if (name == "screen_control" && a.optString("action") in setOf("lock_screen", "wake_screen")) return false
        if (name == "look" && a.optString("source") != "screen") return false
        return true
    }

    /**
     * Actions.run se bulao. null = aage badho (unlock ho gaya / zaroorat nahi / feature band),
     * warna user ko batane wala message (kaam mat karo).
     */
    fun ensureUnlockedFor(c: Context, name: String, a: JSONObject): String? {
        if (!needsUnlock(name, a)) return null
        if (!isLocked(c)) return null
        if (!P.of(c).getBoolean("voice_unlock", false)) return null   // feature band: pehle jaisa behaviour
        val r = unlock(c)
        return if (r.startsWith("Phone unlock ho gaya")) null else "Phone lock hai aur unlock nahi ho paya: $r"
    }

    fun lock(c: Context): String =
        Automation.run(c, "screen_control", JSONObject().put("action", "lock_screen")) ?: "Lock nahi ho paya."

    /** Blocking (~4-8 sec) - background thread se bulao (Actions / Live tool thread). */
    @Suppress("DEPRECATION")
    fun unlock(c: Context): String {
        if (!isLocked(c)) return "Phone pehle se unlocked hai."
        if (!P.of(c).getBoolean("voice_unlock", false))
            return "Awaaz se unlock band hai — Vaani Settings mein 'Awaaz se phone unlock' ON karo aur password daalo."
        val pw = Vault.get(c, "unlock_pw") ?: return "Unlock password set nahi hai — Vaani Settings mein daalo."
        if (GuestMode.isGuest(c)) return "Guest mode mein phone unlock nahi hota."
        if (!VoicePrint(c).enrolled()) return "Pehle apni awaaz enroll karo — bina awaaz-pehchaan ke phone unlock nahi karungi."
        if (System.currentTimeMillis() - ownerOkAt > OWNER_WINDOW_MS)
            return "Aapki awaaz pehchani nahi gayi (ya 'sirf wake word' mode on hai) — phone sirf malik ki pehchani hui awaaz par unlock hota hai."
        val acc = VaaniAccess.inst ?: return "Accessibility ON nahi hai — Settings → Accessibility → Vaani ON karo."

        val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "vaani:unlock")
        wl.acquire(25_000)
        try {
            Thread.sleep(800)                       // screen jaagne do
            for (attempt in 1..3) {
                if (!isLocked(c)) return "Phone unlock ho gaya."
                // Lockscreen upar kheencho taaki password field aaye.
                acc.swipeFrac(0.5f, 0.88f, 0.5f, 0.18f, 380)
                Thread.sleep(1000)
                if (typePassword(acc, pw)) {
                    Thread.sleep(1600)
                    if (!isLocked(c)) return "Phone unlock ho gaya."
                }
            }
            return if (!isLocked(c)) "Phone unlock ho gaya."
            else "Password field nahi mila ya galat gaya. Is phone par lockscreen ke elements Accessibility ko dikh nahi rahe ho sakte — haath se unlock karo."
        } catch (e: Exception) {
            return "Unlock mein dikkat: ${e.message?.take(60)}"
        } finally {
            try { if (wl.isHeld) wl.release() } catch (_: Exception) {}
        }
    }

    /** Password field mein set-text + Enter; na mile to (sirf digits wala password ho to) PIN-pad ke keys dabao. */
    private fun typePassword(acc: VaaniAccess, pw: String): Boolean {
        val edit: AccessibilityNodeInfo? = acc.findEditable()
        if (edit != null) {
            try { edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS); edit.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) {}
            val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, pw)
            if (edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) {
                Thread.sleep(500)
                submit(acc, edit)
                return true
            }
        }
        if (pw.all { it.isDigit() }) {
            var allOk = true
            for (ch in pw) { if (!acc.tapTextAnywhere(ch.toString())) allOk = false; Thread.sleep(160) }
            if (allOk) { Thread.sleep(300); submit(acc, null); return true }
        }
        return false
    }

    private fun submit(acc: VaaniAccess, edit: AccessibilityNodeInfo?) {
        var done = false
        if (android.os.Build.VERSION.SDK_INT >= 30 && edit != null) {
            try { done = edit.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) } catch (_: Exception) {}
        }
        if (!done) {
            for (label in listOf("Enter", "OK", "Done", "Go", "Unlock")) { if (acc.tapTextAnywhere(label)) { done = true; break } }
        }
    }
}

/** Gemini tools: phone_unlock / phone_lock. */
object PhoneLockTools {
    private fun fn(name: String, desc: String): JSONObject = JSONObject().put("name", name).put("description", desc)

    fun decls(): List<JSONObject> = listOf(
        fn("phone_unlock", "Phone ka lockscreen khol do: screen jagao aur malik ka password type karke unlock karo. Sirf tab jab malik bole 'phone unlock karo' ya kaam ke liye unlocked screen chahiye."),
        fn("phone_lock", "Phone ko lock kar do.")
    )

    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "phone_unlock" -> PhoneLock.unlock(c)
        "phone_lock" -> PhoneLock.lock(c)
        else -> null
    }
}
