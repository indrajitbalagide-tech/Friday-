package com.vaani.app

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Messaging notifications:
 * - Naya message aaye to sirf BATATA hai ("X ka message aaya hai") - poora content khud nahi padhta.
 * - Auto-reply ON ho to jawab soch kar pehle POOCHTA hai; bhejta sirf tab hai jab user haan bole
 *   (pending_reply tool se, Actions ke through).
 *
 * FEATURE 2 - ROOT CAUSE (kyun poora message nahi milta tha):
 *  1. Sirf EXTRA_TITLE / EXTRA_TEXT padha jata tha. Lambe messages mein Android poora text
 *     EXTRA_BIG_TEXT mein rakhta hai, group chats mein EXTRA_TEXT_LINES mein, aur WhatsApp/
 *     Telegram jaise apps mein MessagingStyle messages mein - isliye content kata hua ya
 *     bilkul missing milta tha.
 *  2. Har burst par "batau kya?" poochha jata tha aur pendingRead mein sirf AAKHRI chhota
 *     text rakha jata tha - beech ke messages ka poora content kahin save hi nahi hota tha.
 * FIX (neeche): EXTRA_BIG_TEXT -> EXTRA_TEXT_LINES -> MessagingStyle -> EXTRA_TEXT, sabse
 *  lamba/best text rakho; timestamped history "nhist2" mein (200 tak); priority classify karke
 *  zaroori wali turant bolo, spam/low sirf log karo; OTP ke digits kabhi mat bolo.
 *
 * ACTIONS.KT WIRING (coordinator - is file ko chhoone ke baad Actions.kt mein 1 line badlo):
 *   PEHLE:  else -> Extras.run(c, name, a) ?: Automation.run(c, name, a) ?: "Ye action abhi nahi aata."
 *   BAAD:   else -> NotifService.NotifTools.dispatch(c, name, a) ?: Extras.run(c, name, a) ?: Automation.run(c, name, a) ?: "Ye action abhi nahi aata."
 *  (Wiring na bhi ho to purana Extras "notif_summary" fallback ke roop mein chalta rahega.)
 */
class NotifService : NotificationListenerService() {
    companion object {
        val recent: MutableList<Pair<String, String>> = java.util.Collections.synchronizedList(mutableListOf())
        private val lastReply = HashMap<String, Long>()
        private val lastSeen = HashMap<String, Long>()
        private val APPS = setOf("com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
            "com.instagram.android", "com.google.android.apps.messaging")

        @Volatile private var appCtx: Context? = null

        // Permission wala pending jawab - user ke haan bolne ka intezaar karta hai.
        @Volatile var pendingSender: String? = null
        @Volatile var pendingDraft: String? = null
        @Volatile private var pendingAction: Notification.Action? = null
        @Volatile private var pendingCtx: Context? = null

        // Content padhna pending - user ki haan ka intezaar. pendingReadText mein hamesha
        // burst ka POORA text hota hai (sirf aakhri chhota tukda nahi).
        @Volatile var pendingReadApp: String? = null
        @Volatile var pendingReadSender: String? = null
        @Volatile private var pendingReadText: String? = null
        @Volatile private var pendingReadPriority: String? = null

        // ---- Priority classifier: keyword lists yahin edit karo (in-file, editable) ----
        private val OTP_RE = Regex("(?i)(otp|one[- ]time pass(code|word)|verification code|login code)")
        private val BANK_PKGS = setOf("com.google.android.apps.nbu.paisa.user", "com.phonepe.app", "net.one97.paytm", "com.gpay")
        private val BANK_KW = listOf("hdfc", "sbi", "icici", "axis", "kotak", "pnb", "bank of baroda", "bob", "yes bank", "idfc",
            "upi", "debit", "credit", "credited", "debited", "transaction", "account", "balance", "₹", "rs.", "inr",
            "payment received", "payment successful", "salary", "emi", "bill due")
        private val WORK_PKGS = setOf("com.google.android.gm", "com.microsoft.office.outlook", "com.slack",
            "com.google.android.apps.meetings", "com.microsoft.teams", "com.whatsapp.w4b")
        // WORK_SENDERS: apne boss/manager ke naam ya number yahan jodo, jaise "rahul sir" ya "98765".
        private val WORK_SENDERS = setOf<String>()
        private val WORK_KW = listOf("boss", "manager", "office", "meeting", "deadline", "team lead", "sir ", "ma'am", " hr ", "client")
        private val DELIVERY_PKGS = setOf("com.swiggy.android", "com.application.zomato", "in.amazon.mShop.android.shopping",
            "com.flipkart.android", "com.grofers.customerapp", "in.swiggy.android", "com.zepto")
        private val DELIVERY_KW = listOf("swiggy", "zomato", "amazon", "flipkart", "delivery", "out for delivery", "shipped",
            "order", "arriving", "delivered", "courier", "blinkit", "zepto", "dunzo")
        private val SPAM_KW = listOf("offer", "discount", "% off", "sale", "promo", "coupon", "win ", "winner",
            "congratulations", "limited time", "hurry", "claim now", "free gift", "lottery", "cashback offer")

        /** Zaroori priorities (turant bolne wali). */
        val IMPORTANT = setOf("otp", "bank", "work", "delivery")

        /** Priority: "otp" | "bank" | "work" | "delivery" | "spam" | "normal".
         *  OTP kabhi bolna nahi - sirf "OTP aaya hai" bolte hain. */
        fun classifyPriority(pkg: String, sender: String, text: String): String {
            val t = "$sender $text".lowercase()
            if (OTP_RE.containsMatchIn(t)) return "otp"
            if (pkg in BANK_PKGS || BANK_KW.any { t.contains(it) }) return "bank"
            if (pkg in WORK_PKGS || WORK_SENDERS.any { it.isNotEmpty() && sender.lowercase().contains(it.lowercase()) }
                || WORK_KW.any { t.contains(it) }) return "work"
            if (pkg in DELIVERY_PKGS || DELIVERY_KW.any { t.contains(it) }) return "delivery"
            // Spam sirf tab jab 2+ spam words hon — ek "offer"/"sale" word se asli message
            // kabhi nahi girna chahiye (pehle ek word hi kaafi tha, isliye legit messages chup ho jate the).
            if (SPAM_KW.count { t.contains(it) } >= 2) return "spam"
            return "normal"
        }

        /** Priority ki ranking (burst mein sabse zaroori wali jeette hai). */
        private fun rank(p: String) = when (p) { "otp" -> 5; "bank", "work" -> 4; "delivery" -> 3; "normal" -> 2; else -> 1 }

        /** nhist2 history padho: [{app, sender, text, time, priority, pkg}] (nayi pehle nahi, purani pehle). */
        private fun hist2(ctx: Context): JSONArray =
            try { JSONArray(ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE).getString("nhist2", "[]")) }
            catch (e: Exception) { JSONArray() }

        private fun timeStr(t: Long): String =
            SimpleDateFormat("HH:mm", Locale.US).format(Date(t))

        /** OTP wale item ka text tool output mein kabhi digits ke saath nahi jata. */
        private fun safeText(o: JSONObject): String =
            if (o.optString("priority") == "otp") "OTP aaya hai (code nahi bola jata)"
            else o.optString("text").replace('\n', ' ').take(120)

        /** sinceMs ke baad ki zaroori notifications ka ek-line Hinglish summary.
         *  Bina Context wala version service ke appCtx se padhta hai. */
        fun summarySince(sinceMs: Long): String =
            appCtx?.let { summarySince(it, sinceMs) } ?: "Notification history abhi available nahi hai."

        fun summarySince(ctx: Context, sinceMs: Long): String {
            val arr = hist2(ctx)
            val imp = ArrayList<JSONObject>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                if (o.optLong("time") < sinceMs) continue
                if (o.optString("priority") in IMPORTANT) imp.add(o)
            }
            if (imp.isEmpty()) return "Us samay se koi zaroori notification nahi aaya."
            val lines = imp.takeLast(5).map { "${it.optString("app")} — ${it.optString("sender")}: ${safeText(it)}" }
            return "Us samay se ${imp.size} zaroori cheezein: " + lines.joinToString("; ") + "."
        }

        /** Kisi app/sender ke notifications ka poora text, nayi pehle. */
        fun readFor(appOrSender: String): String =
            appCtx?.let { readFor(it, appOrSender) } ?: "Notification history abhi available nahi hai."

        fun readFor(ctx: Context, appOrSender: String): String {
            val q = appOrSender.trim().lowercase()
            if (q.isEmpty()) return "Kis app ya sender ki notifications padhun?"
            val arr = hist2(ctx)
            val hits = ArrayList<JSONObject>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                if (o.optString("app").lowercase().contains(q) || o.optString("sender").lowercase().contains(q)
                    || o.optString("pkg").lowercase().contains(q)) hits.add(o)
            }
            if (hits.isEmpty()) return "'$appOrSender' se koi notification record nahi hai."
            return hits.takeLast(5).reversed().joinToString("\n") {
                "${timeStr(it.optLong("time"))} — ${it.optString("sender")} (${it.optString("app")}): " +
                    if (it.optString("priority") == "otp") "OTP aaya hai (code nahi bola jata)"
                    else it.optString("text").take(500)
            }
        }

        /** Haal ki zaroori notifications (nayi pehle), limit tak. */
        fun recentImportant(limit: Int): List<JSONObject> =
            appCtx?.let { recentImportant(it, limit) } ?: emptyList()

        fun recentImportant(ctx: Context, limit: Int): List<JSONObject> {
            val arr = hist2(ctx); val out = ArrayList<JSONObject>()
            for (i in arr.length() - 1 downTo 0) {
                val o = arr.optJSONObject(i) ?: continue
                if (o.optString("priority") in IMPORTANT) {
                    out.add(o)
                    if (out.size >= limit.coerceIn(1, 20)) break
                }
            }
            return out
        }

        /** User ne faisla diya: read=true to pending message ka content batao, warna gira do. */
        fun respondRead(read: Boolean): String {
            val app = pendingReadApp; val sender = pendingReadSender; val text = pendingReadText
            val prio = pendingReadPriority
            pendingReadApp = null; pendingReadSender = null; pendingReadText = null; pendingReadPriority = null
            if (sender == null || text == null) return "Kuch padhna pending nahi hai."
            if (!read) return "Theek hai, nahi padhta."
            // OTP: user ne haan bhi bola ho to digits kabhi nahi bolte.
            if (prio == "otp") return "$app — $sender: OTP aaya hai (code nahi bola jata)."
            return "$app — $sender: \"$text\""
        }

        /** User ne faisla diya: send=true to pending jawab bhej do, warna gira do. */
        fun respondPending(send: Boolean): String {
            val action = pendingAction; val sender = pendingSender; val draft = pendingDraft; val ctx = pendingCtx
            pendingAction = null; pendingSender = null; pendingDraft = null; pendingCtx = null
            if (sender == null || draft == null) return "Koi jawab pending nahi hai."
            if (!send) return "$sender ko jawab nahi bheja."
            if (action == null || ctx == null) return "Us message ka reply button nahi mila, bhej nahi paya."
            return try {
                val ri = action.remoteInputs[0]; val intent = Intent(); val b = Bundle()
                b.putCharSequence(ri.resultKey, draft)
                RemoteInput.addResultsToIntent(action.remoteInputs, intent, b)
                action.actionIntent.send(ctx, 0, intent)
                "$sender ko jawab bhej diya: \"$draft\""
            } catch (e: Exception) { "Jawab bhejne mein dikkat: ${e.message?.take(60)}" }
        }

        /** v5.3 diagnostics: aakhri notification / aakhri bolna / drop ki wajah prefs mein,
         *  taaki "bol kyu nahi raha" ka jawab phone par hi mil jaye. */
        private fun diag(ctx: Context, key: String, value: String) {
            try { ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE).edit().putString(key, value).apply() } catch (_: Exception) {}
        }
        private fun diagLong(ctx: Context, key: String, value: Long) {
            try { ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE).edit().putLong(key, value).apply() } catch (_: Exception) {}
        }

        /** Notification access ON hai ya nahi (Settings.Secure wali list se). */
        fun listenerOn(ctx: Context): Boolean =
            (android.provider.Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: "")
                .contains(ctx.packageName)

        /** "Notification test karo" — fast path se test line bolo aur report karo. */
        fun testSpeak(ctx: Context): String {
            if (!listenerOn(ctx)) return "Notification access OFF hai — pehle Settings mein Vaani ko notification access do, phir test karo."
            Speaker.speakNow(ctx, "Notification test: main bol rahi hun. Agar ye sunai de raha hai to notifications bolna chalu hai.")
            diagLong(ctx, "notif_last_spoken_at", System.currentTimeMillis())
            diag(ctx, "notif_last_spoken", "test line")
            return "Test line Gemini ki awaaz mein bhej di. Sunai di to notification bolna chalu hai. Na sunai de to chat box mein wajah likhi aayegi."
        }

        /** Listener + aakhri notification + aakhri bolna, ek short Hinglish report. */
        fun statusText(ctx: Context): String {
            val p = ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE)
            val on = listenerOn(ctx)
            val lastAt = p.getLong("notif_last_at", 0L)
            val lastApp = p.getString("notif_last_app", "") ?: ""
            val lastSender = p.getString("notif_last_sender", "") ?: ""
            val spokenAt = p.getLong("notif_last_spoken_at", 0L)
            val drop = p.getString("notif_last_drop", "") ?: ""
            val key = p.getString("key", "").orEmpty()
            fun ago(t: Long) = if (t == 0L) "kabhi nahi" else "${(System.currentTimeMillis() - t) / 1000} sec pehle"
            return "Notification access: " + (if (on) "ON" else "OFF — Settings mein ON karo") +
                ". Aakhri notification: " + (if (lastAt == 0L) "koi nahi aaya" else "$lastApp — $lastSender (${ago(lastAt)})") +
                ". Aakhri baar bola: ${ago(spokenAt)}." +
                (if (drop.isNotEmpty()) " Aakhri drop: $drop." else "") +
                " API key: " + (if (key.isEmpty()) "nahi hai" else "hai") + "."
        }
    }

    /** Notification tools ka dispatcher (Gemini.kt ke notifDecls ke liye).
     *  Naam pehchana nahi to null - Actions.kt uske baad Extras/Automation try karega. */
    object NotifTools {
        fun dispatch(ctx: Context, name: String, args: JSONObject): String? = when (name) {
            "notif_summary" -> NotifService.summarySince(ctx, System.currentTimeMillis() - args.optInt("since_hours", 12) * 3600_000L)
            "notif_read" -> NotifService.readFor(ctx, args.optString("who"))
            "notif_status" -> NotifService.statusText(ctx)
            "notif_test" -> NotifService.testSpeak(ctx)
            else -> null
        }
    }

    override fun onCreate() {
        super.onCreate()
        appCtx = applicationContext
    }

    /** Listener jud gaya — Android ne service bind ki. */
    override fun onListenerConnected() {
        super.onListenerConnected()
        appCtx = applicationContext
        diagLong(this, "notif_listener_connected_at", System.currentTimeMillis())
        diag(this, "notif_listener_on", "true")
        VaaniService.log?.invoke("🔔 Notification listener jud gaya.")
    }

    /** Listener toot gaya (update/reboot/battery-kill) — turant dobara bind karne ko bolo. */
    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        diagLong(this, "notif_listener_disconnected_at", System.currentTimeMillis())
        diag(this, "notif_listener_on", "false")
        VaaniService.log?.invoke("⚠ Notification listener toot gaya — dobara judne ki koshish.")
        try {
            NotificationListenerService.requestRebind(android.content.ComponentName(this, NotifService::class.java))
        } catch (e: Exception) {
            VaaniService.log?.invoke("⚠ Listener dobara nahi juda: ${e.message?.take(60)} — Settings mein notification access dobara ON karo.")
        }
    }

    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val bursts = HashMap<String, Burst>()

    private class Burst(val app: String, val sender: String, val chat: Boolean) {
        var count = 0; var latest = ""; val texts = ArrayList<String>(); var priority = "normal"
        var action: Notification.Action? = null; var runnable: Runnable? = null
    }

    private fun appLabel(pkg: String): String = try {
        val ai = packageManager.getApplicationInfo(pkg, 0)
        packageManager.getApplicationLabel(ai).toString()
    } catch (e: Exception) {
        when (pkg) { "com.whatsapp", "com.whatsapp.w4b" -> "WhatsApp"; "org.telegram.messenger" -> "Telegram"
            "com.instagram.android" -> "Instagram"; else -> "Messages" }
    }

    /**
     * Poora notification text nikalo. ROOT CAUSE FIX: sirf EXTRA_TEXT padhne se
     * lambe messages (EXTRA_BIG_TEXT), multi-line/grouped chats (EXTRA_TEXT_LINES) aur
     * MessagingStyle chats ke messages kat jate the. Yahan saare candidates jama karke
     * sabse lamba/best text rakhte hain.
     */
    /**
     * MessagingStyle ka data seedha notification extras se nikalo.
     * Notification.MessagingStyle.extractMessagingStyleFromNotification() public
     * SDK API mein nahi hai (javap se verify), isliye extras keys padhte hain:
     * "android.messages" (Bundle array: text/sender/time) aur
     * "android.conversationTitle".
     */
    private fun messagingMessages(n: Notification): List<String> {
        val arr = n.extras.getParcelableArray("android.messages") ?: return emptyList()
        return arr.mapNotNull { p ->
            val b = p as? Bundle ?: return@mapNotNull null
            val t = (b.getCharSequence("text") ?: b.getCharSequence("android.text"))
                ?.toString()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val s = (b.getCharSequence("sender") ?: b.getCharSequence("android.sender"))
                ?.toString()?.takeIf { it.isNotBlank() }
                ?: (b.getParcelable("sender_person") as? android.app.Person)?.name?.toString()?.takeIf { it.isNotBlank() }
            if (s != null) "$s: $t" else t
        }
    }

    private fun messagingTitle(n: Notification): String? =
        n.extras.getCharSequence("android.conversationTitle")?.toString()?.takeIf { it.isNotBlank() }

    private fun fullText(n: Notification): String {
        val cands = ArrayList<String>()
        n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.takeIf { it.isNotBlank() }?.let { cands.add(it) }
        n.extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.let { lines ->
            lines.mapNotNull { it?.toString()?.takeIf { s -> s.isNotBlank() } }
                .joinToString("\n").takeIf { it.isNotBlank() }?.let { cands.add(it) }
        }
        messagingMessages(n).joinToString("\n").takeIf { it.isNotBlank() }?.let { cands.add(it) }
        n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.takeIf { it.isNotBlank() }?.let { cands.add(it) }
        return cands.maxByOrNull { it.length } ?: ""
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        val pkg = sbn.packageName
        // Ab SAARE apps ke notifications (sirf messaging nahi) - bas shor wale chhodo:
        // apna app, system UI, group-summary, chal-rahi (ongoing) aur progress (download %) wali.
        if (pkg == packageName || pkg == "android" || pkg.startsWith("com.android.systemui")) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        // Chalti hui (ongoing) notification chhodo - par call / message category wali nahi (kuch apps unhe ongoing mark karte hain).
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0 &&
            n.category != Notification.CATEGORY_MESSAGE && n.category != Notification.CATEGORY_EMAIL) return
        // v5.8 ROOT-CAUSE FIX: pehle yahan `extras.containsKey(EXTRA_PROGRESS)` tha. kai Android versions mein normal
        // notification ke extras mein bhi android.progress=0 / progressMax=0 hota hai, isliye containsKey true ho kar notifications
        // chup-chaap drop ho sakti thi (kuch bola hi nahi). Ab sirf asli progress bar (max>0 ya indeterminate) chhodte hain.
        if (n.extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0) > 0 ||
            n.extras.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: messagingTitle(n)
            ?: appLabel(pkg)
        val text = fullText(n)
        if (text.isBlank()) { diag(this, "notif_last_drop", "blank text (${appLabel(pkg)})"); return }
        // Dedup: ek hi notification (pkg+sender+poora text hash+sbn.key) 30 sec mein dobara nahi;
        // same sender+text 10 sec mein dobara nahi (notification update ki dohri khabar rokne ke liye).
        val now = System.currentTimeMillis()
        val dedupKey = pkg + "|" + title + "|" + text.hashCode() + "|" + sbn.key
        val senderTextKey = pkg + "|" + title + "|" + text.hashCode()
        synchronized(lastSeen) {
            if (now - (lastSeen[dedupKey] ?: 0L) < 30_000) return
            if (now - (lastSeen[senderTextKey] ?: 0L) < 10_000) return
            lastSeen[dedupKey] = now; lastSeen[senderTextKey] = now
            if (lastSeen.size > 500) lastSeen.entries.removeIf { now - it.value > 60_000 }
        }
        recent.add(title to text); if (recent.size > 30) recent.removeAt(0)
        // Pakki history (smart summary ke liye): poora text + priority ke saath, aakhri 200.
        val prio = classifyPriority(pkg, title, text)
        diagLong(this, "notif_last_at", now)
        diag(this, "notif_last_app", appLabel(pkg))
        diag(this, "notif_last_sender", title)
        diag(this, "notif_last_drop", "")
        try {
            val hp = getSharedPreferences("vaani", MODE_PRIVATE)
            val h2 = try { JSONArray(hp.getString("nhist2", "[]")) } catch (e: Exception) { JSONArray() }
            h2.put(JSONObject().put("app", appLabel(pkg)).put("sender", title).put("text", text)
                .put("time", now).put("priority", prio).put("pkg", pkg))
            while (h2.length() > 200) h2.remove(0)
            // Purani "nhist" bhi likhte raho (compat - Extras.notifSummary aur purane code ke liye).
            val hArr = try { JSONArray(hp.getString("nhist", "[]")) } catch (e: Exception) { JSONArray() }
            hArr.put(JSONObject().put("app", appLabel(pkg)).put("t", title).put("x", text))
            while (hArr.length() > 100) hArr.remove(0)
            hp.edit().putString("nhist2", h2.toString()).putString("nhist", hArr.toString()).apply()
        } catch (e: Exception) {}

        // 1) Burst jama karo: ek hi bande ke lagataar messages par har baar NAHI bolna hai.
        //    Zaroori (bank/work/delivery/OTP) wale burst ka intezaar nahi karte - 300ms mein bolte hain.
        //    Baaki wale 2.5 second ki chuppi ke baad EK baar, ginti ke saath.
        val app = appLabel(sbn.packageName)
        val bKey = sbn.packageName + "|" + title
        val replyAction = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
        synchronized(bursts) {
            val b = bursts.getOrPut(bKey) { Burst(app, title, pkg in APPS) }
            b.count++; b.latest = text; b.texts.add(text)
            if (rank(prio) > rank(b.priority)) b.priority = prio
            b.action = replyAction
            b.runnable?.let { handler.removeCallbacks(it) }
            val r = Runnable { fireBurst(bKey) }
            b.runnable = r; handler.postDelayed(r, if (b.priority in IMPORTANT) 200L else 1200L)
        }
    }

    private fun fireBurst(bKey: String) {
        val b = synchronized(bursts) { bursts.remove(bKey) } ?: return
        // pendingRead mein burst ka POORA text (saare messages jode hue), sirf aakhri tukda nahi.
        val full = b.texts.joinToString("\n").take(2000)
        AgentStatus.khabar = "${b.sender} (${b.app}) • ${AgentStatus.time()}"; AgentStatus.khabarAt = System.currentTimeMillis()
        if (b.priority == "spam") {
            // Low/spam: sirf log + history, bolna nahi.
            diag(this, "notif_last_drop", "spam (${b.app} — ${b.sender})")
            VaaniService.log?.invoke("🔕 ${b.app}: ${b.sender} (spam/low, bola nahi)")
            return
        }
        pendingReadApp = b.app; pendingReadSender = b.sender; pendingReadText = full; pendingReadPriority = b.priority
        // v5.4 REAL-TIME BOLNA: content turant, poora, Gemini ki awaaz mein (speakNow = queue mein sabse aage).
        // Pehle sirf "message aaya hai, batau kya?" bolta tha aur jawab ka intezaar karta tha —
        // isiliye real time mein kuch bola hi nahi jata tha. Ab "batau kya?" ka gate nahi hai.
        // OTP: sirf "OTP aaya hai" — digits kabhi nahi. Gaadi mode mein bhi yahi rasta bolta hai.
        val clean = b.latest.replace('\n', ' ').take(200)
        val spoken = when {
            b.priority == "otp" -> "OTP aaya hai, ${b.app} se."
            b.count > 1 -> "${b.app} par ${b.sender} ke ${b.count} message aaye hain: $clean"
            else -> "${b.app} par ${b.sender}: $clean"
        }
        val p0 = getSharedPreferences("vaani", MODE_PRIVATE)
        VaaniService.log?.invoke("🔔 $spoken")
        diagLong(this, "notif_last_spoken_at", System.currentTimeMillis())
        diag(this, "notif_last_spoken", spoken.take(80))
        if (p0.getBoolean("notif_speak", true)) Speaker.speakNow(this, spoken)
        else diag(this, "notif_last_drop", "notif_speak toggle OFF (settings mein ON karo)")

        // 2) Auto-reply: sirf AAKHRI message ka jawab socho, bhejne se pehle poochho. Spam upar hi return ho chuka hai.
        val p = getSharedPreferences("vaani", MODE_PRIVATE)
        if (!p.getBoolean("auto", false)) return
        val key = p.getString("key", "").orEmpty(); if (key.isEmpty()) return
        val action = b.action ?: return
        val sender = b.sender; val text = b.latest
        val now = System.currentTimeMillis()
        synchronized(lastReply) { if (now - (lastReply[sender] ?: 0L) < 60_000) return; lastReply[sender] = now }
        Thread {
            try {
                // useTools=false: incoming text can never trigger phone actions.
                val parts = Gemini.ask(key, "Mere dost $sender ka message: \"$text\". Meri taraf se ek chhota friendly " +
                    "Hinglish jawab likho. Sirf jawab ka text do.", false)
                val reply = (0 until parts.length()).mapNotNull { parts.getJSONObject(it).optString("text").ifEmpty { null } }
                    .joinToString(" ").trim()
                if (reply.isEmpty()) return@Thread
                pendingSender = sender; pendingDraft = reply; pendingAction = action; pendingCtx = applicationContext
                VaaniService.log?.invoke("💬 $sender ke liye jawab socha hai: \"$reply\" — bolna hai to \"bhej do\" bolo")
                Speaker.speak(this, "$sender ko ye jawab socha hai: $reply. Bhej dun?")
            } catch (_: Exception) {}
        }.start()
    }
}
