package com.vaani.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.media.audiofx.AcousticEchoCanceler
import android.os.Bundle
import android.text.InputType
import android.widget.*

/** Vaani 4.0 settings: naam/title, Home Assistant, PC bridge, wake word key, briefing, barge-in. Badlav restart par lagte hain. */
class SettingsActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("vaani", MODE_PRIVATE) }
    private val fields = ArrayList<Pair<String, EditText>>()
    private var unlockPw: EditText? = null

    private fun saveUnlockPw() {
        val v = unlockPw?.text?.toString().orEmpty()
        if (v.isNotEmpty()) { Vault.put(this, "unlock_pw", v); unlockPw?.setText("") }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(root: LinearLayout, t: String) = root.addView(TextView(this).apply {
        text = t; textSize = 9f; letterSpacing = 0.2f; setTextColor(Color.parseColor("#C47F8C")); setPadding(0, dp(12), 0, dp(2)) })

    private fun field(root: LinearLayout, key: String, title: String, hint: String, secret: Boolean = false) {
        label(root, title)
        val e = EditText(this).apply {
            setText(prefs.getString(key, "")); this.hint = hint; setSingleLine(); textSize = 13f
            setTextColor(Color.parseColor("#EAF9FF")); setHintTextColor(Color.parseColor("#7A4A55"))
            setBackgroundColor(Color.parseColor("#04121F")); setPadding(dp(10), dp(8), dp(10), dp(8))
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        fields.add(key to e); root.addView(e)
    }

    private fun toggle(root: LinearLayout, key: String, title: String, def: Boolean) {
        val sw = Switch(this).apply { text = title; setTextColor(Color.WHITE); isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply() } }
        root.addView(sw, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(26), dp(16), dp(20)) }
        root.addView(TextView(this).apply { text = "VAANI SETTINGS"; textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply { text = "Badlav 'Hands-free' dobara chalu karne par lagte hain."; textSize = 11f
            setTextColor(Color.parseColor("#C47F8C")) })

        field(root, "title", "AAPKO KYA BULAYE (boss / sir / naam)", "boss")
        field(root, "pv_key", "WAKE WORD — PICOVOICE ACCESS KEY (picovoice.ai, free). Khali = sirf awaaz-match", "AccessKey", true)
        toggle(root, "wake_strict", "Sirf 'Hey Vaani' / 'Vaani' bolne par jawab do aur kaam karo (ON rakho)", true)
        field(root, "wake_words", "EXTRA WAKE WORDS (comma se, jaise: wani, bani) — Gemini 'Vaani' ko galat likhe to yahan jodo", "wani, bani")
        toggle(root, "wake_only", "Sirf wake word (awaaz-match band)", false)
        toggle(root, "notif_speak", "Notifications real-time bolo", true)
        toggle(root, "announce", "Call aane par bolo (kiska call hai)", true)
        toggle(root, "tts_fallback", "Gemini awaaz na mile to phone ki awaaz se zaroori khabar bolo", true)
        toggle(root, "voice_unlock", "Awaaz se phone unlock (neeche password daalna zaroori)", false)
        label(root, "PHONE UNLOCK PASSWORD (Keystore mein encrypted; khali chhodo = jaisa hai waisa rahe)")
        unlockPw = EditText(this).apply {
            hint = if (Vault.has(this@SettingsActivity, "unlock_pw")) "●●●●●● (set hai — naya daalo to badal jayega)" else "password / PIN"
            setSingleLine(); textSize = 13f
            setTextColor(Color.parseColor("#EAF9FF")); setHintTextColor(Color.parseColor("#7A4A55"))
            setBackgroundColor(Color.parseColor("#04121F")); setPadding(dp(10), dp(8), dp(10), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(unlockPw)
        root.addView(Button(this).apply { text = "🗑 Saved unlock password hatao"; setOnClickListener {
            Vault.put(this@SettingsActivity, "unlock_pw", ""); prefs.edit().putBoolean("voice_unlock", false).apply()
            Toast.makeText(this@SettingsActivity, "Password hata diya, voice unlock band", Toast.LENGTH_SHORT).show() } })
        toggle(root, "bargein", "Barge-in (beech mein bolo to Vaani ruke)", AcousticEchoCanceler.isAvailable())
        toggle(root, "brief_on", "Subah ka briefing", true)
        field(root, "brief_time", "BRIEFING KA SAMAY (HH:MM)", "07:30")
        field(root, "ha_url", "HOME ASSISTANT URL", "http://192.168.1.10:8123")
        field(root, "ha_token", "HOME ASSISTANT LONG-LIVED TOKEN", "token", true)
        field(root, "pc_url", "PC BRIDGE URL", "http://192.168.1.20:8765")
        field(root, "pc_token", "PC BRIDGE TOKEN", "token", true)

        root.addView(Button(this).apply { text = "💾 SAVE"; setOnClickListener {
            val ed = prefs.edit(); for ((k, e) in fields) ed.putString(k, e.text.toString().trim()); ed.apply()
            saveUnlockPw()
            Toast.makeText(this@SettingsActivity, "Save ho gaya", Toast.LENGTH_SHORT).show() } },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        root.addView(Button(this).apply { text = "🔊 Briefing abhi sunao"; setOnClickListener {
            val ed = prefs.edit(); for ((k, e) in fields) ed.putString(k, e.text.toString().trim()); ed.apply()
            Thread { Speaker.speak(this@SettingsActivity, Briefing.make(this@SettingsActivity)) }.start() } })
        root.addView(Button(this).apply { text = "🗑 Vaani ki yaadasht dekho/saaf karo"; setOnClickListener {
            showMemory(this@SettingsActivity) } })

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0A0207")); addView(root) })
    }

    override fun onPause() { val ed = prefs.edit(); for ((k, e) in fields) ed.putString(k, e.text.toString().trim()); ed.apply(); saveUnlockPw(); super.onPause() }

    private fun showMemory(a: Activity) {
        val mem = Memory.recall(a, "")
        android.app.AlertDialog.Builder(a).setTitle("Vaani ko yaad hai").setMessage(mem)
            .setPositiveButton("Sab bhula do") { _, _ -> P.of(a).edit().remove("mem").apply() }
            .setNegativeButton("Theek hai", null).show()
    }
}
