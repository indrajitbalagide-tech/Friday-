package com.vaani.app

import android.content.Context

/**
 * v5.8 WAKE GATE — "Hey Vaani" / "Vaani" ke bina Vaani na bole, na koi kaam kare.
 *
 * Pehle: aapki awaaz match hote hi Gemini Live khul jata tha aur wo har baat ka jawab de deta tha
 * (aap kisi aur se baat kar rahe ho tab bhi). Ab LiveClient har turn ka transcript dekhta hai:
 *  - transcript mein wake word (Vaani / Vani / वाणी ...) ho  -> jawab + tools chalenge
 *  - na ho -> Vaani ki awaaz band (audio drop), koi tool nahi chalta, session turant band
 *
 * Do jagah bina wake word ke bhi chalta hai (kyunki Vaani ne khud poochha ya aapne khud jagaya):
 *  1. Follow-up window: Vaani ne sawal poocha ("answer karun?", "bhej dun?") -> agle ~9 sec ka jawab
 *  2. Explicit start: orb tap, Picovoice wake word hit, bajti call, car-mode connect -> ~12 sec
 * Settings mein "Sirf 'Hey Vaani' par jawab do" toggle (wake_strict, default ON) se band kar sakte ho.
 */
object WakeGate {
    private val DEFAULT_WORDS = setOf("vaani", "vani", "vaanee", "vanee", "wani", "waani", "vany", "vaany",
        "vanni", "vaanii", "वाणी", "वानी", "वाणि", "वाँणी")
    private val FILLER = setOf("hey", "hi", "hello", "ok", "okay", "oye", "are", "arre", "sun", "suno", "listen", "ji",
        "हे", "हाय", "हेलो", "ओके", "सुनो", "सुन", "ओए", "अरे", "जी")
    private val SPLIT = Regex("[^\\p{L}\\p{M}\\p{N}]+")
    private val QUESTION = Regex("(?i)(\\?|karun|kar dun|bhejun|bhej dun|batau|bataun|padhun|padh dun|haan bolo|bolo na|chalu karun)")

    /** Is waqt tak bina wake word ke agla jawab maana jayega. */
    @Volatile var followUpUntil = 0L
    @Volatile var lastReject = 0L

    fun strict(c: Context): Boolean = P.of(c).getBoolean("wake_strict", true)

    private fun words(c: Context): Set<String> {
        val extra = (P.of(c).getString("wake_words", "") ?: "").split(",")
            .map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        return DEFAULT_WORDS + extra
    }

    private fun tokens(text: String): List<String> =
        text.lowercase().split(SPLIT).filter { it.isNotEmpty() }

    /** Transcript mein koi wake word token hai? */
    fun matches(c: Context, text: String): Boolean {
        if (text.isBlank()) return false
        val w = words(c)
        return tokens(text).any { it in w }
    }

    /** Sirf "Hey Vaani" / "Vaani sun" jaisa — command baad mein aayega. */
    fun isWakeOnly(c: Context, text: String): Boolean {
        val w = words(c)
        val rest = tokens(text).filter { it !in w && it !in FILLER }
        return matches(c, text) && rest.isEmpty()
    }

    /** Vaani ne sawal poochha ho to True (jawab ka follow-up window khulega). */
    fun looksLikeQuestion(botText: String): Boolean = QUESTION.containsMatchIn(botText)

    fun openFollowUp(ms: Long) { followUpUntil = maxOf(followUpUntil, System.currentTimeMillis() + ms) }
    fun followUpOpen(): Boolean = System.currentTimeMillis() < followUpUntil
    fun consumeFollowUp() { followUpUntil = 0L }
}
