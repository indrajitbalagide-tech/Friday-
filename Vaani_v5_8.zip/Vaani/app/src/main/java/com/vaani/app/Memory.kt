package com.vaani.app

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Long-term yaadasht: malik ke facts (log, pasand, jagah, aadatein). Har session ke system prompt mein jaati hai.
 * Password/PIN/OTP/card jaisi cheezein jaan-boojhkar yaad nahi rakhti.
 */
object Memory {
    private val SECRET = Regex("(?i)(password|passcode|\\bpin\\b|\\botp\\b|cvv|card number|card no|upi pin)")

    private fun all(c: Context): JSONObject =
        try { JSONObject(P.of(c).getString("mem", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    @Synchronized fun remember(c: Context, key: String, value: String): String {
        val k = key.trim().lowercase().take(40)
        if (k.isEmpty() || value.isBlank()) return "Kya yaad rakhna hai, ye saaf nahi hua."
        if (SECRET.containsMatchIn(k) || SECRET.containsMatchIn(value)) return "Password, PIN ya OTP jaisi cheezein main yaad nahi rakhti."
        val m = all(c)
        if (!m.has(k) && m.length() >= 150) m.keys().asSequence().firstOrNull()?.let { m.remove(it) }
        m.put(k, value.trim().take(300))
        P.of(c).edit().putString("mem", m.toString()).apply()
        return "Yaad rakh liya: $k."
    }

    @Synchronized fun forget(c: Context, key: String): String {
        val m = all(c); val k = key.trim().lowercase()
        val hit = m.keys().asSequence().firstOrNull { it == k } ?: m.keys().asSequence().firstOrNull { it.contains(k) && k.isNotEmpty() }
        return if (hit == null) "'$key' naam ki koi yaad nahi mili." else {
            m.remove(hit); P.of(c).edit().putString("mem", m.toString()).apply(); "'$hit' bhula diya." }
    }

    fun recall(c: Context, q: String): String {
        val m = all(c); val t = q.trim().lowercase()
        val rows = m.keys().asSequence().filter { t.isEmpty() || it.contains(t) || m.optString(it).lowercase().contains(t) }
            .map { "$it: ${m.optString(it)}" }.take(40).toList()
        return if (rows.isEmpty()) "Is baare mein kuch yaad nahi." else rows.joinToString("; ")
    }

    fun get(c: Context, key: String): String? = all(c).optString(key).takeIf { it.isNotEmpty() }

    /** System prompt ke liye chhota saar. */
    fun context(c: Context): String {
        val m = all(c)
        val s = m.keys().asSequence().joinToString("; ") { "$it: ${m.optString(it)}" }
        return s.take(1800)
    }

    // ---- saved places (ghar, office...) ----
    fun places(c: Context): JSONObject =
        try { JSONObject(P.of(c).getString("places", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    fun savePlaces(c: Context, p: JSONObject) { P.of(c).edit().putString("places", p.toString()).apply() }
}

/** Vaani ka vyaktitva + abhi ka samay + yaadasht: har Gemini session ka system prompt yahin banta hai. */
object Brain {
    fun title(c: Context): String = (P.of(c).getString("title", "boss") ?: "boss").ifBlank { "boss" }

    fun system(c: Context, live: Boolean): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        val mem = Memory.context(c)
        return "Tum Vaani ho, malik ki personal AI - shaant, tez, bharosemand, halka sa dry wit (zyada nahi). " +
            "Malik ko '${title(c)}' keh kar bulao. Hindi, Marathi, English aur Hinglish samajhti ho; jis bhasha mein user bole usi mein jawab do (default Hinglish). " +
            "Jawab bahut chhote rakho (1-2 vakya), jaise bolkar baat ho rahi ho; markdown ya emoji mat bolo. " +
            "Phone ke kaam ke liye tools use karo. Bade kaam ko khud chhote steps mein todo, ek ke baad ek tool chalao, tool fail ho to doosra tareeka try karo, aur ant mein ek line mein batao kya hua. " +
            "Current facts, news, score, rate ke liye web_answer; 'ye kya hai / dekho / screen par kya hai' ke liye look; kisi app ke andar ka kaam jo seedhe tool se na ho uske liye screen_agent. " +
            "Jab malik apne baare mein, apne logon ya pasand-napasand ke baare mein koi pakki baat bataye, chupchap memory tool se remember karo. " +
            "Agar koi tool 'ROKO' bole to malik se bolkar poochho 'kar du?' aur uske haan ke baad hi wahi tool wahi arguments ke saath dobara chalao. " +
            "Password, PIN, OTP, payment kabhi khud mat bharo. " +
            "Abhi: $now." + (if (mem.isNotEmpty()) " Malik ke baare mein jo pata hai: $mem." else "") +
            " Kisi bhi app ke andar ka kaam (WhatsApp/Instagram/Telegram/kisi ko message bhejna, kuch dhoondhna, setting badalna) ke liye app_agent tool use karo: app ka naam aur goal do. " +
            "Phone lock ho aur kaam ke liye screen chahiye to khud phone_unlock chalao; 'phone unlock karo' bole to phone_unlock, 'phone lock karo' bole to phone_lock. " +
            (if (live) " SABSE ZAROORI NIYAM: sirf tab jawab do ya koi tool chalao jab user ki baat mein 'Hey Vaani' ya 'Vaani' bola gaya ho " +
                "(ya tumne abhi khud koi sawal poochha ho aur user uska jawab de raha ho). Warna bilkul chup raho: koi awaaz nahi, koi tool nahi. " +
                "User kisi aur insaan se baat kar raha ho sakta hai." else "")
    }
}
