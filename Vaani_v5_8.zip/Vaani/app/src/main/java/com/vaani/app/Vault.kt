package com.vaani.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * v5.8 Vault: phone-unlock password jaisi cheezein AES-256-GCM se encrypt karke rakhta hai.
 * Key Android Keystore ke andar rehti hai (app se nikalti nahi), isliye prefs file khul bhi jaye to password plain text nahi milta.
 * Password kabhi source code, log, chat history, memory ya Gemini ko nahi jata.
 */
object Vault {
    private const val ALIAS = "vaani_vault_key"
    private const val PREF = "vault_"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null)
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build())
        return kg.generateKey()
    }

    /** value khaali ho to entry hata deta hai. true = save ho gaya. */
    fun put(c: Context, name: String, value: String): Boolean {
        return try {
            if (value.isEmpty()) { P.of(c).edit().remove(PREF + name).apply(); return true }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val ct = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
            val blob = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
            P.of(c).edit().putString(PREF + name, blob).apply()
            true
        } catch (e: Exception) { false }
    }

    fun has(c: Context, name: String): Boolean = !P.of(c).getString(PREF + name, "").isNullOrEmpty()

    /** Decrypt. Kuch na ho ya decrypt fail ho to null. */
    fun get(c: Context, name: String): String? {
        val blob = P.of(c).getString(PREF + name, "") ?: return null
        if (blob.isEmpty()) return null
        return try {
            val parts = blob.split(":")
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val ct = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) { null }
    }
}
