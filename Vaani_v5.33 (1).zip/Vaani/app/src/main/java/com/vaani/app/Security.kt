package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/*
 * FEATURE 12 — Security layer (v5.24: SIRF AWAAZ).
 *
 * App mein login sirf voice enrollment hai — fingerprint / PIN / pattern
 * ka koi rasta nahi. Risky kaam (payment, delete, auto-reply,
 * screen agent) se pehle Vaani malik ki awaaz verify karti hai:
 * - VaaniService har baar jab VoicePrint.verify() sahi bataye, tab
 *   Security.markVoiceAuthenticated() bulata hai (session khulne par,
 *   pehli awaaz par aur session ke dauran har ~1.5 sec ki dobara-check par).
 * - Auth window: awaaz se confirm hone ke 5 minute tak risky kaam chal
 *   sakta hai (prefs "voice_auth_at"). 5 minute baad dobara bolna padega.
 * - Kabhi bhi password / PIN / OTP save nahi hota — sirf "kab awaaz se
 *   confirm hua" ka timestamp save hota hai (long).
 * - Fingerprint/PIN wala purana rasta (KeyguardManager confirm screen)
 *   v5.24 mein hata diya gaya — Security.requireAuth / authIntent /
 *   onAuthResult ab nahi hain.
 *
 * Voiceprint data (vp_center / vp_sd / vp_thr) pehle se hi app-private
 * SharedPreferences ("vaani", MODE_PRIVATE) mein hai — use kahin aur copy /
 * upload / export nahi kiya jata. Ye file voiceprint ko haath nahi lagati.
 * v5.32: Guest mode hata diya — ab sab kuch sirf malik ki awaaz se chalta hai.
 */

/** Risky actions ke liye sirf awaaz se confirm (voice enrollment). */
object Security {
    const val AUTH_REQUEST_CODE = 9001   // purana lock-screen code — ab istemal nahi hota (compat ke liye rakha hai)
    private const val AUTH_WINDOW_MS = 5 * 60 * 1000L  // 5 minute
    private const val KEY_VOICE_AUTH_AT = "voice_auth_at"

    /** Kaun se tool risky hain — in par confirm-first + auth dono lagte hain. */
    fun isRisky(toolName: String): Boolean = toolName.lowercase().trim() in setOf(
        // Payment / paise (aaj inme se kuch tools hain nahi, par naam aate hi gate lagega)
        "payment", "upi_pay", "send_money", "pay", "transfer",
        // Delete
        "files",            // sirf delete action par (gateRisky mein action bhi check hota hai)
        "delete",
        // Auto-reply: aapke naam se jawab jayenge
        "notifications",    // sirf enable_auto_reply action par
        "screen_agent"      // phone par khud steps chalana
    )

    /** Is (tool + args) combo par auth chahiye ya nahi — action-level check. */
    fun needsAuth(toolName: String, args: JSONObject): Boolean {
        return when (toolName.lowercase().trim()) {
            "files" -> args.optString("action") == "delete"
            "notifications" -> args.optString("action") == "enable_auto_reply"
            "payment", "upi_pay", "send_money", "pay", "transfer", "delete", "screen_agent" -> true
            else -> false
        }
    }

    /** Pichhle 5 minute mein awaaz se confirm hua ho to true. */
    fun isAuthenticated(c: Context): Boolean {
        val at = P.of(c).getLong(KEY_VOICE_AUTH_AT, 0L)
        return at > 0L && System.currentTimeMillis() - at < AUTH_WINDOW_MS
    }

    /** Awaaz verify hone par bulao — VaaniService ke verify-success points se.
     *  5 minute ki window shuru hoti hai. */
    fun markVoiceAuthenticated(c: Context) {
        P.of(c).edit().putLong(KEY_VOICE_AUTH_AT, System.currentTimeMillis()).apply()
    }

    /**
     * Tool dispatch ke andar ka gate: risky kaam ho aur pichhle 5 minute mein
     * auth na hua ho to proceed() chalaye bina Hinglish mein roko; warna
     * proceed() chalao aur uska result lautao. Ye Safety.Confirm (turn-based
     * ROKO) ki jagah nahi leta — dono lagte hain: pehle Confirm, phir auth.
     */
    fun gateRisky(c: Context, toolName: String, args: JSONObject, proceed: () -> String): String {
        if (!needsAuth(toolName, args)) return proceed()
        if (isAuthenticated(c)) return proceed()
        return "Pehle apni awaaz se confirm karo — kuch bolo, main tumhari awaaz pehchan lungi, phir dobara bolo. " +
            "Bina awaaz-confirm kiye ye kaam nahi karungi."
    }
}

/** Gemini tool: security_auth. (v5.32: guest_mode tool hata diya — ab sab kuch sirf malik ki awaaz se chalta hai.) */
object SecurityTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("security_auth", "Risky kaam (payment, delete, auto-reply) se pehle apni awaaz se confirm karo.",
            mapOf("action" to sp("start | status"), "reason" to sp("kis kaam ke liye confirm kar rahe ho (optional)")),
            listOf("action"))
    )

    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "security_auth" -> when (a.optString("action")) {
            "status" -> if (Security.isAuthenticated(c))
                "Auth abhi valid hai (pichhle 5 minute mein awaaz se confirm hua tha)."
            else
                "Abhi auth nahi hua hai. Risky kaam se pehle apni awaaz se confirm karna padega — kuch bolo, jaise 'haan, confirm karo'."
            // v5.24 — "start": ab koi lock screen nahi khulti. Awaaz se confirm karne ke liye
            // bas bolna hai — VaaniService har verify hui awaaz par markVoiceAuthenticated()
            // bulata hai; uske baad 5 minute tak risky kaam chalenge.
            "start" -> {
                if (Security.isAuthenticated(c))
                    "Awaaz se confirm ho chuka hai — abhi risky kaam kar sakte ho (5 minute ki window)."
                else
                    "Awaaz se confirm karne ke liye kuch bolo — jaise 'haan, confirm karo'. " +
                        "Tumhari awaaz verify hote hi 5 minute ke liye auth valid ho jayega, phir dobara bolo."
            }
            else -> "security_auth: action 'start' ya 'status' do."
        }
        else -> null
    }
}
