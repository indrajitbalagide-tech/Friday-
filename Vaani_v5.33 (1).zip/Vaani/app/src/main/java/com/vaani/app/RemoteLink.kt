package com.vaani.app

import android.content.Context
import org.json.JSONObject
import java.net.URL

/**
 * v5.28 — REMOTE ACCESS (PC bridge ki jagah).
 *
 * Phone apne private Vaani Remote Server (remote_server/ folder) se bahar ki taraf juda rehta hai
 * (long-poll), isliye router / port-forwarding / PC ki zaroorat nahi. Website ya browser se jo text ya
 * awaaz (mic) aati hai wo yahan aakar wahi dimaag (BrainRouter -> Gemini) se chalti hai jo typed
 * commands ke liye chalta hai, to Safety.Confirm ("kar du?") jaise saare rules waise hi lagu hain.
 *
 * Settings: rl_url (https://...) aur rl_token (server ka DEVICE_TOKEN). Vaani 24h mode ON ho tab chalta hai.
 *
 * v5.33 — Website Gemini voice: website se aaye har kaam ka jawab phone Gemini TTS (Aoede) se
 * bolkar bhi bhejta hai (16kHz WAV, base64) — browser Gemini awaaz bajata hai; audio na mile
 * to browser robotic voice (speechSynthesis) se bol deta hai. Lambi reply (>300 akshar) par
 * audio nahi banta (robotic fallback). Purana server audio wala reply reject kare to text-only
 * dobara bheja jata hai (server update hone tak robotic voice chalti rahegi).
 */
object RemoteLink {
    @Volatile private var running = false
    @Volatile var status: String = "band"
    @Volatile var lastCmdAt: Long = 0L

    private class Cfg(val base: String, val token: String)

    private fun cfg(c: Context): Cfg? {
        val p = P.of(c)
        val url = p.getString("rl_url", "").orEmpty().trim().trimEnd('/')
        val tok = p.getString("rl_token", "").orEmpty().trim()
        if (url.isEmpty() || tok.isEmpty()) return null
        return Cfg(url, tok)
    }

    /** https zaroori hai (token + commands saaf internet par na jayein). Ghar ke LAN / localhost par http chalega. */
    private fun urlProblem(base: String): String? {
        val u = try { URL(base) } catch (e: Exception) { return "Remote URL galat hai." }
        if (u.protocol == "https") return null
        val h = (u.host ?: "").lowercase()
        val lan = h == "localhost" || h.endsWith(".local") || h.startsWith("10.") || h.startsWith("192.168.") || h.startsWith("127.")
        return if (lan) null else "Remote URL https:// se shuru hona chahiye."
    }

    fun configured(c: Context) = cfg(c) != null

    fun start(c: Context) {
        val app = c.applicationContext
        if (running || !configured(app)) return
        running = true
        status = "juda ho raha hai…"
        Thread { loop(app) }.also { it.isDaemon = true; it.name = "vaani-remote" }.start()
    }

    fun stop() { running = false; status = "band" }

    private fun loop(c: Context) {
        var fails = 0
        while (running) {
            val cf = cfg(c)
            if (cf == null) { status = "set nahi hai"; running = false; break }
            val bad = urlProblem(cf.base)
            if (bad != null) { status = bad; running = false; break }
            if (!Net.online(c)) { status = "internet nahi"; sleep(5000); continue }
            try {
                val auth = mapOf("Authorization" to "Bearer ${cf.token}")
                val raw = Net.request("GET", cf.base + "/device/next", null, auth, 35000)
                fails = 0; status = "juda hai ✅"
                val j = if (raw.isBlank()) JSONObject() else JSONObject(raw)
                val text = j.optString("text").trim()
                if (text.isEmpty()) continue
                lastCmdAt = System.currentTimeMillis()
                val reply = run(c, text)
                // v5.33 — Website Gemini voice: reply ka TTS audio bhi bhejo (browser Gemini awaaz bajayega).
                val audio = ttsForWeb(c, reply)
                val body = JSONObject().put("id", j.optString("id")).put("text", reply)
                if (audio != null) body.put("audio", audio)
                try { Net.request("POST", cf.base + "/device/reply", body.toString(), auth, 60000) }
                catch (e: Exception) {
                    // Purana server (MAX_BODY 20KB) audio wala reply reject kar dega — text-only dobara bhejo.
                    if (audio != null) {
                        try { Net.request("POST", cf.base + "/device/reply", JSONObject().put("id", j.optString("id")).put("text", reply).toString(), auth, 15000) } catch (_: Exception) {}
                    }
                }
            } catch (e: Exception) {
                fails++
                val m = e.message.orEmpty()
                status = if (m.contains("HTTP 401")) "token galat ❌ (server ka DEVICE_TOKEN check karo)" else "server nahi mil raha (${m.take(40)})"
                sleep(minOf(30_000L, 2_000L * fails))
            }
        }
        running = false
    }

    /** v5.33 — Website ke liye Gemini TTS audio (16kHz WAV, base64) ya null.
     *  Lambi reply (>300 akshar), key na ho, offline ho ya synth fail ho to null —
     *  browser tab robotic voice (speechSynthesis) se bol dega. */
    private fun ttsForWeb(c: Context, reply: String): String? {
        if (reply.isBlank() || reply.length > 300) return null
        val key = P.of(c).getString("key", "").orEmpty()
        if (key.isEmpty() || !Net.online(c)) return null
        return try {
            val pcm24 = GeminiVoice.synth(c, key, reply, null) ?: return null
            val wav = wav16k(downsample24to16(pcm24))
            val b64 = android.util.Base64.encodeToString(wav, android.util.Base64.NO_WRAP)
            if (b64.length > 800_000) null else b64
        } catch (_: Exception) { null }
    }

    /** 24kHz PCM -> 16kHz PCM (har 3 mein se 2 samples) — size ~1/3 kam, awaaz waisi hi. */
    private fun downsample24to16(pcm24: ByteArray): ByteArray {
        val samples = pcm24.size / 2
        val out = ByteArray((samples * 2 / 3) * 2)
        var o = 0; var i = 0
        while (i + 2 < samples) {
            out[o++] = pcm24[i * 2]; out[o++] = pcm24[i * 2 + 1]
            out[o++] = pcm24[(i + 1) * 2]; out[o++] = pcm24[(i + 1) * 2 + 1]
            i += 3
        }
        return out.copyOf(o)
    }

    /** PCM (16kHz mono 16-bit) par 44-byte WAV header lagao — browser seedha baja sake. */
    private fun wav16k(pcm16: ByteArray): ByteArray {
        val out = ByteArray(44 + pcm16.size)
        fun putStr(off: Int, s: String) { s.toByteArray().copyInto(out, off) }
        fun putInt(off: Int, v: Int) { out[off] = (v and 0xFF).toByte(); out[off + 1] = ((v shr 8) and 0xFF).toByte(); out[off + 2] = ((v shr 16) and 0xFF).toByte(); out[off + 3] = ((v shr 24) and 0xFF).toByte() }
        fun putShort(off: Int, v: Int) { out[off] = (v and 0xFF).toByte(); out[off + 1] = ((v shr 8) and 0xFF).toByte() }
        putStr(0, "RIFF"); putInt(4, 36 + pcm16.size); putStr(8, "WAVE"); putStr(12, "fmt ")
        putInt(16, 16); putShort(20, 1); putShort(22, 1); putInt(24, 16000); putInt(28, 32000)
        putShort(32, 2); putShort(34, 16); putStr(36, "data"); putInt(40, pcm16.size)
        pcm16.copyInto(out, 44)
        return out
    }

    private fun run(c: Context, text: String): String {
        val key = P.of(c).getString("key", "").orEmpty()
        return try {
            if (key.isEmpty() && !BrainRouter.hasProviders(c)) "Phone mein koi brain set nahi hai (Gemini key ya Settings > BRAIN ROUTER)."
            else BrainRouter.askAgent(c, key, text).ifBlank { "Ho gaya." }
        } catch (e: Exception) {
            Offline.parse(c, text) ?: "Phone par kaam nahi ho paya: ${e.message?.take(160)}"
        }
    }

    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (_: InterruptedException) {} }
}
