package com.vaani.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*

/**
 * v5.30 — LOGIN PAGE: app khulte hi yahi khulta hai.
 *   Step 1 — VOICE LOCK: awaaz enrolled nahi hai to enroll karwao (1 minute dialogue),
 *   enrolled hai to ~4 sec bolkar verify karo. Verify hue bina aage nahi.
 *   Step 2 — GEMINI API KEY: sirf tab dikhao jab koi key stored nahi hai ya verify nahi hui.
 *   Key pehle se verified hai to ye step skip — baar-baar key nahi mangi jati.
 *   Dono steps poore hote hi MainActivity khulta hai.
 *   Session sirf is process ke liye hota hai (LoginSession.authed) — app band karke dobara
 *   kholo to login dobara karna padega; background se wapas aane par nahi.
 */
object LoginSession {
    @Volatile var authed = false
}

class LoginActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("vaani", MODE_PRIVATE) }
    private lateinit var hint: TextView
    private lateinit var actionBtn: Button
    private lateinit var keyBox: EditText
    private lateinit var keyBtn: Button
    private lateinit var keyRow: LinearLayout
    private var busy = false
    private var origIntent: Intent? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun panel(radius: Int, fill: String, stroke: String) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat(); setColor(Color.parseColor(fill)); setStroke(dp(1), Color.parseColor(stroke))
    }

    private fun bgGrad() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.parseColor("#170409"), Color.parseColor("#010409")))

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        origIntent = intent
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(40), dp(18), dp(18))
            background = bgGrad()
        }
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        titleRow.addView(ImageView(this).apply {
            setImageResource(R.drawable.vaani_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP; background = panel(20, "#160409", "#FF2E4D")
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(10) })
        titleRow.addView(TextView(this).apply {
            text = "VAANI "; textSize = 25f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        })
        titleRow.addView(TextView(this).apply {
            text = "AI"; textSize = 25f; setTextColor(Color.parseColor("#FF2E4D")); typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(titleRow)
        root.addView(TextView(this).apply {
            text = "LOGIN — PEHLE AWAAZ, PHIR KEY"; textSize = 9f; letterSpacing = 0.32f
            setTextColor(Color.parseColor("#C47F8C")); setPadding(0, dp(2), 0, dp(14))
        })

        hint = TextView(this).apply {
            textSize = 15f; setTextColor(Color.parseColor("#FFD9A0")); setPadding(0, dp(6), 0, dp(12))
        }
        root.addView(hint)

        actionBtn = Button(this).apply {
            text = "🎙 AWAAZ VERIFY KARO"; setTextColor(Color.WHITE); textSize = 15f
            typeface = Typeface.DEFAULT_BOLD; background = panel(14, "#3D0A14", "#FF2E4D")
            setOnClickListener { onVoiceButton() }
        }
        root.addView(actionBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        keyRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        keyRow.addView(TextView(this).apply {
            text = "GEMINI API KEY"; textSize = 8f; letterSpacing = 0.3f
            setTextColor(Color.parseColor("#C47F8C")); setPadding(0, dp(14), 0, dp(2))
        })
        keyBox = EditText(this).apply {
            hint = "API key yahan daalo"; setText(prefs.getString("key", "")); setSingleLine()
            textSize = 13f; setTextColor(Color.parseColor("#EAF9FF")); setHintTextColor(Color.parseColor("#C47F8C"))
            background = panel(10, "#04121F", "#70101F"); setPadding(dp(10), dp(9), dp(10), dp(9))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            imeOptions = EditorInfo.IME_ACTION_DONE
        }
        keyRow.addView(keyBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        keyBtn = Button(this).apply {
            text = "✅ API VERIFY KARO"; setTextColor(Color.WHITE); textSize = 14f
            typeface = Typeface.DEFAULT_BOLD; background = panel(12, "#3D0A14", "#FF2E4D")
            setOnClickListener { onKeyButton() }
        }
        keyRow.addView(keyBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        root.addView(keyRow)

        setContentView(ScrollView(this).apply { background = bgGrad(); addView(root) })
        showVoiceStep()
    }

    /** Back dabane se login bypass nahi — app peeche chali jaye, andar nahi. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { moveTaskToBack(true) }

    private fun say(t: String) = runOnUiThread { hint.text = t }

    private fun showVoiceStep() {
        keyRow.visibility = View.GONE
        actionBtn.visibility = View.VISIBLE
        if (!VoicePrint(this).enrolled()) {
            hint.text = "🧬 Awaaz abhi enrolled nahi hai — pehle apni awaaz record karo (1 minute, dialogues padhne hain)."
            actionBtn.text = "🧬 AWAAZ RECORD KARO"
        } else {
            hint.text = "🔒 Login ke liye apni awaaz verify karo — button dabakar 'Vaani' bolo."
            actionBtn.text = "🎙 AWAAZ VERIFY KARO"
        }
    }

    private fun onVoiceButton() {
        if (busy) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 3)
            say("🎙 Mic permission allow karo, phir dobara dabao.")
            return
        }
        if (!VoicePrint(this).enrolled()) {
            busy = true
            actionBtn.isEnabled = false
            say("🧬 Awaaz seekhna shuru — screen par ek-ek karke dialogues aayenge, unhe zor se padhte jao. Poora 1 minute lagega; shant jagah mein, phone munh ke paas rakhkar, normal awaaz mein bolo.")
            VoicePrint.enroll(this, { line -> say(line) }, { m ->
                say(m)
                runOnUiThread { busy = false; actionBtn.isEnabled = true; toKeyStep() }
            })
        } else {
            busy = true
            actionBtn.isEnabled = false
            actionBtn.text = "🎙 SUN RAHA HOON… 'VAANI' BOLO"
            say("🎙 Sun raha hoon — ab bolo 'Vaani' (4 second)…")
            Thread {
                try {
                    val frames = recordFrames()
                    val ok = VoicePrint(this).verify(frames)
                    runOnUiThread {
                        busy = false
                        actionBtn.isEnabled = true
                        if (ok) {
                            Security.markVoiceAuthenticated(this)
                            say("✅ Awaaz pehchani — ab aage badho.")
                            toKeyStep()
                        } else {
                            say("🚫 Awaaz match nahi hui (score ${"%.1f".format(VoicePrint.lastScore)}, limit ${"%.1f".format(VoicePrint.lastLimit)}) — dobara bolo.")
                            showVoiceStep()
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        busy = false; actionBtn.isEnabled = true
                        say("⚠ Mic se record nahi ho paya: ${e.message?.take(120)} — dobara try karo.")
                        showVoiceStep()
                    }
                }
            }.start()
        }
    }

    /** ~4 second mic recording — VaaniService ke verify jaisi 1600-sample chunks. */
    private fun recordFrames(): List<ShortArray> {
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, 32000)
        val frames = ArrayList<ShortArray>()
        try {
            rec.startRecording()
            val buf = ShortArray(1600)
            var reads = 0
            while (reads < 40) {
                val n = rec.read(buf, 0, 1600)
                if (n > 0) { frames.add(buf.copyOf(n)); reads++ } else break
            }
        } finally {
            try { rec.stop() } catch (_: Exception) {}
            try { rec.release() } catch (_: Exception) {}
        }
        return frames
    }

    private fun keyVerified(): Boolean {
        val k = prefs.getString("key", "").orEmpty()
        if (k.isEmpty()) return false
        return prefs.getBoolean("key_verified", false) && prefs.getString("verified_key", "") == k
    }

    /** Key pehle se verified hai to ye step skip — baar-baar key nahi mangi jati. */
    private fun toKeyStep() {
        if (keyVerified()) { done(); return }
        actionBtn.visibility = View.GONE
        keyRow.visibility = View.VISIBLE
        hint.text = "🔑 Gemini API key daalo — ek baar verify hogi, phir dobara nahi mangi jayegi."
    }

    private fun onKeyButton() {
        if (busy) return
        val key = keyBox.text.toString().trim()
        if (key.isEmpty()) { say("⚠ Pehle API key daalo."); return }
        busy = true
        keyBtn.isEnabled = false
        prefs.edit().putString("key", key).putBoolean("key_verified", false).apply()
        say("⏳ Google se verify ho raha hai…")
        Thread {
            try {
                Gemini.ask(key, "hi", false)
                prefs.edit().putBoolean("key_verified", true).putString("verified_key", key).apply()
                runOnUiThread { busy = false; keyBtn.isEnabled = true; say("✅ API verify ho gaya!"); done() }
            } catch (e: Exception) {
                runOnUiThread {
                    busy = false; keyBtn.isEnabled = true
                    say("❌ Verify fail: ${e.message?.take(200)} — key check karke dobara daalo.")
                }
            }
        }.start()
    }

    private fun done() {
        LoginSession.authed = true
        val i = origIntent
        val next = if (i != null && Intent.ACTION_SEND == i.action) {
            Intent(i).setClass(this, MainActivity::class.java)
        } else {
            Intent(this, MainActivity::class.java)
        }
        startActivity(next)
        finish()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) showVoiceStep()
        else say("🎙 Mic permission ke bina voice verify nahi hogi — permission allow karo.")
    }
}
