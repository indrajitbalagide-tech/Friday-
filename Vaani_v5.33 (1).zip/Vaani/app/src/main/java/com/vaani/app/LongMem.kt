package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v5.27 — LONG-TERM MEMORY (RAG, poori tarah phone ke andar).
 *
 * Har baat-cheet ka chhota saar `filesDir/longmem.json` mein rehta hai (600 tak). Search ke liye koi model /
 * internet nahi: shabdon + 3-akshar tukdon ka hashed vector (512 dim) + cosine similarity. Tukde chhote rup-bhed
 * (gaana/gaane, service/services) pakadte hain; galat spelling (restorent vs restaurant) nahi pakadte.
 *
 * Kya save NAHI hota: password/PIN/OTP/card jaisi baatein aur health/dawai se judi baatein
 * (Memory ke niyam jaisa). Settings mein `longmem_on` se band kar sakte ho; `past_forget` tool sab mita deta hai.
 * Limit: ye meaning nahi, shabd-milaan pakadta hai — "kharcha" se "expense" nahi judega.
 */
object LongMem {
    private const val FILE = "longmem.json"
    private const val MAX = 600
    private const val DIM = 512
    private val lock = Any()

    private val SKIP = Regex("(?i)(password|passcode|\\bpin\\b|\\botp\\b|cvv|card number|card no|upi pin|dawai|dawa |dawaai|medicine|neend|sleep|bimari|doctor|health|sehat)")
    private val STOP = setOf(
        "hai", "hain", "ka", "ki", "ke", "ko", "se", "me", "mein", "aur", "to", "ho", "kya", "kar", "karo", "kr",
        "mujhe", "mera", "meri", "mere", "tum", "tumne", "main", "hum", "yeh", "ye", "wo", "woh", "the", "tha", "thi",
        "and", "for", "you", "are", "was", "that", "this", "with", "have", "bata", "batao", "bol", "bolo", "kaun", "kab"
    )

    private fun file(c: Context) = File(c.filesDir, FILE)

    private fun load(c: Context): JSONArray =
        try { val f = file(c); if (f.exists()) JSONArray(f.readText()) else JSONArray() } catch (_: Exception) { JSONArray() }

    private fun save(c: Context, a: JSONArray) {
        try { file(c).writeText(a.toString()) } catch (_: Exception) {}
    }

    fun enabled(c: Context): Boolean = P.of(c).getBoolean("longmem_on", true)

    /** Ek baat-cheet ka saar jodo. Chhoti / secret / health wali baatein chhod di jati hain. */
    fun record(c: Context, user: String, bot: String) {
        try {
            if (!enabled(c)) return
            val u = user.trim(); val b = bot.trim()
            if (u.length < 8 || b.isEmpty()) return
            if (SKIP.containsMatchIn(u) || SKIP.containsMatchIn(b)) return
            val text = "Tumne: " + u.take(160) + " | Vaani: " + b.take(140)
            synchronized(lock) {
                val a = load(c)
                a.put(JSONObject().put("t", System.currentTimeMillis()).put("x", text))
                val out = JSONArray()
                val from = if (a.length() > MAX) a.length() - MAX else 0
                for (i in from until a.length()) out.put(a.get(i))
                save(c, out)
            }
        } catch (_: Exception) {}
    }

    // ---- vector ----

    private fun bump(v: FloatArray, s: String, w: Float) {
        val h = s.hashCode()
        val idx = ((h % DIM) + DIM) % DIM
        v[idx] += w
    }

    private fun vec(text: String): FloatArray {
        val v = FloatArray(DIM)
        val ws = text.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 2 && it !in STOP }
        for (w in ws) {
            bump(v, "w:$w", 1.0f)
            if (w.length >= 4) {
                val pad = "^$w$"
                for (i in 0..(pad.length - 3)) bump(v, "t:" + pad.substring(i, i + 3), 0.35f)
            }
        }
        var n = 0.0
        for (x in v) n += (x * x).toDouble()
        val norm = Math.sqrt(n).toFloat()
        if (norm > 0f) for (i in v.indices) v[i] = v[i] / norm
        return v
    }

    private fun cos(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) s += a[i] * b[i]
        return s
    }

    class Hit(val time: Long, val text: String, val score: Float)

    fun search(c: Context, query: String, k: Int = 4, minScore: Float = 0.30f): List<Hit> {
        if (query.isBlank()) return emptyList()
        val q = vec(query)
        val arr = synchronized(lock) { load(c) }
        val hits = ArrayList<Hit>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val x = o.optString("x"); if (x.isEmpty()) continue
            val sc = cos(q, vec(x))
            if (sc >= minScore) hits.add(Hit(o.optLong("t"), x, sc))
        }
        return hits.sortedByDescending { it.score }.take(k)
    }

    private fun fmt(t: Long): String = SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH).format(Date(t))

    /** System prompt ke liye: sabse milti-julti 3 purani yaadein (ek line). Kuch na mile to khali. */
    fun relevantText(c: Context, query: String): String {
        return try {
            if (!enabled(c)) return ""
            search(c, query, 3, 0.32f).joinToString(" ; ") { "[" + fmt(it.time) + "] " + it.text.take(200) }
        } catch (_: Exception) { "" }
    }

    /** Tool `past_search`: user ke sawal ka jawab dene layak lines. */
    fun searchText(c: Context, query: String): String {
        if (!enabled(c)) return "Lambi yaadasht band hai (Settings mein longmem_on)."
        val hits = search(c, query, 5, 0.25f)
        if (hits.isEmpty()) return "Is baare mein purani baat-cheet mein kuch nahi mila."
        return hits.joinToString("\n") { "[" + fmt(it.time) + "] " + it.text }
    }

    fun count(c: Context): Int = synchronized(lock) { load(c).length() }

    fun forgetAll(c: Context): String {
        val n = count(c)
        synchronized(lock) { try { file(c).delete() } catch (_: Exception) {} }
        return "Purani baat-cheet ki $n yaadein mita di."
    }
}
