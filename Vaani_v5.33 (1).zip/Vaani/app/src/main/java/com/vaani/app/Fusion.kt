package com.vaani.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * v5.27 — CONTEXT FUSION: battery + din ka hissa + agla calendar event + kis saved jagah par ho +
 * zaroori notifications ki ginti — sab ek line mein, Brain.system ke saath model ko jati hai.
 *
 * Isse "Sir, meeting 20 min mein hai, battery 14% hai" jaisi soch banti hai.
 * Privacy: notifications ka TEXT kabhi nahi jata, sirf ginti. Calendar event ka title + saved jagah ka naam jata hai
 * (jo brain use ho raha ho — Gemini / free API — usi ko). Settings mein `fusion_on` se band kar sakte ho.
 * 60 second cache, koi network call nahi, koi bhi dikkat par chup-chaap khali lautata hai.
 */
object Fusion {
    private var cacheAt = 0L
    private var cache = ""

    fun enabled(c: Context): Boolean = P.of(c).getBoolean("fusion_on", true)

    @Synchronized fun line(c: Context): String {
        if (!enabled(c)) return ""
        val now = System.currentTimeMillis()
        if (cache.isNotEmpty() && now - cacheAt < 60_000L) return cache

        val parts = ArrayList<String>()

        // din ka hissa
        try {
            val cal = Calendar.getInstance()
            val h = cal.get(Calendar.HOUR_OF_DAY)
            val part = when {
                h < 5 -> "raat"
                h < 12 -> "subah"
                h < 17 -> "dopahar"
                h < 21 -> "shaam"
                else -> "raat"
            }
            val dow = cal.get(Calendar.DAY_OF_WEEK)
            val wk = if (dow == Calendar.SATURDAY || dow == Calendar.SUNDAY) "weekend" else "kaam ka din"
            parts.add("$part, $wk")
        } catch (_: Exception) {}

        // battery
        try {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
                if (lvl >= 0 && scale > 0) parts.add("battery " + (lvl * 100 / scale) + "%" + if (charging) " (charge ho rahi)" else "")
            }
        } catch (_: Exception) {}

        // agla event (12 ghante ke andar)
        try {
            val ev = Info.events(c, now, now + 12 * 3600_000L).firstOrNull { it.second >= now - 5 * 60_000L }
            if (ev != null) {
                val mins = ((ev.second - now) / 60_000L).toInt()
                val hm = SimpleDateFormat("HH:mm", Locale.US).format(Date(ev.second))
                val when_ = if (mins <= 0) "abhi chal raha hai" else if (mins < 90) "$mins min mein ($hm)" else "$hm par"
                parts.add("agla event: " + ev.first.take(60) + " " + when_ + if (ev.third.isNotBlank()) ", jagah " + ev.third.take(40) else "")
            }
        } catch (_: Exception) {}

        // kis saved jagah par (sirf last known fix, 3 ghante se purana nahi)
        try {
            val pl = Memory.places(c)
            val l = if (pl.length() > 0) Loc.last(c) else null
            if (l != null && now - l.time < 3 * 3600_000L) {
                var here: String? = null
                for (k in pl.keys()) {
                    val o = pl.getJSONObject(k)
                    if (Loc.dist(l, o.getDouble("lat"), o.getDouble("lon")) < maxOf(o.optDouble("r", 150.0), 100.0)) here = k
                }
                if (here != null) parts.add("abhi '$here' par")
            }
        } catch (_: Exception) {}

        // notifications ki ginti (text nahi)
        try {
            val arr = JSONArray(P.of(c).getString("nhist2", "[]") ?: "[]")
            var total = 0; var imp = 0
            val since = now - 3 * 3600_000L
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                if (o.optLong("time") < since) continue
                val pr = o.optString("priority")
                if (pr == "spam") continue
                total++
                if (pr == "bank" || pr == "work" || pr == "delivery" || pr == "otp") imp++
            }
            if (total > 0) parts.add("pichhle 3 ghante mein $total notifications ($imp zaroori)")
        } catch (_: Exception) {}

        cache = if (parts.isEmpty()) "" else
            " Abhi ka context: " + parts.joinToString("; ") + ". Is context ko tabhi use karo jab kaam ka ho " +
            "(jaise meeting se pehle jaldi nikalne ki salah, kam battery par charger ki yaad); bina poochhe poora context mat sunao."
        cacheAt = now
        return cache
    }
}
