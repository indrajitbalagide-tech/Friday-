package com.vaani.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.TelephonyManager

/**
 * Calls:
 * - Bajti call par friendly awaaz mein batata hai kiska call hai + poochta hai "Answer karun ya reject?"
 *   (Live session khul jata hai taaki user bolkar faisla de sake - call_control tool se asal action hota hai.)
 * - Uthaye bina kat jaye to missed call ki khabar deta hai.
 */
class CallReceiver : BroadcastReceiver() {
    companion object {
        @Volatile var lastCaller: String? = null
        @Volatile var ringingNow: String? = null
        @Volatile private var wasAnswered = false
        @Volatile private var lastRingAt = 0L
        private val handler = android.os.Handler(android.os.Looper.getMainLooper())
        @Volatile private var pendingUnknown: Runnable? = null

        /** Call ki khabar: log + status + bolna + Live session (taaki bolkar jawab de sako). Ek call par ek hi baar. */
        private fun announce(c: Context, name: String) {
            // v5.24 — ek call par ek hi announce: pehle 3 sec ki window thi, isliye har ring
            // par dobara bolta tha aur queue mein 3 baar "call aa raha hai" jam jata tha jo
            // answer ke baad bhi bajta rehta tha. Ab ringingNow set hai to dobara nahi bolega.
            if (ringingNow == name) return
            lastRingAt = System.currentTimeMillis()
            ringingNow = name; wasAnswered = false
            lastCaller = name
            VaaniService.log?.invoke("📞 $name ka call aa raha hai")
            AgentStatus.call = "$name ka call aa raha hai"; AgentStatus.callAt = System.currentTimeMillis()
            if (!c.getSharedPreferences("vaani", Context.MODE_PRIVATE).getBoolean("announce", true)) return
            Speaker.speakNow(c, "$name ka call aa raha hai. Answer karun ya reject karun?")
            WakeGate.openFollowUp(15_000)    // Vaani ne khud poochha hai - "answer" / "reject" ke liye "Hey Vaani" zaroori nahi
            VaaniService.forceStart = true   // Live session kholo taaki user bolkar jawab de sake
        }
    }

    override fun onReceive(c: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                if (num.isNullOrBlank()) {
                    // Android 10+ par pehla broadcast bina number ke aata hai aur number wala baad mein. Number ke bina bhi
                    // announce KARO (pehle yahi return poori call khabar rok deta tha) - bas ~0.9 sec ruk kar, taaki
                    // number wala broadcast aa jaye to "anjaan number" ki jagah asli naam bole.
                    val app = c.applicationContext
                    pendingUnknown?.let { handler.removeCallbacks(it) }
                    val r = Runnable { if (ringingNow == null) announce(app, "Ek anjaan number") }
                    pendingUnknown = r
                    handler.postDelayed(r, 900)
                    return
                }
                pendingUnknown?.let { handler.removeCallbacks(it) }; pendingUnknown = null
                announce(c, lookup(c, num) ?: num)
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                wasAnswered = true
                // v5.24 — call uthate hi Vaani chup: queue mein padi "call aa raha hai" wali
                // khabar (agar koi reh gayi ho) turant ruko, warna answer ke baad bhi bajti hai.
                pendingUnknown?.let { handler.removeCallbacks(it) }; pendingUnknown = null
                Speaker.stop()
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                pendingUnknown?.let { handler.removeCallbacks(it) }; pendingUnknown = null
                val missed = ringingNow
                if (missed != null && !wasAnswered) {
                    VaaniService.log?.invoke("📞 Missed call: $missed")
                    AgentStatus.call = "$missed ki missed call • ${AgentStatus.time()}"; AgentStatus.callAt = System.currentTimeMillis()
                    if (c.getSharedPreferences("vaani", Context.MODE_PRIVATE).getBoolean("announce", true))
                        Speaker.speakNow(c, "$missed ki missed call aayi thi")
                }
                ringingNow = null; lastCaller = null; wasAnswered = false
            }
        }
    }

    private fun lookup(c: Context, num: String): String? = try {
        c.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) { null }
}
