package com.vaani.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * v5.27 tools: brain_status, past_search, past_forget, team_run.
 * Dispatch Actions.kt ki chain mein; decls Gemini.tools mein (BrainRouter bhi inhe OpenAI format mein badal leta hai).
 */
object Team {
    /** Sirf PADHNE wale agents ek saath chalte hain. DND / brightness / alarm jaise kaam badalne wale agents
     *  (raat, gaadi, battery, focus, alarm, torch, sos ...) yahan nahi — unhe agent_run se alag chalao. */
    private val SAFE = listOf(
        "subah", "weather", "news", "calendar", "reminder", "whatsapp", "call", "sms", "email", "finance",
        "delivery", "travel", "photo", "security", "screentime", "home", "fitness", "location"
    )

    private val KW: List<Pair<String, List<String>>> = listOf(
        "subah" to listOf("briefing", "subah", "morning"),
        "weather" to listOf("mausam", "weather", "baarish"),
        "news" to listOf("khabar", "news", "samachar"),
        "calendar" to listOf("calendar", "meeting", "schedule", "event"),
        "reminder" to listOf("reminder", "yaad"),
        "whatsapp" to listOf("whatsapp"),
        "sms" to listOf("sms", "message"),
        "email" to listOf("email", "mail"),
        "finance" to listOf("bank", "payment", "bill"),
        "delivery" to listOf("delivery", "order", "parcel"),
        "travel" to listOf("safar", "travel"),
        "call" to listOf("call"),
        "home" to listOf("ghar", "home"),
        "fitness" to listOf("fitness", "steps", "kadam"),
        "security" to listOf("security", "suraksha"),
        "location" to listOf("location", "kahan")
    )

    private fun pick(agents: String, task: String): Pair<List<String>, List<String>> {
        val chosen = LinkedHashSet<String>()
        val skipped = ArrayList<String>()
        if (agents.isNotBlank()) {
            for (raw in agents.lowercase(Locale.ROOT).split(Regex("[,;\\s]+"))) {
                val id = raw.trim(); if (id.isEmpty()) continue
                if (id in SAFE) chosen.add(id)
                else if (Agents.ALL.any { it.id == id }) skipped.add(id)
            }
        }
        if (chosen.isEmpty() && task.isNotBlank()) {
            val t = " " + task.lowercase(Locale.ROOT) + " "
            for ((id, ws) in KW) if (ws.any { t.contains(it) }) chosen.add(id)
        }
        return Pair(chosen.toList().take(8), skipped)
    }

    /** Kai agents ek saath (alag threads), 25 sec ki limit har ek ko. */
    fun run(c: Context, agents: String, task: String): String {
        val (ids, skipped) = pick(agents, task)
        if (ids.isEmpty()) {
            val extra = if (skipped.isEmpty()) "" else " (${skipped.joinToString(", ")} badalne wale agents hain — unhe agent_run se alag chalao.)"
            return "Kaun se agents ek saath chalane hain? Jaise: subah, weather, calendar, whatsapp, sms, news.$extra"
        }
        val pool = Executors.newFixedThreadPool(minOf(ids.size, 6))
        val futs = ids.map { id -> id to pool.submit(Callable { Agents.run(c, id, "") }) }
        val sb = StringBuilder("Team report (${ids.size} agents ek saath):\n")
        for ((id, f) in futs) {
            val name = Agents.ALL.firstOrNull { it.id == id }?.name ?: id
            val res: String = try {
                f.get(25, TimeUnit.SECONDS)
            } catch (_: TimeoutException) {
                f.cancel(true); "time out (25 sec)"
            } catch (e: Exception) {
                "nahi chala: " + (e.message ?: "").take(60)
            }
            sb.append("• ").append(name).append(": ").append(res.replace("\n", " ").take(260)).append("\n")
        }
        pool.shutdown()
        if (skipped.isNotEmpty()) sb.append("(Chhode gaye — badalne wale agents: ").append(skipped.joinToString(", ")).append(")\n")
        return sb.toString().trimEnd()
    }
}

object BrainTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject>, req: List<String> = emptyList()): JSONObject {
        val p = JSONObject(); for ((k, v) in props) p.put(k, v)
        val params = JSONObject().put("type", "OBJECT").put("properties", p)
        if (req.isNotEmpty()) params.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("parameters", params)
    }

    fun decls(): List<JSONObject> = listOf(
        fn("brain_status",
            "Vaani ka dimaag (brain) kaun sa chal raha hai: free API #1, #2, Gemini — kaun juda hai, kaun set nahi.",
            emptyMap()),
        fn("past_search",
            "Purani baat-cheet mein dhoondho: 'pichhle hafte maine kya kaha tha', 'wo restaurant ka naam kya tha' jaise sawaal. Phone ke andar ki lambi yaadasht.",
            mapOf("query" to sp("kya yaad karna hai, jaise 'restaurant ka naam' ya 'Rohit ke saath plan'")),
            listOf("query")),
        fn("past_forget",
            "Purani baat-cheet ki saari lambi yaadasht mita do (sirf user ke kehne par).",
            emptyMap()),
        fn("team_run",
            "Kai PADHNE wale agents EK SAATH chalao aur ek report lo — jaise 'subah ka briefing + mausam + calendar + messages' ek baar mein. " +
                "Badalne wale agents (DND, alarm, brightness) isme nahi chalte.",
            mapOf(
                "agents" to sp("comma se agent id: subah, weather, news, calendar, reminder, whatsapp, sms, email, finance, delivery, travel, call, home, fitness, security, location"),
                "task" to sp("agents na pata ho to kaam Hinglish mein, jaise 'mausam, calendar aur messages batao'")
            ))
    )

    /** Unknown naam par null (Actions chain aage badhe). */
    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "brain_status" -> BrainRouter.status(c)
        "past_search" -> LongMem.searchText(c, a.optString("query", ""))
        "past_forget" -> LongMem.forgetAll(c)
        "team_run" -> Team.run(c, a.optString("agents", ""), a.optString("task", ""))
        else -> null
    }
}
