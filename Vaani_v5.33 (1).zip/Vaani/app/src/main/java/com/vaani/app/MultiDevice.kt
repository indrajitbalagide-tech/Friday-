package com.vaani.app

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URL

/**
 * Multi-device sync (Group 4, Feature 11).
 *
 * KYA ABHI KAAM KARTA HAI (kuch install nahi chahiye):
 * - JSON export/import: ek phone ki memory facts + reminders + saved places dusre phone par
 *   le jao. `sync_export` share sheet kholta hai (WhatsApp/Drive/kahin bhi bhej do),
 *   dusre phone par `sync_import` mein wahi JSON paste karo. Merge hota hai, duplicate nahi banta.
 *
 * KYA ABHI STUB HAI (companion app chahiye):
 * - Wear OS live sync (WearSync.sendToWatch): is phone mein Wear dependency nahi hai
 *   (app/build.gradle.kts mein sirf okhttp + porcupine hain), isliye ye stub hai aur saaf
 *   batata hai "Wear app abhi install nahi hai". Asli live sync ke liye chahiye:
 *   (1) Wear OS companion app (ghadi par Vaani watch app), (2) Gradle mein
 *   com.google.android.gms:play-services-wearable, (3) Wearable DataClient/MessageClient se
 *   DataItem bhejna. Tab tak JSON export/import hi sync ka rasta hai.
 *
 * SAFETY: export/import mein password/PIN/OTP/API key kabhi nahi aate - aisi entry dikhte hi
 * chhod di jati hai (Memory.SECRET wala hi rule). Token/password yahan save nahi hota.
 */

// ---------------------------------------------------------------------------
// Feature 11 - Multi-device sync (JSON export/import) + Wear OS stub
// ---------------------------------------------------------------------------
object MultiDevice {
    private val SECRET = Regex("(?i)(password|passcode|\\bpin\\b|\\botp\\b|cvv|card number|card no|upi pin|api[_-]?key|token|secret)")

    private fun memObj(c: Context): JSONObject =
        try { JSONObject(P.of(c).getString("mem", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun remsArr(c: Context): JSONArray =
        try { JSONArray(P.of(c).getString("rems", "[]")) } catch (e: Exception) { JSONArray() }

    private fun placesObj(c: Context): JSONObject =
        try { JSONObject(P.of(c).getString("places", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun isSecret(k: String, v: String) = SECRET.containsMatchIn(k) || SECRET.containsMatchIn(v)

    /**
     * Export: memory facts + reminders + saved places ka JSON (string).
     * Side effect: wahi JSON app-private storage mein vaani_sync.json mein save hota hai.
     * Password/PIN/OTP/API key wali entries chhod di jati hain (gin kar "skipped_secrets" mein batata hai).
     */
    fun exportSyncJson(c: Context): String {
        val mem = JSONObject(); var skipped = 0
        val all = memObj(c)
        for (k in all.keys()) {
            val v = all.optString(k)
            if (isSecret(k, v)) skipped++ else mem.put(k, v)
        }
        val rems = JSONArray()
        val ra = remsArr(c)
        for (i in 0 until ra.length()) {
            val o = ra.optJSONObject(i) ?: continue
            if (isSecret("", o.optString("text"))) { skipped++; continue }
            rems.put(o)
        }
        val out = JSONObject()
            .put("app", "vaani").put("version", 1).put("exported_at", System.currentTimeMillis())
            .put("memory", mem).put("reminders", rems).put("places", placesObj(c))
            .put("skipped_secrets", skipped)
        val json = out.toString()
        try { File(c.filesDir, "vaani_sync.json").writeText(json) } catch (_: Exception) {}
        return json
    }

    /** Share sheet se JSON dusre device ko bhejo (WhatsApp/Drive/mail...). File bhi save rehti hai. */
    fun shareExport(c: Context): String {
        val json = exportSyncJson(c)
        val i = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_SUBJECT, "Vaani sync export")
            .putExtra(Intent.EXTRA_TEXT, json)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(Intent.createChooser(i, "Vaani sync dusre phone ko bhejo").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Export share kar diya - dusre phone par sync_import se khulega."
    }

    /**
     * Import: dusre device ke export JSON ko merge karo. Dedupe: memory key se, reminder text se,
     * place naam se. Report: kitne naye aaye, kitne pehle se the, kitne secret wale chhode.
     */
    fun importSyncJson(c: Context, json: String): String {
        val root = try { JSONObject(json) } catch (e: Exception) { return "Ye JSON samajh nahi aaya - sync_export wala text poora paste karo." }
        if (root.optString("app") != "vaani") return "Ye Vaani ka sync file nahi lag raha."
        var memNew = 0; var memDup = 0; var remNew = 0; var remDup = 0; var plNew = 0; var plDup = 0; var skipped = 0

        // Memory facts (key se dedupe; pehle wali jeetegi, nayi wahi aayegi jo key nahi hai)
        val mem = memObj(c)
        val inMem = root.optJSONObject("memory") ?: JSONObject()
        for (k in inMem.keys()) {
            val v = inMem.optString(k)
            if (isSecret(k, v)) { skipped++; continue }
            if (mem.has(k)) memDup++ else {
                if (mem.length() >= 150) { skipped++; continue }
                mem.put(k, v.take(300)); memNew++
            }
        }
        P.of(c).edit().putString("mem", mem.toString()).apply()

        // Reminders (text se dedupe, lowercase compare)
        val rems = remsArr(c)
        val seen = (0 until rems.length()).map { rems.getJSONObject(it).optString("text").trim().lowercase() }.toMutableSet()
        val inRems = root.optJSONArray("reminders") ?: JSONArray()
        for (i in 0 until inRems.length()) {
            val o = inRems.optJSONObject(i) ?: continue
            val t = o.optString("text").trim()
            if (t.isEmpty() || isSecret("", t)) { skipped++; continue }
            if (t.lowercase() in seen) remDup++
            else { rems.put(JSONObject().put("text", t).put("at", o.optLong("at", System.currentTimeMillis()))); seen.add(t.lowercase()); remNew++ }
        }
        P.of(c).edit().putString("rems", rems.toString()).apply()

        // Places (naam se dedupe)
        val pl = placesObj(c)
        val inPl = root.optJSONObject("places") ?: JSONObject()
        for (k in inPl.keys()) {
            if (pl.has(k)) plDup++ else { pl.put(k, inPl.opt(k)); plNew++ }
        }
        Memory.savePlaces(c, pl)

        return "Sync ho gaya: $memNew nayi yaadein, $remNew reminders, $plNew jagah add hui; " +
            "${memDup + remDup + plDup} pehle se thi; $skipped secret wali chhod di."
    }
}

/**
 * Wear OS sync - STUB (jaankar stub, TODO nahi).
 * Kaaran: app/build.gradle.kts mein Wear dependency (play-services-wearable) nahi hai, aur ghadi par
 * Vaani ka companion (Wear OS) app bhi nahi hai - bina uske DataClient ka koi sunne wala nahi hota.
 * Asli implementation ke liye: Gradle mein `com.google.android.gms:play-services-wearable` jodo,
 * Wear OS companion app banao, phir Wearable.getDataClient(ctx).putDataItem(...) se bhejo.
 * Tab tak: JSON export/import (upar) hi do devices ke beech sync ka kaam karta hai.
 */
object WearSync {
    fun sendToWatch(ctx: Context, text: String): String {
        if (text.isBlank()) return "Ghadi ko kya bhejna hai, wo text nahi mila."
        return "Wear app abhi install nahi hai — companion app chahiye. " +
            "Live watch sync ke liye ghadi par Vaani Wear app + phone mein wearable dependency chahiye; " +
            "tab tak sync_export se JSON bhej kar dusre device par sync_import karo."
    }
}

/**
 * Sync tools ki declarations + dispatch.
 *
 * WIRING (coordinator ke liye):
 *   Gemini.kt `tools` lazy block mein:  for (d in SyncTools.decls()) if (seen.add(d.optString("name"))) fd.put(d)
 *   Actions.kt/Extras.kt chain mein:   SyncTools.dispatch(c, name, a) ?: ... (Extras.run ke andar)
 */
object SyncTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)

    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("sync_export", "Dusre phone/ghadi se sync ke liye export: memory facts + reminders + saved places ka JSON banao aur share sheet se bhejo. Password/PIN/OTP kabhi export nahi hota.",
            mapOf("confirm" to sp("optional: 'haan' likho to share sheet khulegi"))),
        fn("sync_import", "Dusre device se aaya Vaani sync JSON import karo - merge hota hai, duplicate nahi banta, report milti hai.",
            mapOf("json" to sp("sync_export wala poora JSON text")), listOf("json")),
        fn("wear_send", "Ghadi (Wear OS) par text bhejo. Abhi stub hai - Wear companion app install nahi hai to wahi batayega.",
            mapOf("text" to sp("ghadi ko bhejne wala text")), listOf("text"))
    )

    /** Sirf sync_* / wear_send pakdo, baaki ke liye null (taaki chain aage badh sake). */
    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "sync_export" -> {
            val json = MultiDevice.exportSyncJson(c)
            val counts = try {
                val r = JSONObject(json)
                "${r.optJSONObject("memory")?.length() ?: 0} yaadein, ${r.optJSONArray("reminders")?.length() ?: 0} reminders, " +
                    "${r.optJSONObject("places")?.length() ?: 0} jagah"
            } catch (e: Exception) { "export ready" }
            MultiDevice.shareExport(c)
            "Export ready: $counts. Share sheet khol di - dusre phone ko bhej do, wahan sync_import se khulega. File vaani_sync.json mein bhi save hai."
        }
        "sync_import" -> MultiDevice.importSyncJson(c, a.optString("json"))
        "wear_send" -> WearSync.sendToWatch(c, a.optString("text"))
        else -> null
    }
}
