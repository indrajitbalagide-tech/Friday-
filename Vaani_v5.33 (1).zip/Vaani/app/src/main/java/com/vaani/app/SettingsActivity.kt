package com.vaani.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.media.audiofx.AcousticEchoCanceler
import android.os.Bundle
import android.text.InputType
import android.widget.*

/** Vaani 4.0 settings: naam/title, Home Assistant, wake word key, briefing, barge-in. Badlav restart par lagte hain. */
class SettingsActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("vaani", MODE_PRIVATE) }
    private val fields = ArrayList<Pair<String, EditText>>()
    private var unlockPw: EditText? = null

    private fun saveUnlockPw() {
        val v = unlockPw?.text?.toString().orEmpty()
        if (v.isNotEmpty()) { Vault.put(this, "unlock_pw", v); unlockPw?.setText("") }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(root: LinearLayout, t: String) = root.addView(TextView(this).apply {
        text = t; textSize = 9f; letterSpacing = 0.2f; setTextColor(Color.parseColor("#C47F8C")); setPadding(0, dp(12), 0, dp(2)) })

    private fun field(root: LinearLayout, key: String, title: String, hint: String, secret: Boolean = false) {
        label(root, title)
        val e = EditText(this).apply {
            setText(prefs.getString(key, "")); this.hint = hint; setSingleLine(); textSize = 13f
            setTextColor(Color.parseColor("#EAF9FF")); setHintTextColor(Color.parseColor("#7A4A55"))
            setBackgroundColor(Color.parseColor("#04121F")); setPadding(dp(10), dp(8), dp(10), dp(8))
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        fields.add(key to e); root.addView(e)
    }

    private fun toggle(root: LinearLayout, key: String, title: String, def: Boolean) {
        val sw = Switch(this).apply { text = title; setTextColor(Color.WHITE); isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply() } }
        root.addView(sw, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(26), dp(16), dp(20)) }
        root.addView(TextView(this).apply { text = "VAANI SETTINGS"; textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply { text = "Badlav 'Hands-free' dobara chalu karne par lagte hain."; textSize = 11f
            setTextColor(Color.parseColor("#C47F8C")) })

        field(root, "title", "AAPKO KYA BULAYE (boss / sir / naam)", "boss")
        field(root, "pv_key", "WAKE WORD — PICOVOICE ACCESS KEY (picovoice.ai, free). Khali = openWakeWord ('Vaani' — custom model)", "AccessKey", true)
        toggle(root, "oww_on", "On-device wake word 'Vaani' (custom model — tumhari awaaz se train kiya, bina signup, bina net ke, battery kam). Porcupine .ppn ho to wahi jeetega", true)
        toggle(root, "wake_strict", "Sirf 'Hey Vaani' / 'Vaani' bolne par jawab do (ON = sakht; band ho to aapki awaaz hi kaafi hai)", false)
        toggle(root, "vp_strict", "Voice lock strict — sirf meri awaaz pe Vaani jaage (kisi aur ki awaaz ignore)", true)
        toggle(root, "auto_update", "Naya version aate hi khud update check + download karo (install screen par Install dabana hoga)", true)
        toggle(root, "auto_decide", "Routine kaam khud kar lo — confirm mat mango (paise / bhejna / delete par phir bhi poochhungi)", true)
        field(root, "wake_words", "EXTRA WAKE WORDS (comma se, jaise: wani, bani) — Gemini 'Vaani' ko galat likhe to yahan jodo", "wani, bani")
        toggle(root, "wake_only", "Sirf wake word (awaaz-match band)", false)
        toggle(root, "notif_speak", "Notifications real-time bolo", true)
        toggle(root, "notif_summary_on", "Lambi notifications ka aasan Hindi mein summary bolo (chhoti waisi hi; OTP kabhi nahi)", true)
        toggle(root, "announce", "Call aane par bolo (kiska call hai)", true)
        toggle(root, "voice_unlock", "Awaaz se phone unlock (neeche password daalna zaroori)", false)
        label(root, "PHONE UNLOCK PASSWORD (Keystore mein encrypted; khali chhodo = jaisa hai waisa rahe)")
        unlockPw = EditText(this).apply {
            hint = if (Vault.has(this@SettingsActivity, "unlock_pw")) "●●●●●● (set hai — naya daalo to badal jayega)" else "password / PIN"
            setSingleLine(); textSize = 13f
            setTextColor(Color.parseColor("#EAF9FF")); setHintTextColor(Color.parseColor("#7A4A55"))
            setBackgroundColor(Color.parseColor("#04121F")); setPadding(dp(10), dp(8), dp(10), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(unlockPw)
        root.addView(Button(this).apply { text = "🗑 Saved unlock password hatao"; setOnClickListener {
            Vault.put(this@SettingsActivity, "unlock_pw", ""); prefs.edit().putBoolean("voice_unlock", false).apply()
            Toast.makeText(this@SettingsActivity, "Password hata diya, voice unlock band", Toast.LENGTH_SHORT).show() } })
        toggle(root, "bargein", "Barge-in (beech mein bolo to Vaani ruke)", AcousticEchoCanceler.isAvailable())
        toggle(root, "brief_on", "Subah ka briefing (inbuilt subah 8:00; jaldi utho to unlock par)", true)
        field(root, "ha_url", "HOME ASSISTANT URL", "http://192.168.1.10:8123")
        field(root, "ha_token", "HOME ASSISTANT LONG-LIVED TOKEN", "token", true)
        label(root, "REMOTE ACCESS (v5.28) — apna private Vaani Remote Server. Website se kahin se bhi phone control. Vaani 24h mode ON rakho. Badlav restart par lagta hai.")
        field(root, "rl_url", "REMOTE SERVER URL (https://...)", "https://vaani-remote.onrender.com")
        field(root, "rl_token", "REMOTE DEVICE TOKEN (server ka DEVICE_TOKEN)", "token", true)
        toggle(root, "car_read_all", "Gaadi mode mein saare messages padho (band ho to sirf zaroori)", false)
        // v5.23 — sirf ek master switch (50 alag toggles hata diye — Settings ki bheed kam)
        label(root, "AGENTS — 50 AUTOMATION AGENTS + MANAGER (kaam 'job_create' se ya bol kar do)")
        toggle(root, "agents_on", "ALL AGENTS on/off — ON = saare 50 agents active, OFF = sab band", true)

        // v5.27 — BRAIN ROUTER + yaadasht + context + style
        label(root, "BRAIN ROUTER (v5.27) — typed / agent kaam ke liye dimaag. Order: Free API #1 -> #2 -> Gemini. Khali = chhoda jayega. Live bolti baat-cheet abhi Gemini hi hai.")
        field(root, "br_oa_url", "FREE API #1 URL (OpenAI-style, jaise Groq) — khali = Groq", "https://api.groq.com/openai/v1")
        field(root, "br_oa_key", "FREE API #1 KEY", "key", true)
        field(root, "br_oa_model", "FREE API #1 MODEL (provider ki site par dekho, naam badalte rehte hain)", "llama-3.3-70b-versatile")
        field(root, "br_oa2_url", "FREE API #2 URL — khali = OpenRouter", "https://openrouter.ai/api/v1")
        field(root, "br_oa2_key", "FREE API #2 KEY", "key", true)
        field(root, "br_oa2_model", "FREE API #2 MODEL (':free' wale model)", "meta-llama/llama-3.3-70b-instruct:free")
        toggle(root, "br_gemini", "Gemini ko aakhri fallback rakho (OFF = sirf apne brains; sab fail to error)", true)
        toggle(root, "longmem_on", "Lambi yaadasht: purani baat-cheet phone mein yaad rakho (password/health/dawai nahi) — 'pichhle hafte kya kaha tha'", true)
        toggle(root, "fusion_on", "Context: battery, agla event, kis jagah ho, notification ginti model ko batao (text nahi)", true)
        field(root, "persona", "VAANI KA ANDAAZ: jarvis / dost / seedha", "jarvis")

        root.addView(Button(this).apply { text = "🔄 Update check karo"; setOnClickListener {
            val ed = prefs.edit(); for ((k, e) in fields) ed.putString(k, e.text.toString().trim()); ed.apply()
            Thread {
                val r = UpdateChecker.check(this@SettingsActivity)
                runOnUiThread {
                    // v5.19 — naya version mile to dialog mein seedha "Install karo" button bhi do.
                    // v5.21 — download ki haalat bhi dikhao (download ho raha hai / ho gaya / fail).
                    val msg = r + if (UpdateChecker.hasPending(this@SettingsActivity)) "\n\nDownload: ${UpdateChecker.downloadState(this@SettingsActivity)}" else ""
                    val b = android.app.AlertDialog.Builder(this@SettingsActivity).setTitle("Update check").setMessage(msg)
                    if (UpdateChecker.hasPending(this@SettingsActivity)) {
                        b.setPositiveButton("⬇ Install karo") { _, _ ->
                            Thread {
                                val ir = UpdateChecker.install(this@SettingsActivity)
                                runOnUiThread { android.widget.Toast.makeText(this@SettingsActivity, ir, android.widget.Toast.LENGTH_LONG).show() }
                            }.start()
                        }
                        b.setNegativeButton("Baad mein", null)
                    } else {
                        b.setPositiveButton("Theek hai", null)
                    }
                    b.show()
                }
            }.start() } }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        root.addView(Button(this).apply { text = "💾 SAVE"; setOnClickListener {
            val ed = prefs.edit(); for ((k, e) in fields) ed.putString(k, e.text.toString().trim()); ed.apply()
            saveUnlockPw()
            Toast.makeText(this@SettingsActivity, "Save ho gaya", Toast.LENGTH_SHORT).show() } },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        root.addView(Button(this).apply { text = "🧬 Meri awaaz dobara enroll karo (1 minute)"; setOnClickListener {
            val dlg = android.app.AlertDialog.Builder(this@SettingsActivity).setTitle("Awaaz enroll")
                .setMessage("Shuru ho raha hai… shant jagah mein phone paas rakhkar bolo.").setCancelable(false).show()
            VoicePrint.enroll(this@SettingsActivity,
                { line -> runOnUiThread { dlg.setMessage(line) } },
                { m -> runOnUiThread { dlg.dismiss(); Toast.makeText(this@SettingsActivity, m, Toast.LENGTH_LONG).show() } })
        } }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        root.addView(Button(this).apply { text = "🔊 Briefing abhi sunao"; setOnClickListener {
            val ed = prefs.edit(); for ((k, e) in fields) ed.putString(k, e.text.toString().trim()); ed.apply()
            Thread { Speaker.speak(this@SettingsActivity, Briefing.make(this@SettingsActivity)) }.start() } })
        root.addView(Button(this).apply { text = "🗑 Vaani ki yaadasht dekho/saaf karo"; setOnClickListener {
            showMemory(this@SettingsActivity) } })

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0A0207")); addView(root) })
    }

    override fun onPause() { val ed = prefs.edit(); for ((k, e) in fields) ed.putString(k, e.text.toString().trim()); ed.apply(); saveUnlockPw(); super.onPause() }

    private fun showMemory(a: Activity) {
        val mem = Memory.recall(a, "")
        android.app.AlertDialog.Builder(a).setTitle("Vaani ko yaad hai").setMessage(mem)
            .setPositiveButton("Sab bhula do") { _, _ -> P.of(a).edit().remove("mem").apply() }
            .setNegativeButton("Theek hai", null).show()
    }
}
