package com.vaani.app

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.sqrt

/**
 * On-device speaker check (MFCC statistics).
 * V1.7 sudhar: har hisse (dimension) ko uske apne phailav (sd) se naapo - "whitened" distance.
 * Pehle ek hi paimana sab par lagta tha, isiliye ek bada hissa poore match ko bigaad deta tha.
 * NOT security-grade: shor, sardi, ya recording ise dhokha de sakti hai.
 */
class VoicePrint(ctx: Context) {
    private val p = ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE)
    private val center: FloatArray? = p.getString("vp_center", null)?.split(",")?.map { it.toFloat() }?.toFloatArray()
    private val sd: FloatArray? = p.getString("vp_sd", null)?.split(",")?.map { it.toFloat() }?.toFloatArray()
    private val thr = p.getFloat("vp_thr", 0f)

    fun enrolled() = center != null && thr > 0f

    fun verify(frames: List<ShortArray>): Boolean {
        val c = center ?: return false
        val all = ShortArray(frames.sumOf { it.size }); var o = 0
        for (f in frames) { f.copyInto(all, o); o += f.size }
        val v = Mfcc.vector(all) ?: return false
        val s = sd
        val d = if (s != null && s.size == v.size) wdist(v, c, s) else dist(v, c)
        lastScore = d; lastLimit = thr
        return d <= thr
    }

    companion object {
        @Volatile var lastScore = -1f
        @Volatile var lastLimit = 0f

        fun dist(a: FloatArray, b: FloatArray): Float { var s = 0f; for (i in a.indices) s += (a[i] - b[i]) * (a[i] - b[i]); return sqrt(s) }

        /** Har hisse ko uske sd se bhaag karke naapo - chhota phailav wala hissa zyada sakht, bada wala naram. */
        fun wdist(a: FloatArray, b: FloatArray, sd: FloatArray): Float {
            var s = 0f; for (i in a.indices) { val d = (a[i] - b[i]) / sd[i]; s += d * d }; return sqrt(s)
        }

        fun enroll(ctx: Context, done: (String) -> Unit) = Thread {
            try {
                val total = 16000 * 12
                val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, 32000)
                val pcm = ShortArray(total); rec.startRecording()
                var n = 0; while (n < total) { val r = rec.read(pcm, n, minOf(1600, total - n)); if (r <= 0) break; n += r }
                rec.stop(); rec.release()
                val chunk = 24000  // 1.5 s, same as live check
                val vs = (0 until total / chunk).mapNotNull { Mfcc.vector(pcm.copyOfRange(it * chunk, (it + 1) * chunk)) }
                if (vs.size < 4) return@Thread done("Awaaz kam/shor zyada tha, shant jagah dobara try karo.")
                val c = FloatArray(24) { i -> vs.map { it[i] }.average().toFloat() }
                // Har hisse ka apna phailav; bahut chhote phailav ko floor do taaki ek hissa match ko kaid na kar le.
                // NOTE: sumOf ka Float wala version Kotlin mein hota hi nahi (sirf Int/Long/Double/UInt/ULong) -
                // isiliye andar ka hisaab Double mein rakho, warna "overload resolution ambiguity" se build fail hoti hai.
                val rawSd = FloatArray(24) { i ->
                    val m = c[i]; sqrt(vs.sumOf { ((it[i] - m) * (it[i] - m)).toDouble() } / vs.size).toFloat() }
                val avgSd = rawSd.average().toFloat()
                val effSd = FloatArray(24) { i -> maxOf(rawSd[i], avgSd * 0.30f, 0.05f) }
                val self = vs.map { wdist(it, c, effSd) }.average().toFloat()
                val newThr = (self * 1.6f).coerceIn(4.0f, 12.0f)
                ctx.getSharedPreferences("vaani", Context.MODE_PRIVATE).edit()
                    .putString("vp_center", c.joinToString(","))
                    .putString("vp_sd", effSd.joinToString(","))
                    .putFloat("vp_thr", newThr).apply()
                done("Awaaz save ho gayi (${vs.size} samples, naya smart match).")
            } catch (e: Exception) { done("Record nahi hua: ${e.message?.take(80)}") }
        }.start()
    }
}
