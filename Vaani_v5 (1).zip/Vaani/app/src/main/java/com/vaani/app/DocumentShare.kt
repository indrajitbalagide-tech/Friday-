package com.vaani.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/*
 * FEATURE 4 — Document + photo understanding.
 *
 * Share-to-Vaani: AndroidManifest mein MainActivity par ACTION_SEND intent-filter
 * laga hai (application/pdf, image/*, text/plain). MainActivity ko EDIT karna
 * coordinator ke paas hai — usme ye snippet chahiye (onCreate + onNewIntent dono):
 *
 *   override fun onCreate(b: Bundle?) {
 *       super.onCreate(b)
 *       // ... existing setup ...
 *       handleShareIntent()            // <-- ADD: share se khula ho to turant handle karo
 *   }
 *   override fun onNewIntent(i: Intent) {
 *       super.onNewIntent(i)
 *       setIntent(i)
 *       handleShareIntent()            // <-- ADD: app pehle se khuli ho to bhi
 *   }
 *   private fun handleShareIntent() {  // <-- ADD poora function
 *       val msg = DocumentShare.handleShareIntent(this, intent) ?: return
 *       say(msg)                       // dashboard log mein dikh jayega
 *   }
 *
 * NOTE: manifest mein MainActivity par android:launchMode="singleTop" bhi add
 * kiya gaya hai, warna onNewIntent kabhi fire nahi hota (har share naya
 * instance kholta). Share karte waqt Vaani ko kholne ke liye API key pehle se
 * set honi chahiye; nahi to share sirf save hota hai, jawab setup ke baad milta hai.
 *
 * PDF text: Android mein PDF ka text-layer nikalne wala koi built-in API nahi
 * hai. PdfRenderer sirf pages ko bitmap banata hai, isiliye text Gemini Vision
 * (image -> text) se nikalta hai. Gemini key na ho to PDF khul to jata hai par
 * text nahi nikalta — us haal mein saaf note lautata hai, jhootha text nahi.
 * Kabhi bhi password / PIN / OTP yahan save nahi hota.
 */

/** Share intent ko pakadna + document ka text nikalna. */
object DocumentShare {

    private const val PREF_LAST_URI = "last_doc_uri"
    private const val PREF_LAST_TEXT = "last_doc_text"

    /**
     * MainActivity se bulao (snippet upar dekho). ACTION_SEND intent ho to uska
     * content save karta hai aur ek line ka Hinglish jawab lautata hai; share
     * intent na ho to null (MainActivity kuch na kare).
     */
    fun handleShareIntent(c: Context, intent: Intent?): String? {
        if (intent == null || intent.action != Intent.ACTION_SEND) return null
        val type = intent.type.orEmpty()
        val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)
        val p = P.of(c).edit()
        return when {
            uri != null -> {
                p.putString(PREF_LAST_URI, uri.toString()).apply()
                val kind = when {
                    type.startsWith("application/pdf") -> "PDF"
                    type.startsWith("image/") -> "photo"
                    else -> "file"
                }
                "📄 $kind mil gaya. Uske baare mein kuch bhi poochho — jaise \"ye kitne ka hai?\" ya \"isme deadline kya hai?\""
            }
            !text.isNullOrBlank() -> {
                p.putString(PREF_LAST_TEXT, text.take(8000)).apply()
                "📄 Text mil gaya (${text.length} akshar). Uske baare mein kuch bhi poochho."
            }
            else -> "Share khaali aaya — koi file ya text nahi mila."
        }
    }

    /** Aakhri share ki gayi cheez (uri ya text) — document_understand ka default input. */
    fun lastShared(c: Context): Pair<String?, String?> =
        P.of(c).getString(PREF_LAST_URI, null) to P.of(c).getString(PREF_LAST_TEXT, null)

    private fun jpegOf(bm: Bitmap, maxSide: Int): ByteArray {
        var b = bm
        val s = maxSide.toFloat() / maxOf(b.width, b.height)
        if (s < 1f) b = Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
        val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 80, o); return o.toByteArray()
    }

    /** Ek bitmap ko Gemini Vision ko dikhakar usme likha text / jawab nikalna. Key na ho to khaali. */
    private fun askImage(key: String, jpeg: ByteArray, prompt: String): String {
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray()
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))))
            .put(JSONObject().put("text", prompt)))))
        val parts = Gemini.post(key, body).getJSONArray("parts")
        val sb = StringBuilder(); for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString().trim()
    }

    private fun geminiKey(c: Context): String = P.of(c).getString("key", "").orEmpty()

    /** Uri ek PDF hai ya image — mime type ya naam se pehchano. */
    fun isPdf(c: Context, uri: Uri): Boolean {
        val type = c.contentResolver.getType(uri).orEmpty()
        if (type == "application/pdf") return true
        val name = uri.lastPathSegment.orEmpty().lowercase()
        return name.endsWith(".pdf")
    }

    /**
     * Document ka text nikalna.
     * uriOrText: content:// uri, file path, ya seedha text. Plain text seedha
     * lautata hai. PDF: pehle 5 pages render karke Gemini Vision se padhta hai
     * (key ho to); key na ho to saaf note. Image/screenshot: Vision/Gemini look
     * path se padhta hai (key ho to).
     */
    fun extractText(c: Context, uriOrText: String): String {
        val input = uriOrText.trim()
        if (input.isEmpty()) return "Kuch diya hi nahi — PDF, photo ya text share karo."
        // Uri jaisa nahi lagta to ye seedha text hi hai.
        if (!input.startsWith("content://") && !input.startsWith("file://") && !input.startsWith("/")) return input
        val uri = try { Uri.parse(input) } catch (e: Exception) { return "Ye uri samajh nahi aayi." }
        val key = geminiKey(c)
        return try {
            if (isPdf(c, uri)) extractPdf(c, uri, key) else extractImage(c, uri, key)
        } catch (e: Exception) { "Document khol nahi paya: ${e.message?.take(80)}" }
    }

    /** PDF: pehle 5 pages bitmap -> Gemini Vision OCR. Bina key ke sirf note. */
    private fun extractPdf(c: Context, uri: Uri, key: String): String {
        if (key.isEmpty()) return "PDF khul gaya, text nikalne ke liye Gemini key chahiye. " +
            "Settings mein API key daalo, phir dobara poochho."
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        return try {
            pfd = c.contentResolver.openFileDescriptor(uri, "r") ?: return "PDF khul nahi paya."
            renderer = PdfRenderer(pfd)
            val pages = minOf(renderer.pageCount, 5)
            if (pages == 0) return "PDF khaali hai, koi page nahi mila."
            val out = StringBuilder()
            for (i in 0 until pages) {
                val page = renderer.openPage(i)
                val bm = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
                page.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                val txt = askImage(key, jpegOf(bm, 1024),
                    "Is PDF page par jo bhi text likha hai, use bilkul waise hi likh do. Koi summary mat banao, sirf text. " +
                        "Agar koi text na ho to 'NO_TEXT' likh do.")
                if (txt.isNotEmpty() && txt != "NO_TEXT") out.append(txt).append("\n")
                try { bm.recycle() } catch (_: Exception) {}
            }
            val text = out.toString().trim()
            if (text.isEmpty()) "PDF ke pehle $pages pages mein padhne layak text nahi mila (shayad scanned image hai ya khaali page)."
            else text
        } finally {
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
        }
    }

    /** Image / screenshot: pehle Vision.look path (camera/screen nahi, file hai), yahan seedha Gemini Vision. */
    private fun extractImage(c: Context, uri: Uri, key: String): String {
        if (key.isEmpty()) return "Photo mil gayi, usme kya likha hai ye batane ke liye Gemini key chahiye. Settings mein API key daalo."
        val bytes = c.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return "Photo khul nahi payi."
        val bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return "Photo samajh nahi aayi."
        // Portrait photo ho to seedha rakho; rotation EXIF yahan handle nahi hota (limit, README dekho).
        val matrix = Matrix()
        val fixed = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, matrix, true)
        return askImage(key, jpegOf(fixed, 1280),
            "Is image mein jo bhi text likha hai, use bilkul waise hi likh do. Koi summary mat banao, sirf text. " +
                "Agar koi text na ho to image mein kya dikh raha hai, 2-3 short lines mein batao.").ifEmpty { "Photo mein kuch padh nahi paya." }
    }

    private val AMOUNT = Regex("(?:₹|Rs\\.?|INR|rupees?)\\s*\\d[\\d,]*\\.?\\d*|\\d[\\d,]*\\.?\\d*\\s*(?:₹|rupees?)", RegexOption.IGNORE_CASE)
    private val DATE = Regex("\\b\\d{1,2}[/\\-.]\\d{1,2}[/\\-.]\\d{2,4}\\b|\\b\\d{1,2}\\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\\s+\\d{2,4}\\b", RegexOption.IGNORE_CASE)

    /** Sawaal ke hisaab se document ka jawab — Hinglish mein. */
    fun answerAboutDocument(c: Context, uriOrText: String, question: String): String {
        val q = question.trim().lowercase()
        // Khali input ho to aakhri share ki hui cheez lo.
        val input = uriOrText.ifBlank {
            val (uri, text) = lastShared(c)
            uri ?: text ?: return "Pehle koi PDF, photo ya text share karo, phir uske baare mein poochho."
        }
        val text = extractText(c, input)
        if (text.startsWith("PDF khul gaya") || text.startsWith("Photo mil gayi") || text.startsWith("Document khol nahi"))
            return text  // key / file ki dikkat — wahi saaf note lautao
        val key = geminiKey(c)
        return when {
            // "ye kitne ka hai" — ₹ / Rs wali rakam dhoondho.
            q.contains("kitne ka") || q.contains("price") || q.contains("amount") || q.contains("paise") || q.contains("₹") || q.contains("cost") -> {
                val amounts = AMOUNT.findAll(text).map { it.value.trim() }.distinct().take(5).toList()
                if (amounts.isEmpty()) "Is document mein koi rakam (₹/Rs) nahi mili."
                else "Isme ye rakam mili: ${amounts.joinToString(", ")}."
            }
            // "isme deadline kya hai" — tareekh dhoondho.
            q.contains("deadline") || q.contains("date") || q.contains("tareekh") || q.contains("kab tak") || q.contains("last date") -> {
                val dates = DATE.findAll(text).map { it.value.trim() }.distinct().take(5).toList()
                if (dates.isEmpty()) "Is document mein koi tareekh nahi mili."
                else "Isme ye tareekh mili: ${dates.joinToString(", ")} — kaun si deadline hai, ye context se check kar lo."
            }
            // Summary — pehle ~500 chars + key ho to Gemini summary.
            q.contains("summary") || q.contains("saransh") || q.contains("kya hai") || q.isEmpty() -> {
                val head = text.take(500)
                if (key.isEmpty()) "Summary: $head"
                else try {
                    val parts = Gemini.ask(key, "Is document ka 2-3 lines mein Hinglish summary do:\n\n${text.take(4000)}", false)
                    val s = (0 until parts.length()).mapNotNull { parts.getJSONObject(it).optString("text").ifEmpty { null } }.joinToString(" ").trim()
                    if (s.isEmpty()) "Summary: $head" else s
                } catch (e: Exception) { "Summary: $head" }
            }
            // Aam sawaal — key ho to Gemini se, warna text mein dhoondho.
            else -> {
                if (key.isEmpty()) {
                    val words = q.split(Regex("\\s+")).filter { it.length > 3 }
                    val line = text.lines().firstOrNull { l -> words.any { l.lowercase().contains(it) } }
                    line?.trim()?.take(300) ?: "Is document mein is sawaal ka jawab nahi mila. Gemini key hoti to main khud padhkar batata."
                } else try {
                    val parts = Gemini.ask(key, "Document:\n${text.take(4000)}\n\nSawaal: $question\nHinglish mein 1-2 short lines mein jawab do.", false)
                    val s = (0 until parts.length()).mapNotNull { parts.getJSONObject(it).optString("text").ifEmpty { null } }.joinToString(" ").trim()
                    s.ifEmpty { "Is document mein is sawaal ka jawab nahi mila." }
                } catch (e: Exception) { "Jawab nahi de paya: ${e.message?.take(80)}" }
            }
        }
    }
}

/** Gemini tool: document_understand. */
object DocumentTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject(); for ((k, v) in props) p.put(k, v)
            val params = JSONObject().put("type", "OBJECT").put("properties", p)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    fun decls(): List<JSONObject> = listOf(
        fn("document_understand", "Share ki gayi PDF, photo ya text ke baare mein sawaal ka jawab: kitne ka hai, deadline kya hai, summary kya hai.",
            mapOf("uri_or_text" to sp("PDF/photo ki content uri, ya seedha text. Khaali ho to aakhri share ki hui cheez li jayegi."),
                "question" to sp("sawaal, jaise 'ye kitne ka hai', 'isme deadline kya hai', 'summary batao' (optional)")),
            listOf("uri_or_text"))
    )

    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "document_understand" -> DocumentShare.answerAboutDocument(c, a.optString("uri_or_text"), a.optString("question"))
        else -> null
    }
}
