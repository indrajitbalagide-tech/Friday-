package com.vaani.app

import android.os.Handler
import android.os.Looper
import android.widget.HorizontalScrollView

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONObject

/**
 * Do hisse:
 * 1) SETUP / LOGIN screen - API key verify + saari permissions ki checklist. Sab green hue bina entry nahi.
 * 2) DASHBOARD - sirf live conversation (header, status aur type-box ke saath). Koi faltu gardi nahi.
 */
class MainActivity : Activity() {
    // dashboard views
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var wave: WaveView
    private lateinit var batt: TextView
    // setup views
    private lateinit var keyBox: EditText
    private lateinit var setupHint: TextView
    private lateinit var checkList: LinearLayout
    private lateinit var enterBtn: Button
    private lateinit var setupRoot: ScrollView
    private lateinit var dashRoot: LinearLayout
    private var dashBuilt = false
    private var onDashboard = false
    private val agentNames = listOf("Ears", "Speech", "Brain", "Hands", "Eyes", "Phone", "Mouth", "Memory", "Files", "Home", "Camera")
    private lateinit var officeView: OfficeView
    private lateinit var officeLine: TextView
    private var boardHandler: Handler? = null
    private var greeted = false
    private var lastHint = ""
    private val prefs by lazy { getSharedPreferences("vaani", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun panel(radius: Int, fill: String, stroke: String) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat(); setColor(Color.parseColor(fill)); setStroke(dp(1), Color.parseColor(stroke))
    }
    private fun bgGrad() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.parseColor("#170409"), Color.parseColor("#010409")))

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
            Manifest.permission.ANSWER_PHONE_CALLS, "android.permission.POST_NOTIFICATIONS",
            Manifest.permission.READ_CALENDAR, Manifest.permission.READ_SMS, Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION), 1)
        window.statusBarColor = Color.parseColor("#12030A")
        // Lockscreen ke upar bhi app khule (unlock nahi hota - sirf Vaani ki screen dikhti hai)
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        buildSetup()
        VaaniService.log = { t -> say(t) }
        // Key pehle se hai to seedha andar - har baar verification ka jhanjhat nahi.
        if (prefs.getString("key", "").orEmpty().isNotEmpty()) showDashboard()
        else { setContentView(setupRoot); refreshSetup() }
        handleShareIntent()
    }

    /** v5.0 Share-to-Vaani: PDF/photo/text share se khula ho to turant handle karo. */
    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        handleShareIntent()
    }

    private fun handleShareIntent() {
        val msg = DocumentShare.handleShareIntent(this, intent) ?: return
        say(msg)
    }

    /** v5.0 Security: fingerprint/PIN confirm ka result (security_auth / risky kaam). */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (Security.onAuthResult(this, requestCode, resultCode)) say("✅ Confirm ho gaya.")
    }

    // ---------- SETUP / LOGIN ----------

    private fun buildSetup() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(30), dp(18), dp(18)) }
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        titleRow.addView(ImageView(this).apply { setImageResource(R.drawable.vaani_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP; background = panel(20, "#160409", "#FF2E4D")
            setPadding(dp(2), dp(2), dp(2), dp(2)) }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(10) })
        titleRow.addView(TextView(this).apply { text = "VAANI "; textSize = 25f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        titleRow.addView(TextView(this).apply { text = "AI"; textSize = 25f; setTextColor(Color.parseColor("#FF2E4D")); typeface = Typeface.DEFAULT_BOLD })
        root.addView(titleRow)
        root.addView(TextView(this).apply { text = "PERSONAL INTELLIGENCE SYSTEM"; textSize = 9f; letterSpacing = 0.32f
            setTextColor(Color.parseColor("#C47F8C")); setPadding(0, dp(2), 0, dp(14)) })
        root.addView(TextView(this).apply { text = "API KEY DAALO AUR ANDAR AAO — BAAKI SETUP BAAD MEIN BHI HO SAKTA HAI"; textSize = 10f
            letterSpacing = 0.12f; setTextColor(Color.parseColor("#F2A0AC")); setPadding(0, 0, 0, dp(8)) })

        root.addView(TextView(this).apply { text = "GEMINI API KEY"; textSize = 8f; letterSpacing = 0.3f; setTextColor(Color.parseColor("#C47F8C")) })
        keyBox = EditText(this).apply { hint = "API key yahan daalo"; setText(prefs.getString("key", "")); setSingleLine()
            textSize = 13f; setTextColor(Color.parseColor("#EAF9FF")); setHintTextColor(Color.parseColor("#C47F8C"))
            background = panel(10, "#04121F", "#70101F"); setPadding(dp(10), dp(9), dp(10), dp(9))
            imeOptions = EditorInfo.IME_ACTION_DONE
            setOnEditorActionListener { _, _, _ -> prefs.edit().putString("key", keyBox.text.toString().trim()).apply(); showDashboard(); true } }
        root.addView(keyBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        val verifyBtn = Button(this).apply { text = "✅ API VERIFY KARO"; setTextColor(Color.WHITE); textSize = 14f
            typeface = Typeface.DEFAULT_BOLD; background = panel(12, "#3D0A14", "#FF2E4D"); setOnClickListener { verifyKey() } }
        root.addView(verifyBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        setupHint = TextView(this).apply { textSize = 13f; setTextColor(Color.parseColor("#FFD9A0")); setPadding(0, dp(10), 0, dp(4)) }
        root.addView(setupHint)

        root.addView(TextView(this).apply { text = "CHECKLIST — SAB FEATURES KE LIYE YE ON RAKHO (JO BAAKI HO, TAP KARKE THEEK KARO — ENTRY NAHI RUKEGI)"; textSize = 8f; letterSpacing = 0.25f
            setTextColor(Color.parseColor("#C47F8C")); setPadding(0, dp(8), 0, dp(2)) })
        checkList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(checkList)

        enterBtn = Button(this).apply { text = "🚀 VAANI KHOLO"; setTextColor(Color.WHITE); textSize = 16f
            typeface = Typeface.DEFAULT_BOLD; background = panel(14, "#3D0A14", "#FF2E4D")
            setOnClickListener { prefs.edit().putString("key", keyBox.text.toString().trim()).apply(); showDashboard() } }
        root.addView(enterBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        setupRoot = ScrollView(this).apply { background = bgGrad(); addView(root) }
    }

    private fun phonePerms() = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
        checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED

    private fun adminOn() = getSystemService(DevicePolicyManager::class.java)
        .isAdminActive(ComponentName(this, AdminReceiver::class.java))

    private fun filesAccess() = android.os.Build.VERSION.SDK_INT < 30 ||
        android.os.Environment.isExternalStorageManager()

    /** OEM autostart screen - Xiaomi/Oppo/Vivo par accessibility ka band hona yahi se rukta hai. */
    private fun openAutostart() {
        val tries = listOf(
            Intent().setClassName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
            Intent().setClassName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            Intent().setClassName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        for (i in tries) { try { startActivity(i); return } catch (e: Exception) { /* agla try karo */ } }
    }

    private fun verifiedKey(): Boolean {
        val k = if (::keyBox.isInitialized) keyBox.text.toString().trim() else prefs.getString("key", "").orEmpty()
        return k.isNotEmpty() && prefs.getBoolean("key_verified", false) && prefs.getString("verified_key", "") == k
    }

    private fun allChecks(): List<Triple<String, Boolean, () -> Unit>> {
        val pm = getSystemService(PowerManager::class.java)
        return listOf(
            Triple("API key verify", verifiedKey()) { verifyKey() },
            Triple("Mic permission", checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2) },
            Triple("Phone permission (call ki pehchan ke liye ZAROORI)", phonePerms()) {
                requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.READ_CONTACTS, Manifest.permission.ANSWER_PHONE_CALLS), 41) },
            Triple("Meri awaaz enrolled", VoicePrint(this).enrolled()) { enroll() },
            Triple("Notification access", (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            Triple("Floating orb permission", Settings.canDrawOverlays(this)) { overlayPerm() },
            Triple("Battery unrestricted", pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) },
            Triple("Accessibility on", (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            Triple("Device admin (pakka screen-lock)", adminOn()) {
                val comp = ComponentName(this, AdminReceiver::class.java)
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)) },
            Triple("Files access (file delete ke liye)", filesAccess()) {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) },
            Triple("Autostart ON (warna accessibility band hoti rahegi)", prefs.getBoolean("autostart_seen", false)) {
                prefs.edit().putBoolean("autostart_seen", true).apply(); openAutostart() }
        )
    }

    private fun refreshSetup() {
        if (!::checkList.isInitialized) return
        val checks = allChecks()
        checkList.removeAllViews()
        for ((label, ok, action) in checks) {
            checkList.addView(TextView(this).apply {
                text = (if (ok) "✅  " else "⬜  ") + label + if (ok) "" else "   → tap karo"
                textSize = 15f; setTextColor(Color.parseColor(if (ok) "#9FE8B1" else "#DFF6FF"))
                background = panel(10, "#04121F", if (ok) "#1E7A46" else "#70101F")
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }
        val hasKey = keyBox.text.toString().trim().isNotEmpty()
        enterBtn.isEnabled = hasKey
        enterBtn.alpha = if (hasKey) 1f else 0.45f
        enterBtn.text = if (hasKey) "🚀 VAANI KHOLO" else "🚀 VAANI KHOLO  (pehle API key daalo)"
    }

    private fun verifyKey() {
        val key = keyBox.text.toString().trim()
        if (key.isEmpty()) { setupHint.text = "⚠ Pehle API key daalo."; return }
        prefs.edit().putString("key", key).putBoolean("key_verified", false).apply()
        setupHint.text = "⏳ Google se verify ho raha hai…"
        Thread {
            try {
                Gemini.ask(key, "hi", false)
                prefs.edit().putBoolean("key_verified", true).putString("verified_key", key).apply()
                runOnUiThread { setupHint.text = "✅ API verify ho gaya!"; refreshSetup() }
            } catch (e: Exception) {
                runOnUiThread { setupHint.text = "❌ Verify fail: ${e.message?.take(200)}"; refreshSetup() }
            }
        }.start()
    }

    // ---------- DASHBOARD (sirf conversation) ----------

    private fun buildDashboard() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(20), dp(14), dp(12)); background = bgGrad() }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(ImageView(this).apply { setImageResource(R.drawable.vaani_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP; background = panel(18, "#160409", "#FF2E4D")
            setPadding(dp(2), dp(2), dp(2), dp(2)) }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(8) })
        header.addView(TextView(this).apply { text = "VAANI "; textSize = 17f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        header.addView(TextView(this).apply { text = "AI"; textSize = 17f; setTextColor(Color.parseColor("#FF2E4D")); typeface = Typeface.DEFAULT_BOLD })
        header.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        batt = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#F2A0AC")) }
        header.addView(batt)
        header.addView(Button(this).apply { text = "⚙"; textSize = 13f; setTextColor(Color.parseColor("#DFF6FF"))
            background = panel(10, "#26060D", "#8F1D30"); setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) } })
        header.addView(Button(this).apply { text = "🔑"; textSize = 13f; setTextColor(Color.parseColor("#DFF6FF"))
            background = panel(10, "#26060D", "#8F1D30"); setOnClickListener { logout() } })
        root.addView(header)

        status = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = panel(22, "#2A0810", "#FF2E4D"); setPadding(dp(10), dp(9), dp(10), dp(9)) }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        wave = WaveView(this)
        root.addView(wave, LinearLayout.LayoutParams(-1, dp(22)).apply { topMargin = dp(4) })

        val office = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
            background = panel(16, "#0D0207", "#70101F"); setPadding(dp(10), dp(8), dp(10), dp(10)) }
        office.addView(TextView(this).apply { text = "🏢 VAANI OFFICE — LIVE"; textSize = 10f; letterSpacing = 0.25f
            setTextColor(Color.parseColor("#FF8FA3")); typeface = Typeface.DEFAULT_BOLD })
        officeView = OfficeView(this)
        office.addView(officeView, LinearLayout.LayoutParams(-1, dp(300)).apply { topMargin = dp(4) })
        officeLine = TextView(this).apply { textSize = 10f; setTextColor(Color.parseColor("#C9A0AA"))
            gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0); text = "💤 Abhi sab aaram kar rahe hain" }
        office.addView(officeLine)
        root.addView(office, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        log = TextView(this).apply {
            textSize = 15f; setTextColor(Color.parseColor("#CDEFFF")); setPadding(dp(12), dp(10), dp(12), dp(10))
            movementMethod = ScrollingMovementMethod(); isVerticalScrollBarEnabled = true
            background = panel(12, "#03101C", "#70101F")
        }
        root.addView(log, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })

        // Type karne wala option user ke kehne par hata diya - ab baat sirf awaaz se hogi.

        toggle = Button(this).apply { setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            background = panel(22, "#3D0A14", "#FF2E4D"); setOnClickListener { toggleMode() } }
        root.addView(toggle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        dashRoot = root; dashBuilt = true
    }

    private fun showDashboard() {
        if (!dashBuilt) buildDashboard()
        onDashboard = true
        setContentView(dashRoot)
        if (!greeted) { greeted = true; say("🤖 Namaste! Main Vaani hu. Hindi, मराठी, English ya Hinglish, jo bhi bolo.")
            Speaker.speak(this, "Namaste! Main Vaani hu. Kahiye, kya karun?") }
        Habits.suggestion(this)?.let { say("🧠 $it") }
        startBoard()
        autoStart()
    }

    private fun refreshBoard() {
        if (!::officeView.isInitialized) return
        val now = System.currentTimeMillis()
        val habitsN = try { JSONObject(prefs.getString("habits", "{}") ?: "{}").length() } catch (e: Exception) { 0 }
        val working = booleanArrayOf(
            VaaniService.running,
            AgentStatus.sttAt > 0 && now - AgentStatus.sttAt < 90_000,
            AgentStatus.brain == "Soch raha hai…" || AgentStatus.brain == "Live baat ho rahi hai",
            AgentStatus.workerAt > 0 && now - AgentStatus.workerAt < 120_000,
            AgentStatus.khabarAt > 0 && now - AgentStatus.khabarAt < 300_000,
            (AgentStatus.callAt > 0 && now - AgentStatus.callAt < 300_000) || AgentStatus.call.contains("aa raha"),
            AgentStatus.voiceAt > 0 && now - AgentStatus.voiceAt < 60_000,
            habitsN > 0,
            AgentStatus.filesAt > 0 && now - AgentStatus.filesAt < 300_000,
            AgentStatus.homeAt > 0 && now - AgentStatus.homeAt < 300_000,
            AgentStatus.camAt > 0 && now - AgentStatus.camAt < 300_000)
        val status = arrayOf(
            if (VaaniService.running) "Sun raha hai" else "Band hai",
            AgentStatus.stt,
            AgentStatus.brain, AgentStatus.worker, AgentStatus.khabar, AgentStatus.call, AgentStatus.voice,
            if (habitsN == 0) "Seekh rahi hai" else "$habitsN aadatein seekhi",
            AgentStatus.files, AgentStatus.home, AgentStatus.cam)
        officeView.working = working
        officeView.bossOn = VaaniService.running
        val onDuty = (0 until 11).filter { working[it] }
        officeLine.text = if (onDuty.isEmpty()) "💤 Abhi sab aaram kar rahe hain — kaam aate hi desk par jaag jayenge"
            else onDuty.joinToString("  •  ") { "💻 ${agentNames[it]}: ${status[it]}" }
    }

    private fun startBoard() {
        stopBoard()
        val h = Handler(Looper.getMainLooper()); boardHandler = h
        val r = object : Runnable { override fun run() { if (onDashboard) { refreshBoard(); h.postDelayed(this, 2000) } } }
        h.post(r)
    }

    private fun stopBoard() { boardHandler?.removeCallbacksAndMessages(null); boardHandler = null }

    private fun logout() {
        prefs.edit().putBoolean("key_verified", false).apply()
        if (VaaniService.running) startService(Intent(this, VaaniService::class.java).setAction("STOP"))
        onDashboard = false
        setContentView(setupRoot); refreshSetup()
        setupHint.text = "🔑 Key dobara verify karke ghuso."
    }

    // ---------- shared logic ----------

    override fun onResume() { super.onResume(); if (onDashboard) autoStart() else refreshSetup() }
    override fun onPause() { if (::keyBox.isInitialized) prefs.edit().putString("key", keyBox.text.toString().trim()).apply(); super.onPause() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { if (onDashboard) autoStart() else refreshSetup() }

    private fun say(t: String, speak: Boolean = false) {
        if (onDashboard && ::log.isInitialized) runOnUiThread {
            log.append(t + "\n\n")
            if (log.text.length > 6000) log.text = log.text.takeLast(4000)   // keep memory flat over 24h
            log.layout?.let { l -> log.scrollTo(0, maxOf(0, l.getLineTop(log.lineCount) - log.height + log.paddingTop + log.paddingBottom)) }
        } else if (::setupHint.isInitialized) runOnUiThread { setupHint.text = t }
        if (speak) Speaker.speak(this, t)
    }

    private fun hint(t: String) { if (t != lastHint) { lastHint = t; say(t) } }

    private fun batteryPct(): Int {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (level >= 0) level * 100 / scale else -1
    }

    private fun refresh() { if (!onDashboard) return; runOnUiThread {
        status.text = if (VaaniService.running) "🟢 Hands-free ON, bas bolo" else "⚪ Hands-free band"
        toggle.text = if (VaaniService.running) "⏹ Hands-free band karo" else "▶ Hands-free chalu karo"
        if (::wave.isInitialized) wave.active = VaaniService.running
        val bp = batteryPct(); if (bp >= 0 && ::batt.isInitialized) batt.text = "🔋 $bp%"
    } }

    /** Dashboard par hi chalta hai: setup poora hue bina yahan koi nahi ghusta. */
    private fun autoStart() {
        if (!onDashboard) return
        refresh()
        if (VaaniService.running || prefs.getBoolean("manual_stop", false)) return
        when {
            prefs.getString("key", "").isNullOrEmpty() -> hint("👋 Pehle Gemini API key daalo.")
            !VoicePrint(this).enrolled() -> hint("🧬 Awaaz enrolled nahi hai — 🔑 se setup mein jaakar record karo.")
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED -> hint("🎙 Mic permission allow karo.")
            else -> { startForegroundService(Intent(this, VaaniService::class.java)); window.decorView.postDelayed({ refresh() }, 700) }
        }
    }

    private fun toggleMode() {
        if (VaaniService.running) { prefs.edit().putBoolean("manual_stop", true).apply()
            startService(Intent(this, VaaniService::class.java).setAction("STOP")); window.decorView.postDelayed({ refresh() }, 700) }
        else { prefs.edit().putBoolean("manual_stop", false).apply(); autoStart() }
    }

    private fun enroll() {
        val wasOn = VaaniService.running
        if (wasOn) startService(Intent(this, VaaniService::class.java).setAction("STOP"))
        window.decorView.postDelayed({
            say("🧬 Awaaz seekhna shuru — screen par ek-ek karke dialogues aayenge, unhe zor se padhte jao. Poora 1 minute lagega; shant jagah mein, phone munh ke paas rakhkar, normal awaaz mein bolo.")
            VoicePrint.enroll(this, { line -> say(line) }, { m -> say(m); runOnUiThread {
                prefs.edit().putBoolean("manual_stop", false).apply()
                if (onDashboard) autoStart() else refreshSetup()
            } })
        }, if (wasOn) 900 else 0)
    }

    private fun overlayPerm() {
        if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        else say("🪟 Overlay permission pehle se hai.")
    }

    /** Typed fallback (REST). Spoken conversation goes through the service + Gemini Live. */
    private fun handle(text: String) {
        if (text.isBlank()) return
        val key = prefs.getString("key", "").orEmpty()
        if (key.isEmpty()) return say("Pehle Gemini API key daalo.")
        say("🧑 $text")
        Thread {
            // AGENT MODE: Vaani khud steps banakar poora kaam karti hai (5 steps tak).
            try {
                if (!Net.online(this)) throw RuntimeException("offline")
                say("🤖 " + Gemini.askAgent(this, key, text), true)
            } catch (e: Exception) {
                // Internet/API na chale to basic offline commands
                val r = Offline.parse(this, text)
                if (r != null) say("🤖 $r", true) else say("⚠ ${e.message?.take(240)}")
            }
        }.start()
    }

    override fun onDestroy() { stopBoard(); VaaniService.log = null; super.onDestroy() }
}
