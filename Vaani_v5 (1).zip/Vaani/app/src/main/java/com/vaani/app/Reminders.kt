package com.vaani.app

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.CalendarContract
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/*
 * WIRING (Gemini.kt / Actions.kt / Extras.kt — inhe koi aur group edit karega, ye file nahi):
 *
 * Gemini.kt — tools lazy block mein, `for (d in Extras.decls()) fd.put(d)` ke baad:
 *     for (i in 0 until ReminderTools.decls().length()) fd.put(ReminderTools.decls().getJSONObject(i))
 *
 * Extras.kt — run() ke when() mein, `"reminder" -> Reminders.run(c, a)` ke aas-paas:
 *     "reminder_add", "reminder_list", "reminder_cancel" ->
 *         ReminderTools.dispatch(c, name, a) ?: "Ye reminder action nahi aata."
 *   (dispatch unknown naam par null lautata hai, isliye `?:` fallback zaroori hai.)
 *
 * AndroidManifest.xml mein ye entries chahiye (manifest is task mein edit nahi karna tha):
 *   <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
 *   <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
 *   <receiver android:name=".ReminderReceiver" android:exported="false" />
 *   <receiver android:name=".ReminderBootReceiver" android:exported="false">
 *       <intent-filter><action android:name="android.intent.action.BOOT_COMPLETED" /></intent-filter>
 *   </receiver>
 *   Android 12+ par exact alarm ke liye user ko Settings > Apps > Vaani > Alarms & reminders
 *   mein "Allow setting alarms" bhi on karna padta hai; band ho to inexact alarm lagta hai.
 *
 * Proactive.tick() Reminder ko chhoo nahi sakta (doosri file hai), isliye fireDue() hi
 * time + event + location teeno check karta hai — Proactive.tick pehle se fireDue bulata hai.
 */

/** Ek reminder: time-based, event ke baad wala, ya jagah wala (koi bhi ek ya zyada). */
data class ReminderItem(
    val id: String,
    val text: String,
    val who: String = "",
    val timeMs: Long = 0L,          // 0 = koi fixed time nahi (event/jagah wala)
    val afterEvent: String = "",
    val place: String = "",
    val done: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("text", text).put("who", who).put("at", timeMs)
        .put("afterEvent", afterEvent).put("place", place).put("done", done)

    companion object {
        fun fromJson(o: JSONObject): ReminderItem = ReminderItem(
            id = o.optString("id").ifEmpty { "r" + o.optLong("at").toString() },
            text = o.optString("text"),
            who = o.optString("who"),
            timeMs = o.optLong("at"),
            afterEvent = o.optString("afterEvent"),
            place = o.optString("place"),
            done = o.optBoolean("done")
        )
    }
}

/**
 * Yaad-dilaane wala system: "kal 5 baje Rahul ko call karna yaad dilana", "20 minute baad gas band karna",
 * "meeting khatam hote hi...", "ghar pahunchte hi...". Reminders phone par save rahte hain (prefs "rems").
 * Time wale AlarmManager se bhi lagte hain (reboot par dobara lagte hain) aur Proactive.tick
 * har ~30 sec mein fireDue() se check karta hai. Ek baar bolne ke baad reminder hat jaata hai.
 */
object Reminders {
    private const val ACTION_REMIND = "com.vaani.app.ACTION_REMINDER"
    private const val GEO_RADIUS_M = 200f   // location reminder: jagah se ~200m ke andar

    private fun load(c: Context): JSONArray =
        try { JSONArray(P.of(c).getString("rems", "[]")) } catch (e: Exception) { JSONArray() }

    private fun save(c: Context, arr: JSONArray) { P.of(c).edit().putString("rems", arr.toString()).apply() }

    private fun items(c: Context): MutableList<ReminderItem> {
        val arr = load(c); val out = ArrayList<ReminderItem>()
        for (i in 0 until arr.length()) try { out.add(ReminderItem.fromJson(arr.getJSONObject(i))) } catch (_: Exception) {}
        return out
    }

    private fun saveItems(c: Context, list: List<ReminderItem>) {
        val arr = JSONArray(); for (r in list) arr.put(r.toJson()); save(c, arr)
    }

    private fun fmt(at: Long) = SimpleDateFormat("EEE d MMM, h:mm a", Locale("hi", "IN")).format(Date(at))

    // ---------------- Hinglish time parsing ----------------

    private val HINDI_NUM = mapOf(
        "ek" to 1, "do" to 2, "teen" to 3, "chaar" to 4, "paanch" to 5, "chhe" to 6,
        "saat" to 7, "aath" to 8, "nau" to 9, "das" to 10, "gyarah" to 11, "barah" to 12
    )
    // (naam, Calendar day) — Hindi + English, chhote naam bhi.
    private val WEEKDAYS = listOf(
        listOf("ravivaar", "ravivar", "sunday", "sun", "itvaar") to Calendar.SUNDAY,
        listOf("somvaar", "somvar", "monday", "mon", "som") to Calendar.MONDAY,
        listOf("mangalvaar", "mangalvar", "tuesday", "tue", "mangal") to Calendar.TUESDAY,
        listOf("budhvaar", "budhvar", "wednesday", "wed", "budh") to Calendar.WEDNESDAY,
        listOf("guruvaar", "guruvar", "brihaspativar", "thursday", "thu", "guru") to Calendar.THURSDAY,
        listOf("shukravaar", "shukravar", "friday", "fri", "shukra") to Calendar.FRIDAY,
        listOf("shanivaar", "shanivar", "saturday", "sat", "shani") to Calendar.SATURDAY
    )

    /**
     * Natural Hinglish samay: "kal 5 baje", "aaj shaam 7 baje", "parso subah 9 baje",
     * "10 minute baad", "1 ghante baad", "agle somvaar 5 baje", "raat 9 baje", "saade 5 baje".
     * Kuch na samjhe to null. Rules: "kal" = aane wala kal; bina subah/shaam bataye "5 baje"
     * ka matlab agla aane wala 5 (subah ho to shaam 5, shaam ho to kal subah 5).
     */
    fun parseHinglishTime(text: String, now: Long = System.currentTimeMillis()): Long? {
        val t = text.lowercase(Locale("hi", "IN")).trim()
        if (t.isEmpty()) return null
        val cal = Calendar.getInstance().apply {
            timeInMillis = now; set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }

        // ---- relative: "10 minute baad", "1 ghante baad", "2 ghante 30 minute baad", "aadhe ghante baad"
        if (t.contains("baad") || t.contains("mein") || t.contains("mai")) {
            var mins = 0L
            Regex("""(\d+)\s*(minute|min|mint)\b""").find(t)?.let { mins += it.groupValues[1].toLong() }
            val hNum = Regex("""(\d+)\s*(ghante|ghanta|hour|hrs?)\b""").find(t)?.groupValues?.get(1)?.toLongOrNull()
            if (hNum != null) mins += hNum * 60
            if (t.contains("aadhe ghante") || t.contains("aadha ghanta")) mins += 30
            if (t.contains("ek ghante") || t.contains("ek ghanta")) mins += 60
            if (t.contains("do ghante")) mins += 120
            if (t.contains("teen ghante")) mins += 180
            if (mins > 0) return now + mins * 60_000L
        }

        // ---- din: parso / kal / aaj / weekday
        var dayOffset: Int? = null
        var nextWeek = t.contains("agle") || t.contains("aane wale") || t.contains("next")
        var weekday: Int? = null
        when {
            t.contains("parso") || t.contains("day after tomorrow") -> dayOffset = 2
            t.contains("narso") -> dayOffset = 3
            t.contains("kal") || t.contains("tomorrow") -> dayOffset = 1
            t.contains("aaj") || t.contains("today") -> dayOffset = 0
            else -> for ((names, day) in WEEKDAYS) {
                if (names.any { t.contains(it) }) { weekday = day; break }
            }
        }

        // ---- ghanta: "5 baje", "5:30 baje", "saade 5 baje" (5:30), "sava 5" (5:15), "paune 5" (4:45)
        var hour: Int? = null; var minute = 0
        Regex("""(\d{1,2})\s*:\s*(\d{2})""").find(t)?.let {
            hour = it.groupValues[1].toIntOrNull(); minute = it.groupValues[2].toIntOrNull() ?: 0
        }
        if (hour == null) Regex("""(\d{1,2})\s*(baje|bajey|baj)\b""").find(t)?.let {
            hour = it.groupValues[1].toIntOrNull()
        }
        if (hour == null) for ((w, n) in HINDI_NUM) {
            if (Regex("""\b$w\s*(baje|bajey|baj)\b""").containsMatchIn(t)) { hour = n; break }
        }
        if (hour != null) {
            if (t.contains("saade") || t.contains("sadhe")) minute = 30
            else if (t.contains("sava")) minute = 15
            else if (t.contains("paune")) { hour = (hour!! - 1 + 24) % 24; minute = 45 }
        }

        // ---- subah / dopahar / shaam / raat (sirf 12-hour ghante par lagu)
        val marker = when {
            t.contains("subah") || t.contains("morning") -> "subah"
            t.contains("dopahar") || t.contains("afternoon") -> "dopahar"
            t.contains("shaam") || t.contains("evening") -> "shaam"
            t.contains("raat") || t.contains("night") -> "raat"
            else -> null
        }
        if (hour == null) {
            // Sirf "kal shaam ko" / "subah" — marker ka default time.
            hour = when (marker) { "subah" -> 7; "dopahar" -> 13; "shaam" -> 18; "raat" -> 21; else -> null }
                ?: return null   // na din, na time — kuch samajh nahi aaya
            minute = 0
        }
        var h = hour!!
        if (h in 1..12 && marker != null) {
            h = when (marker) {
                "subah" -> h % 12                 // subah 12 = 0 (aadhi raat), subah 5 = 5
                "dopahar" -> if (h == 12) 12 else h + 12
                "shaam" -> if (h == 12) 12 else h + 12
                else -> if (h == 12) 0 else h + 12   // raat 12 = 0, raat 9 = 21
            }
        }

        // ---- din lagao
        if (weekday != null) {
            val today = cal.get(Calendar.DAY_OF_WEEK)
            var ahead = (weekday - today + 7) % 7
            if (nextWeek && ahead == 0) ahead = 7
            cal.add(Calendar.DAY_OF_YEAR, ahead)
            cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, minute)
            if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 7)   // aaj ka time nikal gaya to agle hafte
        } else {
            cal.add(Calendar.DAY_OF_YEAR, dayOffset ?: 0)
            cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, minute)
            if (cal.timeInMillis <= now) {
                if (marker == null && h in 1..11 && dayOffset == null) {
                    // "5 baje" bina marker: aaj ka doosra 5 (shaam) try karo.
                    cal.set(Calendar.HOUR_OF_DAY, h + 12)
                    if (cal.timeInMillis <= now) { cal.add(Calendar.DAY_OF_YEAR, 1); cal.set(Calendar.HOUR_OF_DAY, h) }
                } else cal.add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        return cal.timeInMillis
    }

    /** "kal shaam 5 baje" jaisa bolne layak hisaab — confirmation text ke liye. */
    fun describeTime(at: Long, now: Long = System.currentTimeMillis()): String {
        val cToday = Calendar.getInstance().apply { timeInMillis = now }
        val cAt = Calendar.getInstance().apply { timeInMillis = at }
        val dayDiff = ((cAt.timeInMillis - cToday.timeInMillis) / 86_400_000L).toInt()
        val day = when {
            cAt.get(Calendar.YEAR) == cToday.get(Calendar.YEAR) &&
                cAt.get(Calendar.DAY_OF_YEAR) == cToday.get(Calendar.DAY_OF_YEAR) -> "aaj"
            cAt.get(Calendar.YEAR) == cToday.get(Calendar.YEAR) &&
                cAt.get(Calendar.DAY_OF_YEAR) == cToday.get(Calendar.DAY_OF_YEAR) + 1 -> "kal"
            dayDiff == 2 -> "parso"
            else -> SimpleDateFormat("EEE d MMM", Locale("hi", "IN")).format(Date(at))
        }
        val h24 = cAt.get(Calendar.HOUR_OF_DAY)
        val period = when (h24) { in 5..11 -> "subah"; in 12..16 -> "dopahar"; in 17..20 -> "shaam"; else -> "raat" }
        val h12 = cAt.get(Calendar.HOUR_OF_DAY) % 12; val hh = if (h12 == 0) 12 else h12
        val mm = cAt.get(Calendar.MINUTE)
        val timePart = if (mm == 0) "$hh baje" else "$hh:${"%02d".format(mm)} baje"
        return "$day $period $timePart"
    }

    /** "Theek hai, kal shaam 5 baje Rahul ko yaad dila dunga." */
    fun confirmText(r: ReminderItem): String {
        val whoPart = if (r.who.isNotBlank()) "${r.who} ko " else ""
        return when {
            r.timeMs > 0 -> "Theek hai, ${describeTime(r.timeMs)} ${whoPart}yaad dila dunga: '${r.text}'."
            r.afterEvent.isNotBlank() -> "Theek hai, '${r.afterEvent}' khatam hote hi ${whoPart}yaad dila dunga: '${r.text}'."
            r.place.isNotBlank() -> "Theek hai, ${r.place} pahunchte hi ${whoPart}yaad dila dunga: '${r.text}'."
            else -> "Theek hai, yaad dila dunga: '${r.text}'."
        }
    }

    // ---------------- AlarmManager (time-based) ----------------

    private fun alarmIntent(c: Context, r: ReminderItem): PendingIntent {
        val i = Intent(c, ReminderReceiver::class.java).setAction(ACTION_REMIND)
            .putExtra("rem_id", r.id).putExtra("rem_text", r.text).putExtra("rem_who", r.who)
        return PendingIntent.getBroadcast(c, r.id.hashCode(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Exact alarm (Android 12+ par permission band ho to inexact fallback). */
    fun scheduleAlarm(c: Context, r: ReminderItem) {
        if (r.timeMs <= 0) return
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.timeMs, alarmIntent(c, r))
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.timeMs, alarmIntent(c, r))
            }
        } catch (_: Exception) { /* alarm na lage to fireDue() backup hai */ }
    }

    fun cancelAlarm(c: Context, id: String) {
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val i = Intent(c, ReminderReceiver::class.java).setAction(ACTION_REMIND)
            am.cancel(PendingIntent.getBroadcast(c, id.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        } catch (_: Exception) {}
    }

    /** Reboot ke baad saare aane wale time-reminders dobara lagao. */
    fun rescheduleAll(c: Context) {
        for (r in items(c)) if (!r.done && r.timeMs > System.currentTimeMillis()) scheduleAlarm(c, r)
    }

    private fun markDone(c: Context, id: String) {
        val list = items(c); var changed = false
        for (i in list.indices) if (list[i].id == id && !list[i].done) { list[i] = list[i].copy(done = true); changed = true }
        if (changed) saveItems(c, list.filter { !it.done })
    }

    /** Alarm se ya fireDue se: bolo + done karo. */
    fun fireOne(c: Context, id: String?, text: String, who: String) {
        val whoPart = if (who.isNotBlank()) "$who, " else ""
        Speaker.speak(c, "${Brain.title(c)}, yaad hai? ${whoPart}${text}")
        if (id != null) markDone(c, id)
    }

    // ---------------- event ke baad + jagah ----------------

    /**
     * `remind_after_event`: calendar event khatam hote hi reminder. Calendar permission
     * na ho to kuch fire nahi hota — reminder save rehta hai, status() wajah batata hai.
     */
    fun checkAfterEventReminders(c: Context): List<String> {
        val fired = ArrayList<String>()
        if (!Perm.has(c, Manifest.permission.READ_CALENDAR)) return fired
        val pending = items(c).filter { !it.done && it.afterEvent.isNotBlank() }
        if (pending.isEmpty()) return fired
        val now = System.currentTimeMillis()
        try {
            val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(b, now - 24 * 3600_000L); ContentUris.appendId(b, now)
            c.contentResolver.query(b.build(),
                arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END),
                null, null, "${CalendarContract.Instances.END} DESC")?.use { cur ->
                while (cur.moveToNext()) {
                    val title = cur.getString(0) ?: continue
                    val end = cur.getLong(2)
                    if (end > now) continue
                    for (r in pending) {
                        val want = r.afterEvent.lowercase()
                        if (title.lowercase().contains(want) || want.contains(title.lowercase())) {
                            fired.add(r.text); fireOne(c, r.id, r.text, r.who)
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        return fired
    }

    /** Geofence check helper: kya (lat, lng) saved jagah `place` se radius ke andar hai? */
    fun isNearPlace(c: Context, place: String, lat: Double, lng: Double, radiusM: Float = GEO_RADIUS_M): Boolean {
        val pl = Memory.places(c)
        val o = try { pl.optJSONObject(place.lowercase().trim()) } catch (_: Exception) { null } ?: return false
        val r = FloatArray(1)
        android.location.Location.distanceBetween(lat, lng, o.optDouble("lat"), o.optDouble("lon"), r)
        return r[0] <= radiusM
    }

    /** "ghar pahunchte hi": saved jagah (ghar/office) ke ~200m andar aate hi bolo. */
    fun checkLocationReminders(c: Context, lat: Double, lng: Double): List<String> {
        val fired = ArrayList<String>()
        for (r in items(c)) {
            if (r.done || r.place.isBlank()) continue
            if (isNearPlace(c, r.place, lat, lng)) { fired.add(r.text); fireOne(c, r.id, r.text, r.who) }
        }
        return fired
    }

    /** Event/jagah wale reminders ki haalat (permission/jagah missing ho to wajah). */
    fun afterEventStatus(c: Context): String {
        val pending = items(c).filter { !it.done && (it.afterEvent.isNotBlank() || it.place.isNotBlank()) }
        if (pending.isEmpty()) return ""
        val noCal = pending.any { it.afterEvent.isNotBlank() } && !Perm.has(c, Manifest.permission.READ_CALENDAR)
        val unknownPlace = pending.filter { it.place.isNotBlank() }
            .map { it.place.lowercase() }.distinct()
            .filter { Memory.places(c).optJSONObject(it) == null }
        val sb = StringBuilder()
        if (noCal) sb.append("Calendar permission nahi hai, isliye event-khatam wale reminders tabhi chalenge jab permission milegi. ")
        if (unknownPlace.isNotEmpty()) sb.append("Ye jagah save nahi hai, isliye location reminder nahi chalega: ${unknownPlace.joinToString(", ")} — pehle 'place save' se jagah save karo. ")
        return sb.toString().trim()
    }

    // ---------------- list / cancel / add ----------------

    fun listReminders(c: Context): String {
        val list = items(c).filter { !it.done }.sortedBy { if (it.timeMs > 0) it.timeMs else Long.MAX_VALUE }
        if (list.isEmpty()) return "Koi reminder set nahi hai."
        return list.mapIndexed { i, r ->
            val whenText = when {
                r.timeMs > 0 -> describeTime(r.timeMs)
                r.afterEvent.isNotBlank() -> "'${r.afterEvent}' khatam hone par"
                r.place.isNotBlank() -> "${r.place} pahunchne par"
                else -> "samay nahi diya"
            }
            "${i + 1}. [${r.id}] ${r.text}" + (if (r.who.isNotBlank()) " (${r.who})" else "") + " — $whenText"
        }.joinToString("\n")
    }

    fun cancelReminder(c: Context, idOrText: String): String {
        val q = idOrText.trim()
        if (q.isEmpty()) return "Kaunsa reminder hatana hai — uska number/id ya text batao."
        val list = items(c).toMutableList()
        val idx = list.indexOfFirst { it.id == q || it.id.startsWith(q) ||
            it.text.lowercase().contains(q.lowercase()) }
        if (idx < 0) return "Aisa koi reminder nahi mila: '$q'."
        val r = list.removeAt(idx)
        saveItems(c, list)
        cancelAlarm(c, r.id)
        return "Reminder hata diya: '${r.text}'."
    }

    /** Naya reminder banao + save + (time ho to) alarm lagao. */
    fun addReminder(c: Context, text: String, who: String = "", whenText: String = "",
                    afterEvent: String = "", place: String = ""): String {
        val t = text.trim()
        if (t.isEmpty()) return "Reminder mein kya yaad dilana hai, wo text nahi mila."
        val at = if (whenText.isNotBlank()) parseHinglishTime(whenText) else null
        if (whenText.isNotBlank() && at == null)
            return "Samay samajh nahi aaya — jaise 'kal 5 baje', '10 minute baad', 'agle somvaar subah 9 baje' bolo."
        if (at == null && afterEvent.isBlank() && place.isBlank())
            return "Reminder ke liye samay chahiye — 'kal 5 baje' ya '10 minute baad' jaisa batao, ya event/jagah batao."
        val r = ReminderItem(
            id = "r" + UUID.randomUUID().toString().take(8),
            text = t, who = who.trim(), timeMs = at ?: 0L,
            afterEvent = afterEvent.trim(), place = place.trim().lowercase()
        )
        val list = items(c).toMutableList(); list.add(r); saveItems(c, list)
        if (r.timeMs > 0) scheduleAlarm(c, r)
        val extra = afterEventStatus(c)
        return confirmText(r) + if (extra.isNotEmpty()) " Note: $extra" else ""
    }

    // ---------------- purana "reminder" tool (Extras se) — pehle jaisa hi chalta hai ----------------

    fun run(c: Context, a: JSONObject): String = when (a.optString("action")) {
        "list" -> listReminders(c)
        "cancel" -> {
            val idx = a.optInt("index", 0)
            if (idx > 0) {
                val list = items(c).filter { !it.done }.sortedBy { if (it.timeMs > 0) it.timeMs else Long.MAX_VALUE }
                if (idx in 1..list.size) cancelReminder(c, list[idx - 1].id)
                else "Aisa koi reminder nahi mila."
            } else cancelReminder(c, a.optString("text"))
        }
        else -> {   // add
            val text = a.optString("text").trim()
            if (text.isEmpty()) return "Reminder mein kya yaad dilana hai, wo text nahi mila."
            val whenText = a.optString("when_text").trim()
            if (whenText.isNotBlank() || a.optString("after_event").isNotBlank() || a.optString("place").isNotBlank()) {
                addReminder(c, text, a.optString("who"), whenText, a.optString("after_event"), a.optString("place"))
            } else if (a.has("minutes") && a.optInt("minutes") > 0) {
                addReminder(c, text, a.optString("who"), "${a.optInt("minutes")} minute baad")
            } else if (a.optString("time").isNotBlank()) {
                val parts = a.optString("time").split(":")
                val hh = parts.getOrNull(0)?.trim()?.toIntOrNull()
                val mm = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
                if (hh == null) "Samay samajh nahi aaya — '17:30' jaise 24-hour mein batao."
                else {
                    val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hh); set(Calendar.MINUTE, mm); set(Calendar.SECOND, 0) }
                    if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
                    val r = ReminderItem(id = "r" + UUID.randomUUID().toString().take(8), text = text, timeMs = cal.timeInMillis)
                    val list = items(c).toMutableList(); list.add(r); saveItems(c, list); scheduleAlarm(c, r)
                    confirmText(r)
                }
            } else "Reminder ke liye samay chahiye — kitne minute baad (minutes), kis baje (time, 24-hour), ya Hinglish mein (when_text: 'kal 5 baje')."
        }
    }

    /** Har tick par: jo reminder pak gaya, bol do aur hata do. Bachi hui pehli 3 ka chhota hisaab (Live context ke liye). */
    fun fireDue(c: Context) {
        val now = System.currentTimeMillis()
        val list = items(c)
        var changed = false
        for (r in list) {
            if (!r.done && r.timeMs > 0 && r.timeMs <= now) { fireOne(c, r.id, r.text, r.who); changed = true }
        }
        if (changed) saveItems(c, items(c).filter { !it.done })
        try { checkAfterEventReminders(c) } catch (_: Exception) {}
        try { Loc.last(c)?.let { checkLocationReminders(c, it.latitude, it.longitude) } } catch (_: Exception) {}
    }

    fun upcoming(c: Context): String {
        val list = items(c).filter { !it.done && it.timeMs > 0 }.sortedBy { it.timeMs }.take(3)
        if (list.isEmpty()) return ""
        return list.joinToString("; ") { "${it.text} (${fmt(it.timeMs)})" }
    }
}

/** AlarmManager se bajta hai: reminder bolo + done karo. Manifest mein register karna zaroori hai. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val text = i.getStringExtra("rem_text") ?: return
        Reminders.fireOne(c, i.getStringExtra("rem_id"), text, i.getStringExtra("rem_who") ?: "")
    }
}

/** Phone reboot hone par saare aane wale reminders dobara lagao. */
class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) Reminders.rescheduleAll(c)
    }
}

/** Gemini tools: reminder_add / reminder_list / reminder_cancel. */
object ReminderTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject>, req: List<String> = emptyList()): JSONObject {
        val p = JSONObject(); for ((k, v) in props) p.put(k, v)
        val params = JSONObject().put("type", "OBJECT").put("properties", p)
        if (req.isNotEmpty()) params.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("parameters", params)
    }

    fun decls(): JSONArray = JSONArray().put(fn("reminder_add",
        "Reminder set karo: Hinglish time ('kal 5 baje', '10 minute baad', 'agle somvaar subah 9 baje'), ya kisi calendar event ke khatam hone par, ya kisi saved jagah (ghar/office) pahunchne par.",
        mapOf("text" to sp("kya yaad dilana hai"), "who" to sp("kisko yaad dilana hai, jaise Rahul (optional)"),
            "when_text" to sp("Hinglish samay: 'kal 5 baje', '10 minute baad', 'aaj shaam 7 baje'"),
            "after_event" to sp("us calendar event ka naam jiske khatam hote hi yaad dilana hai (optional)"),
            "place" to sp("saved jagah ka naam, jaise ghar ya office (optional)")), listOf("text")))
        .put(fn("reminder_list", "Saare set reminders dikhao.", emptyMap()))
        .put(fn("reminder_cancel", "Reminder hatao: id ya text se.",
            mapOf("id_or_text" to sp("list mein dikha id ya reminder ka text")), listOf("id_or_text")))

    /** Unknown naam par null (taaki Actions/Extras aage fall-through kar sake). */
    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "reminder_add" -> Reminders.addReminder(c, a.optString("text"), a.optString("who"),
            a.optString("when_text"), a.optString("after_event"), a.optString("place"))
        "reminder_list" -> Reminders.listReminders(c)
        "reminder_cancel" -> Reminders.cancelReminder(c, a.optString("id_or_text"))
        else -> null
    }
}
