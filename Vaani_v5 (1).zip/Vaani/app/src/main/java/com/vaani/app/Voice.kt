package com.vaani.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale

/*
 * WIRING (Gemini.kt / Extras.kt — inhe koi aur group edit karega, ye file nahi):
 *
 * Gemini.kt — tools lazy block mein, `for (d in Extras.decls()) fd.put(d)` ke baad:
 *     for (i in 0 until VoiceTools.decls().length()) fd.put(VoiceTools.decls().getJSONObject(i))
 *
 * Extras.kt — run() ke when() mein:
 *     "voice_lang", "voice_tone" ->
 *         VoiceTools.dispatch(c, name, a) ?: "Ye voice action nahi aata."
 *
 * Tone (jaldi/raat) sirf phone ki local TTS par chalta hai — Gemini cloud TTS mein
 * rate/pitch control nahi hota, isliye mood wali awaaz ke liye local TTS use hoti hai.
 */

/**
 * Friendly voice: Gemini's natural TTS voice (Aoede) over REST.
 * If the Gemini voice is unreachable, falls back to the phone's own TTS so a message is never lost.
 */
object GeminiVoice {
    // NAYE models pehle: purane 2.5-wale nayi API keys par 404 dete hain - wahi robotic awaaz ki jad thi.
    private val MODELS = listOf("gemini-3.8-flash-lite-tts", "gemini-3.8-flash-tts",
        "gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
    @Volatile private var preferred: String? = null   // jo model chal jaye, agli baar wahi sabse pehle
    @Volatile var lastError: String? = null           // dashboard par wajah dikhane ke liye
    private const val VOICE = "Aoede"

    /** Blocking call - background thread se bulao. true = Gemini ki awaaz bol gayi. */
    fun speak(key: String, text: String): Boolean {
        // Do chance: network ki ek jhatka-kharabi (CGNAT/signal) par robotic par mat giro - ek baar aur try karo.
        for (attempt in 1..2) {
            val order = listOfNotNull(preferred) + MODELS.filter { it != preferred }
            var err: String? = lastError
            for (model in order) {
                try { if (speakWith(model, key, text)) { preferred = model; lastError = null; return true } }
                catch (e: Exception) { err = "$model: ${e.message}".take(150) }
            }
            lastError = err
            if (attempt == 1) Thread.sleep(1200)
        }
        return false
    }

    private fun speakWith(model: String, key: String, text: String): Boolean {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", VOICE)))))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode !in 200..299) {
            val ebody = try { c.errorStream?.bufferedReader()?.readText() ?: "" } catch (_: Exception) { "" }
            throw RuntimeException("API ${c.responseCode}: ${ebody.take(130)}")
        }
        val txt = c.inputStream.bufferedReader().readText()
        val data = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getJSONObject("inlineData").getString("data")
        play(stripWav(Base64.decode(data, Base64.DEFAULT)))
        return true
    }

    /** Kuch naye models WAV (RIFF header ke saath) bhejte hain, kuch kaccha PCM - dono ko saaf PCM bana do. */
    private fun stripWav(b: ByteArray): ByteArray {
        if (b.size < 44 || !(b[0] == 'R'.code.toByte() && b[1] == 'I'.code.toByte())) return b
        var i = 12
        while (i + 8 <= b.size) {
            val id = String(b, i, 4)
            val sz = (b[i + 4].toInt() and 0xFF) or ((b[i + 5].toInt() and 0xFF) shl 8) or
                ((b[i + 6].toInt() and 0xFF) shl 16) or ((b[i + 7].toInt() and 0xFF) shl 24)
            if (id == "data") return b.copyOfRange(i + 8, minOf(b.size, i + 8 + sz))
            i += 8 + sz + (sz and 1)
        }
        return b
    }

    private fun play(pcm: ByteArray) {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, pcm.size))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        track.setVolume(1f)
        track.play()
        track.write(pcm, 0, pcm.size)
        Thread.sleep(pcm.size / 2 * 1000L / 24000 + 250)   // bajne ka intezaar
        try { track.stop() } catch (_: Exception) {}
        track.release()
    }
}

/** Shared speaker for announcements (calls, messages, typed replies): pehle Gemini ki friendly awaaz, warna phone ki TTS. */
object Speaker {
    private val lock = Any()
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false

    // ---- multi-language voice (Feature 9) ----
    /** Supported TTS bhashayein. Hinglish default = hi-IN (Hindi + English mixed text usi mein bolta hai). */
    val LANGS = mapOf(
        "hi-IN" to Locale("hi", "IN"),
        "mr-IN" to Locale("mr", "IN"),
        "en-IN" to Locale("en", "IN")
    )
    private val LANG_NAMES = mapOf("hi-IN" to "Hindi (Hinglish)", "mr-IN" to "Marathi", "en-IN" to "English (India)")

    fun voiceLang(c: Context): String =
        P.of(c).getString("voice_lang", "hi-IN") ?: "hi-IN"

    private fun langLocale(c: Context): Locale = LANGS[voiceLang(c)] ?: Locale("hi", "IN")

    /**
     * Awaaz ki bhasha badlo: "hindi"/"hinglish" -> hi-IN, "marathi" -> mr-IN, "english" -> en-IN
     * (seedha code "hi-IN"/"mr-IN"/"en-IN" bhi chalega). Setting prefs "voice_lang"/"voice_name" mein
     * save hoti hai; agle bolne par lagti hai.
     */
    fun setVoiceLang(ctx: Context, lang: String): String {
        val code = when (lang.trim().lowercase()) {
            "hindi", "hinglish", "hi", "hi-in" -> "hi-IN"
            "marathi", "mr", "mr-in" -> "mr-IN"
            "english", "en", "en-in" -> "en-IN"
            else -> null
        } ?: return "Ye bhasha abhi nahi aati — Hindi (Hinglish), Marathi ya English (India) chuno."
        P.of(ctx).edit().putString("voice_lang", code).remove("voice_name").apply()
        applyVoicePrefs(ctx)
        return "Awaaz badal di: ${LANG_NAMES[code]}. Ab se isi bhasha mein bolungi."
    }

    /** Phone ki TTS voices mein se sabse natural chuno: Google neural pehle, phir us bhasha ki koi bhi. */
    private fun pickBestVoice(locale: Locale): Voice? {
        val voices = try { tts?.voices } catch (_: Exception) { null } ?: return null
        var best: Voice? = null; var bestScore = -1
        for (v in voices) {
            val vl = v.locale ?: continue
            var score = 0
            if (vl.language == locale.language && vl.country == locale.country) score += 3
            else if (vl.language == locale.language) score += 2
            else continue
            if (v.name.contains("google", ignoreCase = true)) score += 2
            if (v.quality >= Voice.QUALITY_VERY_HIGH) score += 1
            if (!v.isNetworkConnectionRequired) score += 1
            if (score > bestScore) { bestScore = score; best = v }
        }
        return best
    }

    /** Saved bhasha + best voice phone ki TTS par lagao (TTS ready ho to turant, warna init par). */
    fun applyVoicePrefs(ctx: Context) {
        val t = tts ?: return
        try {
            val loc = langLocale(ctx)
            t.language = loc
            pickBestVoice(loc)?.let { v ->
                t.voice = v
                P.of(ctx).edit().putString("voice_name", v.name).apply()
            }
        } catch (_: Exception) {}
    }

    // ---- tone by mood / time (Feature 9) ----

    /** Raat 22:00–06:00 — awaaz apne aap dheemi/narm. */
    fun isNight(): Boolean {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return h >= 22 || h < 6
    }

    /**
     * Mood ke hisaab se bolo — local TTS par (Gemini cloud voice mein rate control nahi hota):
     * "jaldi" = tez (rate 1.25), "raat" = dheemi/narm (rate 0.85, pitch 0.9),
     * "normal" = 1.0, "auto" = raat ho to raat wala, warna normal.
     * Speaker.speak(ctx, text) jaisa hi hai — purane callers ko koi farq nahi padta.
     */
    fun speakTone(ctx: Context, text: String, mood: String = "auto") {
        val m = mood.trim().lowercase()
        val (rate, pitch) = when (m) {
            "jaldi", "fast", "tez" -> 1.25f to 1.0f
            "raat", "slow", "dheemi", "soft" -> 0.85f to 0.9f
            "normal" -> 1.0f to 1.0f
            else -> if (isNight()) 0.85f to 0.9f else 1.0f to 1.0f   // "auto" + unknown
        }
        val app = ctx.applicationContext
        Thread {
            synchronized(lock) {
                AgentStatus.voice = "Bol rahi hai…"; AgentStatus.voiceAt = System.currentTimeMillis()
                deviceTts(app, text, rate, pitch)
                AgentStatus.voice = "Bola (tone: $m) • ${AgentStatus.time()}"
            }
        }.start()
    }

    fun speak(ctx: Context, text: String) {
        val app = ctx.applicationContext
        Thread {
            synchronized(lock) {
                AgentStatus.voice = "Bol rahi hai…"; AgentStatus.voiceAt = System.currentTimeMillis()
                val key = app.getSharedPreferences("vaani", Context.MODE_PRIVATE).getString("key", "").orEmpty()
                if (key.isEmpty()) {
                    // Key hi nahi hai to Gemini ki awaaz aa hi nahi sakti - wajah saaf likho, chup mat raho.
                    VaaniService.log?.invoke("🔑 API key phone par mili hi nahi — isiliye phone ki robotic awaaz chalegi. Setup (🔑) mein jaakar key dobara daalo.")
                    deviceTts(app, text)
                    AgentStatus.voice = "Bola (phone TTS) • ${AgentStatus.time()}"
                } else {
                    val ok = GeminiVoice.speak(key, text)
                    if (!ok) {
                        // Robotic par girne ki WAJAH dashboard par likho, taaki screenshot se pakdi jaye.
                        VaaniService.log?.invoke("🔊 Gemini ki awaaz nahi mili" +
                            (GeminiVoice.lastError?.let { " — $it" } ?: "") + " | Abhi phone wali awaaz chalegi.")
                        deviceTts(app, text)
                    }
                    AgentStatus.voice = "Bola • ${AgentStatus.time()}"
                }
            }
        }.start()
    }

    /** Internet ke bina: seedha phone ki apni awaaz. */
    fun speakLocal(ctx: Context, text: String) {
        val app = ctx.applicationContext
        Thread { synchronized(lock) { deviceTts(app, text) } }.start()
    }

    /** Mood ke saath bolo: "jaldi"/"raat" ho (ya raat mein "auto") to tone wali local awaaz, warna normal Gemini-first rasta. */
    fun speak(ctx: Context, text: String, mood: String) {
        val m = mood.trim().lowercase()
        val nightAuto = m == "auto" && isNight()
        if (m in setOf("jaldi", "fast", "tez", "raat", "slow", "dheemi", "soft") || nightAuto) speakTone(ctx, text, mood)
        else speak(ctx, text)
    }

    private fun deviceTts(ctx: Context, text: String, rate: Float = 1f, pitch: Float = 1f) {
        if (tts == null) {
            tts = TextToSpeech(ctx) { s ->
                if (s == TextToSpeech.SUCCESS) {
                    tts?.language = langLocale(ctx); ttsReady = true
                    applyVoicePrefs(ctx)
                }
            }
            Thread.sleep(700)
        }
        if (!ttsReady) tts?.language = langLocale(ctx) else applyVoicePrefs(ctx)
        tts?.setSpeechRate(rate)
        tts?.setPitch(pitch)
        // Fallback awaaz bhi bade speaker (media stream) par, full volume mein.
        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1f)
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "sp")
    }
}

/** Gemini tools: voice_lang / voice_tone. */
object VoiceTools {
    private fun sp(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun fn(name: String, desc: String, props: Map<String, JSONObject>, req: List<String> = emptyList()): JSONObject {
        val p = JSONObject(); for ((k, v) in props) p.put(k, v)
        val params = JSONObject().put("type", "OBJECT").put("properties", p)
        if (req.isNotEmpty()) params.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("parameters", params)
    }

    fun decls(): JSONArray = JSONArray().put(fn("voice_lang",
        "Vaani ki bolne ki bhasha badlo: Hindi (Hinglish, default), Marathi, ya English (India).",
        mapOf("lang" to sp("hindi|hinglish|marathi|english ya hi-IN|mr-IN|en-IN")), listOf("lang")))
        .put(fn("voice_tone",
            "Kisi text ko khaas mood mein bolo: jaldi (tez), raat (dheemi/narm), normal, auto (raat mein apne aap dheemi).",
            mapOf("text" to sp("bolne wala text"), "mood" to sp("jaldi|raat|normal|auto")), listOf("text")))

    /** Unknown naam par null (taaki Actions/Extras aage fall-through kar sake). */
    fun dispatch(c: Context, name: String, a: JSONObject): String? = when (name) {
        "voice_lang" -> Speaker.setVoiceLang(c, a.optString("lang"))
        "voice_tone" -> {
            Speaker.speakTone(c, a.optString("text"), a.optString("mood", "auto"))
            "Bol raha hu (${a.optString("mood", "auto")} tone mein)."
        }
        else -> null
    }
}
