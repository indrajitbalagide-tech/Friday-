package com.friday.assistant.actions

import android.content.Context
import com.friday.assistant.screen.ScreenContextService
import org.json.JSONArray
import org.json.JSONObject

/**
 * The bridge between the model and the phone. Every capability FRIDAY has is
 * declared here as a Gemini function; [execute] runs the call on-device and
 * returns a short spoken-style result for the model to relay.
 */
class ActionRouter(private val context: Context) {

    fun execute(name: String, args: JSONObject): String = try {
        when (name) {
            "open_app" -> AppActions.openApp(context, args.optString("app_name"))
            "make_call" -> CallActions.makeCall(context, args.optString("contact_or_number"))
            "answer_call" -> CallActions.answerCall(context)
            "reject_call" -> CallActions.rejectOrEndCall(context)
            "end_call" -> CallActions.rejectOrEndCall(context)
            "control_music" -> MusicActions.control(context, args.optString("action"))
            "now_playing" -> MusicActions.nowPlaying(context)
            "set_volume" -> MusicActions.setVolumePercent(context, args.optInt("percent", 50))
            "read_notifications" -> MessageActions.readNotifications(args.optInt("limit", 5))
            "reply_to_message" -> MessageActions.replyToLatestMessage(
                context, args.optString("app").ifBlank { null }, args.optString("text")
            )
            "send_sms" -> MessageActions.sendSms(
                context, args.optString("contact_or_number"), args.optString("text")
            )
            "get_screen_context" -> ScreenContextService.summary()
            "control_device_hardware" -> DeviceActions.hardware(
                context, args.optString("target"), args.optString("action").ifBlank { "toggle" }
            )
            "open_deep_link" -> DeviceActions.deepLink(
                context, args.optString("target_app"), args.optString("query")
            )
            "close_app" -> DeviceActions.closeApp(context)
            "send_whatsapp_message" -> MessageActions.sendWhatsApp(
                context, args.optString("contact_name"), args.optString("message")
            )
            "search_contacts" -> CallActions.describeContact(context, args.optString("contact_name"))
            "check_schedule" -> CalendarActions.readSchedule(context)
            "schedule_new_event" -> CalendarActions.createEvent(
                context, args.optString("title"),
                args.optLong("hours_from_now", 1), args.optInt("duration_minutes", 30)
            )
            "save_core_memory" -> com.friday.assistant.data.FridayMemory.save(
                context, args.optString("fact")
            )
            "access_core_memory" -> com.friday.assistant.data.FridayMemory.recall(
                context, args.optString("query")
            )
            else -> "Unknown action: $name"
        }
    } catch (e: Exception) {
        "That action failed: ${e.message}"
    }

    companion object {
        val SYSTEM_INSTRUCTION = """
            You are FRIDAY, a premium voice assistant living on the user's Android phone.
            Speak naturally, briefly and warmly — one or two short sentences unless asked for more.
            You can do real things on the phone through your tools: open apps, make and answer
            calls, control music, read notifications, reply to messages and texts, look at
            what is on the screen, switch the flashlight and open settings panels, search
            inside YouTube/Spotify/Maps, read the calendar and create events, send WhatsApp
            messages, and remember facts the user asks you to remember — recall them whenever
            relevant. When the user asks for something a tool can do, use the tool
            first, then confirm in one short sentence. Never invent results — only report what a
            tool returned. If an incoming call is announced, the user may say "answer it" or
            "reject it" — use the call tools. If asked what is on screen, call get_screen_context
            and use it to help. Keep answers voice-friendly: no lists read aloud beyond three items,
            no markdown, no URLs.
        """.trimIndent()

        fun declarations(): JSONArray {
            fun fn(name: String, desc: String, props: JSONObject, required: JSONArray): JSONObject =
                JSONObject().put("name", name).put("description", desc)
                    .put("parameters", JSONObject().put("type", "OBJECT")
                        .put("properties", props).put("required", required))
            fun str(desc: String) = JSONObject().put("type", "STRING").put("description", desc)
            fun num(desc: String) = JSONObject().put("type", "NUMBER").put("description", desc)

            return JSONArray()
                .put(fn("open_app", "Open an installed app by its spoken name.",
                    JSONObject().put("app_name", str("App name, e.g. WhatsApp, Spotify, Camera")),
                    JSONArray().put("app_name")))
                .put(fn("make_call", "Call a contact by name or a raw phone number.",
                    JSONObject().put("contact_or_number", str("Contact name or phone number")),
                    JSONArray().put("contact_or_number")))
                .put(fn("answer_call", "Answer the currently ringing phone call.",
                    JSONObject(), JSONArray()))
                .put(fn("reject_call", "Reject the currently ringing phone call.",
                    JSONObject(), JSONArray()))
                .put(fn("end_call", "End the current ongoing phone call.",
                    JSONObject(), JSONArray()))
                .put(fn("control_music", "Control music playback in the active media app.",
                    JSONObject().put("action", str("One of: play, pause, next, previous, stop")),
                    JSONArray().put("action")))
                .put(fn("now_playing", "Report what music or media is currently playing or paused.",
                    JSONObject(), JSONArray()))
                .put(fn("set_volume", "Set the media volume as a percentage 0-100.",
                    JSONObject().put("percent", num("Volume percent")),
                    JSONArray().put("percent")))
                .put(fn("read_notifications", "Read the user's latest notifications aloud.",
                    JSONObject().put("limit", num("How many to read (default 5)")),
                    JSONArray()))
                .put(fn("reply_to_message",
                    "Reply to the most recent message notification (WhatsApp, SMS, Telegram...). " +
                    "Use when the user says 'reply ...' after hearing a message.",
                    JSONObject()
                        .put("app", str("Optional app hint: whatsapp, sms, telegram, signal"))
                        .put("text", str("The reply text to send")),
                    JSONArray().put("text")))
                .put(fn("send_sms", "Send a new SMS text message to a contact or number.",
                    JSONObject()
                        .put("contact_or_number", str("Contact name or phone number"))
                        .put("text", str("Message text")),
                    JSONArray().put("contact_or_number").put("text")))
                .put(fn("control_device_hardware",
                    "Control device hardware or open a settings panel: flashlight on/off, " +
                    "or open wifi, bluetooth, location or hotspot settings.",
                    JSONObject()
                        .put("target", str("One of: flashlight, wifi, bluetooth, location, hotspot"))
                        .put("action", str("One of: on, off, toggle, open")),
                    JSONArray().put("target").put("action")))
                .put(fn("open_deep_link",
                    "Open a search or page directly inside YouTube, Spotify, Maps or the web browser.",
                    JSONObject()
                        .put("target_app", str("One of: youtube, spotify, maps, chrome"))
                        .put("query", str("What to search for or open")),
                    JSONArray().put("target_app").put("query")))
                .put(fn("close_app",
                    "Help close the current app (goes Home; Android does not allow force-closing other apps).",
                    JSONObject(), JSONArray()))
                .put(fn("send_whatsapp_message",
                    "Send a WhatsApp message to a contact by name: opens their chat with the " +
                    "message pre-filled for the user to tap send.",
                    JSONObject()
                        .put("contact_name", str("Contact name as saved in the phone"))
                        .put("message", str("Message text")),
                    JSONArray().put("contact_name").put("message")))
                .put(fn("search_contacts", "Find a contact's phone number by name.",
                    JSONObject().put("contact_name", str("Contact name to look up")),
                    JSONArray().put("contact_name")))
                .put(fn("check_schedule",
                    "Read the user's calendar events for the next 48 hours.",
                    JSONObject(), JSONArray()))
                .put(fn("schedule_new_event", "Create a calendar event.",
                    JSONObject()
                        .put("title", str("Event title"))
                        .put("hours_from_now", num("How many hours from now it starts"))
                        .put("duration_minutes", num("Duration in minutes (default 30)")),
                    JSONArray().put("title")))
                .put(fn("save_core_memory",
                    "Remember a fact the user asks you to remember (e.g. where something is, a preference).",
                    JSONObject().put("fact", str("The fact to remember")),
                    JSONArray().put("fact")))
                .put(fn("access_core_memory",
                    "Recall facts the user previously asked you to remember.",
                    JSONObject().put("query", str("What to recall (keywords, or empty for everything)")),
                    JSONArray()))
                .put(fn("get_screen_context",
                    "Look at what is currently on the phone screen and describe it. " +
                    "Use when the user asks what is on screen or needs help with visible content.",
                    JSONObject(), JSONArray()))
        }
    }
}
