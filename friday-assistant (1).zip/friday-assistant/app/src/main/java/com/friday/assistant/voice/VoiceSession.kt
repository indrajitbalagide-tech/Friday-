package com.friday.assistant.voice

import android.content.Context
import com.friday.assistant.FridayApp
import com.friday.assistant.actions.ActionRouter
import com.friday.assistant.util.ChatLine
import com.friday.assistant.util.RuntimeState
import com.friday.assistant.util.SessionStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * One assistant conversation. Two engines behind one facade:
 *  - Gemini Live (API key present): true realtime voice, natural language,
 *    function calling into ActionRouter.
 *  - On-device (no key / offline): SpeechRecognizer + intent parser + TTS,
 *    same ActionRouter.
 */
class VoiceSession(
    private val context: Context,
    val speaker: Speaker
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val settings get() = FridayApp.instance.settings
    private val router = ActionRouter(context)
    private val audio = AudioEngine()
    private var live: GeminiLiveClient? = null
    private var onDevice: OnDeviceVoice? = null
    @Volatile private var liveConnected = false

    val isLive: Boolean get() = live != null

    fun start() {
        if (live != null || onDevice != null) return
        if (settings.hasApiKey) startLive() else startOnDevice()
        greet()
    }

    /** FRIDAY speaks first - a warm greeting in the user's language, so the
     *  user immediately hears her voice and knows speaking works. Speaker
     *  queues the line until the TTS engine is ready. */
    private fun greet() {
        val line = when (settings.language) {
            "marathi" -> "Namaskar! Mi FRIDAY, tumchi maitreen. Mi aale aahe - bola, tumchyasaathi kay karu?"
            "english" -> "Hello! I'm FRIDAY, your friend. I'm here now - tell me, what can I do for you?"
            else -> "Namaste! Main FRIDAY hoon, aapki apni dost. Main aa gayi hoon - boliye, aapke liye kya karoon?"
        }
        RuntimeState.addLine(ChatLine.Role.FRIDAY, line)
        speaker.speak(line)
    }

    /** Settings "Awaaz suno" button: speak a sample line so the user can
     *  hear the current voice and language any time. */
    fun testVoice() {
        if (live == null && onDevice == null) start()
        val line = when (settings.language) {
            "marathi" -> "Hi majhi awaaz aahe. Mi FRIDAY - tumchi maitreen, nehmi tumchya sobat."
            "english" -> "This is my voice. I'm FRIDAY - your friend, always with you."
            else -> "Ye meri awaaz hai. Main FRIDAY hoon - aapki dost, hamesha aapke saath."
        }
        RuntimeState.addLine(ChatLine.Role.FRIDAY, line)
        speaker.speak(line)
        if (!speaker.ready) {
            RuntimeState.addLine(
                ChatLine.Role.SYSTEM,
                "Awaaz abhi taiyaar nahi hai - agar upar TTS wali chetaavni aayi ho to woh setting check karo."
            )
        }
    }

    fun stop() {
        live?.close(); live = null
        onDevice?.stopListening(); onDevice = null
        audio.release()
        RuntimeState.liveMode.value = false
        RuntimeState.setStatus(SessionStatus.STOPPED, "FRIDAY is stopped")
    }

    /** Push-to-talk for on-device mode; in Live mode the mic is already open. */
    fun talkOnce() {
        if (onDevice != null) {
            speaker.stop()
            onDevice?.startListening()
            RuntimeState.setStatus(SessionStatus.ON_DEVICE, "Listening…")
        }
    }

    /** Announcements (incoming caller, etc.) always use TTS so they work in
     *  both modes and even while a Live turn is in flight. */
    fun announce(text: String) {
        RuntimeState.addLine(ChatLine.Role.SYSTEM, text)
        speaker.speak(text)
    }

    private fun startLive() {
        liveConnected = false
        RuntimeState.setStatus(SessionStatus.CONNECTING, "Connecting to Gemini Live…")
        RuntimeState.liveMode.value = true
        val client = GeminiLiveClient(
            apiKey = settings.geminiApiKey,
            model = settings.liveModel,
            voiceName = settings.voiceName,
            systemInstruction = ActionRouter.SYSTEM_INSTRUCTION,
            functionDeclarations = ActionRouter.declarations(),
            listener = object : GeminiLiveClient.Listener {
                override fun onConnected() {
                    liveConnected = true
                    RuntimeState.setStatus(SessionStatus.LISTENING, "Listening — just talk")
                    audio.startPlayback()
                    audio.startCapture { frame ->
                        RuntimeState.micLevel.value = audio.micLevel
                        live?.sendAudio(frame)
                    }
                }

                override fun onAudio(pcm24k: ByteArray) {
                    RuntimeState.setStatus(SessionStatus.SPEAKING, "FRIDAY is speaking…")
                    audio.enqueuePlayback(pcm24k)
                }

                override fun onUserTranscript(text: String) =
                    RuntimeState.addLine(ChatLine.Role.USER, text)

                override fun onAssistantTranscript(text: String) =
                    RuntimeState.addLine(ChatLine.Role.FRIDAY, text)

                override fun onToolCall(id: String, name: String, args: JSONObject) {
                    scope.launch {
                        val result = router.execute(name, args)
                        RuntimeState.addLine(ChatLine.Role.SYSTEM, "$name → $result")
                        live?.sendToolResponse(id, name, result)
                    }
                }

                override fun onInterrupted() {
                    audio.flushPlayback()
                    RuntimeState.setStatus(SessionStatus.LISTENING, "Listening — just talk")
                }

                override fun onTurnComplete() {
                    RuntimeState.setStatus(SessionStatus.LISTENING, "Listening — just talk")
                }

                override fun onError(message: String) {
                    RuntimeState.addLine(ChatLine.Role.SYSTEM, "Live error: $message")
                    if (!liveConnected) {
                        // The #1 V1.0 failure: a key is saved, Live cannot be
                        // reached, and the user is left with a dead assistant.
                        // Fall back to on-device mode instead.
                        fallbackToOnDevice("Live connect nahi ho paya (key/network check karo).")
                    } else {
                        RuntimeState.setStatus(SessionStatus.ERROR, "Live connection problem — check key / network")
                    }
                }

                override fun onClosed() {
                    if (live != null && !liveConnected) {
                        fallbackToOnDevice("Live session judne se pehle band ho gayi.")
                    } else if (live != null) {
                        RuntimeState.setStatus(SessionStatus.STOPPED, "Live session closed")
                    }
                }
            }
        )
        live = client
        client.connect()
    }

    /** Switch a never-connected Live session over to the on-device engine so
     *  voice commands (and speech-to-text) keep working without Live. */
    private fun fallbackToOnDevice(reason: String) {
        val client = live ?: return
        live = null
        try { client.close() } catch (_: Exception) {}
        RuntimeState.liveMode.value = false
        RuntimeState.addLine(
            ChatLine.Role.SYSTEM,
            "$reason On-device mode chalu kar diya hai — Talk dabakar bolo, " +
                "commands (open app, call, music, notifications) kaam karenge."
        )
        startOnDevice()
    }

    private fun startOnDevice() {
        RuntimeState.liveMode.value = false
        RuntimeState.setStatus(
            SessionStatus.ON_DEVICE,
            if (settings.handsFree) "Hands-free mode - bas bolo, main sun rahi hoon"
            else "On-device mode - tap Talk and speak"
        )
        onDevice = OnDeviceVoice(
            context = context,
            router = router,
            speaker = speaker,
            onTranscript = { RuntimeState.addLine(ChatLine.Role.USER, it) },
            onReply = { RuntimeState.addLine(ChatLine.Role.FRIDAY, it) }
        )
        RuntimeState.addLine(
            ChatLine.Role.SYSTEM,
            "On-device mode: Talk dabakar bolo - 'kholo', 'call karo', 'gaana chalao' " +
                "jaise commands chalenge. Dil kholkar baatcheet ke liye Settings mein Gemini key daalo."
        )
        if (settings.handsFree) onDevice?.startContinuous()
    }
}
