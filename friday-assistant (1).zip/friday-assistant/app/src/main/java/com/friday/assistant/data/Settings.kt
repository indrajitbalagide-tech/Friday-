package com.friday.assistant.data

import android.content.Context
import android.content.SharedPreferences

/** Simple persisted settings for FRIDAY. The Gemini API key never leaves the device
 *  except to Google's Live API endpoint over TLS. */
class Settings(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE)

    var geminiApiKey: String
        get() = prefs.getString(KEY_API, "").orEmpty()
        set(value) = prefs.edit().putString(KEY_API, value.trim()).apply()

    /** Live API voice name. The getter sanitizes: anything that is not one
     *  of the supported voices (e.g. a user typing "gemini" into the old
     *  free-text field) falls back to Kore instead of breaking Live setup. */
    var voiceName: String
        get() = prefs.getString(KEY_VOICE, "Kore").orEmpty().takeIf { it in VOICES } ?: "Kore"
        set(value) = prefs.edit().putString(KEY_VOICE, value).apply()

    var liveModel: String
        get() = prefs.getString(KEY_MODEL, DEFAULT_MODEL).orEmpty()
        set(value) = prefs.edit().putString(KEY_MODEL, value).apply()

    /** Speak the caller's name aloud when a call arrives. */
    var announceCallers: Boolean
        get() = prefs.getBoolean(KEY_ANNOUNCE, true)
        set(value) = prefs.edit().putBoolean(KEY_ANNOUNCE, value).apply()

    /** Show the floating bubble whenever the assistant service runs. */
    var overlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_OVERLAY, true)
        set(value) = prefs.edit().putBoolean(KEY_OVERLAY, value).apply()

    /** Autonomous AI replies to incoming message notifications. Opt-in only,
     *  and only active when a Gemini key is set (the reply is written by AI). */
    var autoReplyEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTOREPLY, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTOREPLY, value).apply()

    val hasApiKey: Boolean get() = geminiApiKey.isNotBlank()

    companion object {
        const val DEFAULT_MODEL = "models/gemini-2.5-flash-native-audio-preview-12-2025"
        private const val KEY_API = "gemini_api_key"
        private const val KEY_VOICE = "voice_name"
        private const val KEY_MODEL = "live_model"
        private const val KEY_ANNOUNCE = "announce_callers"
        private const val KEY_OVERLAY = "overlay_enabled"
        private const val KEY_AUTOREPLY = "auto_reply_enabled"
        val VOICES = listOf("Kore", "Puck", "Charon", "Fenrir", "Aoede")
    }
}
