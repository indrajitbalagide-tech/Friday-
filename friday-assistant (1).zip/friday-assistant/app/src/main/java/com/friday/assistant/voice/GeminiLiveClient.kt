package com.friday.assistant.voice

import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Minimal, dependency-light client for the Gemini Live API
 * (BidiGenerateContent over WebSocket, v1beta).
 *
 * Streams 16 kHz PCM mic audio up, receives 24 kHz PCM audio back, and
 * surfaces function calls so the app can execute real phone actions.
 * Docs: https://developer.android.com/ai/gemini/live
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val model: String,
    private val voiceName: String,
    private val systemInstruction: String,
    private val functionDeclarations: JSONArray,
    private val listener: Listener
) {
    interface Listener {
        fun onConnected()
        fun onAudio(pcm24k: ByteArray)
        fun onUserTranscript(text: String)
        fun onAssistantTranscript(text: String)
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onInterrupted()
        fun onTurnComplete()
        fun onError(message: String)
        fun onClosed()
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var socket: WebSocket? = null
    @Volatile private var closedByUser = false
    private var attempts = 0
    @Volatile private var ready = false

    fun connect() {
        val url = "wss://generativelanguage.googleapis.com/ws/" +
            "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent" +
            "?key=$apiKey"
        val ws = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(setupMessage().toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleMessage(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                handleMessage(bytes.utf8())
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                ready = false
                // One quiet retry before surfacing the error: on mobile
                // networks (CGNAT, tower handovers) the first attempt often
                // times out while a second one goes through.
                if (!closedByUser && attempts == 0) {
                    attempts = 1
                    Handler(Looper.getMainLooper()).postDelayed({
                        if (!closedByUser) connect()
                    }, 1500)
                } else {
                    listener.onError(t.message ?: "Connection failed")
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                ready = false
                listener.onClosed()
            }
        })
        socket = ws
    }

    private fun setupMessage(): JSONObject {
        val speechConfig = JSONObject()
            .put("voiceConfig", JSONObject().put(
                "prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName)
            ))
        val generationConfig = JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put("speechConfig", speechConfig)
        val setup = JSONObject()
            .put("model", model)
            .put("generationConfig", generationConfig)
            .put("systemInstruction", JSONObject().put(
                "parts", JSONArray().put(JSONObject().put("text", systemInstruction))
            ))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", functionDeclarations)))
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
        return JSONObject().put("setup", setup)
    }

    /** One 16 kHz PCM frame from the mic. */
    fun sendAudio(pcm16k: ByteArray) {
        if (!ready) return
        val chunk = JSONObject()
            .put("mimeType", "audio/pcm;rate=16000")
            .put("data", Base64.encodeToString(pcm16k, Base64.NO_WRAP))
        val msg = JSONObject().put(
            "realtimeInput",
            JSONObject().put("mediaChunks", JSONArray().put(chunk))
        )
        socket?.send(msg.toString())
    }

    fun sendToolResponse(id: String, name: String, result: String) {
        val response = JSONObject()
            .put("id", id)
            .put("name", name)
            .put("response", JSONObject().put("result", result))
        val msg = JSONObject().put(
            "toolResponse",
            JSONObject().put("functionResponses", JSONArray().put(response))
        )
        socket?.send(msg.toString())
    }

    fun sendText(text: String) {
        val part = JSONObject().put("text", text)
        val turn = JSONObject()
            .put("parts", JSONArray().put(part))
            .put("turnComplete", true)
        val msg = JSONObject().put("clientContent", JSONObject().put("turns", JSONArray().put(turn)))
        socket?.send(msg.toString())
    }

    fun close() {
        closedByUser = true
        ready = false
        try { socket?.close(1000, "bye") } catch (_: Exception) {}
        socket = null
    }

    private fun handleMessage(text: String) {
        try {
            val root = JSONObject(text)
            if (root.has("setupComplete")) {
                ready = true
                listener.onConnected()
                return
            }
            root.optJSONObject("toolCall")?.let { toolCall ->
                val calls = toolCall.optJSONArray("functionCalls") ?: JSONArray()
                for (i in 0 until calls.length()) {
                    val c = calls.getJSONObject(i)
                    listener.onToolCall(
                        c.optString("id"),
                        c.optString("name"),
                        c.optJSONObject("args") ?: JSONObject()
                    )
                }
            }
            val content = root.optJSONObject("serverContent") ?: return
            if (content.optBoolean("interrupted")) listener.onInterrupted()
            content.optJSONObject("inputTranscription")?.optString("text")
                ?.takeIf { it.isNotBlank() }?.let { listener.onUserTranscript(it) }
            content.optJSONObject("outputTranscription")?.optString("text")
                ?.takeIf { it.isNotBlank() }?.let { listener.onAssistantTranscript(it) }
            val parts = content.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val inline = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
                    val data = inline.optString("data")
                    if (data.isNotEmpty()) {
                        listener.onAudio(Base64.decode(data, Base64.DEFAULT))
                    }
                }
            }
            if (content.optBoolean("turnComplete")) listener.onTurnComplete()
        } catch (e: Exception) {
            Log.w(TAG, "parse: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "GeminiLive"
    }
}
