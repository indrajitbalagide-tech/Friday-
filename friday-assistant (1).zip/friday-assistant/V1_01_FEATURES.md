# FRIDAY V1.01 — Feature Spec (locked 2026-11-04)

Source: user-uploaded IRIS-MX README (feature list only — implemented in FRIDAY's own
original Kotlin codebase, name stays FRIDAY). Current installed build works but has
"lots of errors" per user — fixing those errors is part of V1.01.

## Core (unchanged)
- Voice-first: Gemini Live realtime bidirectional audio (WebSocket) + on-device fallback
- Floating overlay bubble, foreground/background service
- IRIS-X-style sci-fi UI skin

## Tool registry — target for V1.01
1. Incoming calls: answer / reject / announce caller name aloud (TTS, contact lookup) — EXISTS
2. Notifications: read latest (WhatsApp, Instagram, Telegram, SMS), app filter,
   quick reply — EXISTS; auto-reply mode on/off — NEW
3. Media: play / pause / toggle / next / previous, system-wide sessions — EXISTS
4. WhatsApp: send a NEW message to a contact by name (lookup + pre-filled chat) — NEW
5. Contacts & phone: search contacts, make call, send SMS — EXISTS
6. Apps: open app — EXISTS; deep links (YouTube/Spotify search, Maps, Chrome) — NEW;
   close app — limited by Android (home/recents level only)
7. Hardware & settings: flashlight on/off/toggle; open Wi-Fi / Bluetooth / Location /
   Hotspot settings panels — NEW
8. Calendar & memory: read schedule (48h), create event, save/recall remembered
   facts ("yaad karo...") — NEW

## Honest limits
- Full live screen-video streaming to the AI is NOT in V1.01; accessibility-based
  screen reading (already in FRIDAY) stays. Streaming is a V1.02 candidate.
- Errors to fix: pending user's list/screenshots of what breaks in the current build.

## Release steps
1. User sends error list/screenshots from current build
2. Fix errors + add NEW features above, versionName 1.01 / versionCode bump
3. Repackage friday-assistant.zip
4. Upload to GitHub repo → Actions build → FRIDAY-APK artifact
5. Install over existing FRIDAY (update keeps data/permissions), test feature checklist

## Error reports from current build (user screenshots)
- E1 (2026-11-04 21:03): Gemini Live connection FAILS — "failed to connect to
  generativelanguage.googleapis.com:443 after 10000ms" + "sent ping but didn't
  receive pong within 20000ms (0 successful)". TCP-level timeout from the phone's
  mobile data (Vi 5G, CGNAT 10.21.x). Top banner shows CONNECTION PROBLEM.
  V1.01: robust reconnect/retry, clear user-facing message, seamless offline
  fallback notice. Diagnosis pending: try Wi-Fi; key validity unconfirmed
  (a wrong key usually errors AFTER connect, timeout points to network).
- E2 (2026-11-04 21:03): "Live voice" is a free-text field and the user typed
  "gemini" into it — an invalid voice name the API would reject.
  V1.01: voice becomes a dropdown (Kore/Puck/Charon/Fenrir/Aoede) + validation.
- Confirmed working in same screenshot: ALL System Setup permissions granted
  (mic/calls/contacts/SMS, overlay, notification access, accessibility, battery);
  caller-announce path fired once ("Incoming call from Unknown caller").
- E3 ROOT CAUSE FOUND (code read, 2026-11-04): VoiceSession.start() picks Live
  whenever a key exists and NEVER falls back — on Live error it only sets an
  error status. So with a key saved + Live unreachable, the on-device
  SpeechRecognizer engine never starts: that is why "speech-to-text bhi nahi
  chal raha". V1.01 fix: if Live fails BEFORE connecting, auto-switch to
  on-device mode and tell the user plainly; Talk button then works.
- E4: No key-validity feedback anywhere. V1.01: "Verify key" button (REST
  models call) with clear status: valid / invalid / network unreachable.
- User offered to share a repo link to work from (2026-11-04 21:05) — link awaited.

## V1.01 IMPLEMENTATION DONE (2026-11-04 night)
All items implemented in the friday-assistant codebase and statically verified
(all Kotlin files balanced; declarations == dispatch == on-device calls, 21 tools):
E3 fallback (VoiceSession.fallbackToOnDevice), E2 voice chips + Settings sanitizer,
E4 verifyGeminiKey button, DeviceActions (torch/panels/deep links/close), 
CalendarActions (48h read + create), FridayMemory (facts), sendWhatsApp (wa.me),
AutoReplier (opt-in toggle, Gemini REST reply via own RemoteInput, 60s/sender
cooldown), calendar manifest+runtime permissions, version 1.01 (code 2).
Zip repackaged as friday-assistant.zip. NEXT: user uploads zip to repo (delete
old zip first) -> GitHub build -> install over V1.0 -> test. Compile itself can
only be proven by that GitHub build (sandbox cannot run Gradle).
