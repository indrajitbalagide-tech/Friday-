# FRIDAY — Voice-First Android Assistant

FRIDAY is a premium, voice-first assistant for Android. Talk naturally and FRIDAY
does real things on the phone: opens apps, makes and answers calls, announces
who is calling, controls music, reads notifications, replies to WhatsApp/SMS
messages, and can look at what is on your screen to help in context.

It runs as a background foreground service with a floating bubble, so it is
always one tap away — no digging through menus.

---

## Interface — IRIS-X sci-fi skin

FRIDAY's UI uses the IRIS-X visual language (sampled from its native views):
neon cyan `#00F0FF`, magenta `#FF007A` and violet `#7000FF` over deep space
violet-black. The home screen has a holographic particle/grid background, a
layered cyber orb (concentric glowing rings, counter-rotating arcs, orbiting
particles, a core that reacts to your voice level), a live spectrum bar row
under the orb, HUD corner-bracket panels, and a matching neon overlay bubble.
All assistant features underneath are unchanged.

## Two voice engines, one assistant

| Mode | When | How it works |
|---|---|---|
| **Gemini Live** (recommended) | You paste a Gemini API key in Settings | Realtime speech-to-speech over the Gemini Live API (WebSocket, `gemini-2.5-flash-native-audio-preview-12-2025`). Mic audio streams at 16 kHz, replies stream back at 24 kHz, and the model calls on-device **tools** to perform actions. Natural conversation, barge-in supported. |
| **On-device** | No key / offline | Android `SpeechRecognizer` + a fast intent parser + `TextToSpeech`, driving the exact same action layer. Understands commands like “open WhatsApp”, “call Mom”, “pause music”, “read my notifications”, “what's on my screen”. Private and free. |

## What it can do

- **Open apps by name** — “Open Spotify”, fuzzy-matched against installed apps.
- **Calls** — “Call Mom” (contacts lookup), **answer/reject by voice** while a
  call is ringing, end calls.
- **Caller announcements** — incoming calls are announced out loud by contact
  name (“Incoming call from Mom — say *answer it* or *reject it*”).
- **Music control** — play / pause / next / previous / stop and “what's
  playing”, via the active media session (Spotify, YouTube Music, players),
  plus volume by percent.
- **Notifications** — “Read my notifications” reads the latest ones aloud.
- **Quick replies** — “Reply: I'll be there in 10” answers the latest
  WhatsApp / Messages / Telegram / Signal notification using the app's own
  notification reply action (the supported Android mechanism). New SMS can
  also be sent directly.
- **Screen awareness** — “What's on my screen?” / “Help me with this” reads
  the foreground app's visible text (password fields are always skipped) and
  gives it to the model as context.
- **Floating bubble** — draggable overlay: tap to talk, long-press to open
  the app. Green while a session is live.
- **Background-ready** — microphone foreground service with a persistent
  notification (Talk / Stop actions), designed around Android 14/15 rules.

## Architecture

```
MainActivity (Compose UI: orb, transcript, setup checklist, settings)
AssistantService (foreground service, type microphone|specialUse)
 ├─ VoiceSession
 │    ├─ GeminiLiveClient  — Live API WebSocket, tool calls
 │    ├─ OnDeviceVoice     — SpeechRecognizer + parser + TTS
 │    └─ AudioEngine       — 16 kHz capture / 24 kHz playback, AEC + NS
 ├─ ActionRouter           — the tool surface the model can call
 │    ├─ AppActions        — resolve + launch apps
 │    ├─ CallActions       — TelecomManager accept/end, dialler
 │    ├─ MusicActions      — MediaSession transport controls
 │    └─ MessageActions    — read notifications, RemoteInput replies, SMS
 ├─ CallWatcher            — TelephonyCallback, contact-name lookup
 ├─ OverlayController      — floating bubble (WindowManager)
AssistantNotificationListener — notification store + reply actions
ScreenContextService      — AccessibilityService (read-only screen text)
BootReceiver              — posts tap-to-start after reboot (see below)
```

## Build on GitHub — no computer needed (cloud APK)

This project includes a ready GitHub Actions workflow
(`.github/workflows/build.yml`). Two ways to use it:

- **Whole project:** create a GitHub repo and upload the *contents* of this
  folder to the repo root. Every push builds the APK automatically.
- **Phone-friendly:** create a repo, add just the workflow file at
  `.github/workflows/build.yml` (paste its contents), then upload
  `friday-assistant.zip` to the repo root — the workflow unzips and builds it.

Then open the repo's **Actions** tab → latest run → **Artifacts → FRIDAY-APK**
→ download, unzip, and install `app-debug.apk`. (The very first run — right
after adding only the workflow file — will fail because the project is not
there yet; the run after the zip upload is the real one.)

## Build & run

**Android Studio (easiest):** open this folder, let it sync, run on a device
(API 26+; a physical device is strongly recommended — telephony, overlay and
media sessions don't behave in emulators).

**Command line:**

```bash
gradle wrapper --gradle-version 8.14.3   # one time, if gradlew is absent
./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

Requires JDK 17 and Android SDK 35 (`compileSdk 35`, `minSdk 26`,
`targetSdk 35`). Create `local.properties` with `sdk.dir=<your SDK path>`
(or copy `local.properties.example`).

## First-run setup (in the app)

1. Tap **Start FRIDAY** and grant the runtime permissions (mic, phone,
   contacts, SMS, notifications).
2. In the **Setup** card, grant:
   - **Floating bubble** (draw over other apps),
   - **Notification access** (needed to read notifications, reply to
     messages, and find the active music session),
   - **Screen awareness** (Accessibility → FRIDAY, if you want screen context),
   - **Battery** exemption (so Android doesn't kill the background service).
3. Optional but recommended: paste a **Gemini API key** in Settings
   (from Google AI Studio) to unlock natural realtime conversation.
   The key is stored only on the device and used only against Google's
   Live API endpoint over TLS.

## Honest platform notes

- **Android 15** forbids starting a *microphone* foreground service from
  `BOOT_COMPLETED`; after a reboot FRIDAY posts a “tap to start” notification
  instead of failing. Starting FRIDAY from the app or the visible bubble is
  always allowed.
- There is **no always-on hotword** (“Hey FRIDAY”) in this build — true
  hotword detection needs a dedicated on-device keyword engine. The bubble,
  the notification **Talk** action and the in-app orb are the entry points.
- **Quick replies** work when the messaging app exposes a reply action on
  its notification (WhatsApp, Google Messages, Telegram and Signal do).
  If it doesn't, FRIDAY says so and offers to open the app instead.
- Caller-name announcements need the **contacts** permission; answering and
  rejecting by voice need **ANSWER_PHONE_CALLS** (both are requested).
- `QUERY_ALL_PACKAGES` is used to resolve spoken app names. It's right for
  a personal/sideloaded build; a Play Store release would need Google's
  permission declaration for it.

## Build status

The full project source is complete and internally consistent (manifest,
resources and all 22 Kotlin files validated). It was authored in a hosted
sandbox whose VM did not have enough free memory to run the Gradle/Android
build, so **no prebuilt APK is included** — build it with the steps above
(Android Studio import is a one-click sync). If your first sync reports a
version nit, the pins are: AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01,
Gradle 8.14.3.

## What's new in V1.01

- **Live fallback fixed:** if Gemini Live cannot connect (bad network / key),
  FRIDAY now switches to on-device mode automatically and says so — voice
  commands and speech-to-text no longer die with the Live connection.
- **Voice picker:** the Live voice is chosen from a list (Kore, Puck, Charon,
  Fenrir, Aoede) instead of a free-text field; invalid stored values are
  sanitized to Kore.
- **Key check button:** Configuration now verifies the Gemini API key with one
  tap and shows a clear result (valid / invalid / network unreachable).
- **New tools (IRIS registry names):** control_device_hardware (flashlight,
  Wi-Fi/Bluetooth/Location/Hotspot panels), open_deep_link (YouTube/Spotify/
  Maps/web searches), close_app, send_whatsapp_message (contact by name,
  pre-filled chat), search_contacts, check_schedule + schedule_new_event
  (calendar), save_core_memory + access_core_memory (remember/recall facts).
- **Auto-reply mode (opt-in, Configuration):** Gemini writes and sends replies
  to new WhatsApp/Telegram/SMS notifications, 1 per sender per minute.
- On-device (offline) voice commands added for the new tools; calendar
  permissions added. Version 1.01 (versionCode 2).
