package com.vaani.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import java.util.Calendar
import kotlin.math.sin

/**
 * Bada din-wala office (2D), user ki bheji reference jaisa layout:
 * peeche badi khidkiyon se sheher ka skyline, dayein taraf SHEESHE ka BOSS CABIN (andar Vaani),
 * neeche-dayein CAFE POINT (coffee machine), 2 kataaron mein 11 agents apni desk par.
 * Kaam wala = seedha typing + sir par speech-bubble; khaali = leta aaram + "Z", ya baari se coffee break par.
 * Haalat nakli nahi: MainActivity AgentStatus ke asli timestamps se working[] bharata hai.
 */
class OfficeView(ctx: Context) : View(ctx) {
    var working = BooleanArray(11)
    var bossOn = false
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private val path = Path()
    private var tick = 0
    private val anim = object : Runnable {
        override fun run() { tick++; invalidate(); postDelayed(this, 120) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(anim) }
    override fun onDetachedFromWindow() { removeCallbacks(anim); super.onDetachedFromWindow() }

    companion object {
        val NAMES = listOf("Ears", "Speech", "Brain", "Hands", "Eyes", "Phone", "Mouth", "Memory", "Files", "Home", "Camera")
        private val SHIRTS = listOf("#FF2E4D", "#26A69A", "#B388FF", "#FFB74D", "#4DD0E1", "#81C784", "#F48FB1",
            "#90A4AE", "#AED581", "#FF8A65", "#64B5F6")
        private val SKIN = listOf("#F1C27D", "#E0AC69", "#C68642", "#FFDBAC")
        private val HAIR = listOf("#14100E", "#241611", "#2E2A26", "#191410")
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val phase = tick * 0.28f
        drawRoom(c, w, h)
        val breakIdx = (tick / 200) % 11
        val onBreak = !working.getOrElse(breakIdx) { false }
        drawCabin(c, w, h, phase)
        drawPlant(c, w * 0.022f, h * 0.575f)
        val backW = (w * 0.61f) / 5f
        for (i in 0 until 5) { val idx = i + 6; val cx = w * 0.05f + backW * (i + 0.5f)
            if (!(onBreak && idx == breakIdx)) drawSeat(c, cx, h * 0.575f, backW, idx, phase, true)
            else drawEmptySeat(c, cx, h * 0.575f, backW, idx) }
        drawCoffeePoint(c, w, h, phase)
        val frontW = (w * 0.82f) / 6f
        if (onBreak) drawStanding(c, w * 0.802f, h * 0.885f, frontW, breakIdx)
        for (i in 0 until 6) { val idx = i; val cx = frontW * (i + 0.5f)
            if (!(onBreak && idx == breakIdx)) drawSeat(c, cx, h * 0.885f, frontW, idx, phase, false)
            else drawEmptySeat(c, cx, h * 0.885f, frontW, idx) }
    }

    /** Kamra: halki deewar, badi khidkiyan (aasman + skyline + sooraj), ceiling lights, lakdi ka farsh, ghadi. */
    private fun drawRoom(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#F6E7D2"); c.drawRect(0f, 0f, w, h * 0.60f, p)
        p.color = Color.parseColor("#EAC79C"); c.drawRect(0f, h * 0.60f, w, h, p)
        p.color = Color.parseColor("#D89B6A"); p.alpha = 70
        rf.set(w * 0.06f, h * 0.76f, w * 0.80f, h * 0.83f); c.drawOval(rf, p); p.alpha = 255
        p.color = Color.parseColor("#C89B6A"); c.drawRect(0f, h * 0.60f, w, h * 0.60f + 1.4f * d, p)
        // Ceiling lights
        p.color = Color.parseColor("#FFF3D6")
        for (lx in listOf(0.20f, 0.48f)) { rf.set(w * lx, h * 0.012f, w * (lx + 0.13f), h * 0.012f + 3.2f * d); c.drawRoundRect(rf, 1.6f * d, 1.6f * d, p) }
        // Khidkiyan — aasman, sooraj, badal, sheher
        val wx = w * 0.03f; val wy = h * 0.05f; val ww = w * 0.63f; val wh = h * 0.25f
        p.color = Color.parseColor("#BDE9FF"); rf.set(wx, wy, wx + ww, wy + wh); c.drawRoundRect(rf, 3 * d, 3 * d, p)
        p.color = Color.parseColor("#FFD54F"); c.drawCircle(wx + ww * 0.86f, wy + wh * 0.28f, 6.5f * d, p)
        p.color = Color.parseColor("#FFFFFF"); p.alpha = 235
        for ((bx, by, bs) in listOf(Triple(0.16f, 0.26f, 1f), Triple(0.52f, 0.18f, 0.8f))) {
            c.drawCircle(wx + ww * bx, wy + wh * by, 4.4f * d * bs, p)
            c.drawCircle(wx + ww * bx + 4.6f * d * bs, wy + wh * by + 0.8f * d, 3.4f * d * bs, p)
        }
        p.alpha = 255
        p.color = Color.parseColor("#8FB8D8")
        val base = wy + wh
        val bw = ww / 9f
        val heights = listOf(0.34f, 0.52f, 0.42f, 0.62f, 0.38f, 0.55f, 0.45f, 0.60f, 0.36f)
        for (i in 0 until 9) c.drawRect(wx + i * bw + 1f, base - wh * heights[i], wx + (i + 1) * bw - 1f, base, p)
        p.color = Color.parseColor("#E8F6FF"); p.alpha = 190
        for (i in 0 until 9) for (r in 0 until 2) c.drawRect(wx + i * bw + bw * 0.3f, base - wh * heights[i] + (3 + r * 5) * d, wx + i * bw + bw * 0.55f, base - wh * heights[i] + (4.6f + r * 5) * d, p)
        p.alpha = 255
        p.style = Paint.Style.STROKE; p.color = Color.parseColor("#FFFFFF"); p.strokeWidth = 2.2f * d
        rf.set(wx, wy, wx + ww, wy + wh); c.drawRoundRect(rf, 3 * d, 3 * d, p)
        c.drawLine(wx + ww / 3f, wy, wx + ww / 3f, wy + wh, p); c.drawLine(wx + 2 * ww / 3f, wy, wx + 2 * ww / 3f, wy + wh, p)
        p.style = Paint.Style.FILL
        // Ghadi (asal samay)
        val cal = Calendar.getInstance()
        val gx = w * 0.345f; val gy = h * 0.375f; val gr = 8.5f * d
        p.color = Color.parseColor("#FFFFFF"); c.drawCircle(gx, gy, gr, p)
        p.style = Paint.Style.STROKE; p.color = Color.parseColor("#5A3A28"); p.strokeWidth = 1.4f * d; c.drawCircle(gx, gy, gr, p)
        fun hand(frac: Double, len: Float, widthPx: Float, col: Int) {
            val a = frac * 2 * Math.PI - Math.PI / 2
            p.strokeWidth = widthPx; p.color = col
            c.drawLine(gx, gy, gx + (Math.cos(a) * len).toFloat(), gy + (Math.sin(a) * len).toFloat(), p)
        }
        hand((cal.get(Calendar.HOUR) % 12 + cal.get(Calendar.MINUTE) / 60.0) / 12.0, gr * 0.52f, 1.7f * d, Color.parseColor("#5A3A28"))
        hand(cal.get(Calendar.MINUTE) / 60.0, gr * 0.78f, 1.2f * d, Color.parseColor("#5A3A28"))
        hand((cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000.0) / 60.0, gr * 0.88f, 0.7f * d, Color.parseColor("#FF2E4D"))
        p.style = Paint.Style.FILL
    }

    /** Farsh par rakha paudha. */
    private fun drawPlant(c: Canvas, cx: Float, base: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#C96F4A")
        path.reset(); path.moveTo(cx - 4.5f * d, base); path.lineTo(cx + 4.5f * d, base)
        path.lineTo(cx + 3.4f * d, base - 6 * d); path.lineTo(cx - 3.4f * d, base - 6 * d); path.close(); c.drawPath(path, p)
        p.color = Color.parseColor("#43A047")
        c.drawCircle(cx, base - 11 * d, 4.6f * d, p); c.drawCircle(cx - 4.4f * d, base - 8.6f * d, 3.4f * d, p); c.drawCircle(cx + 4.4f * d, base - 8.6f * d, 3.4f * d, p)
    }

    /** BOSS CABIN — sheeshe ke andar Vaani ki desk. Service band ho to cabin khaali. */
    private fun drawCabin(c: Canvas, w: Float, h: Float, phase: Float) {
        val x0 = w * 0.685f; val x1 = w * 0.978f; val y0 = h * 0.045f; val y1 = h * 0.56f
        val cx = (x0 + x1) / 2f; val base = h * 0.50f; val sw = (x1 - x0) * 0.66f; val u = sw / 100f
        val deskY = base - 34 * u
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#F1DDBE"); c.drawRect(x0, y0, x1, y1, p)
        // Kursi
        p.color = Color.parseColor("#8D6E63")
        rf.set(cx - 36 * u, deskY - 18 * u, cx - 29 * u, deskY + 17 * u); c.drawRoundRect(rf, 3 * u, 3 * u, p)
        c.drawRect(cx - 34 * u, deskY + 15 * u, cx - 31 * u, base - 3 * u, p)
        if (bossOn) {
            val bob = sin((phase * 0.8f).toDouble()).toFloat() * 0.9f * u
            p.color = Color.parseColor("#37474F")
            rf.set(cx - 27 * u, deskY + 6 * u, cx - 2 * u, deskY + 12 * u); c.drawRoundRect(rf, 3 * u, 3 * u, p)
            c.drawRect(cx - 7 * u, deskY + 10 * u, cx - 3.6f * u, base - 3 * u, p)
            p.color = Color.parseColor("#263238"); c.drawRect(cx - 8.5f * u, base - 3.2f * u, cx + 1.5f * u, base - 1 * u, p)
            val hx = cx - 23.5f * u; val hy = deskY - 32 * u + bob
            p.color = Color.parseColor("#17100C")
            rf.set(hx - 9.5f * u, hy - 9 * u, hx + 9.5f * u, hy + 17 * u); c.drawRoundRect(rf, 4.5f * u, 4.5f * u, p)
            p.color = Color.parseColor("#FF2E4D")
            rf.set(cx - 32 * u, deskY - 25 * u + bob, cx - 15 * u, deskY + 9 * u); c.drawRoundRect(rf, 5.5f * u, 5.5f * u, p)
            p.color = Color.parseColor("#FFDBAC"); c.drawCircle(hx, hy, 8.4f * u, p)
            p.color = Color.parseColor("#17100C")
            rf.set(hx - 8.4f * u, hy - 9.4f * u, hx + 8.4f * u, hy + 0.8f * u); c.drawArc(rf, 180f, 180f, true, p)
            p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4.8f * u
            p.color = Color.parseColor("#FF2E4D")
            c.drawLine(cx - 18 * u, deskY - 17 * u + bob, cx - 4 * u, deskY - 4 * u, p)
            p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
        }
        // Desk
        p.color = Color.parseColor("#A9743F")
        c.drawRect(cx - 52 * u, deskY, cx + 54 * u, deskY + 4 * u, p)
        c.drawRect(cx - 49 * u, deskY + 4 * u, cx - 45 * u, base - 1 * u, p)
        c.drawRect(cx + 48 * u, deskY + 4 * u, cx + 52 * u, base - 1 * u, p)
        p.color = Color.parseColor("#8D5524"); c.drawRect(cx - 47 * u, deskY - 3.2f * u, cx - 42.8f * u, deskY, p)
        p.color = Color.parseColor("#43A047")
        c.drawCircle(cx - 44.9f * u, deskY - 5.2f * u, 2.4f * u, p); c.drawCircle(cx - 47 * u, deskY - 3.9f * u, 1.7f * u, p); c.drawCircle(cx - 42.8f * u, deskY - 3.9f * u, 1.7f * u, p)
        p.color = Color.parseColor("#263238"); rf.set(cx - 9 * u, deskY - 1.8f * u, cx + 9 * u, deskY + 0.4f * u); c.drawRoundRect(rf, 1 * u, 1 * u, p)
        val mx0 = cx + 16 * u; val my0 = deskY - 28 * u; val mx1 = cx + 44 * u; val my1 = deskY - 5 * u
        p.color = Color.parseColor("#263238"); rf.set(mx0, my0, mx1, my1); c.drawRoundRect(rf, 2 * u, 2 * u, p)
        if (bossOn) {
            val glow = 0.82f + 0.18f * sin((phase * 1.2f).toDouble()).toFloat()
            p.color = Color.argb(255, 255, (190 * glow + 40).toInt(), (200 * glow).toInt())
            rf.set(mx0 + 1.8f * u, my0 + 1.8f * u, mx1 - 1.8f * u, my1 - 1.8f * u); c.drawRoundRect(rf, 1.4f * u, 1.4f * u, p)
            p.color = Color.parseColor("#5C1220")
            for (r in 0 until 3) c.drawRect(mx0 + 4 * u, my0 + (5f + r * 6.5f) * u, mx0 + (13f + ((r * 5) % 4) * 3f) * u, my0 + (7f + r * 6.5f) * u, p)
        } else {
            p.color = Color.parseColor("#78909C"); rf.set(mx0 + 1.8f * u, my0 + 1.8f * u, mx1 - 1.8f * u, my1 - 1.8f * u); c.drawRoundRect(rf, 1.4f * u, 1.4f * u, p)
        }
        p.color = Color.parseColor("#263238"); c.drawRect(cx + 29f * u, my1, cx + 31.5f * u, deskY - 1.5f * u, p)
        tp.color = if (bossOn) Color.parseColor("#C2183F") else Color.parseColor("#8A7A6A")
        tp.textSize = 10.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText("VAANI", cx, base + 13.5f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
        // Sheesha + frame + plate (sabke UPAR — glass ka asar)
        p.color = Color.parseColor("#D9F2FF"); p.alpha = 46; c.drawRect(x0, y0, x1, y1, p); p.alpha = 255
        p.style = Paint.Style.STROKE; p.color = Color.parseColor("#FFFFFF"); p.strokeWidth = 1.8f * d
        c.drawRect(x0, y0, x1, y1, p); c.drawLine(x1 - (x1 - x0) * 0.28f, y0, x1 - (x1 - x0) * 0.28f, y1, p)
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#FFFFFF")
        rf.set(cx - 23 * d, y0 + 2.5f * d, cx + 23 * d, y0 + 11.5f * d); c.drawRoundRect(rf, 1.5f * d, 1.5f * d, p)
        tp.color = Color.parseColor("#37474F"); tp.textSize = 6.8f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText("BOSS CABIN", cx, y0 + 9.3f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
    }

    /** CAFE POINT — neeche-dayein counter par coffee machine, bhaap ke saath. */
    private fun drawCoffeePoint(c: Canvas, w: Float, h: Float, phase: Float) {
        val x0 = w * 0.85f; val x1 = w * 0.992f; val cTop = h * 0.735f; val base = h * 0.885f
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#8D5524"); c.drawRect(x0 - 2 * d, cTop, x1, cTop + 3 * d, p)
        p.color = Color.parseColor("#A9743F"); c.drawRect(x0, cTop + 3 * d, x1, base, p)
        p.color = Color.parseColor("#8D5524"); c.drawRect(x0 + (x1 - x0) * 0.48f, cTop + 6 * d, x0 + (x1 - x0) * 0.52f, base - 3 * d, p)
        // Machine
        val mx0 = x0 + (x1 - x0) * 0.18f; val mx1 = x0 + (x1 - x0) * 0.82f; val my1 = cTop; val my0 = cTop - 25 * d
        p.color = Color.parseColor("#37474F"); rf.set(mx0, my0, mx1, my1); c.drawRoundRect(rf, 2.5f * d, 2.5f * d, p)
        p.color = Color.parseColor("#263238"); rf.set(mx0 + 3 * d, my0 + 3.5f * d, mx1 - 3 * d, my0 + 12 * d); c.drawRoundRect(rf, 1.5f * d, 1.5f * d, p)
        val glow = 0.6f + 0.4f * sin((phase * 1.6f).toDouble()).toFloat()
        p.color = Color.argb(255, (120 * glow).toInt(), (230 * glow).toInt(), (255 * glow).toInt())
        rf.set(mx0 + 5 * d, my0 + 5.5f * d, mx1 - 5 * d, my0 + 10 * d); c.drawRoundRect(rf, 1 * d, 1 * d, p)
        p.color = Color.parseColor("#ECEFF1"); c.drawRect(mx0 + (mx1 - mx0) / 2 - 1.2f * d, my0 + 14 * d, mx0 + (mx1 - mx0) / 2 + 1.2f * d, my0 + 17.5f * d, p)
        p.color = Color.parseColor("#FFFFFF"); rf.set(mx0 + (mx1 - mx0) / 2 - 3.2f * d, my0 + 17.5f * d, mx0 + (mx1 - mx0) / 2 + 3.2f * d, my0 + 22.5f * d); c.drawRoundRect(rf, 0.8f * d, 0.8f * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.1f * d; p.strokeCap = Paint.Cap.ROUND
        p.color = Color.parseColor("#FFFFFF")
        for (s in 0 until 2) {
            val bx = mx0 + (mx1 - mx0) / 2 + (s - 0.5f) * 3.6f * d
            val rise = ((tick * 2 + s * 14) % 44) / 44f
            p.alpha = (170 * (1f - rise)).toInt().coerceIn(0, 170)
            path.reset(); path.moveTo(bx, my0 + 16.5f * d - rise * 2 * d)
            path.quadTo(bx + 2f * d * sin((phase + s * 2f).toDouble()).toFloat(), my0 + 11 * d - rise * 4 * d, bx, my0 + 6 * d - rise * 6 * d)
            c.drawPath(path, p)
        }
        p.alpha = 255; p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#FFFFFF")
        rf.set(x1 - 11 * d, cTop - 6 * d, x1 - 6.4f * d, cTop - 1.4f * d); c.drawRoundRect(rf, 0.7f * d, 0.7f * d, p)
        tp.color = Color.parseColor("#5A3A28"); tp.textSize = 7.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText("CAFE POINT", (x0 + x1) / 2, base + 10.5f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
    }

    /** Coffee break par khada agent — haath mein cup. (Unit wahi jo drawSeat ka: u = sw/100) */
    private fun drawStanding(c: Canvas, cx: Float, feet: Float, sw: Float, idx: Int) {
        val u = sw / 100f
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#37474F")
        c.drawRect(cx - 5 * u, feet - 30 * u, cx - 1 * u, feet, p)
        c.drawRect(cx + 1 * u, feet - 30 * u, cx + 5 * u, feet, p)
        p.color = Color.parseColor(SHIRTS[idx])
        rf.set(cx - 7 * u, feet - 58 * u, cx + 7 * u, feet - 28 * u); c.drawRoundRect(rf, 3.5f * u, 3.5f * u, p)
        val hx = cx; val hy = feet - 66 * u
        p.color = Color.parseColor(SKIN[idx % SKIN.size]); c.drawCircle(hx, hy, 7.5f * u, p)
        p.color = Color.parseColor(HAIR[idx % HAIR.size])
        rf.set(hx - 7.5f * u, hy - 8.4f * u, hx + 7.5f * u, hy + 1.3f * u); c.drawArc(rf, 180f, 180f, true, p)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4.4f * u
        p.color = Color.parseColor(SHIRTS[idx])
        c.drawLine(cx + 5 * u, feet - 52 * u, cx + 11 * u, feet - 44 * u, p)
        p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
        p.color = Color.parseColor("#FFFFFF")
        rf.set(cx + 9.5f * u, feet - 48.5f * u, cx + 13.5f * u, feet - 43.5f * u); c.drawRoundRect(rf, 0.9f * u, 0.9f * u, p)
        tp.color = Color.parseColor("#4E342E"); tp.textSize = 10.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(NAMES[idx], cx, feet + 13.5f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
    }

    /** Khaali seat (agent coffee break par gaya hai). */
    private fun drawEmptySeat(c: Canvas, cx: Float, base: Float, sw: Float, idx: Int) {
        val u = sw / 100f; val deskY = base - 34 * u
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#8D6E63")
        rf.set(cx - 34 * u, deskY - 16 * u, cx - 28.5f * u, deskY + 16 * u); c.drawRoundRect(rf, 2.5f * u, 2.5f * u, p)
        c.drawRect(cx - 33 * u, deskY + 14 * u, cx - 30 * u, base - 3 * u, p)
        p.color = Color.parseColor("#A9743F")
        c.drawRect(cx - 40 * u, deskY, cx + 42 * u, deskY + 3.6f * u, p)
        c.drawRect(cx - 38 * u, deskY + 3.6f * u, cx - 35 * u, base - 1 * u, p)
        c.drawRect(cx + 38 * u, deskY + 3.6f * u, cx + 41 * u, base - 1 * u, p)
        p.color = Color.parseColor("#263238")
        rf.set(cx + 16 * u, deskY - 27 * u, cx + 40 * u, deskY - 5 * u); c.drawRoundRect(rf, 1.8f * u, 1.8f * u, p)
        tp.color = Color.parseColor("#6D4C41"); tp.textSize = 10.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(NAMES[idx], cx, base + 13.5f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
    }

    /** Ek workstation: kursi par baitha insaan (side view), saamne desk + monitor. Kaam wale ke sir par speech bubble. */
    private fun drawSeat(c: Canvas, cx: Float, base: Float, sw: Float, idx: Int, phase: Float, backRow: Boolean) {
        val wk = working.getOrElse(idx) { false }
        val u = sw / 100f
        val deskY = base - 34 * u
        val bob = if (wk) sin((phase + idx * 1.7f).toDouble()).toFloat() * 1.1f * u else 0f
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#8D6E63")
        rf.set(cx - 34 * u, deskY - 16 * u, cx - 28.5f * u, deskY + 16 * u); c.drawRoundRect(rf, 2.5f * u, 2.5f * u, p)
        c.drawRect(cx - 33 * u, deskY + 14 * u, cx - 30 * u, base - 3 * u, p)
        c.drawRect(cx - 38 * u, base - 3.5f * u, cx - 25 * u, base - 1.2f * u, p)
        p.color = Color.parseColor("#37474F")
        rf.set(cx - 27 * u, deskY + 6 * u + bob * 0.3f, cx - 2 * u, deskY + 11.5f * u); c.drawRoundRect(rf, 2.5f * u, 2.5f * u, p)
        c.drawRect(cx - 7 * u, deskY + 10 * u, cx - 3.6f * u, base - 2.5f * u, p)
        p.color = Color.parseColor("#263238"); c.drawRect(cx - 8.5f * u, base - 3 * u, cx + 1.5f * u, base - 0.8f * u, p)
        val lean = if (wk) 0f else -16f
        c.save()
        c.translate(cx - 24 * u, deskY + 8 * u); c.rotate(lean); c.translate(-(cx - 24 * u), -(deskY + 8 * u))
        p.color = Color.parseColor(SHIRTS[idx])
        rf.set(cx - 31 * u, deskY - 24 * u + bob, cx - 16 * u, deskY + 9 * u); c.drawRoundRect(rf, 5 * u, 5 * u, p)
        val hx = cx - 23.5f * u; val hy = deskY - 31 * u + bob
        p.color = Color.parseColor(SKIN[idx % SKIN.size]); c.drawCircle(hx, hy, 7.6f * u, p)
        p.color = Color.parseColor(HAIR[idx % HAIR.size])
        rf.set(hx - 7.6f * u, hy - 8.6f * u, hx + 7.6f * u, hy + 1.5f * u); c.drawArc(rf, 180f, 180f, true, p)
        if (!wk) {
            p.style = Paint.Style.STROKE; p.color = Color.parseColor("#4A3428"); p.strokeWidth = 1.1f * u
            c.drawLine(hx + 2.5f * u, hy + 0.5f * u, hx + 6 * u, hy + 0.5f * u, p)
            p.style = Paint.Style.FILL
        }
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4.6f * u
        p.color = Color.parseColor(SHIRTS[idx])
        if (wk) {
            val ty = deskY - 4 * u + sin((phase * 2f + idx).toDouble()).toFloat() * 1.4f * u
            c.drawLine(cx - 19 * u, deskY - 17 * u + bob, cx - 4 * u, ty, p)
        } else {
            c.drawLine(cx - 20 * u, deskY - 18 * u, cx - 30 * u, deskY - 33 * u, p)
        }
        p.strokeCap = Paint.Cap.BUTT
        c.restore()
        // Speech bubble (kaam wala kuch bol/soch raha hai) ya "Z" (aaram wala)
        val hx2 = cx - 23.5f * u; val hy2 = deskY - 31 * u + bob
        if (wk) {
            val bx0 = hx2 - 2 * u; val by1 = hy2 - 13.5f * u; val bx1 = hx2 + 15 * u; val by0 = by1 - 11 * u
            p.color = Color.parseColor("#FFFFFF")
            rf.set(bx0, by0, bx1, by1); c.drawRoundRect(rf, 3.4f * u, 3.4f * u, p)
            path.reset(); path.moveTo(hx2 + 3 * u, by1 - 0.5f * u); path.lineTo(hx2 + 6.4f * u, by1 + 3.6f * u); path.lineTo(hx2 + 8.6f * u, by1 - 0.5f * u); path.close(); c.drawPath(path, p)
            p.color = Color.parseColor("#37474F")
            val pulse = 0.55f + 0.45f * sin((phase * 2.2f + idx).toDouble()).toFloat()
            for (dot in 0 until 3) { p.alpha = if (dot == ((tick / 4 + idx) % 3)) 255 else 110
                c.drawCircle(bx0 + (4.6f + dot * 3.4f) * u, (by0 + by1) / 2f, 1.05f * u, p) }
            p.alpha = 255
        } else {
            val floatY = (tick % 36) / 36f
            tp.color = Color.parseColor("#5C7C99"); tp.alpha = (210 * (1f - floatY)).toInt().coerceIn(0, 210)
            tp.textSize = (8f + floatY * 3.5f) * d
            c.drawText("Z", cx - 8 * u + floatY * 5 * u, deskY - 44 * u - floatY * 8 * u, tp)
            tp.alpha = 255
        }
        // Desk + keyboard + monitor
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#A9743F")
        c.drawRect(cx - 40 * u, deskY, cx + 42 * u, deskY + 3.6f * u, p)
        c.drawRect(cx - 38 * u, deskY + 3.6f * u, cx - 35 * u, base - 1 * u, p)
        c.drawRect(cx + 38 * u, deskY + 3.6f * u, cx + 41 * u, base - 1 * u, p)
        p.color = Color.parseColor("#263238"); rf.set(cx - 9 * u, deskY - 1.8f * u, cx + 9 * u, deskY + 0.4f * u)
        c.drawRoundRect(rf, 1 * u, 1 * u, p)
        val mx0 = cx + 16 * u; val my0 = deskY - 27 * u; val mx1 = cx + 40 * u; val my1 = deskY - 5 * u
        p.color = Color.parseColor("#263238"); rf.set(mx0, my0, mx1, my1); c.drawRoundRect(rf, 1.8f * u, 1.8f * u, p)
        if (wk) {
            val glow = 0.82f + 0.18f * sin((phase * 1.4f + idx * 2.1f).toDouble()).toFloat()
            p.color = Color.argb(255, (170 * glow).toInt(), (225 * glow).toInt(), (255 * glow).toInt())
            rf.set(mx0 + 1.6f * u, my0 + 1.6f * u, mx1 - 1.6f * u, my1 - 1.6f * u); c.drawRoundRect(rf, 1.2f * u, 1.2f * u, p)
            p.color = Color.parseColor("#0B3B52")
            for (r in 0 until 3) c.drawRect(mx0 + 3.4f * u, my0 + (4.5f + r * 5.5f) * u,
                mx0 + (10f + ((idx + r * 3) % 4) * 2.6f) * u, my0 + (6.3f + r * 5.5f) * u, p)
        } else {
            p.color = Color.parseColor("#78909C"); rf.set(mx0 + 1.6f * u, my0 + 1.6f * u, mx1 - 1.6f * u, my1 - 1.6f * u)
            c.drawRoundRect(rf, 1.2f * u, 1.2f * u, p)
        }
        p.color = Color.parseColor("#263238"); c.drawRect(cx + 26.5f * u, my1, cx + 29.5f * u, deskY - 1.5f * u, p)
        // Naam + bindu
        p.color = if (wk) Color.parseColor("#2E9E4F") else Color.parseColor("#B09A88")
        c.drawCircle(cx, base + 4.2f * d, 1.5f * d, p)
        tp.color = if (wk) Color.parseColor("#4E342E") else Color.parseColor("#6D4C41")
        tp.textSize = 10.5f * d; tp.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(NAMES[idx], cx, base + 13.5f * d, tp); tp.typeface = android.graphics.Typeface.DEFAULT
    }
}
