package com.vaani.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.TelephonyManager

/**
 * Calls:
 * - Bajti call par friendly awaaz mein batata hai kiska call hai + poochta hai "Answer karun ya reject?"
 *   (Live session khul jata hai taaki user bolkar faisla de sake - call_control tool se asal action hota hai.)
 * - Uthaye bina kat jaye to missed call ki khabar deta hai.
 */
class CallReceiver : BroadcastReceiver() {
    companion object {
        @Volatile var lastCaller: String? = null
        @Volatile var ringingNow: String? = null
        @Volatile private var wasAnswered = false
    }

    override fun onReceive(c: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: return
                val name = lookup(c, num) ?: num
                ringingNow = name; wasAnswered = false
                if (name == lastCaller) return
                lastCaller = name
                VaaniService.log?.invoke("📞 $name ka call aa raha hai")
                AgentStatus.call = "$name ka call aa raha hai"; AgentStatus.callAt = System.currentTimeMillis()
                if (!c.getSharedPreferences("vaani", Context.MODE_PRIVATE).getBoolean("announce", true)) return
                Speaker.speak(c, "$name ka call aa raha hai. Answer karun ya reject karun?")
                VaaniService.forceStart = true   // Live session kholo taaki user bolkar jawab de sake
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> wasAnswered = true
            TelephonyManager.EXTRA_STATE_IDLE -> {
                val missed = ringingNow
                if (missed != null && !wasAnswered) {
                    VaaniService.log?.invoke("📞 Missed call: $missed")
                    AgentStatus.call = "$missed ki missed call • ${AgentStatus.time()}"; AgentStatus.callAt = System.currentTimeMillis()
                    if (c.getSharedPreferences("vaani", Context.MODE_PRIVATE).getBoolean("announce", true))
                        Speaker.speak(c, "$missed ki missed call aayi thi")
                }
                ringingNow = null; lastCaller = null; wasAnswered = false
            }
        }
    }

    private fun lookup(c: Context, num: String): String? = try {
        c.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) { null }
}
