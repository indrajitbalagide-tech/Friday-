package com.vaani.app

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Messaging notifications:
 * - Naya message aaye to sirf BATATA hai ("X ka message aaya hai") - poora content khud nahi padhta.
 * - Auto-reply ON ho to jawab soch kar pehle POOCHTA hai; bhejta sirf tab hai jab user haan bole
 *   (pending_reply tool se, Actions ke through).
 */
class NotifService : NotificationListenerService() {
    companion object {
        val recent: MutableList<Pair<String, String>> = java.util.Collections.synchronizedList(mutableListOf())
        private val lastReply = HashMap<String, Long>()
        private val APPS = setOf("com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
            "com.instagram.android", "com.google.android.apps.messaging")

        // Permission wala pending jawab - user ke haan bolne ka intezaar karta hai.
        @Volatile var pendingSender: String? = null
        @Volatile var pendingDraft: String? = null
        @Volatile private var pendingAction: Notification.Action? = null
        @Volatile private var pendingCtx: Context? = null

        // Content padhna pending - user ki haan ka intezaar.
        @Volatile var pendingReadApp: String? = null
        @Volatile var pendingReadSender: String? = null
        @Volatile private var pendingReadText: String? = null

        /** User ne faisla diya: read=true to pending message ka content batao, warna gira do. */
        fun respondRead(read: Boolean): String {
            val sender = pendingReadSender; val text = pendingReadText
            pendingReadApp = null; pendingReadSender = null; pendingReadText = null
            if (sender == null || text == null) return "Koi message padhna pending nahi hai."
            return if (read) "$sender ka message hai: \"$text\"" else "Theek hai, nahi padhta."
        }

        /** User ne faisla diya: send=true to pending jawab bhej do, warna gira do. */
        fun respondPending(send: Boolean): String {
            val action = pendingAction; val sender = pendingSender; val draft = pendingDraft; val ctx = pendingCtx
            pendingAction = null; pendingSender = null; pendingDraft = null; pendingCtx = null
            if (sender == null || draft == null) return "Koi jawab pending nahi hai."
            if (!send) return "$sender ko jawab nahi bheja."
            if (action == null || ctx == null) return "Us message ka reply button nahi mila, bhej nahi paya."
            return try {
                val ri = action.remoteInputs[0]; val intent = Intent(); val b = Bundle()
                b.putCharSequence(ri.resultKey, draft)
                RemoteInput.addResultsToIntent(action.remoteInputs, intent, b)
                action.actionIntent.send(ctx, 0, intent)
                "$sender ko jawab bhej diya: \"$draft\""
            } catch (e: Exception) { "Jawab bhejne mein dikkat: ${e.message?.take(60)}" }
        }
    }

    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val bursts = HashMap<String, Burst>()

    private class Burst(val app: String, val sender: String) {
        var count = 0; var latest = ""; var action: Notification.Action? = null; var runnable: Runnable? = null
    }

    private fun appLabel(pkg: String): String = try {
        val ai = packageManager.getApplicationInfo(pkg, 0)
        packageManager.getApplicationLabel(ai).toString()
    } catch (e: Exception) {
        when (pkg) { "com.whatsapp", "com.whatsapp.w4b" -> "WhatsApp"; "org.telegram.messenger" -> "Telegram"
            "com.instagram.android" -> "Instagram"; else -> "Messages" }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in APPS) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        recent.add(title to text); if (recent.size > 30) recent.removeAt(0)

        // 1) Burst jama karo: ek hi bande ke lagataar messages par har baar NAHI bolna hai.
        //    4 second ki chuppi ke baad EK baar, ginti ke saath announce hoga.
        val app = appLabel(sbn.packageName)
        val bKey = sbn.packageName + "|" + title
        val replyAction = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
        synchronized(bursts) {
            val b = bursts.getOrPut(bKey) { Burst(app, title) }
            b.count++; b.latest = text; b.action = replyAction
            b.runnable?.let { handler.removeCallbacks(it) }
            val r = Runnable { fireBurst(bKey) }
            b.runnable = r; handler.postDelayed(r, 4000)
        }
    }

    private fun fireBurst(bKey: String) {
        val b = synchronized(bursts) { bursts.remove(bKey) } ?: return
        pendingReadApp = b.app; pendingReadSender = b.sender; pendingReadText = b.latest
        AgentStatus.khabar = "${b.sender} (${b.app}) • ${AgentStatus.time()}"; AgentStatus.khabarAt = System.currentTimeMillis()
        if (b.count == 1) {
            VaaniService.log?.invoke("📩 ${b.app} par ${b.sender} ka message aaya hai")
            Speaker.speak(this, "${b.app} par ${b.sender} ka message aaya hai. Message mein kya hai, batau kya?")
        } else {
            VaaniService.log?.invoke("📩 ${b.app} par ${b.sender} ke ${b.count} message aaye hain")
            Speaker.speak(this, "${b.app} par ${b.sender} ke ${b.count} message aaye hain. Aakhri message mein kya hai, batau kya?")
        }

        // 2) Auto-reply: sirf AAKHRI message ka jawab socho, bhejne se pehle poochho.
        val p = getSharedPreferences("vaani", MODE_PRIVATE)
        if (!p.getBoolean("auto", false)) return
        val key = p.getString("key", "").orEmpty(); if (key.isEmpty()) return
        val action = b.action ?: return
        val sender = b.sender; val text = b.latest
        val now = System.currentTimeMillis()
        synchronized(lastReply) { if (now - (lastReply[sender] ?: 0L) < 60_000) return; lastReply[sender] = now }
        Thread {
            try {
                // useTools=false: incoming text can never trigger phone actions.
                val parts = Gemini.ask(key, "Mere dost $sender ka message: \"$text\". Meri taraf se ek chhota friendly " +
                    "Hinglish jawab likho. Sirf jawab ka text do.", false)
                val reply = (0 until parts.length()).mapNotNull { parts.getJSONObject(it).optString("text").ifEmpty { null } }
                    .joinToString(" ").trim()
                if (reply.isEmpty()) return@Thread
                pendingSender = sender; pendingDraft = reply; pendingAction = action; pendingCtx = applicationContext
                VaaniService.log?.invoke("💬 $sender ke liye jawab socha hai: \"$reply\" — bolna hai to \"bhej do\" bolo")
                Speaker.speak(this, "$sender ko ye jawab socha hai: $reply. Bhej dun?")
            } catch (_: Exception) {}
        }.start()
    }
}
