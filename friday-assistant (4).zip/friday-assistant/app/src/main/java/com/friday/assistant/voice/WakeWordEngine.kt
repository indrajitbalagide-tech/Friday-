package com.friday.assistant.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService

/**
 * Offline wake word: listens (fully on-device, Vosk) for "Hey FRIDAY" while
 * the assistant service is in standby, then hands over to the real voice
 * session. English small model - the wake phrase is English by design.
 */
class WakeWordEngine(
    context: Context,
    private val onWake: () -> Unit
) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var speechService: SpeechService? = null

    @Volatile
    var running = false
        private set

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) = check(hypothesis, "partial")
        override fun onResult(hypothesis: String?) = check(hypothesis, "text")
        override fun onFinalResult(hypothesis: String?) = check(hypothesis, "text")
        override fun onError(exception: Exception?) {}
        override fun onTimeout() {}
    }

    private fun check(hypothesis: String?, key: String) {
        if (!running || hypothesis.isNullOrBlank()) return
        val heard = try {
            JSONObject(hypothesis).optString(key).lowercase()
        } catch (e: Exception) {
            ""
        }
        if ("friday" in heard) {
            stop()
            main.post { onWake() }
        }
    }

    fun start() {
        if (running || !VoskModel.isReady(appContext)) return
        running = true
        Thread {
            try {
                val m = Model(VoskModel.modelDir(appContext).absolutePath)
                val r = Recognizer(m, 16000f, "[\"hey friday\", \"friday\", \"[unk]\"]")
                val ss = SpeechService(r, 16000f)
                model = m
                recognizer = r
                speechService = ss
                if (running) ss.startListening(listener) else shutdownInternal()
            } catch (e: Exception) {
                running = false
            }
        }.start()
    }

    fun stop() {
        running = false
        shutdownInternal()
    }

    private fun shutdownInternal() {
        try { speechService?.stop() } catch (_: Exception) {}
        try { speechService?.shutdown() } catch (_: Exception) {}
        speechService = null
        recognizer = null
        model = null
    }
}
