package com.friday.assistant.voice

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

/**
 * Downloads and unpacks the offline Vosk speech model (small en-US, ~40 MB)
 * on first use, so the FRIDAY zip itself stays small enough to upload.
 * Used by the wake word ("Hey FRIDAY") and offline listening.
 */
object VoskModel {

    private const val MODEL_URL =
        "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val INNER_DIR = "vosk-model-small-en-us-0.15"

    private val downloading = AtomicBoolean(false)

    fun modelDir(context: Context): File = File(context.filesDir, "vosk/model-en-us")

    fun isReady(context: Context): Boolean =
        File(modelDir(context), "am/final.mdl").exists()

    /** Ensures the model exists; downloads in the background if missing. */
    fun ensure(context: Context, onReady: () -> Unit) {
        val app = context.applicationContext
        if (isReady(app)) {
            onReady()
            return
        }
        if (!downloading.compareAndSet(false, true)) return
        Thread {
            try {
                val base = File(app.filesDir, "vosk")
                val zipFile = File(app.cacheDir, "vosk-model.zip")
                val client = OkHttpClient.Builder()
                    .dns(Ipv4FirstDns)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(120, TimeUnit.SECONDS)
                    .build()
                val downloaded = client.newCall(Request.Builder().url(MODEL_URL).build())
                    .execute().use { resp ->
                        val body = resp.body
                        if (!resp.isSuccessful || body == null) {
                            false
                        } else {
                            body.byteStream().use { input ->
                                FileOutputStream(zipFile).use { out -> input.copyTo(out) }
                            }
                            true
                        }
                    }
                if (downloaded) {
                    base.mkdirs()
                    ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            val outFile = File(base, entry.name)
                            if (entry.isDirectory) {
                                outFile.mkdirs()
                            } else {
                                outFile.parentFile?.mkdirs()
                                FileOutputStream(outFile).use { out -> zis.copyTo(out) }
                            }
                            zis.closeEntry()
                            entry = zis.nextEntry
                        }
                    }
                    zipFile.delete()
                    val inner = File(base, INNER_DIR)
                    val target = modelDir(app)
                    if (inner.exists() && !target.exists()) inner.renameTo(target)
                    if (isReady(app)) onReady()
                }
            } catch (e: Exception) {
                // Offline features simply stay off; the rest of FRIDAY works.
            } finally {
                downloading.set(false)
            }
        }.start()
    }
}
