package com.friday.assistant.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * FRIDAY's natural voice WITHOUT the Live WebSocket: Gemini text-to-speech
 * over plain HTTPS (REST generateContent, model gemini-2.5-flash-preview-tts,
 * 24 kHz PCM out - the same voice family as Live's prebuilt voices).
 *
 * Built because on the user's phone the Live socket never connects (E1),
 * so every spoken line fell back to the phone's robotic TTS. Ordinary HTTPS
 * requests do get through, so the voice now travels this road instead.
 * Any failure (offline, bad key, model issue) reports back through onFail
 * and the caller falls back to phone TTS for that line - never silence.
 */
object GeminiVoice {

    private const val MODEL = "gemini-2.5-flash-preview-tts"
    private const val SAMPLE_RATE = 24000

    private val client = OkHttpClient.Builder()
        .dns(Ipv4FirstDns)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private class Item(
        val text: String,
        val apiKey: String,
        val voiceName: String,
        val onFail: (() -> Unit)?,
        val latch: CountDownLatch?,
        val ok: AtomicBoolean,
        val gen: Int
    )

    private val queue = LinkedBlockingQueue<Item>()
    private val executor = Executors.newSingleThreadExecutor()

    @Volatile
    private var workerStarted = false

    @Volatile
    var playing = false
        private set

    @Volatile
    private var generation = 0

    private var track: AudioTrack? = null

    fun speak(text: String, apiKey: String, voiceName: String, onFail: () -> Unit) {
        if (text.isBlank()) return
        ensureWorker()
        queue.offer(Item(text, apiKey, voiceName, onFail, null, AtomicBoolean(false), generation))
    }

    /** Interrupt current speech and drop anything queued. */
    fun stop() {
        generation++
        queue.clear()
        try {
            track?.pause()
            track?.flush()
        } catch (_: Exception) {
        }
    }

    private fun ensureWorker() {
        if (workerStarted) return
        synchronized(this) {
            if (workerStarted) return
            workerStarted = true
            executor.execute {
                while (true) {
                    val item = queue.take()
                    process(item)
                }
            }
        }
    }

    private fun process(item: Item) {
        playing = true
        try {
            val pcm = fetch(item.text, item.apiKey, item.voiceName)
            if (pcm == null || pcm.isEmpty()) {
                if (item.gen == generation) item.onFail?.invoke()
            } else {
                play(pcm, item.gen)
                item.ok.set(true)
            }
        } catch (e: Exception) {
            if (item.gen == generation) item.onFail?.invoke()
        } finally {
            playing = false
            item.latch?.countDown()
        }
    }

    private fun fetch(text: String, apiKey: String, voiceName: String): ByteArray? {
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", text))
                    )
                )
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig",
                        JSONObject().put(
                            "voiceConfig",
                            JSONObject().put(
                                "prebuiltVoiceConfig",
                                JSONObject().put("voiceName", voiceName)
                            )
                        )
                    )
            )
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        return try {
            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val raw = resp.body?.string().orEmpty()
                val parts = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")
                    ?: return null
                var data: String? = null
                for (i in 0 until parts.length()) {
                    val d = parts.optJSONObject(i)?.optJSONObject("inlineData")
                        ?.optString("data")
                    if (!d.isNullOrBlank()) {
                        data = d
                        break
                    }
                }
                data?.let { Base64.decode(it, Base64.DEFAULT) }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun play(pcm: ByteArray, gen: Int) {
        val t = obtainTrack()
        try {
            t.play()
        } catch (_: Exception) {
        }
        var offset = 0
        while (offset < pcm.size && gen == generation) {
            val n = try {
                t.write(pcm, offset, minOf(8192, pcm.size - offset))
            } catch (e: Exception) {
                break
            }
            if (n <= 0) break
            offset += n
        }
        // Wait until the written audio has actually been heard.
        val totalFrames = pcm.size / 2
        val deadline = System.currentTimeMillis() +
            (totalFrames * 1000L / SAMPLE_RATE) + 4000
        while (gen == generation &&
            t.playbackHeadPosition < totalFrames &&
            System.currentTimeMillis() < deadline
        ) {
            try {
                Thread.sleep(60)
            } catch (e: InterruptedException) {
                break
            }
        }
    }

    private fun obtainTrack(): AudioTrack {
        track?.let {
            if (it.state == AudioTrack.STATE_INITIALIZED) return it
        }
        val minBuffer = AudioTrack.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val created = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuffer, SAMPLE_RATE))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = created
        return created
    }
}
