package com.friday.assistant.voice

import android.content.Context
import android.media.AudioAttributes
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.friday.assistant.FridayApp
import com.friday.assistant.util.ChatLine
import com.friday.assistant.util.RuntimeState
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/**
 * FRIDAY's own voice — TextToSpeech for announcements (callers, notifications)
 * and for the whole conversation in on-device mode.
 *
 * V1.02 rewrite, because V1.0/V1.01 could stay completely silent:
 *  - lines requested before the engine is ready are QUEUED, never dropped;
 *  - if the default engine fails to start, Google's TTS engine is tried
 *    explicitly; if that also fails, the reason is posted to the transcript
 *    with the exact phone setting to fix — silence is never unexplained;
 *  - language follows the text: Devanagari lines are read in the user's
 *    chosen Indian language (Hindi or Marathi), other lines in Indian
 *    English, with a checked fallback chain when a voice pack is missing;
 *  - audio goes to the MEDIA stream (USAGE_MEDIA) so it is reliably audible;
 *  - a female voice is preferred when the engine exposes one, with a soft
 *    pitch as a fallback.
 */
class Speaker(context: Context) {
    private var tts: TextToSpeech? = null
    @Volatile var ready = false
        private set
    private val pending = ArrayDeque<String>()
    private var currentLangTag: String? = null
    @Volatile private var ttsSpeaking = false

    /** True while FRIDAY herself is talking - via phone TTS or via the
     *  Gemini voice. The hands-free listener waits for this so she never
     *  hears her own voice. */
    val isSpeaking: Boolean get() = ttsSpeaking || GeminiVoice.playing
    private val waiters = mutableMapOf<String, () -> Unit>()
    private var announcedReady = false

    init {
        val appContext = context.applicationContext
        createEngine(appContext, null) { ok ->
            if (!ok) {
                try { tts?.shutdown() } catch (_: Exception) {}
                createEngine(appContext, GOOGLE_TTS_ENGINE) { ok2 ->
                    if (!ok2) postTtsWarning()
                }
            }
        }
    }

    private fun createEngine(appContext: Context, engine: String?, done: (Boolean) -> Unit) {
        val listener = TextToSpeech.OnInitListener { status ->
            if (status == TextToSpeech.SUCCESS) {
                onEngineReady()
                done(true)
            } else {
                done(false)
            }
        }
        tts = if (engine == null) TextToSpeech(appContext, listener)
        else TextToSpeech(appContext, listener, engine)
    }

    private fun onEngineReady() {
        val engine = tts ?: return
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        applyLanguageFor(engine, "नमस्ते")
        preferFemaleVoice(engine)
        engine.setPitch(1.05f)
        engine.setSpeechRate(0.98f)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                ttsSpeaking = true
            }
            override fun onDone(utteranceId: String?) {
                ttsSpeaking = false
                utteranceId?.let { id ->
                    synchronized(waiters) { waiters.remove(id) }?.invoke()
                }
            }
            @Deprecated("legacy")
            override fun onError(utteranceId: String?) {
                ttsSpeaking = false
                utteranceId?.let { id ->
                    synchronized(waiters) { waiters.remove(id) }?.invoke()
                }
            }
        })
        ready = true
        if (!announcedReady) {
            announcedReady = true
            RuntimeState.addLine(
                ChatLine.Role.SYSTEM,
                "🔊 Awaaz taiyaar hai — FRIDAY ab bolkar jawab degi."
            )
        }
        // Flush whatever was asked for while the engine was waking up.
        while (true) {
            val next = synchronized(pending) {
                if (pending.isEmpty()) null else pending.removeFirst()
            } ?: break
            speakNow(next, flush = false)
        }
    }

    private fun postTtsWarning() {
        RuntimeState.addLine(
            ChatLine.Role.SYSTEM,
            "⚠ Phone ki awaaz (TTS) chalu nahi ho payi — isiliye FRIDAY bol nahi " +
                "pa rahi. Phone Settings → 'Text-to-speech output' mein Google " +
                "engine chuno, Hindi voice download karo, phir FRIDAY band karke " +
                "dobara Start karo."
        )
    }

    /** The locale a line should be read in: Devanagari script goes to the
     *  user's chosen Indian language; everything else to Indian English. */
    private fun desiredLocale(text: String): Locale {
        val devanagari = text.any { it in 'ऀ'..'ॿ' }
        return if (devanagari) FridayApp.instance.settings.devanagariLocale()
        else Locale("en", "IN")
    }

    private fun applyLanguageFor(engine: TextToSpeech, text: String) {
        val want = desiredLocale(text)
        val tag = want.toLanguageTag()
        if (tag == currentLangTag) return
        fun usable(result: Int) =
            result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED
        if (usable(engine.setLanguage(want))) {
            currentLangTag = tag
            return
        }
        // Fallback chain: Hindi → Indian English → device default.
        for (fallback in listOf(Locale("hi", "IN"), Locale("en", "IN"), Locale.getDefault())) {
            if (usable(engine.setLanguage(fallback))) {
                currentLangTag = fallback.toLanguageTag()
                return
            }
        }
        currentLangTag = tag // nothing better available; engine does its best
    }

    /** Pick an explicitly female voice when the engine names one. Most
     *  engines (including Google's) do not expose gender in voice names, so
     *  this is best-effort — the gentle pitch in onEngineReady is the
     *  reliable part of the "female primary voice" behaviour. */
    private fun preferFemaleVoice(engine: TextToSpeech) {
        try {
            val lang = currentLangTag?.substringBefore("-")
            val female = engine.voices?.firstOrNull { voice ->
                voice.name.contains("female", ignoreCase = true) &&
                    (lang == null || voice.locale.language == lang)
            } ?: engine.voices?.firstOrNull {
                it.name.contains("female", ignoreCase = true)
            }
            if (female != null) engine.voice = female
        } catch (_: Exception) {
            // Voice enumeration is not available on every engine — ignore.
        }
    }

    /** Speak a line. Default road (V2.1): Gemini's own voice over HTTPS -
     *  natural, and the voice-picker names (Aoede, Kore...) become real.
     *  Phone TTS is the fallback: when there is no key, while a Live session
     *  is active (its audio owns the speaker), or when the Gemini voice
     *  request itself fails. */
    fun speak(text: String, flush: Boolean = true) {
        if (text.isBlank()) return
        if (useGeminiVoice()) {
            val s = FridayApp.instance.settings
            GeminiVoice.speak(text, s.geminiApiKey, s.voiceName) {
                speakViaTts(text, flush)
            }
            return
        }
        speakViaTts(text, flush)
    }

    private fun useGeminiVoice(): Boolean {
        val s = FridayApp.instance.settings
        return s.geminiVoiceEnabled && s.hasApiKey && !RuntimeState.liveMode.value
    }

    private fun speakViaTts(text: String, flush: Boolean) {
        if (text.isBlank()) return
        if (!ready) {
            synchronized(pending) {
                pending.addLast(text)
                while (pending.size > MAX_PENDING) pending.removeFirst()
            }
            return
        }
        speakNow(text, flush)
    }

    private fun speakNow(text: String, flush: Boolean) {
        val engine = tts ?: return
        applyLanguageFor(engine, text)
        engine.speak(
            text,
            if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
            null,
            UUID.randomUUID().toString()
        )
    }

    suspend fun speakAndWait(text: String) = suspendCancellableCoroutine<Unit> { cont ->
        val engine = tts
        if (!ready || engine == null) {
            cont.resume(Unit)
            return@suspendCancellableCoroutine
        }
        applyLanguageFor(engine, text)
        val id = UUID.randomUUID().toString()
        synchronized(waiters) {
            waiters[id] = { if (cont.isActive) cont.resume(Unit) }
        }
        cont.invokeOnCancellation {
            synchronized(waiters) { waiters.remove(id) }
        }
        val params = Bundle()
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, id)
    }

    fun stop() {
        GeminiVoice.stop()
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
        synchronized(pending) { pending.clear() }
    }

    companion object {
        private const val GOOGLE_TTS_ENGINE = "com.google.android.tts"
        private const val MAX_PENDING = 6
    }
}
