package com.friday.assistant.screen

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Base64
import android.util.DisplayMetrics
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.friday.assistant.FridayApp
import com.friday.assistant.R
import com.friday.assistant.ai.GeminiText
import com.friday.assistant.service.AssistantService
import com.friday.assistant.util.ChatLine
import com.friday.assistant.util.RuntimeState
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * V2.0 screen vision, step 2: a media-projection foreground service that
 * captures exactly ONE frame of the screen, asks Gemini (REST vision) what
 * is on it, speaks the answer, and stops. Nothing is recorded or stored.
 */
class ScreenVisionService : Service() {

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val captured = AtomicBoolean(false)
    private lateinit var worker: HandlerThread
    private lateinit var workerHandler: Handler
    private val mainHandler = Handler(android.os.Looper.getMainLooper())

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            cleanup()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (code == 0 || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val notification = NotificationCompat.Builder(this, FridayApp.CHANNEL_ASSISTANT)
            .setSmallIcon(R.drawable.ic_stat_friday)
            .setContentTitle("FRIDAY screen dekh rahi hai")
            .setContentText("Sirf ek photo lekar jawab degi")
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(
                this, NOTIF_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            ServiceCompat.startForeground(this, NOTIF_ID, notification, 0)
        }

        worker = HandlerThread("friday-vision").also { it.start() }
        workerHandler = Handler(worker.looper)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = try {
            mpm.getMediaProjection(code, data)
        } catch (e: Exception) {
            fail("Screen capture shuru nahi ho paya.")
            return START_NOT_STICKY
        }
        projection = proj
        proj.registerCallback(projectionCallback, mainHandler)

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager)
            .defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        this.reader = reader
        reader.setOnImageAvailableListener({ r ->
            if (!captured.compareAndSet(false, true)) return@setOnImageAvailableListener
            val image = try {
                r.acquireLatestImage()
            } catch (e: Exception) {
                null
            }
            if (image == null) {
                fail("Screen ki photo nahi mil payi.")
                return@setOnImageAvailableListener
            }
            val bitmap = imageToBitmap(image, w, h)
            image.close()
            cleanupCapture()
            if (bitmap == null) {
                fail("Screen ki photo ban nahi payi.")
                return@setOnImageAvailableListener
            }
            answerFromBitmap(bitmap)
        }, workerHandler)
        display = proj.createVirtualDisplay(
            "friday-vision", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, workerHandler
        )
        mainHandler.postDelayed({
            if (!captured.get()) fail("Screen ki photo time par nahi aayi.")
        }, 12000)
        return START_NOT_STICKY
    }

    private fun imageToBitmap(image: android.media.Image, w: Int, h: Int): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * w
            val padded = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(padded, 0, 0, w, h)
            val maxDim = maxOf(cropped.width, cropped.height)
            if (maxDim > 1024) {
                val scale = 1024f / maxDim
                Bitmap.createScaledBitmap(
                    cropped,
                    (cropped.width * scale).toInt(),
                    (cropped.height * scale).toInt(),
                    true
                )
            } else {
                cropped
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun answerFromBitmap(bitmap: Bitmap) {
        val key = FridayApp.instance.settings.geminiApiKey
        if (key.isBlank()) {
            fail("Screen samajhne ke liye Gemini key chahiye - Settings mein daal dijiye.")
            return
        }
        Thread {
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, out)
            val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            val answer = GeminiText.ask(
                key,
                "Is phone screenshot mein kya dikhai de raha hai? User ko Hinglish mein " +
                    "short mein batao (2-3 chhoti lines) - kaunsi app hai, kya likha hai, " +
                    "koi zaroori cheez ho to woh bhi.",
                b64
            )
            RuntimeState.addLine(ChatLine.Role.FRIDAY, answer)
            AssistantService.announceText(applicationContext, answer)
            stopSelf()
        }.start()
    }

    private fun fail(message: String) {
        RuntimeState.addLine(ChatLine.Role.SYSTEM, message)
        cleanup()
        stopSelf()
    }

    private fun cleanupCapture() {
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { reader?.close() } catch (_: Exception) {}
        reader = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
    }

    private fun cleanup() {
        cleanupCapture()
        if (::worker.isInitialized) worker.quitSafely()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    companion object {
        private const val NOTIF_ID = 77
        private const val EXTRA_CODE = "result_code"
        private const val EXTRA_DATA = "result_data"

        fun start(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, ScreenVisionService::class.java).apply {
                putExtra(EXTRA_CODE, resultCode)
                putExtra(EXTRA_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
