package com.friday.assistant.actions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.provider.AlarmClock
import android.provider.CallLog
import androidx.core.content.ContextCompat
import com.friday.assistant.voice.Ipv4FirstDns
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * V2.0 information + utility actions (all FRIDAY's own code):
 * alarm, timer, weather (Open-Meteo, no key), stock prices (Yahoo Finance),
 * currency rates (Frankfurter), and the call log. The network functions
 * BLOCK - ActionRouter callers run them off the main thread.
 */
object InfoTools {

    private val client = OkHttpClient.Builder()
        .dns(Ipv4FirstDns)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private fun get(url: String, ua: Boolean = false): String? {
        val b = Request.Builder().url(url)
        if (ua) b.header("User-Agent", "Mozilla/5.0 (Android)")
        return try {
            client.newCall(b.build()).execute().use { r ->
                if (r.isSuccessful) r.body?.string() else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Alarm & timer (system clock intents) ----------

    fun setAlarm(context: Context, hour: Int, minute: Int, period: String, label: String): String {
        val h = when {
            hour in 13..23 -> hour
            else -> {
                var x = hour % 12
                if (period.equals("PM", true) || period == "shaam" || period == "raat") x += 12
                if (x == 24) 0 else x
            }
        }
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, h)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            if (label.isNotBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            val shown = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(
                java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, h)
                    set(java.util.Calendar.MINUTE, minute)
                }.time
            )
            "Alarm lag gaya hai - $shown par bajega."
        } catch (e: Exception) {
            "Alarm nahi lag paya - phone mein Clock app nahi mila."
        }
    }

    fun setTimer(context: Context, seconds: Int): String {
        if (seconds <= 0) return "Timer ke liye samay samajh nahi aaya - jaise bolo: 10 minute ka timer."
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            val human = when {
                seconds % 3600 == 0 -> "${seconds / 3600} ghante"
                seconds % 60 == 0 -> "${seconds / 60} minute"
                else -> "$seconds second"
            }
            "Timer lag gaya hai - $human ka."
        } catch (e: Exception) {
            "Timer nahi lag paya - phone mein Clock app nahi mila."
        }
    }

    // ---------- Weather (Open-Meteo, keyless) ----------

    private val weatherDesc = mapOf(
        0 to "aasman bilkul saaf", 1 to "halke badal", 2 to "badal chhaye hue",
        3 to "ghane badal", 45 to "dhundh", 48 to "dhundh",
        51 to "halki boonda-baandi", 53 to "boonda-baandi", 55 to "boonda-baandi",
        56 to "halki baarish", 57 to "baarish", 61 to "halki baarish",
        63 to "baarish", 65 to "tez baarish", 66 to "tez baarish", 67 to "tez baarish",
        71 to "halki barf", 73 to "barf", 75 to "tez barf",
        80 to "halki fuhaar", 81 to "fuhaar", 82 to "tez fuhaar",
        95 to "garaj ke saath baarish", 96 to "bijli-baarish", 99 to "bijli-baarish"
    )

    fun weather(context: Context, cityRaw: String): String {
        var lat: Double? = null
        var lon: Double? = null
        var place = cityRaw.trim()
        if (place.isNotBlank()) {
            val enc = URLEncoder.encode(place, "UTF-8")
            val raw = get("https://geocoding-api.open-meteo.com/v1/search?name=$enc&count=1&language=en")
            val first = raw?.let { JSONObject(it) }?.optJSONArray("results")?.optJSONObject(0)
            if (first != null) {
                lat = first.optDouble("latitude")
                lon = first.optDouble("longitude")
                place = first.optString("name")
            }
        } else {
            // No city named - try the phone's last known location.
            try {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val loc = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
                    .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }
                    .maxByOrNull { it.time }
                if (loc != null) {
                    lat = loc.latitude
                    lon = loc.longitude
                    place = "aapke area"
                }
            } catch (e: Exception) { /* fall through to the ask */ }
        }
        if (lat == null || lon == null) {
            return "Mausam ke liye sheher ka naam boliye - jaise: Pune ka mausam batao."
        }
        val raw = get(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code,wind_speed_10m" +
                "&daily=temperature_2m_max,temperature_2m_min&timezone=auto"
        ) ?: return "Mausam ki jaankari abhi nahi mil payi - network check karo."
        val root = JSONObject(raw)
        val cur = root.optJSONObject("current") ?: return "Mausam samajh nahi aaya."
        val daily = root.optJSONObject("daily")
        val temp = cur.optDouble("temperature_2m")
        val wind = cur.optDouble("wind_speed_10m")
        val desc = weatherDesc[cur.optInt("weather_code")] ?: "mausam mila-jula"
        val max = daily?.optJSONArray("temperature_2m_max")?.optDouble(0)
        val min = daily?.optJSONArray("temperature_2m_min")?.optDouble(0)
        return buildString {
            append("$place mein abhi $desc hai, taapman ${temp.toInt()} degree hai.")
            if (max != null && min != null) {
                append(" Aaj zyada se zyada ${max.toInt()} aur kam se kam ${min.toInt()} degree rahega.")
            }
            append(" Hawa ${wind.toInt()} kilometre per ghanta chal rahi hai.")
        }
    }

    // ---------- Stocks (Yahoo Finance chart API, keyless) ----------

    private val stockAliases = mapOf(
        "reliance" to "RELIANCE.NS", "tcs" to "TCS.NS", "infosys" to "INFY.NS",
        "sbi" to "SBIN.NS", "hdfc" to "HDFCBANK.NS", "icici" to "ICICIBANK.NS",
        "tata motors" to "TATAMOTORS.NS", "tatamotors" to "TATAMOTORS.NS",
        "itc" to "ITC.NS", "wipro" to "WIPRO.NS", "zomato" to "ZOMATO.NS",
        "paytm" to "PAYTM.NS", "nifty" to "^NSEI", "sensex" to "^BSESN",
        "bitcoin" to "BTC-USD", "gold" to "GC=F", "silver" to "SI=F",
        "apple" to "AAPL", "tesla" to "TSLA", "nvidia" to "NVDA",
        "microsoft" to "MSFT", "google" to "GOOGL", "amazon" to "AMZN"
    )

    fun stock(queryRaw: String): String {
        val q = queryRaw.trim().lowercase()
        if (q.isBlank()) return "Kaunse share ka bhaav chahiye? Naam boliye - jaise Reliance, TCS, Nifty."
        val symbol = stockAliases[q]
            ?: if (q.any { it in ".^-=" }) q.uppercase()
            else q.uppercase().replace(" ", "") + ".NS"
        val enc = URLEncoder.encode(symbol, "UTF-8")
        val raw = get("https://query1.finance.yahoo.com/v8/finance/chart/$enc?interval=1d&range=5d", ua = true)
            ?: return "$queryRaw ka bhaav abhi nahi mil paya - naam dobara boliye ya network check karo."
        val meta = JSONObject(raw).optJSONObject("chart")?.optJSONArray("result")
            ?.optJSONObject(0)?.optJSONObject("meta")
            ?: return "$queryRaw ke liye data nahi mila - shayad naam alag hai."
        val price = meta.optDouble("regularMarketPrice")
        val prev = meta.optDouble("chartPreviousClose")
        val cur = meta.optString("currency", "")
        val sym = if (cur == "INR") "₹" else if (cur == "USD") "$" else "$cur "
        val change = if (prev > 0) ((price - prev) / prev) * 100 else 0.0
        val dir = when {
            change > 0.05 -> "upar"
            change < -0.05 -> "neeche"
            else -> "lagbhag sthir"
        }
        return String.format(
            Locale.ENGLISH,
            "%s ka bhaav abhi %s%.2f hai - aaj %.1f%% %s hai.",
            queryRaw.replaceFirstChar { it.uppercase() }, sym, price, kotlin.math.abs(change), dir
        )
    }

    // ---------- Currency (Frankfurter, keyless) ----------

    fun currency(fromRaw: String, toRaw: String): String {
        val from = fromRaw.trim().uppercase().ifBlank { "USD" }
        val to = toRaw.trim().uppercase().ifBlank { "INR" }
        val raw = get("https://api.frankfurter.app/latest?from=$from&to=$to")
            ?: return "Currency rate abhi nahi mil paya - network check karo."
        val rate = JSONObject(raw).optJSONObject("rates")?.optDouble(to)
            ?: return "$from se $to ka rate nahi mila."
        return String.format(
            Locale.ENGLISH,
            "Aaj 1 %s barabar %.2f %s hai.",
            from, rate, to
        )
    }

    // ---------- Call log ----------

    fun callLog(context: Context): String {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALL_LOG) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return "Call log padhne ki permission chahiye - app ki System Setup mein de dijiye."
        }
        val cursor = try {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                    CallLog.Calls.TYPE, CallLog.Calls.DATE
                ),
                null, null, CallLog.Calls.DATE + " DESC"
            )
        } catch (e: Exception) {
            null
        } ?: return "Call log khul nahi paya."
        var missed = 0
        val latest = mutableListOf<String>()
        val timeFmt = SimpleDateFormat("h:mm a", Locale.ENGLISH)
        cursor.use {
            var i = 0
            while (it.moveToNext() && i < 12) {
                i++
                val number = it.getString(0).orEmpty()
                val name = it.getString(1)?.takeIf { n -> n.isNotBlank() } ?: number
                val type = it.getInt(2)
                val whenMs = it.getLong(3)
                if (type == CallLog.Calls.MISSED_TYPE) missed++
                if (latest.size < 3) {
                    val kind = when (type) {
                        CallLog.Calls.INCOMING_TYPE -> "aaya tha"
                        CallLog.Calls.OUTGOING_TYPE -> "aapne kiya tha"
                        CallLog.Calls.MISSED_TYPE -> "miss ho gaya tha"
                        CallLog.Calls.REJECTED_TYPE -> "aapne kaata tha"
                        else -> "call tha"
                    }
                    latest.add("$name ka call ${timeFmt.format(Date(whenMs))} par $kind")
                }
            }
        }
        if (latest.isEmpty()) return "Call log khaali hai - koi recent call nahi mila."
        return buildString {
            append("Pichhle kuch calls: ")
            append(latest.joinToString("; "))
            append(".")
            if (missed > 0) append(" Inmein $missed missed call hain.")
        }
    }
}
