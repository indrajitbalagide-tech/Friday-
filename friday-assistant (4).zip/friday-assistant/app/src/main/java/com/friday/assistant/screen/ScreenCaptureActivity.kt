package com.friday.assistant.screen

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import com.friday.assistant.util.ChatLine
import com.friday.assistant.util.RuntimeState

/**
 * V2.0 screen vision, step 1: asks the user for one-time screen-capture
 * consent (Android requires the system dialog), then hands the result to
 * ScreenVisionService, which grabs exactly one frame and answers about it.
 */
class ScreenCaptureActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQUEST_CODE)
    }

    @Deprecated("Platform callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            ScreenVisionService.start(this, resultCode, data)
        } else {
            RuntimeState.addLine(
                ChatLine.Role.SYSTEM,
                "Screen capture cancel ho gaya - FRIDAY ne kuch nahi dekha."
            )
        }
        finish()
    }

    private companion object {
        const val REQUEST_CODE = 7001
    }
}
