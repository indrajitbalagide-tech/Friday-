package com.friday.assistant.ai

import com.friday.assistant.voice.Ipv4FirstDns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * REST text brain - gemini-3.5-flash-lite, the same model family IRIS-MX
 * uses as its brain. FRIDAY uses it whenever the Live voice session is not
 * connected: smart spoken answers in on-device mode (instead of fixed
 * canned replies), translation, and screen-vision answers.
 *
 * All calls BLOCK - always invoke from a background thread.
 */
object GeminiText {

    private const val MODEL = "gemini-3.5-flash-lite"

    private val client = OkHttpClient.Builder()
        .dns(Ipv4FirstDns)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val chatHistory = mutableListOf<Pair<String, String>>()

    private const val PERSONA =
        "You are FRIDAY, a warm, loving female friend-companion assistant on the user's " +
            "Android phone. Answer briefly (1-3 short spoken sentences), in the user's own " +
            "language mix - Hindi, Hinglish (Roman Hindi), Marathi or English - mirroring how " +
            "they speak. No markdown, no lists, no URLs. Be affectionate and natural, " +
            "never robotic."

    /** One-shot question with an optional JPEG image (screen vision). */
    fun ask(apiKey: String, prompt: String, imageJpegBase64: String? = null): String {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (!imageJpegBase64.isNullOrBlank()) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", "image/jpeg").put("data", imageJpegBase64)
                )
            )
        }
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", parts))
        return generate(apiKey, contents) ?: "Abhi jawab nahi mil paya - network ya key check karo."
    }

    /** Conversational reply with short memory, for on-device fallback mode. */
    fun chat(apiKey: String, userText: String): String {
        val contents = JSONArray()
        synchronized(chatHistory) {
            for ((role, text) in chatHistory) {
                contents.put(
                    JSONObject().put("role", role)
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            }
        }
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userText)))
        )
        val reply = generate(apiKey, contents)
            ?: return "Abhi mera dimaag (Gemini) se sampark nahi ho paya. Ek baar phir boliye?"
        synchronized(chatHistory) {
            chatHistory.add("user" to userText)
            chatHistory.add("model" to reply)
            while (chatHistory.size > 10) chatHistory.removeAt(0)
        }
        return reply
    }

    fun resetChat() = synchronized(chatHistory) { chatHistory.clear() }

    private fun generate(apiKey: String, contents: JSONArray): String? {
        if (apiKey.isBlank()) return null
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", PERSONA))
                )
            )
            .put("contents", contents)
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        return try {
            client.newCall(request).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return null
                val root = JSONObject(raw)
                val parts = root.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")
                    ?: return null
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    parts.optJSONObject(i)?.optString("text")?.let { sb.append(it) }
                }
                sb.toString().trim().ifBlank { null }
            }
        } catch (e: Exception) {
            null
        }
    }
}
